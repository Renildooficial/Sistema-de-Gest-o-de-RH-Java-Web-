package com.sigrh.util;

import java.sql.Connection;
import java.sql.DriverManager;

public class TestConnection {
    
    public static void main(String[] args) {
        String url = "jdbc:mysql://localhost:3306/sigrh?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=Africa/Maputo";
        String user = "root";
        String password = "renas";
        
        System.out.println("Testando conexão...");
        System.out.println("URL: " + url);
        System.out.println("Usuário: " + user);
        System.out.println("Senha: " + password);
        
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection(url, user, password);
            System.out.println("✅ CONEXÃO BEM-SUCEDIDA!");
            System.out.println("   Database: " + conn.getCatalog());
            conn.close();
        } catch (Exception e) {
            System.out.println("❌ ERRO: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
package com.sigrh.test;

import com.sigrh.util.PasswordUtil;

public class GerarHash {
    public static void main(String[] args) {
        String senha = "admin123";
        String hash = PasswordUtil.hashPassword(senha);
        System.out.println("========================================");
        System.out.println("🔑 SENHA: " + senha);
        System.out.println("🔐 HASH: " + hash);
        System.out.println("========================================");
        System.out.println("UPDATE usuario SET senha = '" + hash + "' WHERE usuario = 'admin';");
        System.out.println("========================================");
    }
}
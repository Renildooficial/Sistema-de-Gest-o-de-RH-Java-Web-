package com.sigrh.model;

import java.sql.Date;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

public class Ferias {
    
    private Integer id;
    private Integer idFuncionario;
    private Integer anoReferencia;
    private Date dataInicio;
    private Date dataFim;
    private Integer diasUteis;
    private Integer diasCalendario;
    private String status;
    private Timestamp dataSolicitacao;
    private Timestamp dataAprovacao;
    private Integer aprovadoPor;
    private Timestamp dataCheckout;
    private Timestamp dataCheckin;
    private String observacao;
    private String motivoRejeicao;
    
    private Integer idPlanoFerias;
    private String planoReferencia;
    private Boolean alertaEnviado = false;
    private String alertaTipo; // CONFLITO, FORA_PLANO, DENTRO_PLANO
    private List<SolicitacaoDia> solicitacoesDias = new ArrayList<>();
    
    // Campos para interrupção
    private Integer diasInterrompidos;
    private String motivoInterrupcao;
    private Timestamp dataInterrupcao;
    private Integer diasCompensados;
    private String statusCompensacao;
    
    // Campos para relacionamento
    private Funcionario funcionario;
    
    // ============================================================
    // CONSTRUTORES
    // ============================================================
    
    public Ferias() {
    }
    
    public Ferias(Integer id, Integer idFuncionario, Date dataInicio, Date dataFim) {
        this.id = id;
        this.idFuncionario = idFuncionario;
        this.dataInicio = dataInicio;
        this.dataFim = dataFim;
    }
    
    // ============================================================
    // GETTERS E SETTERS
    // ============================================================
    
    
    
    public Integer getId() {
        return id;
    }
    
    public void setId(Integer id) {
        this.id = id;
    }
    
    public Integer getIdFuncionario() {
        return idFuncionario;
    }
    
    public void setIdFuncionario(Integer idFuncionario) {
        this.idFuncionario = idFuncionario;
    }
    
    public Integer getAnoReferencia() {
        return anoReferencia;
    }
    
    public void setAnoReferencia(Integer anoReferencia) {
        this.anoReferencia = anoReferencia;
    }
    
    public Date getDataInicio() {
        return dataInicio;
    }
    
    public void setDataInicio(Date dataInicio) {
        this.dataInicio = dataInicio;
    }
    
    public Date getDataFim() {
        return dataFim;
    }
    
    public void setDataFim(Date dataFim) {
        this.dataFim = dataFim;
    }
    
    public Integer getDiasUteis() {
        return diasUteis;
    }
    
    public void setDiasUteis(Integer diasUteis) {
        this.diasUteis = diasUteis;
    }
    
    public Integer getDiasCalendario() {
        return diasCalendario;
    }
    
    public void setDiasCalendario(Integer diasCalendario) {
        this.diasCalendario = diasCalendario;
    }
    
    public String getStatus() {
        return status;
    }
    
    public void setStatus(String status) {
        this.status = status;
    }
    
    public Timestamp getDataSolicitacao() {
        return dataSolicitacao;
    }
    
    public void setDataSolicitacao(Timestamp dataSolicitacao) {
        this.dataSolicitacao = dataSolicitacao;
    }
    
    public Timestamp getDataAprovacao() {
        return dataAprovacao;
    }
    
    public void setDataAprovacao(Timestamp dataAprovacao) {
        this.dataAprovacao = dataAprovacao;
    }
    
    public Integer getAprovadoPor() {
        return aprovadoPor;
    }
    
    public void setAprovadoPor(Integer aprovadoPor) {
        this.aprovadoPor = aprovadoPor;
    }
    
    public Timestamp getDataCheckout() {
        return dataCheckout;
    }
    
    public void setDataCheckout(Timestamp dataCheckout) {
        this.dataCheckout = dataCheckout;
    }
    
    public Timestamp getDataCheckin() {
        return dataCheckin;
    }
    
    public void setDataCheckin(Timestamp dataCheckin) {
        this.dataCheckin = dataCheckin;
    }
    
    public String getObservacao() {
        return observacao;
    }
    
    public void setObservacao(String observacao) {
        this.observacao = observacao;
    }
    
    public String getMotivoRejeicao() {
        return motivoRejeicao;
    }
    
    public void setMotivoRejeicao(String motivoRejeicao) {
        this.motivoRejeicao = motivoRejeicao;
    }
    
    public Integer getDiasInterrompidos() {
        return diasInterrompidos;
    }
    
    public void setDiasInterrompidos(Integer diasInterrompidos) {
        this.diasInterrompidos = diasInterrompidos;
    }
    
    public String getMotivoInterrupcao() {
        return motivoInterrupcao;
    }
    
    public void setMotivoInterrupcao(String motivoInterrupcao) {
        this.motivoInterrupcao = motivoInterrupcao;
    }
    
    public Timestamp getDataInterrupcao() {
        return dataInterrupcao;
    }
    
    public void setDataInterrupcao(Timestamp dataInterrupcao) {
        this.dataInterrupcao = dataInterrupcao;
    }
    
    public Integer getDiasCompensados() {
        return diasCompensados;
    }
    
    public void setDiasCompensados(Integer diasCompensados) {
        this.diasCompensados = diasCompensados;
    }
    
    public String getStatusCompensacao() {
        return statusCompensacao;
    }
    
    public void setStatusCompensacao(String statusCompensacao) {
        this.statusCompensacao = statusCompensacao;
    }
    
    public Funcionario getFuncionario() {
        return funcionario;
    }
    
    public void setFuncionario(Funcionario funcionario) {
        this.funcionario = funcionario;
    }
}
package com.sigrh.util;

import com.sigrh.service.ConfiguracaoService;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.math.BigDecimal;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class ConfiguracaoUtil {
    
    private static final Logger logger = LogManager.getLogger(ConfiguracaoUtil.class);
    private static ConfiguracaoService configuracaoService;
    
    static {
        configuracaoService = new ConfiguracaoService();
    }
    
    // ============================================================
    // MÉTODOS PARA ACESSAR CONFIGURAÇÕES (SEM LANÇAR EXCEPTION)
    // ============================================================
    
    /**
     * Busca uma configuração como String
     */
    public static String getString(String chave, String defaultValue) {
        try {
            String valor = configuracaoService.getValor(chave);
            return valor != null && !valor.isEmpty() ? valor : defaultValue;
        } catch (Exception e) {
            logger.error("Erro ao buscar configuração: {}", chave, e);
            return defaultValue;
        }
    }
    
    /**
     * Busca uma configuração como int
     */
    public static int getInt(String chave, int defaultValue) {
        try {
            String valor = configuracaoService.getValor(chave);
            if (valor != null && !valor.isEmpty()) {
                try {
                    return Integer.parseInt(valor);
                } catch (NumberFormatException e) {
                    logger.warn("Valor não é um número válido para {}: {}", chave, valor);
                    return defaultValue;
                }
            }
            return defaultValue;
        } catch (Exception e) {
            logger.error("Erro ao buscar configuração int: {}", chave, e);
            return defaultValue;
        }
    }
    
    /**
     * Busca uma configuração como boolean
     */
    public static boolean getBoolean(String chave, boolean defaultValue) {
        try {
            String valor = configuracaoService.getValor(chave);
            if (valor != null && !valor.isEmpty()) {
                return "true".equalsIgnoreCase(valor) || 
                       "1".equals(valor) || 
                       "on".equalsIgnoreCase(valor) || 
                       "sim".equalsIgnoreCase(valor) ||
                       "yes".equalsIgnoreCase(valor);
            }
            return defaultValue;
        } catch (Exception e) {
            logger.error("Erro ao buscar configuração boolean: {}", chave, e);
            return defaultValue;
        }
    }
    
    /**
     * Busca uma configuração como double
     */
    public static double getDouble(String chave, double defaultValue) {
        try {
            String valor = configuracaoService.getValor(chave);
            if (valor != null && !valor.isEmpty()) {
                try {
                    return Double.parseDouble(valor.replace(",", "."));
                } catch (NumberFormatException e) {
                    logger.warn("Valor não é um número válido para {}: {}", chave, valor);
                    return defaultValue;
                }
            }
            return defaultValue;
        } catch (Exception e) {
            logger.error("Erro ao buscar configuração double: {}", chave, e);
            return defaultValue;
        }
    }
    
    // ============================================================
    // MÉTODOS ESPECÍFICOS
    // ============================================================
    
    public static String getEmpresaNome() {
        return getString("empresa_nome", "SIGRH");
    }
    
    public static String getEmpresaLogo() {
        return getString("empresa_logo", "");
    }
    
    public static String getEmpresaEmail() {
        return getString("empresa_email", "contato@sigrh.com");
    }
    
    public static String getEmpresaTelefone() {
        return getString("empresa_telefone", "+258 84 123 4567");
    }
    
    public static String getMoedaSimbolo() {
        return getString("moeda_simbolo", "MT");
    }
    
    public static String getMoedaCodigo() {
        return getString("moeda_codigo", "MZN");
    }
    
    public static String getMoeda() {
        return getMoedaSimbolo();
    }
    
    public static String getSimboloMoeda() {
        return getMoedaSimbolo();
    }
    
    public static int getDiasFerias() {
        return getInt("dias_ferias", 30);
    }
    
    public static double getTaxaIrs() {
        return getDouble("taxa_irs", 15.0);
    }
    
    public static double getTaxaInss() {
        return getDouble("taxa_inss", 11.0);
    }
    
    public static int getExpiraSenha() {
        return getInt("expira_senha", 90);
    }
    
    public static int getTentativasLogin() {
        return getInt("tentativas_login", 5);
    }
    
    public static int getMinCaracteresSenha() {
        return getInt("min_caracteres_senha", 8);
    }
    
    public static int getSessaoTimeout() {
        return getInt("sessao_timeout", 30);
    }
    
    public static String getBackupFrequencia() {
        return getString("backup_frequencia", "SEMANAL");
    }
    
    public static boolean isNotifNovosFuncionarios() {
        return getBoolean("notif_novos_funcionarios", true);
    }
    
    public static boolean isNotifSolicitacoesFerias() {
        return getBoolean("notif_solicitacoes_ferias", true);
    }
    
    public static boolean isNotifAlteracoesDados() {
        return getBoolean("notif_alteracoes_dados", false);
    }
    
    public static boolean isNotifVencimentoSenha() {
        return getBoolean("notif_vencimento_senha", true);
    }
    
    // ============================================================
    // MÉTODOS PARA NOTIFICAÇÕES POR USUÁRIO (NOVOS)
    // ============================================================
    
    /**
     * Verifica se as notificações estão ativas para um usuário
     */
    public static boolean isNotificacoesAtivas(Integer idUsuario) {
        // Verifica na tabela config_notificacao se existe registro
        // Se não existir, retorna true (padrão)
        try {
            return getBoolean("notif_ativas_" + idUsuario, true);
        } catch (Exception e) {
            return true;
        }
    }
    
    /**
     * Verifica se um tipo específico de notificação está ativo para um usuário
     */
    public static boolean isTipoNotificacaoAtiva(Integer idUsuario, String tipo) {
        try {
            // Mapeia o tipo para a chave de configuração
            String chave = "notif_" + tipo + "_" + idUsuario;
            return getBoolean(chave, true);
        } catch (Exception e) {
            return true;
        }
    }
    
    // ============================================================
    // FORMATAÇÃO DE VALORES
    // ============================================================
    
    public static String formatarMoeda(BigDecimal valor) {
        if (valor == null) {
            return getMoedaSimbolo() + " 0,00";
        }
        try {
            String simbolo = getMoedaSimbolo();
            NumberFormat format = NumberFormat.getInstance(new Locale("pt", "MZ"));
            format.setMinimumFractionDigits(2);
            format.setMaximumFractionDigits(2);
            return simbolo + " " + format.format(valor);
        } catch (Exception e) {
            return getMoedaSimbolo() + " " + valor.toString();
        }
    }
    
    public static String formatarMoeda(double valor) {
        return formatarMoeda(BigDecimal.valueOf(valor));
    }
    
    public static String formatarMoeda(String valor) {
        try {
            if (valor == null || valor.isEmpty()) {
                return getMoedaSimbolo() + " 0,00";
            }
            return formatarMoeda(new BigDecimal(valor.replace(",", ".")));
        } catch (NumberFormatException e) {
            return getMoedaSimbolo() + " 0,00";
        }
    }
    
    public static String formatarData(Date data) {
        if (data == null) return "-";
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        return sdf.format(data);
    }
    
    public static String formatarDataHora(Date data) {
        if (data == null) return "-";
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm");
        return sdf.format(data);
    }
}
package com.sigrh.exception;

public class BusinessException extends Exception {
    
    private static final long serialVersionUID = 1L;
    private String code;
    
    public BusinessException(String message) {
        super(message);
    }
    
    public BusinessException(String message, Throwable cause) {
        super(message, cause);
    }
    
    public BusinessException(String code, String message) {
        super(message);
        this.code = code;
    }
    
    public String getCode() { return code; }
}
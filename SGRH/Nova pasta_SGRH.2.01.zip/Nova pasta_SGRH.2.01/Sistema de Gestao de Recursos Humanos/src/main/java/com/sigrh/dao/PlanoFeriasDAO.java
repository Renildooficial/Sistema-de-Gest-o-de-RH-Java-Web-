package com.sigrh.dao;

import com.sigrh.exception.DatabaseException;
import com.sigrh.model.PlanoFerias;
import com.sigrh.util.DatabaseUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class PlanoFeriasDAO extends GenericDAO<PlanoFerias> {
    
    @Override
    protected String getTableName() {
        return "plano_ferias";
    }
    
    @Override
    protected PlanoFerias mapResultSetToEntity(ResultSet rs) throws SQLException {
        PlanoFerias plano = new PlanoFerias();
        plano.setId(rs.getInt("id"));
        plano.setIdFuncionario(rs.getInt("id_funcionario"));
        plano.setMesPlanejado(rs.getInt("mes_planejado"));
        plano.setAno(rs.getInt("ano"));
        plano.setPrioridade(rs.getInt("prioridade"));
        plano.setStatus(rs.getString("status"));
        plano.setObservacao(rs.getString("observacao"));
        plano.setDataCadastro(rs.getTimestamp("data_cadastro"));
        return plano;
    }
    
    @Override
    protected void setInsertParameters(PreparedStatement ps, PlanoFerias entity) throws SQLException {
        ps.setInt(1, entity.getIdFuncionario());
        ps.setInt(2, entity.getMesPlanejado());
        ps.setInt(3, entity.getAno());
        ps.setInt(4, entity.getPrioridade());
        // CORRIGIDO: status como String
        ps.setString(5, entity.getStatus() != null ? entity.getStatus() : "PENDENTE");
        ps.setString(6, entity.getObservacao());
    }

    @Override
    protected void setUpdateParameters(PreparedStatement ps, PlanoFerias entity) throws SQLException {
        ps.setInt(1, entity.getIdFuncionario());
        ps.setInt(2, entity.getMesPlanejado());
        ps.setInt(3, entity.getAno());
        ps.setInt(4, entity.getPrioridade());
        // CORRIGIDO: status como String
        ps.setString(5, entity.getStatus() != null ? entity.getStatus() : "PENDENTE");
        ps.setString(6, entity.getObservacao());
        ps.setInt(7, entity.getId());
    }
    
    @Override
    protected String getInsertColumns() {
        return "id_funcionario, mes_planejado, ano, prioridade, status, observacao";
    }
    
    @Override
    protected String getInsertPlaceholders() {
        return "?, ?, ?, ?, ?, ?";
    }
    
    @Override
    protected String getUpdateColumns() {
        return "id_funcionario = ?, mes_planejado = ?, ano = ?, prioridade = ?, status = ?, observacao = ?";
    }
    
    @Override
    protected int getUpdateParameterCount() {
        return 6;
    }
    
    @Override
    protected Integer getId(PlanoFerias entity) {
        return entity.getId();
    }
    
    @Override
    protected void setId(PlanoFerias entity, Integer id) {
        entity.setId(id);
    }
    
    // ============================================================
    // MÉTODOS ADICIONAIS (ALIAS PARA COMPATIBILIDADE)
    // ============================================================
    
    /**
     * Busca todos os planos (alias para findAll)
     */
    public List<PlanoFerias> listarTodos() throws DatabaseException {
        return findAll();
    }
    
    /**
     * Busca plano por ID (alias para findById)
     */
    public PlanoFerias buscarPorId(Integer id) throws DatabaseException {
        return findById(id);
    }
    
    /**
     * Salva um plano (alias para insert)
     */
    public void salvar(PlanoFerias plano) throws DatabaseException {
        insert(plano);
    }
    
    /**
     * Atualiza um plano (alias para update)
     */
    public void atualizar(PlanoFerias plano) throws DatabaseException {
        update(plano);
    }
    
    /**
     * Exclui um plano (alias para delete)
     */
    public void excluir(Integer id) throws DatabaseException {
        delete(id);
    }
    
    /**
     * Conta planos por ano
     */
    public int contarPorAno(Integer ano) throws DatabaseException {
        String sql = "SELECT COUNT(*) as total FROM " + getTableName() + " WHERE ano = ?";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setInt(1, ano);
            
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt("total");
                }
            }
            return 0;
            
        } catch (SQLException e) {
            logger.error("Erro ao contar planos por ano", e);
            throw new DatabaseException("Erro ao contar planos por ano: " + e.getMessage(), e);
        }
    }
    
    // ============================================================
    // MÉTODOS ESPECÍFICOS
    // ============================================================
    
    /**
     * Busca planos de férias de um funcionário
     */
    public List<PlanoFerias> findByFuncionario(Integer idFuncionario) throws DatabaseException {
        List<PlanoFerias> list = new ArrayList<>();
        String sql = "SELECT * FROM " + getTableName() + " WHERE id_funcionario = ? ORDER BY ano, mes_planejado";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setInt(1, idFuncionario);
            
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(mapResultSetToEntity(rs));
                }
            }
            return list;
            
        } catch (SQLException e) {
            logger.error("Erro ao buscar planos do funcionário ID {}", idFuncionario, e);
            throw new DatabaseException("Erro ao buscar planos: " + e.getMessage(), e);
        }
    }
    
    /**
     * Busca planos de férias por ano
     */
    public List<PlanoFerias> findByAno(Integer ano) throws DatabaseException {
        List<PlanoFerias> list = new ArrayList<>();
        String sql = "SELECT * FROM " + getTableName() + " WHERE ano = ? ORDER BY mes_planejado";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setInt(1, ano);
            
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(mapResultSetToEntity(rs));
                }
            }
            
            logger.debug("Buscados {} planos para o ano {}", list.size(), ano);
            return list;
            
        } catch (SQLException e) {
            logger.error("Erro ao buscar planos por ano", e);
            throw new DatabaseException("Erro ao buscar planos por ano: " + e.getMessage(), e);
        }
    }
    
    /**
     * Busca planos de férias por mês e ano
     */
    public List<PlanoFerias> findByMesAno(Integer mes, Integer ano) throws DatabaseException {
        List<PlanoFerias> list = new ArrayList<>();
        String sql = "SELECT * FROM " + getTableName() + 
                    " WHERE mes_planejado = ? AND ano = ? ORDER BY prioridade";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setInt(1, mes);
            ps.setInt(2, ano);
            
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(mapResultSetToEntity(rs));
                }
            }
            return list;
            
        } catch (SQLException e) {
            logger.error("Erro ao buscar planos por mês {} e ano {}", mes, ano, e);
            throw new DatabaseException("Erro ao buscar planos: " + e.getMessage(), e);
        }
    }
    
    /**
     * Busca planos por status
     */
    public List<PlanoFerias> findByStatus(String status) throws DatabaseException {
        List<PlanoFerias> list = new ArrayList<>();
        String sql = "SELECT * FROM " + getTableName() + " WHERE status = ? ORDER BY ano, mes_planejado";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setString(1, status);
            
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(mapResultSetToEntity(rs));
                }
            }
            return list;
            
        } catch (SQLException e) {
            logger.error("Erro ao buscar planos por status", e);
            throw new DatabaseException("Erro ao buscar planos por status: " + e.getMessage(), e);
        }
    }
    
    /**
     * Atualiza status de um plano
     */
    public void atualizarStatus(Integer id, String status) throws DatabaseException {
        String sql = "UPDATE " + getTableName() + " SET status = ? WHERE id = ?";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setString(1, status);
            ps.setInt(2, id);
            ps.executeUpdate();
            
            logger.debug("Status do plano ID {} atualizado para {}", id, status);
            
        } catch (SQLException e) {
            logger.error("Erro ao atualizar status do plano ID {}", id, e);
            throw new DatabaseException("Erro ao atualizar status: " + e.getMessage(), e);
        }
    }
    
 // Verificar se existe plano para um funcionário em determinado mês
    public PlanoFerias buscarPorFuncionarioMes(Integer idFuncionario, Integer mes, Integer ano) {
        String sql = "SELECT * FROM plano_ferias WHERE id_funcionario = ? AND mes = ? AND ano = ?";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setInt(1, idFuncionario);
            ps.setInt(2, mes);
            ps.setInt(3, ano);
            
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToEntity(rs);
                }
            }
        } catch (SQLException e) {
            logger.error("Erro ao buscar plano por funcionário e mês", e);
        }
        return null;
    }

    // Verificar se uma data está dentro do plano do funcionário
    public boolean isDataNoPlano(Integer idFuncionario, Date data) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(data);
        int mes = cal.get(Calendar.MONTH) + 1;
        int ano = cal.get(Calendar.YEAR);
        
        PlanoFerias plano = buscarPorFuncionarioMes(idFuncionario, mes, ano);
        return plano != null && "ATIVO".equals(plano.getStatus());
    }
    
}
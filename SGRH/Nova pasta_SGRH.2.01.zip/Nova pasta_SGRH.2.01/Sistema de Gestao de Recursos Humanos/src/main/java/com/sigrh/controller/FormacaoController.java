package com.sigrh.controller;

import com.sigrh.exception.BusinessException;
import com.sigrh.model.Formacao;
import com.sigrh.model.Funcionario;
import com.sigrh.model.Usuario;
import com.sigrh.service.FuncionarioService;
import com.sigrh.service.SistemaNotificacaoService;
import com.sigrh.util.Constants;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;
import java.util.List;

@WebServlet(urlPatterns = "/formacoes/*")
public class FormacaoController extends HttpServlet {
    
    private static final long serialVersionUID = 1L;
    private final FuncionarioService funcionarioService;
    private final SistemaNotificacaoService sistemaNotificacaoService;

    
    public FormacaoController() {
        this.funcionarioService = new FuncionarioService();
        this.sistemaNotificacaoService = new SistemaNotificacaoService();

    }
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String path = request.getPathInfo();
        
        if (path == null || path.equals("/")) {
            listar(request, response);
        } else if (path.equals("/novo")) {
            novo(request, response);
        } else if (path.startsWith("/editar/")) {
            editar(request, response);
        } else {
            response.sendError(HttpServletResponse.SC_NOT_FOUND);
        }
    }
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String path = request.getPathInfo();
        
        if (path == null || path.equals("/")) {
            salvar(request, response);
        } else if (path.equals("/excluir")) {
            excluir(request, response);
        } else {
            response.sendError(HttpServletResponse.SC_NOT_FOUND);
        }
    }
    
    // ==================== LISTAR ====================
    private void listar(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        Usuario usuario = (Usuario) request.getSession().getAttribute(Constants.SESSION_USER);
        if (usuario == null || !(usuario.isAdmin() || usuario.isRH())) {
            request.getSession().setAttribute(Constants.MSG_ERRO, "Acesso negado");
            response.sendRedirect(request.getContextPath() + "/dashboard");
            return;
        }
        
        try {
            List<Formacao> formacoes = funcionarioService.listarTodasFormacoes();
            request.setAttribute("formacoes", formacoes);
            request.setAttribute("total", formacoes.size());
            
            request.getSession().removeAttribute(Constants.MSG_ERRO);
            request.getSession().removeAttribute(Constants.MSG_SUCESSO);
            request.getSession().removeAttribute(Constants.MSG_INFO);
            
            request.getRequestDispatcher("/WEB-INF/views/rh/formacoes.jsp").forward(request, response);
            
        } catch (BusinessException e) {
            request.getSession().setAttribute(Constants.MSG_ERRO, e.getMessage());
            response.sendRedirect(request.getContextPath() + "/dashboard");
        }
    }
    
    // ==================== NOVO ====================
    private void novo(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        Usuario usuario = (Usuario) request.getSession().getAttribute(Constants.SESSION_USER);
        if (usuario == null || !(usuario.isAdmin() || usuario.isRH())) {
            request.getSession().setAttribute(Constants.MSG_ERRO, "Acesso negado");
            response.sendRedirect(request.getContextPath() + "/dashboard");
            return;
        }
        
        try {
            var funcionarios = funcionarioService.listarTodos();
            request.setAttribute("funcionarios", funcionarios);
            request.setAttribute("formacao", new Formacao());
            request.setAttribute("acao", "cadastrar");
            
            request.getSession().removeAttribute(Constants.MSG_ERRO);
            request.getSession().removeAttribute(Constants.MSG_SUCESSO);
            request.getSession().removeAttribute(Constants.MSG_INFO);
            
            request.getRequestDispatcher("/WEB-INF/views/rh/formacao-form.jsp").forward(request, response);
            
        } catch (BusinessException e) {
            request.getSession().setAttribute(Constants.MSG_ERRO, e.getMessage());
            response.sendRedirect(request.getContextPath() + "/formacoes");
        }
    }
    
    // ==================== EDITAR ====================
    private void editar(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        Usuario usuario = (Usuario) request.getSession().getAttribute(Constants.SESSION_USER);
        if (usuario == null || !(usuario.isAdmin() || usuario.isRH())) {
            request.getSession().setAttribute(Constants.MSG_ERRO, "Acesso negado");
            response.sendRedirect(request.getContextPath() + "/dashboard");
            return;
        }
        
        try {
            String idStr = request.getPathInfo().substring("/editar/".length());
            Integer id = Integer.parseInt(idStr);
            
            Formacao formacao = funcionarioService.buscarFormacao(id);
            var funcionarios = funcionarioService.listarTodos();
            
            request.setAttribute("funcionarios", funcionarios);
            request.setAttribute("formacao", formacao);
            request.setAttribute("acao", "editar");
            
            request.getSession().removeAttribute(Constants.MSG_ERRO);
            request.getSession().removeAttribute(Constants.MSG_SUCESSO);
            request.getSession().removeAttribute(Constants.MSG_INFO);
            
            request.getRequestDispatcher("/WEB-INF/views/rh/formacao-form.jsp").forward(request, response);
            
        } catch (NumberFormatException e) {
            request.getSession().setAttribute(Constants.MSG_ERRO, "ID inválido");
            response.sendRedirect(request.getContextPath() + "/formacoes");
        } catch (BusinessException e) {
            request.getSession().setAttribute(Constants.MSG_ERRO, e.getMessage());
            response.sendRedirect(request.getContextPath() + "/formacoes");
        }
    }
    
 // ==================== SALVAR ====================
    private void salvar(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        Usuario usuario = (Usuario) request.getSession().getAttribute(Constants.SESSION_USER);
        if (usuario == null || !(usuario.isAdmin() || usuario.isRH())) {
            request.getSession().setAttribute(Constants.MSG_ERRO, "Acesso negado");
            response.sendRedirect(request.getContextPath() + "/dashboard");
            return;
        }
        
        try {
            Formacao formacao = new Formacao();
            
            String id = request.getParameter("id");
            if (id != null && !id.isEmpty()) {
                formacao.setId(Integer.parseInt(id));
            }
            
            formacao.setIdFuncionario(Integer.parseInt(request.getParameter("idFuncionario")));
            formacao.setCurso(request.getParameter("curso"));
            formacao.setNivel(request.getParameter("nivel"));
            formacao.setInstituicao(request.getParameter("instituicao"));
            formacao.setLocal(request.getParameter("local"));
            
            String dataInicio = request.getParameter("dataInicio");
            if (dataInicio != null && !dataInicio.isEmpty()) {
                formacao.setDataInicio(Date.valueOf(dataInicio));
            }
            
            String dataConclusao = request.getParameter("dataConclusao");
            if (dataConclusao != null && !dataConclusao.isEmpty()) {
                formacao.setDataConclusao(Date.valueOf(dataConclusao));
            }
            
            String cargaHoraria = request.getParameter("cargaHoraria");
            if (cargaHoraria != null && !cargaHoraria.isEmpty()) {
                formacao.setCargaHoraria(Integer.parseInt(cargaHoraria));
            }
            
            formacao.setCertificado("on".equals(request.getParameter("certificado")));
            formacao.setStatus(request.getParameter("status"));
            formacao.setObservacao(request.getParameter("observacao"));
            
            if (formacao.getId() != null) {
                funcionarioService.atualizarFormacao(formacao);
                request.getSession().setAttribute(Constants.MSG_SUCESSO, "Formação atualizada com sucesso!");
            } else {
                funcionarioService.adicionarFormacao(formacao);
                
                // =============================================================
                // NOTIFICAR NOVA FORMAÇÃO
                // =============================================================
                try {
                    Funcionario func = funcionarioService.buscarPorId(formacao.getIdFuncionario());
                    if (func != null) {
                        sistemaNotificacaoService.notificarNovaFormacao(
                            formacao.getIdFuncionario(),
                            func.getNome(),
                            formacao.getCurso(),
                            formacao.getInstituicao()
                        );
                    }
                } catch (Exception e) {
                    System.err.println("⚠️ Erro ao notificar nova formação: " + e.getMessage());
                }
                
                request.getSession().setAttribute(Constants.MSG_SUCESSO, "Formação cadastrada com sucesso!");
            }
            
            response.sendRedirect(request.getContextPath() + "/formacoes");
            
        } catch (BusinessException e) {
            request.getSession().setAttribute(Constants.MSG_ERRO, e.getMessage());
            response.sendRedirect(request.getContextPath() + "/formacoes/novo");
        } catch (Exception e) {
            request.getSession().setAttribute(Constants.MSG_ERRO, "Erro ao salvar: " + e.getMessage());
            response.sendRedirect(request.getContextPath() + "/formacoes/novo");
        }
    }
    
    // ==================== EXCLUIR ====================
    private void excluir(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        
        response.setContentType("application/json");
        PrintWriter out = response.getWriter();
        
        Usuario usuario = (Usuario) request.getSession().getAttribute(Constants.SESSION_USER);
        if (usuario == null || !(usuario.isAdmin() || usuario.isRH())) {
            response.setStatus(HttpServletResponse.SC_FORBIDDEN);
            out.print("{\"success\":false,\"message\":\"Acesso negado\"}");
            out.flush();
            return;
        }
        
        try {
            Integer id = Integer.parseInt(request.getParameter("id"));
            funcionarioService.excluirFormacao(id);
            
            out.print("{\"success\":true,\"message\":\"Formação excluída com sucesso!\"}");
            
        } catch (BusinessException e) {
            out.print("{\"success\":false,\"message\":\"" + e.getMessage() + "\"}");
        } catch (Exception e) {
            out.print("{\"success\":false,\"message\":\"Erro ao excluir formação\"}");
        }
        
        out.flush();
    }
}
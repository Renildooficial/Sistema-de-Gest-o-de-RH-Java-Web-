package com.sigrh.util;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.InputStream;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Properties;

public class DatabaseUtil {
    
    private static final Logger logger = LogManager.getLogger(DatabaseUtil.class);
    private static HikariDataSource dataSource;
    
    static {
        try {
            Properties props = new Properties();
            try (InputStream input = DatabaseUtil.class.getClassLoader()
                    .getResourceAsStream("db.properties")) {
                if (input == null) {
                    throw new RuntimeException("Arquivo db.properties não encontrado!");
                }
                props.load(input);
            }
            
            String driver = props.getProperty("db.driver");
            String url = props.getProperty("db.url");
            String username = props.getProperty("db.username");
            String password = props.getProperty("db.password");
            int poolSize = Integer.parseInt(props.getProperty("db.pool.size", "10"));
            int maxPoolSize = Integer.parseInt(props.getProperty("db.pool.max.size", "20"));
            
            // Carregar driver
            Class.forName(driver);
            
            HikariConfig config = new HikariConfig();
            config.setJdbcUrl(url);
            config.setUsername(username);
            config.setPassword(password);
            config.setDriverClassName(driver);
            config.setMaximumPoolSize(maxPoolSize);
            config.setMinimumIdle(poolSize);
            config.setConnectionTimeout(30000);
            config.setIdleTimeout(600000);
            config.setMaxLifetime(1800000);
            
            // Configurações adicionais
            config.addDataSourceProperty("cachePrepStmts", "true");
            config.addDataSourceProperty("prepStmtCacheSize", "250");
            config.addDataSourceProperty("prepStmtCacheSqlLimit", "2048");
            
            dataSource = new HikariDataSource(config);
            
            logger.info("✅ Pool de conexões inicializado com sucesso!");
            logger.info("   Database: {}", url);
            logger.info("   User: {}", username);
            
        } catch (Exception e) {
            logger.error("❌ Erro ao inicializar pool de conexões: {}", e.getMessage(), e);
            throw new RuntimeException("Erro ao inicializar conexão com banco de dados", e);
        }
    }
    
    public static Connection getConnection() throws SQLException {
        if (dataSource == null) {
            throw new SQLException("DataSource não inicializado");
        }
        return dataSource.getConnection();
    }
    
    public static void closeDataSource() {
        if (dataSource != null && !dataSource.isClosed()) {
            dataSource.close();
            logger.info("✅ Pool de conexões fechado");
        }
    }
    
    public static boolean testConnection() {
        try (Connection conn = getConnection()) {
            boolean isValid = conn.isValid(2);
            logger.info("🔌 Teste de conexão: {}", isValid ? "✅ Sucesso" : "❌ Falha");
            return isValid;
        } catch (SQLException e) {
            logger.error("❌ Erro ao testar conexão: {}", e.getMessage());
            return false;
        }
    }
}
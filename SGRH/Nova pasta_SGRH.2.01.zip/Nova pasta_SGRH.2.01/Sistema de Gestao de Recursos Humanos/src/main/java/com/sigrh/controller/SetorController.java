package com.sigrh.controller;

import com.sigrh.dao.SetorDAO;
import com.sigrh.model.Setor;
import com.sigrh.model.Usuario;
import com.sigrh.service.AuditoriaService;
import com.sigrh.util.Constants;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

@WebServlet(name = "SetorController", urlPatterns = {"/setores", "/setores/*"})
public class SetorController extends HttpServlet {
    
    private static final long serialVersionUID = 1L;
    private SetorDAO setorDAO;
    private AuditoriaService auditoriaService;
    
    @Override
    public void init() {
        this.setorDAO = new SetorDAO();
        this.auditoriaService = new AuditoriaService();
    }
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String pathInfo = request.getPathInfo();
        System.out.println("🔍 SetorController.doGet - Path: " + pathInfo);
        
        Usuario usuario = (Usuario) request.getSession().getAttribute(Constants.SESSION_USER);
        if (usuario == null || !usuario.isAdmin()) {
            request.getSession().setAttribute(Constants.MSG_ERRO, "Acesso negado");
            response.sendRedirect(request.getContextPath() + "/dashboard");
            return;
        }
        
        try {
            if (pathInfo == null || pathInfo.equals("/") || pathInfo.equals("")) {
                listar(request, response);
            } else if (pathInfo.equals("/novo")) {
                novo(request, response);
            } else if (pathInfo.startsWith("/editar/")) {
                editar(request, response);
            } else {
                response.sendError(HttpServletResponse.SC_NOT_FOUND);
            }
        } catch (Exception e) {
            e.printStackTrace();
            request.getSession().setAttribute(Constants.MSG_ERRO, "Erro ao processar requisição: " + e.getMessage());
            response.sendRedirect(request.getContextPath() + "/setores");
        }
    }
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String pathInfo = request.getPathInfo();
        System.out.println("🔍 SetorController.doPost - Path: " + pathInfo);
        
        Usuario usuario = (Usuario) request.getSession().getAttribute(Constants.SESSION_USER);
        if (usuario == null || !usuario.isAdmin()) {
            response.setContentType("application/json");
            response.getWriter().write("{\"success\": false, \"message\": \"Acesso negado\"}");
            return;
        }
        
        try {
            if (pathInfo == null || pathInfo.equals("/") || pathInfo.equals("")) {
                salvar(request, response);
            } else if (pathInfo.equals("/excluir")) {
                excluir(request, response);
            } else if (pathInfo.equals("/toggle-status")) {
                toggleStatus(request, response);
            } else {
                response.sendError(HttpServletResponse.SC_NOT_FOUND);
            }
        } catch (Exception e) {
            e.printStackTrace();
            response.setContentType("application/json");
            response.getWriter().write("{\"success\": false, \"message\": \"" + e.getMessage() + "\"}");
        }
    }
    
    // ============================================================
    // LISTAR
    // ============================================================
    private void listar(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        List<Setor> setores = setorDAO.listarTodos();
        int total = setores.size();
        int ativos = 0;
        
        for (Setor s : setores) {
            if (s.getAtivo() != null && s.getAtivo()) {
                ativos++;
            }
        }
        
        request.setAttribute("setores", setores);
        request.setAttribute("total", total);
        request.setAttribute("ativos", ativos);
        
        request.getSession().removeAttribute(Constants.MSG_ERRO);
        request.getSession().removeAttribute(Constants.MSG_SUCESSO);
        request.getSession().removeAttribute(Constants.MSG_INFO);
        
        request.getRequestDispatcher("/WEB-INF/views/admin/setores.jsp").forward(request, response);
    }
    
    // ============================================================
    // NOVO
    // ============================================================
    private void novo(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        request.setAttribute("setor", new Setor());
        request.setAttribute("acao", "cadastrar");
        
        request.getRequestDispatcher("/WEB-INF/views/admin/setor-form.jsp").forward(request, response);
    }
    
    // ============================================================
    // EDITAR
    // ============================================================
    private void editar(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String pathInfo = request.getPathInfo();
        String[] parts = pathInfo.split("/");
        
        if (parts.length < 3) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST);
            return;
        }
        
        try {
            Integer id = Integer.parseInt(parts[2]);
            System.out.println("🔍 Editando setor ID: " + id);
            
            Setor setor = setorDAO.buscarPorId(id);
            
            if (setor == null) {
                request.getSession().setAttribute(Constants.MSG_ERRO, "Setor não encontrado");
                response.sendRedirect(request.getContextPath() + "/setores");
                return;
            }
            
            request.setAttribute("setor", setor);
            request.setAttribute("acao", "editar");
            
            request.getRequestDispatcher("/WEB-INF/views/admin/setor-form.jsp").forward(request, response);
            
        } catch (NumberFormatException e) {
            System.err.println("❌ ID inválido: " + e.getMessage());
            response.sendError(HttpServletResponse.SC_BAD_REQUEST);
        }
    }
    
    // ============================================================
    // SALVAR
    // ============================================================
    private void salvar(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        System.out.println("🔥🔥🔥 SALVANDO SETOR 🔥🔥🔥");
        
        try {
            String idStr = request.getParameter("id");
            Integer id = idStr != null && !idStr.isEmpty() ? Integer.parseInt(idStr) : null;
            
            String nome = request.getParameter("nome");
            String descricao = request.getParameter("descricao");
            String responsavel = request.getParameter("responsavel");
            String ativoStr = request.getParameter("ativo");
            
            System.out.println("📝 ID: " + id);
            System.out.println("📝 Nome: " + nome);
            System.out.println("📝 Ativo: " + ativoStr);
            
            // VALIDAÇÕES
            if (nome == null || nome.trim().isEmpty()) {
                request.getSession().setAttribute(Constants.MSG_ERRO, "Nome é obrigatório");
                request.getRequestDispatcher("/WEB-INF/views/admin/setor-form.jsp").forward(request, response);
                return;
            }
            
            if (nome.trim().length() < 3) {
                request.getSession().setAttribute(Constants.MSG_ERRO, "Nome deve ter no mínimo 3 caracteres");
                request.getRequestDispatcher("/WEB-INF/views/admin/setor-form.jsp").forward(request, response);
                return;
            }
            
            // Criar objeto
            Setor setor = new Setor();
            if (id != null) {
                setor.setId(id);
            }
            setor.setNome(nome.trim());
            setor.setDescricao(descricao);
            setor.setResponsavel(responsavel);
            setor.setAtivo("on".equals(ativoStr) || "true".equals(ativoStr) || "checked".equals(ativoStr));
            
            // SALVAR
            Usuario usuario = (Usuario) request.getSession().getAttribute(Constants.SESSION_USER);
            
            if (id == null) {
                System.out.println("📝 Inserindo novo setor...");
                setorDAO.salvar(setor);
                request.getSession().setAttribute(Constants.MSG_SUCESSO, "Setor cadastrado com sucesso!");
                
                // Auditoria
                if (usuario != null) {
                    auditoriaService.registrar(usuario, "CREATE", "setor", setor.getId(), 
                        null, "ID: " + setor.getId() + ", Nome: " + setor.getNome(), request);
                }
            } else {
                System.out.println("📝 Atualizando setor ID: " + id);
                setorDAO.atualizar(setor);
                request.getSession().setAttribute(Constants.MSG_SUCESSO, "Setor atualizado com sucesso!");
                
                // Auditoria
                if (usuario != null) {
                    auditoriaService.registrar(usuario, "UPDATE", "setor", setor.getId(), 
                        null, "ID: " + setor.getId() + ", Nome: " + setor.getNome(), request);
                }
            }
            
            response.sendRedirect(request.getContextPath() + "/setores");
            
        } catch (Exception e) {
            e.printStackTrace();
            request.getSession().setAttribute(Constants.MSG_ERRO, "Erro ao salvar setor: " + e.getMessage());
            request.getRequestDispatcher("/WEB-INF/views/admin/setor-form.jsp").forward(request, response);
        }
    }
    
    // ============================================================
    // EXCLUIR
    // ============================================================
    private void excluir(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        
        response.setContentType("application/json");
        PrintWriter out = response.getWriter();
        
        try {
            String idStr = request.getParameter("id");
            if (idStr == null || idStr.isEmpty()) {
                out.print("{\"success\": false, \"message\": \"ID não informado\"}");
                out.flush();
                return;
            }
            
            Integer id = Integer.parseInt(idStr);
            System.out.println("🔍 Excluindo setor ID: " + id);
            
            setorDAO.excluir(id);
            
            // Auditoria
            Usuario usuario = (Usuario) request.getSession().getAttribute(Constants.SESSION_USER);
            if (usuario != null) {
                auditoriaService.registrar(usuario, "DELETE", "setor", id, 
                    null, "ID: " + id, request);
            }
            
            out.print("{\"success\": true, \"message\": \"Setor excluído com sucesso!\"}");
            
        } catch (NumberFormatException e) {
            out.print("{\"success\": false, \"message\": \"ID inválido\"}");
        } catch (Exception e) {
            e.printStackTrace();
            out.print("{\"success\": false, \"message\": \"Erro ao excluir setor: " + e.getMessage() + "\"}");
        }
        
        out.flush();
    }
    
    // ============================================================
    // TOGGLE STATUS (ATIVAR/DESATIVAR) - NOVO
    // ============================================================
    private void toggleStatus(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        
        response.setContentType("application/json");
        PrintWriter out = response.getWriter();
        
        try {
            String idStr = request.getParameter("id");
            if (idStr == null || idStr.isEmpty()) {
                out.print("{\"success\": false, \"message\": \"ID não informado\"}");
                out.flush();
                return;
            }
            
            Integer id = Integer.parseInt(idStr);
            System.out.println("🔍 Alternando status do setor ID: " + id);
            
            Setor setor = setorDAO.buscarPorId(id);
            
            if (setor == null) {
                out.print("{\"success\": false, \"message\": \"Setor não encontrado\"}");
                out.flush();
                return;
            }
            
            // Inverter status
            boolean novoStatus = !setor.getAtivo();
            setor.setAtivo(novoStatus);
            setorDAO.atualizar(setor);
            
            String mensagem = novoStatus ? "Setor ativado com sucesso!" : "Setor desativado com sucesso!";
            
            // Auditoria
            Usuario usuario = (Usuario) request.getSession().getAttribute(Constants.SESSION_USER);
            if (usuario != null) {
                auditoriaService.registrar(usuario, "UPDATE", "setor", setor.getId(), 
                    null, "Status alterado para: " + (novoStatus ? "ATIVO" : "INATIVO"), request);
            }
            
            out.print("{\"success\": true, \"message\": \"" + mensagem + "\"}");
            
        } catch (NumberFormatException e) {
            out.print("{\"success\": false, \"message\": \"ID inválido\"}");
        } catch (Exception e) {
            e.printStackTrace();
            out.print("{\"success\": false, \"message\": \"Erro ao alterar status: " + e.getMessage() + "\"}");
        }
        
        out.flush();
    }
}
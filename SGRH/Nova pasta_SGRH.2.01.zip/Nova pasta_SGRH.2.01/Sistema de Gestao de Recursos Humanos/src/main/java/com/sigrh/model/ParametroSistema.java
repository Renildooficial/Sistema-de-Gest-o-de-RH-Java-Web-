package com.sigrh.model;

import java.sql.Timestamp;

public class ParametroSistema extends BaseModel {
    
    private static final long serialVersionUID = 1L;
    
    private String chave;
    private String valor;
    private String descricao;
    private String categoria;
    private Timestamp dataAtualizacao;
    
    public ParametroSistema() {
        super();
    }
    
    public ParametroSistema(String chave, String valor, String descricao, String categoria) {
        this.chave = chave;
        this.valor = valor;
        this.descricao = descricao;
        this.categoria = categoria;
    }
    
    // Getters e Setters
    public String getChave() {
        return chave;
    }
    
    public void setChave(String chave) {
        this.chave = chave;
    }
    
    public String getValor() {
        return valor;
    }
    
    public void setValor(String valor) {
        this.valor = valor;
    }
    
    public String getDescricao() {
        return descricao;
    }
    
    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }
    
    public String getCategoria() {
        return categoria;
    }
    
    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }
    
    public Timestamp getDataAtualizacao() {
        return dataAtualizacao;
    }
    
    public void setDataAtualizacao(Timestamp dataAtualizacao) {
        this.dataAtualizacao = dataAtualizacao;
    }
    
    @Override
    public String toString() {
        return String.format("ParametroSistema{chave='%s', valor='%s', categoria='%s'}", 
                chave, valor, categoria);
    }
}
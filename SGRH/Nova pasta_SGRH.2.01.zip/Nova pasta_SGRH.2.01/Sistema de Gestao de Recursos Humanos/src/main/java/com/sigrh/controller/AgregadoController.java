package com.sigrh.controller;

import com.sigrh.exception.BusinessException;
import com.sigrh.model.AgregadoFamiliar;
import com.sigrh.model.Usuario;
import com.sigrh.service.FuncionarioService;
import com.sigrh.util.Constants;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;
import java.util.List;

@WebServlet(urlPatterns = "/agregados/*")
public class AgregadoController extends HttpServlet {
    
    private static final long serialVersionUID = 1L;
    private final FuncionarioService funcionarioService;
    
    public AgregadoController() {
        this.funcionarioService = new FuncionarioService();
    }
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String path = request.getPathInfo();
        
        if (path == null || path.equals("/")) {
            listar(request, response);
        } else if (path.equals("/novo")) {
            novo(request, response);
        } else if (path.startsWith("/editar/")) {
            editar(request, response);
        } else {
            response.sendError(HttpServletResponse.SC_NOT_FOUND);
        }
    }
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String path = request.getPathInfo();
        
        if (path == null || path.equals("/")) {
            salvar(request, response);
        } else if (path.equals("/excluir")) {
            excluir(request, response);
        } else {
            response.sendError(HttpServletResponse.SC_NOT_FOUND);
        }
    }
    
    // ==================== LISTAR ====================
    private void listar(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        Usuario usuario = (Usuario) request.getSession().getAttribute(Constants.SESSION_USER);
        if (usuario == null || !(usuario.isAdmin() || usuario.isRH())) {
            request.getSession().setAttribute(Constants.MSG_ERRO, "Acesso negado");
            response.sendRedirect(request.getContextPath() + "/dashboard");
            return;
        }
        
        try {
            List<AgregadoFamiliar> agregados = funcionarioService.listarTodosAgregados();
            request.setAttribute("agregados", agregados);
            request.setAttribute("total", agregados.size());
            
            request.getSession().removeAttribute(Constants.MSG_ERRO);
            request.getSession().removeAttribute(Constants.MSG_SUCESSO);
            request.getSession().removeAttribute(Constants.MSG_INFO);
            
            request.getRequestDispatcher("/WEB-INF/views/rh/agregados.jsp").forward(request, response);
            
        } catch (BusinessException e) {
            request.getSession().setAttribute(Constants.MSG_ERRO, e.getMessage());
            response.sendRedirect(request.getContextPath() + "/dashboard");
        }
    }
    
    // ==================== NOVO ====================
    private void novo(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        Usuario usuario = (Usuario) request.getSession().getAttribute(Constants.SESSION_USER);
        if (usuario == null || !(usuario.isAdmin() || usuario.isRH())) {
            request.getSession().setAttribute(Constants.MSG_ERRO, "Acesso negado");
            response.sendRedirect(request.getContextPath() + "/dashboard");
            return;
        }
        
        try {
            var funcionarios = funcionarioService.listarTodos();
            request.setAttribute("funcionarios", funcionarios);
            request.setAttribute("agregado", new AgregadoFamiliar());
            request.setAttribute("acao", "cadastrar");
            
            request.getSession().removeAttribute(Constants.MSG_ERRO);
            request.getSession().removeAttribute(Constants.MSG_SUCESSO);
            request.getSession().removeAttribute(Constants.MSG_INFO);
            
            request.getRequestDispatcher("/WEB-INF/views/rh/agregado-form.jsp").forward(request, response);
            
        } catch (BusinessException e) {
            request.getSession().setAttribute(Constants.MSG_ERRO, e.getMessage());
            response.sendRedirect(request.getContextPath() + "/agregados");
        }
    }
    
    // ==================== EDITAR ====================
    private void editar(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        Usuario usuario = (Usuario) request.getSession().getAttribute(Constants.SESSION_USER);
        if (usuario == null || !(usuario.isAdmin() || usuario.isRH())) {
            request.getSession().setAttribute(Constants.MSG_ERRO, "Acesso negado");
            response.sendRedirect(request.getContextPath() + "/dashboard");
            return;
        }
        
        try {
            String idStr = request.getPathInfo().substring("/editar/".length());
            Integer id = Integer.parseInt(idStr);
            
            AgregadoFamiliar agregado = funcionarioService.buscarAgregado(id);
            var funcionarios = funcionarioService.listarTodos();
            
            request.setAttribute("funcionarios", funcionarios);
            request.setAttribute("agregado", agregado);
            request.setAttribute("acao", "editar");
            
            request.getSession().removeAttribute(Constants.MSG_ERRO);
            request.getSession().removeAttribute(Constants.MSG_SUCESSO);
            request.getSession().removeAttribute(Constants.MSG_INFO);
            
            request.getRequestDispatcher("/WEB-INF/views/rh/agregado-form.jsp").forward(request, response);
            
        } catch (NumberFormatException e) {
            request.getSession().setAttribute(Constants.MSG_ERRO, "ID inválido");
            response.sendRedirect(request.getContextPath() + "/agregados");
        } catch (BusinessException e) {
            request.getSession().setAttribute(Constants.MSG_ERRO, e.getMessage());
            response.sendRedirect(request.getContextPath() + "/agregados");
        }
    }
    
    // ==================== SALVAR ====================
    private void salvar(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        Usuario usuario = (Usuario) request.getSession().getAttribute(Constants.SESSION_USER);
        if (usuario == null || !(usuario.isAdmin() || usuario.isRH())) {
            request.getSession().setAttribute(Constants.MSG_ERRO, "Acesso negado");
            response.sendRedirect(request.getContextPath() + "/dashboard");
            return;
        }
        
        try {
            AgregadoFamiliar agregado = new AgregadoFamiliar();
            
            String id = request.getParameter("id");
            if (id != null && !id.isEmpty()) {
                agregado.setId(Integer.parseInt(id));
            }
            
            agregado.setIdFuncionario(Integer.parseInt(request.getParameter("idFuncionario")));
            agregado.setNome(request.getParameter("nome"));
            agregado.setGrauParentesco(request.getParameter("grauParentesco"));
            
            String dataNasc = request.getParameter("dataNascimento");
            if (dataNasc != null && !dataNasc.isEmpty()) {
                agregado.setDataNascimento(Date.valueOf(dataNasc));
            }
            
            agregado.setDocumento(request.getParameter("documento"));
            agregado.setObservacao(request.getParameter("observacao"));
            
            if (agregado.getId() != null) {
                funcionarioService.atualizarAgregado(agregado);
                request.getSession().setAttribute(Constants.MSG_SUCESSO, "Agregado atualizado com sucesso!");
            } else {
                funcionarioService.adicionarAgregado(agregado);
                request.getSession().setAttribute(Constants.MSG_SUCESSO, "Agregado cadastrado com sucesso!");
            }
            
            response.sendRedirect(request.getContextPath() + "/agregados");
            
        } catch (BusinessException e) {
            request.getSession().setAttribute(Constants.MSG_ERRO, e.getMessage());
            response.sendRedirect(request.getContextPath() + "/agregados/novo");
        } catch (Exception e) {
            request.getSession().setAttribute(Constants.MSG_ERRO, "Erro ao salvar: " + e.getMessage());
            response.sendRedirect(request.getContextPath() + "/agregados/novo");
        }
    }
    
    // ==================== EXCLUIR ====================
    private void excluir(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        
        response.setContentType("application/json");
        PrintWriter out = response.getWriter();
        
        Usuario usuario = (Usuario) request.getSession().getAttribute(Constants.SESSION_USER);
        if (usuario == null || !(usuario.isAdmin() || usuario.isRH())) {
            response.setStatus(HttpServletResponse.SC_FORBIDDEN);
            out.print("{\"success\":false,\"message\":\"Acesso negado\"}");
            out.flush();
            return;
        }
        
        try {
            Integer id = Integer.parseInt(request.getParameter("id"));
            funcionarioService.excluirAgregado(id);
            
            out.print("{\"success\":true,\"message\":\"Agregado excluído com sucesso!\"}");
            
        } catch (BusinessException e) {
            out.print("{\"success\":false,\"message\":\"" + e.getMessage() + "\"}");
        } catch (Exception e) {
            out.print("{\"success\":false,\"message\":\"Erro ao excluir agregado\"}");
        }
        
        out.flush();
    }
}
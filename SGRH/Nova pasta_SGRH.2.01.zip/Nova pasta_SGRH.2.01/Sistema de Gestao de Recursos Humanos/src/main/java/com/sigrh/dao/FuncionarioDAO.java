package com.sigrh.dao;

import com.sigrh.exception.DatabaseException;
import com.sigrh.model.Funcionario;
import com.sigrh.util.DatabaseUtil;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.math.BigDecimal;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class FuncionarioDAO extends GenericDAO<Funcionario> {

    private static final Logger logger = LogManager.getLogger(FuncionarioDAO.class);

    @Override
    protected String getTableName() {
        return "funcionario";
    }

    @Override
    protected Funcionario mapResultSetToEntity(ResultSet rs) throws SQLException {
        Funcionario f = new Funcionario();

        f.setId(rs.getInt("id"));
        f.setNome(rs.getString("nome"));
        f.setDataNascimento(rs.getDate("data_nascimento"));
        f.setProvincia(rs.getString("provincia"));
        f.setDistrito(rs.getString("distrito"));

        // Estado Civil (corrige a ambiguidade)
        String estadoCivilStr = rs.getString("estado_civil");
        if (estadoCivilStr != null && !estadoCivilStr.isEmpty()) {
            try {
                f.setEstadoCivil(Funcionario.EstadoCivil.valueOf(estadoCivilStr));
            } catch (IllegalArgumentException e) {
                f.setEstadoCivil((Funcionario.EstadoCivil) null);
            }
        }

        f.setNomeConjuge(rs.getString("nome_conjuge"));
        f.setDataAdmissao(rs.getDate("data_admissao"));
        f.setTelefone(rs.getString("telefone"));
        f.setNuit(rs.getString("nuit"));
        f.setNumeroConta(rs.getString("numero_conta"));
        f.setBanco(rs.getString("banco"));

        // Status
        String statusStr = rs.getString("status");
        if (statusStr != null && !statusStr.isEmpty()) {
            try {
                f.setStatus(Funcionario.StatusFuncionario.valueOf(statusStr));
            } catch (IllegalArgumentException e) {
                f.setStatus(Funcionario.StatusFuncionario.ATIVO);
            }
        }

        // Foto
        try {
            byte[] foto = rs.getBytes("foto");
            f.setFoto(foto);
        } catch (SQLException ignored) {
        }

        int idSetor = rs.getInt("id_setor");
        if (!rs.wasNull()) {
            f.setIdSetor(idSetor);
        }

        int idUsuario = rs.getInt("id_usuario");
        if (!rs.wasNull()) {
            f.setIdUsuario(idUsuario);
        }

        f.setEmailEmpresa(rs.getString("email_empresa"));
        f.setRg(rs.getString("rg"));
        f.setBi(rs.getString("bi"));
        f.setDataCadastro(rs.getTimestamp("data_cadastro"));

        // ============================================================
        // CAMPOS DE SALÁRIO
        // ============================================================
        f.setSalarioBase(rs.getBigDecimal("salario_base") != null ? rs.getBigDecimal("salario_base") : BigDecimal.ZERO);
        f.setSubsidioAlimentacao(rs.getBigDecimal("subsidio_alimentacao") != null ? rs.getBigDecimal("subsidio_alimentacao") : BigDecimal.ZERO);
        f.setSubsidioTransporte(rs.getBigDecimal("subsidio_transporte") != null ? rs.getBigDecimal("subsidio_transporte") : BigDecimal.ZERO);
        f.setSubsidioSaude(rs.getBigDecimal("subsidio_saude") != null ? rs.getBigDecimal("subsidio_saude") : BigDecimal.ZERO);

        return f;
    }

    @Override
    protected void setInsertParameters(PreparedStatement ps, Funcionario entity) throws SQLException {
        int i = 1;

        ps.setString(i++, entity.getNome());
        ps.setDate(i++, entity.getDataNascimento() != null ? new java.sql.Date(entity.getDataNascimento().getTime()) : null);
        ps.setString(i++, entity.getProvincia());
        ps.setString(i++, entity.getDistrito());
        ps.setString(i++, entity.getEstadoCivil() != null ? entity.getEstadoCivil().name() : null);
        ps.setString(i++, entity.getNomeConjuge());
        ps.setDate(i++, entity.getDataAdmissao() != null ? new java.sql.Date(entity.getDataAdmissao().getTime()) : null);
        ps.setString(i++, entity.getTelefone());
        ps.setString(i++, entity.getNuit());
        ps.setString(i++, entity.getNumeroConta());
        ps.setString(i++, entity.getBanco());
        ps.setString(i++, entity.getStatus() != null ? entity.getStatus().name() : "ATIVO");

        if (entity.getFoto() != null) {
            ps.setBytes(i++, entity.getFoto());
        } else {
            ps.setNull(i++, Types.BLOB);
        }

        if (entity.getIdSetor() != null && entity.getIdSetor() > 0) {
            ps.setInt(i++, entity.getIdSetor());
        } else {
            ps.setNull(i++, Types.INTEGER);
        }

        if (entity.getIdUsuario() != null && entity.getIdUsuario() > 0) {
            ps.setInt(i++, entity.getIdUsuario());
        } else {
            ps.setNull(i++, Types.INTEGER);
        }

        ps.setString(i++, entity.getEmailEmpresa());
        ps.setString(i++, entity.getRg());
        ps.setString(i++, entity.getBi());

        // Salários
        ps.setBigDecimal(i++, entity.getSalarioBase() != null ? entity.getSalarioBase() : BigDecimal.ZERO);
        ps.setBigDecimal(i++, entity.getSubsidioAlimentacao() != null ? entity.getSubsidioAlimentacao() : BigDecimal.ZERO);
        ps.setBigDecimal(i++, entity.getSubsidioTransporte() != null ? entity.getSubsidioTransporte() : BigDecimal.ZERO);
        ps.setBigDecimal(i++, entity.getSubsidioSaude() != null ? entity.getSubsidioSaude() : BigDecimal.ZERO);
    }

    @Override
    protected void setUpdateParameters(PreparedStatement ps, Funcionario entity) throws SQLException {
        int i = 1;

        ps.setString(i++, entity.getNome());
        ps.setDate(i++, entity.getDataNascimento() != null ? new java.sql.Date(entity.getDataNascimento().getTime()) : null);
        ps.setString(i++, entity.getProvincia());
        ps.setString(i++, entity.getDistrito());
        ps.setString(i++, entity.getEstadoCivil() != null ? entity.getEstadoCivil().name() : null);
        ps.setString(i++, entity.getNomeConjuge());
        ps.setDate(i++, entity.getDataAdmissao() != null ? new java.sql.Date(entity.getDataAdmissao().getTime()) : null);
        ps.setString(i++, entity.getTelefone());
        ps.setString(i++, entity.getNuit());
        ps.setString(i++, entity.getNumeroConta());
        ps.setString(i++, entity.getBanco());
        ps.setString(i++, entity.getStatus() != null ? entity.getStatus().name() : "ATIVO");

        if (entity.getFoto() != null) {
            ps.setBytes(i++, entity.getFoto());
        } else {
            ps.setNull(i++, Types.BLOB);
        }

        if (entity.getIdSetor() != null && entity.getIdSetor() > 0) {
            ps.setInt(i++, entity.getIdSetor());
        } else {
            ps.setNull(i++, Types.INTEGER);
        }

        if (entity.getIdUsuario() != null && entity.getIdUsuario() > 0) {
            ps.setInt(i++, entity.getIdUsuario());
        } else {
            ps.setNull(i++, Types.INTEGER);
        }

        ps.setString(i++, entity.getEmailEmpresa());
        ps.setString(i++, entity.getRg());
        ps.setString(i++, entity.getBi());

        // Salários (CRÍTICO)
        ps.setBigDecimal(i++, entity.getSalarioBase() != null ? entity.getSalarioBase() : BigDecimal.ZERO);
        ps.setBigDecimal(i++, entity.getSubsidioAlimentacao() != null ? entity.getSubsidioAlimentacao() : BigDecimal.ZERO);
        ps.setBigDecimal(i++, entity.getSubsidioTransporte() != null ? entity.getSubsidioTransporte() : BigDecimal.ZERO);
        ps.setBigDecimal(i++, entity.getSubsidioSaude() != null ? entity.getSubsidioSaude() : BigDecimal.ZERO);
    }

    @Override
    protected String getInsertColumns() {
        return "nome, data_nascimento, provincia, distrito, estado_civil, nome_conjuge, " +
               "data_admissao, telefone, nuit, numero_conta, banco, status, foto, " +
               "id_setor, id_usuario, email_empresa, rg, bi, " +
               "salario_base, subsidio_alimentacao, subsidio_transporte, subsidio_saude";
    }

    @Override
    protected String getInsertPlaceholders() {
        return "?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?";
    }

    @Override
    protected String getUpdateColumns() {
        return "nome = ?, data_nascimento = ?, provincia = ?, distrito = ?, estado_civil = ?, " +
               "nome_conjuge = ?, data_admissao = ?, telefone = ?, nuit = ?, numero_conta = ?, " +
               "banco = ?, status = ?, foto = ?, id_setor = ?, id_usuario = ?, " +
               "email_empresa = ?, rg = ?, bi = ?, " +
               "salario_base = ?, subsidio_alimentacao = ?, subsidio_transporte = ?, subsidio_saude = ?";
    }

    @Override
    protected int getUpdateParameterCount() {
        return 22;
    }

    @Override
    protected Integer getId(Funcionario entity) {
        return entity.getId();
    }

    @Override
    protected void setId(Funcionario entity, Integer id) {
        entity.setId(id);
    }

    // ============================================================
    // MÉTODOS QUE O RESTO DO SISTEMA ESTÁ A CHAMAR
    // (Aliases + métodos específicos)
    // ============================================================

    /** Alias usado por vários Controllers */
    public Funcionario buscarPorId(Integer id) throws DatabaseException {
        return findById(id);
    }

    /** Alias usado por Controllers e Services */
    public List<Funcionario> listarTodos() throws DatabaseException {
        return findAll();
    }

    /** Alias usado por FolhaPagamentoService e outros */
    public List<Funcionario> listarAtivos() throws DatabaseException {
        return findAtivos();
    }

    public List<Funcionario> findAtivos() throws DatabaseException {
        List<Funcionario> list = new ArrayList<>();
        String sql = "SELECT * FROM " + getTableName() + " WHERE status = 'ATIVO' ORDER BY nome";

        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                list.add(mapResultSetToEntity(rs));
            }
            return list;

        } catch (SQLException e) {
            logger.error("Erro ao buscar funcionários ativos", e);
            throw new DatabaseException("Erro ao buscar funcionários ativos: " + e.getMessage(), e);
        }
    }

    public List<Funcionario> findByStatus(String status) throws DatabaseException {
        List<Funcionario> list = new ArrayList<>();
        String sql = "SELECT * FROM " + getTableName() + " WHERE status = ? ORDER BY nome";

        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, status);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(mapResultSetToEntity(rs));
                }
            }
            return list;

        } catch (SQLException e) {
            logger.error("Erro ao buscar funcionários por status {}", status, e);
            throw new DatabaseException("Erro ao buscar funcionários por status: " + e.getMessage(), e);
        }
    }

    public List<Funcionario> findBySetor(Integer idSetor) throws DatabaseException {
        List<Funcionario> list = new ArrayList<>();
        String sql = "SELECT * FROM " + getTableName() + " WHERE id_setor = ? ORDER BY nome";

        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, idSetor);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(mapResultSetToEntity(rs));
                }
            }
            return list;

        } catch (SQLException e) {
            logger.error("Erro ao buscar funcionários do setor {}", idSetor, e);
            throw new DatabaseException("Erro ao buscar funcionários do setor: " + e.getMessage(), e);
        }
    }

    public int countBySetor(Integer idSetor) throws DatabaseException {
        String sql = "SELECT COUNT(*) FROM " + getTableName() + " WHERE id_setor = ?";

        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, idSetor);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1);
                }
            }
            return 0;

        } catch (SQLException e) {
            logger.error("Erro ao contar funcionários do setor {}", idSetor, e);
            throw new DatabaseException("Erro ao contar funcionários do setor: " + e.getMessage(), e);
        }
    }

    public List<Funcionario> findByNomeContaining(String nome) throws DatabaseException {
        List<Funcionario> list = new ArrayList<>();
        String sql = "SELECT * FROM " + getTableName() + " WHERE nome LIKE ? ORDER BY nome";

        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, "%" + nome + "%");
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(mapResultSetToEntity(rs));
                }
            }
            return list;

        } catch (SQLException e) {
            logger.error("Erro ao pesquisar funcionários por nome {}", nome, e);
            throw new DatabaseException("Erro ao pesquisar funcionários: " + e.getMessage(), e);
        }
    }

    public Funcionario findByNuit(String nuit) throws DatabaseException {
        String sql = "SELECT * FROM " + getTableName() + " WHERE nuit = ?";

        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, nuit);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToEntity(rs);
                }
            }
            return null;

        } catch (SQLException e) {
            logger.error("Erro ao buscar funcionário por NUIT {}", nuit, e);
            throw new DatabaseException("Erro ao buscar por NUIT: " + e.getMessage(), e);
        }
    }

    public Funcionario findByBi(String bi) throws DatabaseException {
        String sql = "SELECT * FROM " + getTableName() + " WHERE bi = ?";

        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, bi);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToEntity(rs);
                }
            }
            return null;

        } catch (SQLException e) {
            logger.error("Erro ao buscar funcionário por BI {}", bi, e);
            throw new DatabaseException("Erro ao buscar por BI: " + e.getMessage(), e);
        }
    }

    public Funcionario findByTelefone(String telefone) throws DatabaseException {
        String sql = "SELECT * FROM " + getTableName() + " WHERE telefone = ?";

        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, telefone);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToEntity(rs);
                }
            }
            return null;

        } catch (SQLException e) {
            logger.error("Erro ao buscar funcionário por telefone {}", telefone, e);
            throw new DatabaseException("Erro ao buscar por telefone: " + e.getMessage(), e);
        }
    }

    // ============================================================
    // ESTATÍSTICAS (corrige o erro "afastados cannot be resolved")
    // ============================================================
    public static class FuncionarioStats {
        public int total;
        public int ativos;
        public int inativos;
        public int licenca;
        public int ferias;
        public int afastados;   // <-- nome que o DashboardController e RelatorioService esperam
    }

    public FuncionarioStats getStats() throws DatabaseException {
        FuncionarioStats stats = new FuncionarioStats();
        String sql = "SELECT status, COUNT(*) as qtd FROM " + getTableName() + " GROUP BY status";

        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                String status = rs.getString("status");
                int qtd = rs.getInt("qtd");
                stats.total += qtd;

                if (status != null) {
                    switch (status) {
                        case "ATIVO"    -> stats.ativos = qtd;
                        case "INATIVO"  -> stats.inativos = qtd;
                        case "LICENCA"  -> stats.licenca = qtd;
                        case "FERIAS"   -> stats.ferias = qtd;
                        case "AFASTADO" -> stats.afastados = qtd;
                    }
                }
            }
            return stats;

        } catch (SQLException e) {
            logger.error("Erro ao obter estatísticas de funcionários", e);
            throw new DatabaseException("Erro ao obter estatísticas: " + e.getMessage(), e);
        }
    }
}
package com.sigrh.controller;

import com.sigrh.exception.BusinessException;
import com.sigrh.model.Usuario;
import com.sigrh.service.ConfiguracaoService;
import com.sigrh.service.AuditoriaService;
import com.sigrh.util.Constants;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.Part;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.sql.Date;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@WebServlet(name = "ConfiguracoesController", urlPatterns = {"/configuracoes", "/configuracoes/*"})
@MultipartConfig(maxFileSize = 2 * 1024 * 1024) // 2MB
public class ConfiguracoesController extends HttpServlet {
    
    private static final long serialVersionUID = 1L;
    private ConfiguracaoService configuracaoService;
    private AuditoriaService auditoriaService;
    
    @Override
    public void init() {
        this.configuracaoService = new ConfiguracaoService();
        this.auditoriaService = new AuditoriaService();
    }
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String pathInfo = request.getPathInfo();
        System.out.println("🔍 ConfiguracoesController.doGet - Path: " + pathInfo);
        
        Usuario usuario = (Usuario) request.getSession().getAttribute(Constants.SESSION_USER);
        if (usuario == null || !usuario.isAdmin()) {
            request.getSession().setAttribute(Constants.MSG_ERRO, "Acesso negado");
            response.sendRedirect(request.getContextPath() + "/dashboard");
            return;
        }
        
        try {
            if (pathInfo == null || pathInfo.equals("/") || pathInfo.equals("")) {
                listar(request, response);
            } else if (pathInfo.equals("/backups")) {
                listarBackups(request, response);
            } else if (pathInfo.equals("/download-backup")) {
                downloadBackup(request, response);
            } else {
                response.sendError(HttpServletResponse.SC_NOT_FOUND);
            }
        } catch (Exception e) {
            e.printStackTrace();
            request.getSession().setAttribute(Constants.MSG_ERRO, "Erro ao carregar configurações: " + e.getMessage());
            response.sendRedirect(request.getContextPath() + "/dashboard");
        }
    }
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String pathInfo = request.getPathInfo();
        System.out.println("🔍 ConfiguracoesController.doPost - Path: " + pathInfo);
        
        Usuario usuario = (Usuario) request.getSession().getAttribute(Constants.SESSION_USER);
        if (usuario == null || !usuario.isAdmin()) {
            request.getSession().setAttribute(Constants.MSG_ERRO, "Acesso negado");
            response.sendRedirect(request.getContextPath() + "/dashboard");
            return;
        }
        
        try {
            if (pathInfo == null || pathInfo.equals("/") || pathInfo.equals("")) {
                salvar(request, response);
            } else if (pathInfo.equals("/backup")) {
                realizarBackup(request, response);
            } else if (pathInfo.equals("/excluir-backup")) {
                excluirBackup(request, response);
            } else {
                response.sendError(HttpServletResponse.SC_NOT_FOUND);
            }
        } catch (Exception e) {
            e.printStackTrace();
            response.setContentType("application/json");
            response.getWriter().write("{\"success\": false, \"message\": \"" + e.getMessage() + "\"}");
        }
    }
    
    // ============================================================
    // LISTAR CONFIGURAÇÕES
    // ============================================================
    private void listar(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        try {
            Map<String, Object> configs = configuracaoService.getConfiguracoesCompletas();
            
            for (Map.Entry<String, Object> entry : configs.entrySet()) {
                request.setAttribute(entry.getKey(), entry.getValue());
            }
            
            request.setAttribute("ultimaAtualizacao", Timestamp.valueOf(LocalDateTime.now()));
            request.setAttribute("ultimoBackup", "15/08/2026 22:30");
            
            // ============================================================
            // CARREGAR LISTA DE BACKUPS
            // ============================================================
            String caminhoBackup = getServletContext().getRealPath("/") + "backups/";
            File pastaBackup = new File(caminhoBackup);
            
            List<Map<String, String>> backups = new ArrayList<>();
            
            if (pastaBackup.exists()) {
                File[] arquivos = pastaBackup.listFiles((dir, name) -> name.endsWith(".sql"));
                if (arquivos != null) {
                    Arrays.sort(arquivos, (a, b) -> Long.compare(b.lastModified(), a.lastModified()));
                    int count = 0;
                    for (File f : arquivos) {
                        if (count >= 5) break; // Mostrar apenas os 5 mais recentes
                        Map<String, String> item = new HashMap<>();
                        item.put("nome", f.getName());
                        item.put("tamanho", formatarTamanho(f.length()));
                        item.put("data", new SimpleDateFormat("dd/MM/yyyy HH:mm").format(new Date(f.lastModified())));
                        backups.add(item);
                        count++;
                    }
                }
            }
            
            request.setAttribute("backups", backups);
            request.setAttribute("totalBackups", backups.size());
            
            request.getSession().removeAttribute(Constants.MSG_ERRO);
            request.getSession().removeAttribute(Constants.MSG_SUCESSO);
            request.getSession().removeAttribute(Constants.MSG_INFO);
            
            request.getRequestDispatcher("/WEB-INF/views/admin/configuracoes.jsp").forward(request, response);
            
        } catch (BusinessException e) {
            request.getSession().setAttribute(Constants.MSG_ERRO, e.getMessage());
            response.sendRedirect(request.getContextPath() + "/dashboard");
        }
    }
    
    // ============================================================
    // SALVAR CONFIGURAÇÕES
    // ============================================================
    private void salvar(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        System.out.println("🔥🔥🔥 SALVANDO CONFIGURAÇÕES 🔥🔥🔥");
        
        try {
            // DADOS DA EMPRESA
            String empresaNome = request.getParameter("empresaNome");
            String empresaEmail = request.getParameter("empresaEmail");
            String empresaTelefone = request.getParameter("empresaTelefone");
            
            // PARÂMETROS FINANCEIROS
            String diasFerias = request.getParameter("diasFerias");
            String taxaIrs = request.getParameter("taxaIrs");
            String taxaInss = request.getParameter("taxaInss");
            
            // MOEDA
            String moedaSimbolo = request.getParameter("moedaSimbolo");
            String moedaCodigo = request.getParameter("moedaCodigo");
            
            // SEGURANÇA
            String expiraSenha = request.getParameter("expiraSenha");
            String tentativasLogin = request.getParameter("tentativasLogin");
            String minCaracteresSenha = request.getParameter("minCaracteresSenha");
            String sessaoTimeout = request.getParameter("sessaoTimeout");
            
            // BACKUP
            String backupFrequencia = request.getParameter("backupFrequencia");
            
            // NOTIFICAÇÕES
            Map<String, Boolean> notificacoes = new HashMap<>();
            notificacoes.put("notif_novos_funcionarios", request.getParameter("notifNovosFuncionarios") != null);
            notificacoes.put("notif_solicitacoes_ferias", request.getParameter("notifSolicitacoesFerias") != null);
            notificacoes.put("notif_alteracoes_dados", request.getParameter("notifAlteracoesDados") != null);
            notificacoes.put("notif_vencimento_senha", request.getParameter("notifVencimentoSenha") != null);
            
            // VALIDAÇÕES
            if (empresaNome == null || empresaNome.trim().isEmpty()) {
                throw new BusinessException("Nome da empresa é obrigatório");
            }
            
            if (diasFerias != null) {
                int dias = Integer.parseInt(diasFerias);
                if (dias < 0 || dias > 365) {
                    throw new BusinessException("Dias de férias deve estar entre 0 e 365");
                }
            }
            
            if (taxaIrs != null) {
                double irs = Double.parseDouble(taxaIrs);
                if (irs < 0 || irs > 100) {
                    throw new BusinessException("Taxa de IRS deve estar entre 0 e 100");
                }
            }
            
            if (taxaInss != null) {
                double inss = Double.parseDouble(taxaInss);
                if (inss < 0 || inss > 100) {
                    throw new BusinessException("Taxa de INSS deve estar entre 0 e 100");
                }
            }
            
            // SALVAR EMPRESA
            configuracaoService.atualizarConfiguracoesEmpresa(
                empresaNome.trim(), empresaEmail, empresaTelefone, null
            );
            
            // SALVAR MOEDA
            if (moedaSimbolo != null && !moedaSimbolo.trim().isEmpty()) {
                configuracaoService.salvarConfiguracao("moeda_simbolo", moedaSimbolo.trim(), 
                    "Símbolo da moeda", "FINANCEIRO", "TEXT");
            }
            if (moedaCodigo != null && !moedaCodigo.trim().isEmpty()) {
                configuracaoService.salvarConfiguracao("moeda_codigo", moedaCodigo.trim(), 
                    "Código da moeda", "FINANCEIRO", "TEXT");
            }
            
            // SALVAR FINANCEIRO
            configuracaoService.atualizarConfiguracoesFinanceiras(diasFerias, taxaIrs, taxaInss);
            
            // SALVAR SEGURANÇA
            configuracaoService.atualizarConfiguracoesSeguranca(
                expiraSenha, tentativasLogin, minCaracteresSenha, sessaoTimeout
            );
            
            // SALVAR BACKUP
            if (backupFrequencia != null) {
                configuracaoService.salvarConfiguracao("backup_frequencia", backupFrequencia, 
                    "Frequência de backup", "BACKUP", "TEXT");
            }
            
            // SALVAR NOTIFICAÇÕES
            configuracaoService.atualizarNotificacoes(notificacoes);
            
            // AUDITORIA
            Usuario usuario = (Usuario) request.getSession().getAttribute(Constants.SESSION_USER);
            if (usuario != null) {
                auditoriaService.registrar(
                    usuario, "UPDATE", "configuracao", null, null, 
                    "Configurações atualizadas por " + usuario.getNome(), request
                );
            }
            
            request.getSession().setAttribute(Constants.MSG_SUCESSO, "Configurações salvas com sucesso!");
            response.sendRedirect(request.getContextPath() + "/configuracoes");
            
        } catch (BusinessException e) {
            request.getSession().setAttribute(Constants.MSG_ERRO, e.getMessage());
            response.sendRedirect(request.getContextPath() + "/configuracoes");
        } catch (NumberFormatException e) {
            request.getSession().setAttribute(Constants.MSG_ERRO, "Valor numérico inválido: " + e.getMessage());
            response.sendRedirect(request.getContextPath() + "/configuracoes");
        } catch (Exception e) {
            e.printStackTrace();
            request.getSession().setAttribute(Constants.MSG_ERRO, "Erro ao salvar configurações: " + e.getMessage());
            response.sendRedirect(request.getContextPath() + "/configuracoes");
        }
    }
    
    // ============================================================
    // REALIZAR BACKUP - CORRIGIDO
    // ============================================================
    private void realizarBackup(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        
        response.setContentType("application/json");
        
        try {
            System.out.println("🔍 Realizando backup do sistema...");
            
            String caminhoBackup = getServletContext().getRealPath("/") + "backups/";
            File pastaBackup = new File(caminhoBackup);
            if (!pastaBackup.exists()) {
                pastaBackup.mkdirs();
            }
            
            String dataBackup = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss"));
            String nomeArquivo = "backup_sigrh_" + dataBackup + ".sql";
            String caminhoCompleto = caminhoBackup + nomeArquivo;
            
            // ============================================================
            // CORRIGIDO: Renomeado para dbUsuario para não conflitar
            // ============================================================
            String dbUsuario = "root";
            String dbSenha = "";
            String banco = "sigrh";
            
            ProcessBuilder pb = new ProcessBuilder(
                "mysqldump",
                "-u", dbUsuario,
                "-p" + dbSenha,
                "--add-drop-table",
                "--routines",
                "--triggers",
                banco
            );
            
            pb.redirectOutput(new File(caminhoCompleto));
            Process process = pb.start();
            int exitCode = process.waitFor();
            
            if (exitCode != 0) {
                throw new Exception("Erro ao executar mysqldump. Código: " + exitCode);
            }
            
            System.out.println("✅ Backup criado: " + nomeArquivo);
            System.out.println("📁 Local: " + caminhoCompleto);
            
            // Registrar no banco
            configuracaoService.salvarConfiguracao(
                "ultimo_backup", 
                LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm")),
                "Data do último backup", "BACKUP", "TEXT"
            );
            
            // ============================================================
            // CORRIGIDO: Não redeclarar usuario, usar o que já existe
            // ============================================================
            Usuario usuario = (Usuario) request.getSession().getAttribute(Constants.SESSION_USER);
            if (usuario != null) {
                auditoriaService.registrar(
                    usuario, "BACKUP", "sistema", null, null, 
                    "Backup realizado por " + usuario.getNome() + " - Arquivo: " + nomeArquivo, request
                );
            }
            
            response.getWriter().write("{\"success\": true, \"message\": \"Backup realizado com sucesso!\\nArquivo: " + nomeArquivo + "\"}");
            
        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().write("{\"success\": false, \"message\": \"Erro ao realizar backup: " + e.getMessage() + "\"}");
        }
    }
    
 // No método doGet, a rota /backups já existe, mas precisa carregar os dados
 // Adicione no método listarBackups:

 private void listarBackups(HttpServletRequest request, HttpServletResponse response) 
         throws ServletException, IOException {
     
     try {
         String caminhoBackup = getServletContext().getRealPath("/") + "backups/";
         File pastaBackup = new File(caminhoBackup);
         
         List<Map<String, String>> backups = new ArrayList<>();
         long espacoTotal = 0;
         
         if (pastaBackup.exists()) {
             File[] arquivos = pastaBackup.listFiles((dir, name) -> name.endsWith(".sql"));
             if (arquivos != null) {
                 Arrays.sort(arquivos, (a, b) -> Long.compare(b.lastModified(), a.lastModified()));
                 for (File f : arquivos) {
                     Map<String, String> item = new HashMap<>();
                     item.put("nome", f.getName());
                     item.put("tamanho", formatarTamanho(f.length()));
                     item.put("data", new SimpleDateFormat("dd/MM/yyyy HH:mm").format(new Date(f.lastModified())));
                     backups.add(item);
                     espacoTotal += f.length();
                 }
             }
         }
         
         request.setAttribute("backups", backups);
         request.setAttribute("totalBackups", backups.size());
         request.setAttribute("espacoTotal", formatarTamanho(espacoTotal));
         request.setAttribute("pastaBackup", caminhoBackup);
         
         request.getSession().removeAttribute(Constants.MSG_ERRO);
         request.getSession().removeAttribute(Constants.MSG_SUCESSO);
         request.getSession().removeAttribute(Constants.MSG_INFO);
         
         request.getRequestDispatcher("/WEB-INF/views/admin/backups.jsp").forward(request, response);
         
     } catch (Exception e) {
         e.printStackTrace();
         request.getSession().setAttribute(Constants.MSG_ERRO, "Erro ao listar backups: " + e.getMessage());
         response.sendRedirect(request.getContextPath() + "/configuracoes");
     }
 }
    
    // ============================================================
    // DOWNLOAD BACKUP
    // ============================================================
    private void downloadBackup(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        
        String arquivo = request.getParameter("arquivo");
        if (arquivo == null || arquivo.trim().isEmpty()) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Nome do arquivo não informado");
            return;
        }
        
        String caminhoBackup = getServletContext().getRealPath("/") + "backups/" + arquivo;
        File file = new File(caminhoBackup);
        
        if (!file.exists()) {
            response.sendError(HttpServletResponse.SC_NOT_FOUND, "Arquivo não encontrado");
            return;
        }
        
        response.setContentType("application/octet-stream");
        response.setHeader("Content-Disposition", "attachment; filename=\"" + arquivo + "\"");
        response.setContentLengthLong(file.length());
        
        try (FileInputStream fis = new FileInputStream(file);
             OutputStream os = response.getOutputStream()) {
            byte[] buffer = new byte[4096];
            int bytesRead;
            while ((bytesRead = fis.read(buffer)) != -1) {
                os.write(buffer, 0, bytesRead);
            }
            os.flush();
        }
    }
    
    // ============================================================
    // EXCLUIR BACKUP
    // ============================================================
    private void excluirBackup(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        
        response.setContentType("application/json");
        
        try {
            String arquivo = request.getParameter("arquivo");
            if (arquivo == null || arquivo.trim().isEmpty()) {
                response.getWriter().write("{\"success\": false, \"message\": \"Nome do arquivo não informado\"}");
                return;
            }
            
            String caminhoBackup = getServletContext().getRealPath("/") + "backups/" + arquivo;
            File file = new File(caminhoBackup);
            
            if (!file.exists()) {
                response.getWriter().write("{\"success\": false, \"message\": \"Arquivo não encontrado\"}");
                return;
            }
            
            if (file.delete()) {
                Usuario usuario = (Usuario) request.getSession().getAttribute(Constants.SESSION_USER);
                if (usuario != null) {
                    auditoriaService.registrar(
                        usuario, "DELETE_BACKUP", "sistema", null, null, 
                        "Backup excluído: " + arquivo + " por " + usuario.getNome(), request
                    );
                }
                response.getWriter().write("{\"success\": true, \"message\": \"Backup excluído com sucesso!\"}");
            } else {
                response.getWriter().write("{\"success\": false, \"message\": \"Não foi possível excluir o arquivo\"}");
            }
            
        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().write("{\"success\": false, \"message\": \"Erro ao excluir backup: " + e.getMessage() + "\"}");
        }
    }
    
    // ============================================================
    // MÉTODO AUXILIAR - FORMATAR TAMANHO
    // ============================================================
    private String formatarTamanho(long bytes) {
        if (bytes < 1024) return bytes + " B";
        if (bytes < 1024 * 1024) return String.format("%.1f KB", bytes / 1024.0);
        if (bytes < 1024 * 1024 * 1024) return String.format("%.1f MB", bytes / (1024.0 * 1024));
        return String.format("%.2f GB", bytes / (1024.0 * 1024 * 1024));
    }
}
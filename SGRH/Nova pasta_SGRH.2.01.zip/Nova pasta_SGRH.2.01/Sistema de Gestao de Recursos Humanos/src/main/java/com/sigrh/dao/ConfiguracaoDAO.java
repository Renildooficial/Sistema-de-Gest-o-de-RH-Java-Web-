package com.sigrh.dao;

import com.sigrh.exception.DatabaseException;
import com.sigrh.model.Configuracao;
import com.sigrh.util.DatabaseUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ConfiguracaoDAO extends GenericDAO<Configuracao> {

    @Override
    protected String getTableName() {
        return "configuracao";
    }

    @Override
    protected Configuracao mapResultSetToEntity(ResultSet rs) throws SQLException {
        Configuracao config = new Configuracao();
        config.setId(rs.getInt("id"));
        config.setChave(rs.getString("chave"));
        config.setValor(rs.getString("valor"));
        config.setDescricao(rs.getString("descricao"));
        config.setCategoria(rs.getString("categoria"));
        config.setTipo(rs.getString("tipo"));
        // REMOVER: config.setDataCadastro(rs.getTimestamp("data_cadastro"));
        return config;
    }

    @Override
    protected void setInsertParameters(PreparedStatement ps, Configuracao entity) throws SQLException {
        ps.setString(1, entity.getChave());
        ps.setString(2, entity.getValor());
        ps.setString(3, entity.getDescricao());
        ps.setString(4, entity.getCategoria());
        ps.setString(5, entity.getTipo());
    }

    @Override
    protected void setUpdateParameters(PreparedStatement ps, Configuracao entity) throws SQLException {
        ps.setString(1, entity.getChave());
        ps.setString(2, entity.getValor());
        ps.setString(3, entity.getDescricao());
        ps.setString(4, entity.getCategoria());
        ps.setString(5, entity.getTipo());
        ps.setInt(6, entity.getId());
    }

    @Override
    protected String getInsertColumns() {
        return "chave, valor, descricao, categoria, tipo";
    }

    @Override
    protected String getInsertPlaceholders() {
        return "?, ?, ?, ?, ?";
    }

    @Override
    protected String getUpdateColumns() {
        return "chave = ?, valor = ?, descricao = ?, categoria = ?, tipo = ?";
    }

    @Override
    protected int getUpdateParameterCount() {
        return 5;
    }

    @Override
    protected Integer getId(Configuracao entity) {
        return entity.getId();
    }

    @Override
    protected void setId(Configuracao entity, Integer id) {
        entity.setId(id);
    }

    // ============================================================
    // MÉTODOS ADICIONAIS
    // ============================================================

    public Configuracao findByChave(String chave) throws DatabaseException {
        String sql = "SELECT * FROM " + getTableName() + " WHERE chave = ?";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setString(1, chave);
            
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToEntity(rs);
                }
            }
            return null;
            
        } catch (SQLException e) {
            logger.error("Erro ao buscar configuração pela chave {}", chave, e);
            throw new DatabaseException("Erro ao buscar configuração: " + e.getMessage(), e);
        }
    }

    public Configuracao buscarPorChave(String chave) throws DatabaseException {
        return findByChave(chave);
    }

    public String getValor(String chave) throws DatabaseException {
        Configuracao config = findByChave(chave);
        return config != null ? config.getValor() : null;
    }

    public void setValor(String chave, String valor) throws DatabaseException {
        Configuracao config = findByChave(chave);
        if (config != null) {
            config.setValor(valor);
            atualizar(config);
        } else {
            Configuracao nova = new Configuracao();
            nova.setChave(chave);
            nova.setValor(valor);
            nova.setCategoria("GERAL");
            nova.setTipo("TEXT");
            salvar(nova);
        }
    }

    public List<Configuracao> findByCategoria(String categoria) throws DatabaseException {
        List<Configuracao> list = new ArrayList<>();
        String sql = "SELECT * FROM " + getTableName() + " WHERE categoria = ? ORDER BY chave";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setString(1, categoria);
            
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(mapResultSetToEntity(rs));
                }
            }
            return list;
            
        } catch (SQLException e) {
            logger.error("Erro ao buscar configurações por categoria {}", categoria, e);
            throw new DatabaseException("Erro ao buscar configurações: " + e.getMessage(), e);
        }
    }

    public List<Configuracao> listarTodos() throws DatabaseException {
        return findAll();
    }

    public void salvar(Configuracao config) throws DatabaseException {
        insert(config);
    }

    public void atualizar(Configuracao config) throws DatabaseException {
        update(config);
    }
}
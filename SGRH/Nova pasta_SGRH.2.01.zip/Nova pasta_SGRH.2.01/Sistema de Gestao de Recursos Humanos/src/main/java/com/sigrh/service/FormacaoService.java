package com.sigrh.service;

import com.sigrh.dao.FormacaoDAO;
import com.sigrh.model.Formacao;
import com.sigrh.exception.BusinessException;
import com.sigrh.exception.DatabaseException;

import java.util.List;

public class FormacaoService {
    
    private FormacaoDAO formacaoDAO;
    
    public FormacaoService() {
        this.formacaoDAO = new FormacaoDAO();
    }
    
    /**
     * Busca todas as formações de um funcionário
     */
    public List<Formacao> buscarPorFuncionario(Integer idFuncionario) throws BusinessException {
        if (idFuncionario == null || idFuncionario <= 0) {
            throw new BusinessException("ID do funcionário inválido");
        }
        try {
            return formacaoDAO.findByFuncionario(idFuncionario);
        } catch (DatabaseException e) {
            throw new BusinessException("Erro ao buscar formações: " + e.getMessage());
        }
    }
    
    /**
     * Busca todas as formações
     */
    public List<Formacao> listarTodas() throws BusinessException {
        try {
            return formacaoDAO.listarTodos();
        } catch (DatabaseException e) {
            throw new BusinessException("Erro ao listar formações: " + e.getMessage());
        }
    }
    
    /**
     * Conta todas as formações
     * NOVO MÉTODO
     */
    public int contarTodas() throws BusinessException {
        try {
            return formacaoDAO.contarTodas();
        } catch (DatabaseException e) {
            throw new BusinessException("Erro ao contar formações: " + e.getMessage());
        }
    }
    
    /**
     * Busca uma formação por ID
     */
    public Formacao buscarPorId(Integer id) throws BusinessException {
        if (id == null || id <= 0) {
            throw new BusinessException("ID da formação inválido");
        }
        try {
            Formacao formacao = formacaoDAO.buscarPorId(id);
            if (formacao == null) {
                throw new BusinessException("Formação não encontrada");
            }
            return formacao;
        } catch (DatabaseException e) {
            throw new BusinessException("Erro ao buscar formação: " + e.getMessage());
        }
    }
    
    /**
     * Salva uma nova formação
     */
    public void salvar(Formacao formacao) throws BusinessException {
        if (formacao == null) {
            throw new BusinessException("Formação não pode ser nula");
        }
        if (formacao.getIdFuncionario() == null || formacao.getIdFuncionario() <= 0) {
            throw new BusinessException("Funcionário é obrigatório");
        }
        if (formacao.getCurso() == null || formacao.getCurso().trim().isEmpty()) {
            throw new BusinessException("Curso é obrigatório");
        }
        try {
            formacaoDAO.salvar(formacao);
        } catch (DatabaseException e) {
            throw new BusinessException("Erro ao salvar formação: " + e.getMessage());
        }
    }
    
    /**
     * Atualiza uma formação existente
     */
    public void atualizar(Formacao formacao) throws BusinessException {
        if (formacao == null) {
            throw new BusinessException("Formação não pode ser nula");
        }
        if (formacao.getId() == null || formacao.getId() <= 0) {
            throw new BusinessException("ID da formação inválido");
        }
        try {
            formacaoDAO.atualizar(formacao);
        } catch (DatabaseException e) {
            throw new BusinessException("Erro ao atualizar formação: " + e.getMessage());
        }
    }
    
    /**
     * Exclui uma formação
     */
    public void excluir(Integer id) throws BusinessException {
        if (id == null || id <= 0) {
            throw new BusinessException("ID da formação inválido");
        }
        try {
            formacaoDAO.excluir(id);
        } catch (DatabaseException e) {
            throw new BusinessException("Erro ao excluir formação: " + e.getMessage());
        }
    }
}
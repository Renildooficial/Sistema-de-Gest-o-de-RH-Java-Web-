package com.sigrh.controller;

import com.sigrh.dao.AuditoriaDAO;
import com.sigrh.exception.DatabaseException;
import com.sigrh.model.Auditoria;
import com.sigrh.util.Constants;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.List;

@WebServlet(urlPatterns = {"/auditoria", "/auditoria/*"})
public class AuditoriaController extends HttpServlet {
    
    private static final long serialVersionUID = 1L;
    private final AuditoriaDAO auditoriaDAO;
    
    public AuditoriaController() {
        this.auditoriaDAO = new AuditoriaDAO();
    }
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String path = request.getPathInfo();
        
        if (path == null || path.equals("/")) {
            listar(request, response);
        } else if (path.equals("/estatisticas")) {
            // Estatísticas (implementar se necessário)
            response.sendRedirect(request.getContextPath() + "/auditoria");
        } else {
            response.sendError(HttpServletResponse.SC_NOT_FOUND);
        }
    }
    
    private void listar(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        try {
            List<Auditoria> logs = auditoriaDAO.findAllWithUser();
            request.setAttribute("logs", logs);
            request.setAttribute("total", logs.size());
            
            request.getRequestDispatcher("/WEB-INF/views/admin/auditoria.jsp").forward(request, response);
            
        } catch (DatabaseException e) {
            e.printStackTrace();
            request.getSession().setAttribute(Constants.MSG_ERRO, "Erro ao carregar logs: " + e.getMessage());
            response.sendRedirect(request.getContextPath() + "/dashboard");
        }
    }
}
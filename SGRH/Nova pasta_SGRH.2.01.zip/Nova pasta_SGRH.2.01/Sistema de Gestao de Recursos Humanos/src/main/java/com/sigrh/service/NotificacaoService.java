package com.sigrh.service;

import com.sigrh.dao.NotificacaoDAO;
import com.sigrh.model.Notificacao;
import com.sigrh.model.Usuario;
import com.sigrh.model.Usuario.Perfil;
import com.sigrh.util.ConfiguracaoUtil;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class NotificacaoService {
    
    private final NotificacaoDAO notificacaoDAO;
    private final UsuarioService usuarioService;
    private final ConfiguracaoUtil configuracaoUtil;
    
    public NotificacaoService() {
        this.notificacaoDAO = new NotificacaoDAO();
        this.usuarioService = new UsuarioService();
        this.configuracaoUtil = new ConfiguracaoUtil();
    }
    
    // ============================================================
    // ENVIAR NOTIFICAÇÕES
    // ============================================================
    
    public void enviarNotificacao(Integer idUsuario, String titulo, String mensagem, String tipo) throws Exception {
        Notificacao notificacao = new Notificacao(idUsuario, titulo, mensagem, tipo);
        notificacaoDAO.salvar(notificacao);
    }
    
    public void enviarNotificacao(Usuario usuario, String titulo, String mensagem, String tipo) throws Exception {
        enviarNotificacao(usuario.getId(), titulo, mensagem, tipo);
    }
    
    public void enviarParaPerfil(Perfil perfil, String titulo, String mensagem, String tipo) throws Exception {
        List<Usuario> usuarios = usuarioService.buscarPorPerfil(perfil);
        if (usuarios != null) {
            for (Usuario u : usuarios) {
                if (deveEnviarNotificacao(u, titulo)) {
                    enviarNotificacao(u.getId(), titulo, mensagem, tipo);
                }
            }
        }
    }
    
    public void enviarParaTodos(String titulo, String mensagem, String tipo) throws Exception {
        List<Usuario> usuarios = usuarioService.listarTodos();
        if (usuarios != null) {
            for (Usuario u : usuarios) {
                if (deveEnviarNotificacao(u, titulo)) {
                    enviarNotificacao(u.getId(), titulo, mensagem, tipo);
                }
            }
        }
    }
    
    // ============================================================
    // NOTIFICAÇÕES ESPECÍFICAS POR EVENTO
    // ============================================================
    
    public void notificarNovoFuncionario(Integer idFuncionario, String nome, Integer idSetor) throws Exception {
        String titulo = "🆕 Novo Funcionário Cadastrado";
        String mensagem = String.format("O funcionário %s foi cadastrado no sistema.", nome);
        
        enviarParaPerfil(Perfil.ADMIN, titulo, mensagem, "SUCESSO");
        enviarParaPerfil(Perfil.RH, titulo, mensagem, "SUCESSO");
        
        Usuario usuario = usuarioService.buscarPorFuncionario(idFuncionario);
        if (usuario != null) {
            enviarNotificacao(usuario, "👋 Bem-vindo!", 
                String.format("Seja bem-vindo(a) %s! Seu cadastro foi realizado com sucesso.", nome), 
                "SUCESSO");
        }
    }
    
    public void notificarSolicitacaoFerias(Integer idFuncionario, String nome, String periodo) throws Exception {
        String titulo = "🏖️ Nova Solicitação de Férias";
        String mensagem = String.format("O funcionário %s solicitou férias para %s.", nome, periodo);
        
        enviarParaPerfil(Perfil.ADMIN, titulo, mensagem, "AVISO");
        enviarParaPerfil(Perfil.RH, titulo, mensagem, "AVISO");
        enviarParaPerfil(Perfil.GESTOR, titulo, mensagem, "AVISO");
    }
    
    public void notificarAprovacaoFerias(Integer idFuncionario, String nome, String status) throws Exception {
        String titulo = status.equals("APROVADA") ? "✅ Férias Aprovadas" : "❌ Férias Rejeitadas";
        String mensagem = String.format("Sua solicitação de férias foi %s.", status.toLowerCase());
        
        Usuario usuario = usuarioService.buscarPorFuncionario(idFuncionario);
        if (usuario != null) {
            enviarNotificacao(usuario, titulo, mensagem, status.equals("APROVADA") ? "SUCESSO" : "ERRO");
        }
    }
    
    public void notificarNovaFormacao(Integer idFuncionario, String nome, String curso) throws Exception {
        String titulo = "🎓 Nova Formação Adicionada";
        String mensagem = String.format("A formação %s foi adicionada ao perfil de %s.", curso, nome);
        
        enviarParaPerfil(Perfil.ADMIN, titulo, mensagem, "INFO");
        enviarParaPerfil(Perfil.RH, titulo, mensagem, "INFO");
    }
    
    public void notificarFolhaProcessada(Integer mes, Integer ano, int total) throws Exception {
        String titulo = "📊 Folha de Pagamento Processada";
        String mensagem = String.format("Folha de %d/%d processada para %d funcionários.", mes, ano, total);
        
        enviarParaPerfil(Perfil.ADMIN, titulo, mensagem, "SUCESSO");
        enviarParaPerfil(Perfil.FINANCEIRO, titulo, mensagem, "SUCESSO");
    }
    
    public void notificarFolhaPaga(Integer idFolha, Integer idFuncionario, String nome) throws Exception {
        String titulo = "💰 Pagamento Confirmado";
        String mensagem = String.format("O pagamento da folha foi confirmado para %s.", nome);
        
        Usuario usuario = usuarioService.buscarPorFuncionario(idFuncionario);
        if (usuario != null) {
            enviarNotificacao(usuario, titulo, mensagem, "SUCESSO");
        }
        
        enviarParaPerfil(Perfil.FINANCEIRO, titulo, mensagem, "SUCESSO");
    }
    
    public void notificarVencimentoSenha(Integer idUsuario, String nome) throws Exception {
        String titulo = "🔑 Sua senha está prestes a expirar";
        String mensagem = String.format("Olá %s, sua senha irá expirar em breve. Por favor, altere-a.", nome);
        
        enviarNotificacao(idUsuario, titulo, mensagem, "AVISO");
    }
    
    // ============================================================
    // VERIFICAR CONFIGURAÇÕES DE NOTIFICAÇÃO
    // ============================================================
    
    private boolean deveEnviarNotificacao(Usuario usuario, String titulo) {
        try {
            // Verificar se o usuário quer receber notificações
            if (!ConfiguracaoUtil.isNotificacoesAtivas(usuario.getId())) {
                return false;
            }
            
            // Verificar configurações específicas
            String tipoNotificacao = getTipoNotificacao(titulo);
            if (tipoNotificacao != null) {
                return ConfiguracaoUtil.isTipoNotificacaoAtiva(usuario.getId(), tipoNotificacao);
            }
            
            return true;
        } catch (Exception e) {
            return true;
        }
    }
    
    private String getTipoNotificacao(String titulo) {
        if (titulo == null) return null;
        titulo = titulo.toLowerCase();
        
        if (titulo.contains("funcionário") || titulo.contains("cadastro")) {
            return "novos_funcionarios";
        } else if (titulo.contains("férias") || titulo.contains("ferias")) {
            return "solicitacoes_ferias";
        } else if (titulo.contains("alteraç") || titulo.contains("edição")) {
            return "alteracoes_dados";
        } else if (titulo.contains("senha") || titulo.contains("expirar")) {
            return "vencimento_senha";
        }
        return null;
    }
    
    // ============================================================
    // BUSCAR NOTIFICAÇÕES
    // ============================================================
    
    public List<Notificacao> buscarPorUsuario(Integer idUsuario) throws Exception {
        try {
            return notificacaoDAO.buscarPorUsuario(idUsuario);
        } catch (SQLException e) {
            throw new Exception("Erro ao buscar notificações: " + e.getMessage());
        }
    }
    
    public List<Notificacao> buscarNaoLidas(Integer idUsuario) throws Exception {
        try {
            return notificacaoDAO.buscarNaoLidas(idUsuario);
        } catch (SQLException e) {
            throw new Exception("Erro ao buscar notificações não lidas: " + e.getMessage());
        }
    }
    
    public List<Notificacao> buscarRecentes(Integer idUsuario, int limite) throws Exception {
        try {
            return notificacaoDAO.buscarRecentes(idUsuario, limite);
        } catch (SQLException e) {
            throw new Exception("Erro ao buscar notificações recentes: " + e.getMessage());
        }
    }
    
    public int contarNaoLidas(Integer idUsuario) throws Exception {
        try {
            return notificacaoDAO.contarNaoLidas(idUsuario);
        } catch (SQLException e) {
            throw new Exception("Erro ao contar notificações: " + e.getMessage());
        }
    }
    
    public void marcarComoLida(Integer id) throws Exception {
        try {
            notificacaoDAO.marcarComoLida(id);
        } catch (SQLException e) {
            throw new Exception("Erro ao marcar notificação como lida: " + e.getMessage());
        }
    }
    
    public void marcarTodasComoLidas(Integer idUsuario) throws Exception {
        try {
            notificacaoDAO.marcarTodasComoLidas(idUsuario);
        } catch (SQLException e) {
            throw new Exception("Erro ao marcar todas notificações como lidas: " + e.getMessage());
        }
    }
    
    public void deletarAntigas(Integer idUsuario, int dias) throws Exception {
        try {
            notificacaoDAO.deletarAntigas(idUsuario, dias);
        } catch (SQLException e) {
            throw new Exception("Erro ao deletar notificações antigas: " + e.getMessage());
        }
    }
}
package com.sigrh.dao;

import com.sigrh.model.Ferias;
import com.sigrh.exception.DatabaseException;
import com.sigrh.util.DatabaseUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class FeriasDAO extends GenericDAO<Ferias> {
    
    // ============================================================
    // MÉTODOS ABSTRATOS OBRIGATÓRIOS
    // ============================================================
    
    @Override
    protected String getTableName() {
        return "ferias";
    }
    
    @Override
    protected Ferias mapResultSetToEntity(ResultSet rs) throws SQLException {
        Ferias f = new Ferias();
        f.setId(rs.getInt("id"));
        f.setIdFuncionario(rs.getInt("id_funcionario"));
        f.setAnoReferencia(rs.getInt("ano_referencia"));
        f.setDataInicio(rs.getDate("data_inicio"));
        f.setDataFim(rs.getDate("data_fim"));
        f.setDiasUteis(rs.getInt("dias_uteis"));
        f.setDiasCalendario(rs.getInt("dias_calendario"));
        f.setStatus(rs.getString("status"));
        f.setDataSolicitacao(rs.getTimestamp("data_solicitacao"));
        f.setDataAprovacao(rs.getTimestamp("data_aprovacao"));
        f.setAprovadoPor(rs.getInt("aprovado_por"));
        f.setDataCheckout(rs.getTimestamp("data_checkout"));
        f.setDataCheckin(rs.getTimestamp("data_checkin"));
        f.setObservacao(rs.getString("observacao"));
        f.setMotivoRejeicao(rs.getString("motivo_rejeicao"));
        return f;
    }
    
    @Override
    protected void setInsertParameters(PreparedStatement ps, Ferias entity) throws SQLException {
        ps.setInt(1, entity.getIdFuncionario());
        ps.setInt(2, entity.getAnoReferencia() != null ? entity.getAnoReferencia() : java.time.Year.now().getValue());
        ps.setDate(3, new java.sql.Date(entity.getDataInicio().getTime()));
        ps.setDate(4, new java.sql.Date(entity.getDataFim().getTime()));
        ps.setInt(5, entity.getDiasUteis());
        ps.setInt(6, entity.getDiasCalendario());
        ps.setString(7, entity.getStatus() != null ? entity.getStatus() : "SOLICITADA");
        ps.setTimestamp(8, entity.getDataSolicitacao() != null ? new Timestamp(entity.getDataSolicitacao().getTime()) : new Timestamp(System.currentTimeMillis()));
        ps.setTimestamp(9, entity.getDataAprovacao() != null ? new Timestamp(entity.getDataAprovacao().getTime()) : null);
        if (entity.getAprovadoPor() != null) {
            ps.setInt(10, entity.getAprovadoPor());
        } else {
            ps.setNull(10, Types.INTEGER);
        }
        ps.setTimestamp(11, entity.getDataCheckout() != null ? new Timestamp(entity.getDataCheckout().getTime()) : null);
        ps.setTimestamp(12, entity.getDataCheckin() != null ? new Timestamp(entity.getDataCheckin().getTime()) : null);
        ps.setString(13, entity.getObservacao());
        ps.setString(14, entity.getMotivoRejeicao());
    }
    
    @Override
    protected void setUpdateParameters(PreparedStatement ps, Ferias entity) throws SQLException {
        ps.setInt(1, entity.getIdFuncionario());
        ps.setInt(2, entity.getAnoReferencia() != null ? entity.getAnoReferencia() : java.time.Year.now().getValue());
        ps.setDate(3, new java.sql.Date(entity.getDataInicio().getTime()));
        ps.setDate(4, new java.sql.Date(entity.getDataFim().getTime()));
        ps.setInt(5, entity.getDiasUteis());
        ps.setInt(6, entity.getDiasCalendario());
        ps.setString(7, entity.getStatus() != null ? entity.getStatus() : "SOLICITADA");
        ps.setTimestamp(8, entity.getDataSolicitacao() != null ? new Timestamp(entity.getDataSolicitacao().getTime()) : new Timestamp(System.currentTimeMillis()));
        ps.setTimestamp(9, entity.getDataAprovacao() != null ? new Timestamp(entity.getDataAprovacao().getTime()) : null);
        if (entity.getAprovadoPor() != null) {
            ps.setInt(10, entity.getAprovadoPor());
        } else {
            ps.setNull(10, Types.INTEGER);
        }
        ps.setTimestamp(11, entity.getDataCheckout() != null ? new Timestamp(entity.getDataCheckout().getTime()) : null);
        ps.setTimestamp(12, entity.getDataCheckin() != null ? new Timestamp(entity.getDataCheckin().getTime()) : null);
        ps.setString(13, entity.getObservacao());
        ps.setString(14, entity.getMotivoRejeicao());
        ps.setInt(15, entity.getId());
    }
    
    @Override
    protected String getInsertColumns() {
        return "id_funcionario, ano_referencia, data_inicio, data_fim, dias_uteis, dias_calendario, " +
               "status, data_solicitacao, data_aprovacao, aprovado_por, data_checkout, data_checkin, " +
               "observacao, motivo_rejeicao";
    }
    
    @Override
    protected String getInsertPlaceholders() {
        return "?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?";
    }
    
    @Override
    protected String getUpdateColumns() {
        return "id_funcionario = ?, ano_referencia = ?, data_inicio = ?, data_fim = ?, dias_uteis = ?, " +
               "dias_calendario = ?, status = ?, data_solicitacao = ?, data_aprovacao = ?, " +
               "aprovado_por = ?, data_checkout = ?, data_checkin = ?, observacao = ?, motivo_rejeicao = ?";
    }
    
    @Override
    protected int getUpdateParameterCount() {
        return 14;
    }
    
    @Override
    protected Integer getId(Ferias entity) {
        return entity.getId();
    }
    
    @Override
    protected void setId(Ferias entity, Integer id) {
        entity.setId(id);
    }
    
    // ============================================================
    // MÉTODOS ADICIONAIS
    // ============================================================
    
    public List<Ferias> listarTodos() throws DatabaseException {
        return findAll();
    }
    
    public Ferias buscarPorId(Integer id) throws DatabaseException {
        return findById(id);
    }
    
    public void salvar(Ferias ferias) {
        String sql = "INSERT INTO ferias (id_funcionario, ano_referencia, data_inicio, data_fim, " +
                     "dias_uteis, dias_calendario, status, data_solicitacao, observacao) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            
            System.out.println("📝 SQL INSERT: " + sql);
            System.out.println("   id_funcionario: " + ferias.getIdFuncionario());
            System.out.println("   data_inicio: " + ferias.getDataInicio());
            System.out.println("   data_fim: " + ferias.getDataFim());
            System.out.println("   dias_uteis: " + ferias.getDiasUteis());
            System.out.println("   status: " + ferias.getStatus());
            
            stmt.setInt(1, ferias.getIdFuncionario());
            stmt.setInt(2, ferias.getAnoReferencia() != null ? ferias.getAnoReferencia() : java.util.Calendar.getInstance().get(java.util.Calendar.YEAR));
            stmt.setDate(3, ferias.getDataInicio());
            stmt.setDate(4, ferias.getDataFim());
            stmt.setInt(5, ferias.getDiasUteis() != null ? ferias.getDiasUteis() : 0);
            stmt.setInt(6, ferias.getDiasCalendario() != null ? ferias.getDiasCalendario() : 0);
            stmt.setString(7, ferias.getStatus() != null ? ferias.getStatus() : "SOLICITADA");
            stmt.setTimestamp(8, ferias.getDataSolicitacao() != null ? ferias.getDataSolicitacao() : new java.sql.Timestamp(System.currentTimeMillis()));
            stmt.setString(9, ferias.getObservacao());
            
            int rows = stmt.executeUpdate();
            System.out.println("✅ Linhas afetadas: " + rows);
            
            try (ResultSet rs = stmt.getGeneratedKeys()) {
                if (rs.next()) {
                    ferias.setId(rs.getInt(1));
                    System.out.println("✅ ID gerado: " + ferias.getId());
                }
            }
        } catch (SQLException e) {
            System.err.println("❌ ERRO SQL: " + e.getMessage());
            e.printStackTrace();
            throw new RuntimeException("Erro ao salvar férias", e);
        }
    }
    
    public void atualizar(Ferias ferias) throws DatabaseException {
        update(ferias);
    }
    
    public void excluir(Integer id) throws DatabaseException {
        delete(id);
    }
    
    public int contar() throws DatabaseException {
        return count();
    }
    
    // ============================================================
    // MÉTODOS ESPECÍFICOS
    // ============================================================
    
    public List<Ferias> findByFuncionario(Integer idFuncionario) throws DatabaseException {
        List<Ferias> list = new ArrayList<>();
        String sql = "SELECT * FROM " + getTableName() + " WHERE id_funcionario = ? ORDER BY data_inicio DESC";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setInt(1, idFuncionario);
            
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(mapResultSetToEntity(rs));
                }
            }
            return list;
            
        } catch (SQLException e) {
            logger.error("Erro ao buscar férias por funcionário ID: {}", idFuncionario, e);
            throw new DatabaseException("Erro ao buscar férias: " + e.getMessage(), e);
        }
    }
    
    public List<Ferias> findByStatus(String status) throws DatabaseException {
        List<Ferias> list = new ArrayList<>();
        String sql = "SELECT * FROM " + getTableName() + " WHERE status = ? ORDER BY data_solicitacao DESC";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setString(1, status);
            
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(mapResultSetToEntity(rs));
                }
            }
            return list;
            
        } catch (SQLException e) {
            logger.error("Erro ao buscar férias por status: {}", status, e);
            throw new DatabaseException("Erro ao buscar férias: " + e.getMessage(), e);
        }
    }
    
    public List<Ferias> findPendentes() throws DatabaseException {
        return findByStatus("SOLICITADA");
    }
    
    public List<Ferias> findByPeriodo(Date dataInicio, Date dataFim) throws DatabaseException {
        List<Ferias> list = new ArrayList<>();
        String sql = "SELECT * FROM " + getTableName() + 
                    " WHERE data_inicio >= ? AND data_fim <= ? ORDER BY data_inicio";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setDate(1, dataInicio);
            ps.setDate(2, dataFim);
            
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(mapResultSetToEntity(rs));
                }
            }
            return list;
            
        } catch (SQLException e) {
            logger.error("Erro ao buscar férias por período", e);
            throw new DatabaseException("Erro ao buscar férias: " + e.getMessage(), e);
        }
    }
    
    public List<Ferias> findByAno(Integer ano) throws DatabaseException {
        List<Ferias> list = new ArrayList<>();
        String sql = "SELECT * FROM " + getTableName() + " WHERE ano_referencia = ? ORDER BY data_inicio";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setInt(1, ano);
            
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(mapResultSetToEntity(rs));
                }
            }
            return list;
            
        } catch (SQLException e) {
            logger.error("Erro ao buscar férias por ano: {}", ano, e);
            throw new DatabaseException("Erro ao buscar férias: " + e.getMessage(), e);
        }
    }
    
    public void atualizarStatus(Integer id, String status) throws DatabaseException {
        String sql = "UPDATE " + getTableName() + " SET status = ? WHERE id = ?";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setString(1, status);
            ps.setInt(2, id);
            ps.executeUpdate();
            
            logger.debug("Status da férias ID {} atualizado para {}", id, status);
            
        } catch (SQLException e) {
            logger.error("Erro ao atualizar status da férias ID: {}", id, e);
            throw new DatabaseException("Erro ao atualizar status: " + e.getMessage(), e);
        }
    }
    
    public int countByStatus(String status) throws DatabaseException {
        String sql = "SELECT COUNT(*) as total FROM " + getTableName() + " WHERE status = ?";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setString(1, status);
            
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt("total");
                }
            }
            return 0;
            
        } catch (SQLException e) {
            logger.error("Erro ao contar férias por status: {}", status, e);
            throw new DatabaseException("Erro ao contar férias: " + e.getMessage(), e);
        }
    }
    
    // ============================================================
    // MÉTODOS ADICIONADOS PARA CORRIGIR OS ERROS
    // ============================================================
    
    public int somarDiasAprovados(int idFuncionario) throws DatabaseException {
        String sql = "SELECT COALESCE(SUM(dias_uteis), 0) as total FROM " + getTableName() + 
                    " WHERE id_funcionario = ? AND status IN ('APROVADA', 'CONCLUIDA', 'EM_ANDAMENTO')";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setInt(1, idFuncionario);
            
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt("total");
                }
            }
            return 0;
            
        } catch (SQLException e) {
            logger.error("Erro ao somar dias aprovados para funcionário ID: {}", idFuncionario, e);
            throw new DatabaseException("Erro ao somar dias aprovados: " + e.getMessage(), e);
        }
    }
    
    public int somarDiasPendentes(int idFuncionario) throws DatabaseException {
        String sql = "SELECT COALESCE(SUM(dias_uteis), 0) as total FROM " + getTableName() + 
                    " WHERE id_funcionario = ? AND status = 'SOLICITADA'";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setInt(1, idFuncionario);
            
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt("total");
                }
            }
            return 0;
            
        } catch (SQLException e) {
            logger.error("Erro ao somar dias pendentes para funcionário ID: {}", idFuncionario, e);
            throw new DatabaseException("Erro ao somar dias pendentes: " + e.getMessage(), e);
        }
    }
    
    public int contarPorStatus(int idFuncionario, String status) throws DatabaseException {
        String sql = "SELECT COUNT(*) as total FROM " + getTableName() + 
                    " WHERE id_funcionario = ? AND status = ?";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setInt(1, idFuncionario);
            ps.setString(2, status);
            
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt("total");
                }
            }
            return 0;
            
        } catch (SQLException e) {
            logger.error("Erro ao contar férias por status para funcionário ID: {}", idFuncionario, e);
            throw new DatabaseException("Erro ao contar férias: " + e.getMessage(), e);
        }
    }
    
    public List<Ferias> listarPorFuncionario(int idFuncionario, String status, Date dataReferencia) 
            throws DatabaseException {
        List<Ferias> list = new ArrayList<>();
        String sql = "SELECT * FROM " + getTableName() + 
                    " WHERE id_funcionario = ? AND status = ? AND data_inicio >= ? " +
                    "ORDER BY data_inicio ASC LIMIT 1";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setInt(1, idFuncionario);
            ps.setString(2, status);
            ps.setDate(3, dataReferencia);
            
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(mapResultSetToEntity(rs));
                }
            }
            return list;
            
        } catch (SQLException e) {
            logger.error("Erro ao buscar próximas férias para funcionário ID: {}", idFuncionario, e);
            throw new DatabaseException("Erro ao buscar próximas férias: " + e.getMessage(), e);
        }
    }
    
    public List<Ferias> listarPorMes(int idFuncionario, int mes, int ano) throws DatabaseException {
        List<Ferias> list = new ArrayList<>();
        String sql = "SELECT * FROM " + getTableName() + 
                    " WHERE id_funcionario = ? " +
                    " AND MONTH(data_inicio) = ? AND YEAR(data_inicio) = ?" +
                    " UNION " +
                    "SELECT * FROM " + getTableName() + 
                    " WHERE id_funcionario = ? " +
                    " AND MONTH(data_fim) = ? AND YEAR(data_fim) = ?" +
                    " ORDER BY data_inicio";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setInt(1, idFuncionario);
            ps.setInt(2, mes);
            ps.setInt(3, ano);
            ps.setInt(4, idFuncionario);
            ps.setInt(5, mes);
            ps.setInt(6, ano);
            
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(mapResultSetToEntity(rs));
                }
            }
            return list;
            
        } catch (SQLException e) {
            logger.error("Erro ao buscar férias por mês para funcionário ID: {}", idFuncionario, e);
            throw new DatabaseException("Erro ao buscar férias por mês: " + e.getMessage(), e);
        }
    }
    
    public List<Ferias> listarAprovadasPorFuncionario(int idFuncionario) throws DatabaseException {
        String sql = "SELECT * FROM " + getTableName() + 
                    " WHERE id_funcionario = ? AND status IN ('APROVADA', 'CONCLUIDA', 'EM_ANDAMENTO')" +
                    " ORDER BY data_inicio";
        
        List<Ferias> list = new ArrayList<>();
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setInt(1, idFuncionario);
            
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(mapResultSetToEntity(rs));
                }
            }
            return list;
            
        } catch (SQLException e) {
            logger.error("Erro ao listar férias aprovadas para funcionário ID: {}", idFuncionario, e);
            throw new DatabaseException("Erro ao listar férias aprovadas: " + e.getMessage(), e);
        }
    }
    
    public List<Ferias> listarTodasFerias() throws DatabaseException {
        return findAll("ORDER BY data_inicio DESC");
    }
}
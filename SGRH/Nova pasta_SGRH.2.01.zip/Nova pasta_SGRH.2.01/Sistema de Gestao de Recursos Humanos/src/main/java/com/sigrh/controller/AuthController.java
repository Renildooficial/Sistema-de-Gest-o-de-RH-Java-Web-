package com.sigrh.controller;

import com.sigrh.exception.BusinessException;
import com.sigrh.model.Usuario;
import com.sigrh.service.AuditoriaService;
import com.sigrh.service.AuthService;
import com.sigrh.service.EmailService;
import com.sigrh.service.SistemaNotificacaoService;
import com.sigrh.util.Constants;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;

@WebServlet(urlPatterns = {"/auth/*", "/login", "/logout"})
public class AuthController extends HttpServlet {
    
    private static final long serialVersionUID = 1L;
    private final AuthService authService;
    private final SistemaNotificacaoService sistemaNotificacaoService;
    private final AuditoriaService auditoriaService;
    
    public AuthController() {
        this.authService = new AuthService();
        this.sistemaNotificacaoService = new SistemaNotificacaoService();
        this.auditoriaService = new AuditoriaService();
    }
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String path = request.getRequestURI().substring(request.getContextPath().length());
        System.out.println("🔍 AuthController.doGet - Path: " + path);
        
        // ========== ROTAS DE AUTENTICAÇÃO ==========
        if (path.equals("/login") || path.equals("/auth/login")) {
            showLogin(request, response);
        } else if (path.equals("/logout") || path.equals("/auth/logout")) {
            logout(request, response);
        } 
        // ========== ROTAS DE RECUPERAÇÃO (LINK) ==========
        else if (path.equals("/auth/recuperar-senha")) {
            showRecuperarSenhaLink(request, response);
        } else if (path.equals("/auth/nova-senha")) {
            showNovaSenhaLink(request, response);
        }
        // ========== ROTAS DE RECUPERAÇÃO (CÓDIGO) ==========
        else if (path.equals("/auth/recuperar-senha-codigo")) {
            showRecuperarSenhaCodigo(request, response);
        } else if (path.equals("/auth/verificar-codigo")) {
            showVerificarCodigo(request, response);
        } else if (path.equals("/auth/nova-senha-codigo")) {
            showNovaSenhaCodigo(request, response);
        } else {
            System.out.println("❌ Path não encontrado (GET): " + path);
            response.sendError(HttpServletResponse.SC_NOT_FOUND);
        }
    }
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String path = request.getRequestURI().substring(request.getContextPath().length());
        System.out.println("🔍 AuthController.doPost - Path: " + path);
        
        // ========== ROTAS DE AUTENTICAÇÃO ==========
        if (path.equals("/login") || path.equals("/auth/login")) {
            login(request, response);
        } else if (path.equals("/logout") || path.equals("/auth/logout")) {
            logout(request, response);
        }
        // ========== ROTAS DE RECUPERAÇÃO (LINK) ==========
        else if (path.equals("/auth/recuperar-senha")) {
            recuperarSenhaLink(request, response);
        } else if (path.equals("/auth/nova-senha")) {
            redefinirSenhaLink(request, response);
        }
        // ========== ROTAS DE RECUPERAÇÃO (CÓDIGO) ==========
        else if (path.equals("/auth/solicitar-codigo")) {
            solicitarCodigo(request, response);
        } else if (path.equals("/auth/verificar-codigo")) {
            verificarCodigo(request, response);
        } else if (path.equals("/auth/redefinir-senha-codigo")) {
            redefinirSenhaCodigo(request, response);
        } else {
            System.out.println("❌ Path não encontrado (POST): " + path);
            response.sendError(HttpServletResponse.SC_NOT_FOUND);
        }
    }
    
    // ============================================================
    // AUTENTICAÇÃO
    // ============================================================
    
    private void showLogin(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        System.out.println("📄 Mostrando página de login...");
        
        HttpSession session = request.getSession(false);
        if (session != null && session.getAttribute(Constants.SESSION_USER) != null) {
            System.out.println("✅ Usuário já logado, redirecionando para dashboard");
            response.sendRedirect(request.getContextPath() + "/dashboard");
            return;
        }
        
        request.getSession().removeAttribute(Constants.MSG_ERRO);
        request.getSession().removeAttribute(Constants.MSG_SUCESSO);
        request.getSession().removeAttribute(Constants.MSG_INFO);
        
        request.getRequestDispatcher("/WEB-INF/views/auth/login.jsp").forward(request, response);
    }
    
    private void login(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String usuario = request.getParameter("usuario");
        String senha = request.getParameter("senha");
        String ip = request.getRemoteAddr();
        String userAgent = request.getHeader("User-Agent");
        
        System.out.println("🔐 Tentativa de login - Usuário: " + usuario);
        System.out.println("📍 IP: " + ip);
        System.out.println("🌐 Navegador: " + userAgent);
        
        try {
            if (usuario == null || usuario.trim().isEmpty()) {
                throw new Exception("Usuário é obrigatório");
            }
            if (senha == null || senha.trim().isEmpty()) {
                throw new Exception("Senha é obrigatória");
            }
            
            // =============================================================
            // AUTENTICAÇÃO
            // =============================================================
            Usuario user = authService.autenticar(usuario, senha);
            
            if (user == null) {
                // =============================================================
                // NOTIFICAR TENTATIVA FALHA
                // =============================================================
                sistemaNotificacaoService.notificarTentativaFalha(usuario, ip);
                
                System.out.println("❌ Tentativa falha para: " + usuario);
                request.getSession().setAttribute(Constants.MSG_ERRO, "Usuário ou senha inválidos");
                response.sendRedirect(request.getContextPath() + "/login");
                return;
            }
            
            // =============================================================
            // NOTIFICAR LOGIN BEM-SUCEDIDO
            // =============================================================
            // 1. Notificar sobre o login atual
            sistemaNotificacaoService.notificarLogin(user, ip, userAgent);
            
            // 2. Notificar sobre o último login
            sistemaNotificacaoService.notificarUltimoLogin(user, user.getUltimoLogin());
            
            // =============================================================
            // SALVAR NA SESSÃO
            // =============================================================
            HttpSession session = request.getSession();
            session.setAttribute(Constants.SESSION_USER, user);
            session.setAttribute(Constants.SESSION_PERFIL, user.getPerfil().name());
            session.setAttribute(Constants.MSG_SUCESSO, "Bem-vindo, " + user.getNome() + "!");
            
            // =============================================================
            // REGISTRAR AUDITORIA
            // =============================================================
            auditoriaService.registrar(user, "LOGIN", "usuario", user.getId(), request);
            
            System.out.println("✅ Login bem-sucedido: " + usuario);
            response.sendRedirect(request.getContextPath() + "/dashboard");
            
        } catch (Exception e) {
            System.out.println("❌ Erro no login: " + e.getMessage());
            e.printStackTrace();
            
            // Notificar erro no login
            try {
                sistemaNotificacaoService.notificarTentativaFalha(usuario, ip);
            } catch (Exception ex) {
                System.err.println("⚠️ Erro ao notificar tentativa falha: " + ex.getMessage());
            }
            
            request.getSession().setAttribute(Constants.MSG_ERRO, e.getMessage());
            request.getRequestDispatcher("/WEB-INF/views/auth/login.jsp").forward(request, response);
        }
    }
    
 // ============================================================
    // LOGOUT - CORRIGIDO
    // ============================================================
    private void logout(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        
        HttpSession session = request.getSession(false);
        Usuario user = null;
        String ip = request.getRemoteAddr();
        
        if (session != null) {
            user = (Usuario) session.getAttribute(Constants.SESSION_USER);
            
            if (user != null) {
                // Registrar logout na auditoria - COM TRY-CATCH
                try {
                    auditoriaService.registrar(user, "LOGOUT", "usuario", user.getId(), request);
                } catch (BusinessException e) {
                    System.err.println("⚠️ Erro ao registrar logout na auditoria: " + e.getMessage());
                } catch (Exception e) {
                    System.err.println("⚠️ Erro ao registrar logout na auditoria: " + e.getMessage());
                }
                
                // Notificar logout
                try {
                    String titulo = "👋 Logout realizado";
                    String mensagem = String.format(
                        "Você saiu do sistema em %s.\n" +
                        "IP: %s",
                        new java.text.SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(new java.util.Date()),
                        ip != null ? ip : "Não disponível"
                    );
                    sistemaNotificacaoService.enviarNotificacao(
                        user.getId(),
                        titulo,
                        mensagem,
                        "INFO"
                    );
                } catch (Exception e) {
                    System.err.println("⚠️ Erro ao notificar logout: " + e.getMessage());
                }
            }
            
            session.removeAttribute(Constants.SESSION_USER);
            session.removeAttribute(Constants.SESSION_PERFIL);
            session.removeAttribute(Constants.MSG_SUCESSO);
            session.removeAttribute(Constants.MSG_ERRO);
            session.removeAttribute(Constants.MSG_INFO);
            session.invalidate();
            System.out.println("✅ Sessão invalidada");
        }
        
        HttpSession newSession = request.getSession();
        newSession.setAttribute(Constants.MSG_INFO, "Sessão encerrada com sucesso");
        
        System.out.println("🔄 Redirecionando para login...");
        response.sendRedirect(request.getContextPath() + "/login");
    }
    
    // ============================================================
    // RECUPERAÇÃO POR LINK (TOKEN)
    // ============================================================
    
    private void showRecuperarSenhaLink(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        request.getSession().removeAttribute(Constants.MSG_ERRO);
        request.getSession().removeAttribute(Constants.MSG_SUCESSO);
        request.getSession().removeAttribute(Constants.MSG_INFO);
        
        request.getRequestDispatcher("/WEB-INF/views/auth/recuperar-senha.jsp").forward(request, response);
    }
    
 // No método recuperarSenhaLink, adicione try-catch para BusinessException
    private void recuperarSenhaLink(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String email = request.getParameter("email");
        
        try {
            if (email == null || email.trim().isEmpty()) {
                throw new BusinessException("E-mail é obrigatório");
            }
            
            String token = authService.solicitarRecuperacaoSenha(email);
            Usuario usuario = authService.buscarPorEmail(email);
            
            String baseUrl = request.getScheme() + "://" + request.getServerName() + ":" + 
                            request.getServerPort() + request.getContextPath();
            
            EmailService emailService = new EmailService();
            emailService.enviarRecuperacaoSenha(email, usuario.getNome(), token, baseUrl);
            
            request.getSession().setAttribute(Constants.MSG_SUCESSO, 
                "Link de recuperação enviado para seu e-mail. Verifique sua caixa de entrada e spam.");
            response.sendRedirect(request.getContextPath() + "/login");
            
        } catch (BusinessException e) {
            request.getSession().setAttribute(Constants.MSG_ERRO, e.getMessage());
            request.getRequestDispatcher("/WEB-INF/views/auth/recuperar-senha.jsp").forward(request, response);
        } catch (Exception e) {
            request.getSession().setAttribute(Constants.MSG_ERRO, "Erro ao enviar link de recuperação: " + e.getMessage());
            request.getRequestDispatcher("/WEB-INF/views/auth/recuperar-senha.jsp").forward(request, response);
        }
    }
    
    private void showNovaSenhaLink(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String token = request.getParameter("token");
        
        if (token == null || token.trim().isEmpty()) {
            request.getSession().setAttribute(Constants.MSG_ERRO, "Token inválido");
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }
        
        try { 
            authService.validarTokenRecuperacao(token);
            request.setAttribute("token", token);
            request.getRequestDispatcher("/WEB-INF/views/auth/nova-senha.jsp").forward(request, response);
            
        } catch (BusinessException e) {
            request.getSession().setAttribute(Constants.MSG_ERRO, e.getMessage());
            response.sendRedirect(request.getContextPath() + "/login");
        }
    }
    
    private void redefinirSenhaLink(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String token = request.getParameter("token");
        String novaSenha = request.getParameter("novaSenha");
        String confirmarSenha = request.getParameter("confirmarSenha");
        
        try {
            if (token == null || token.trim().isEmpty()) {
                throw new BusinessException("Token inválido");
            }
            if (novaSenha == null || novaSenha.trim().isEmpty()) {
                throw new BusinessException("Nova senha é obrigatória");
            }
            if (!novaSenha.equals(confirmarSenha)) {
                throw new BusinessException("As senhas não coincidem");
            }
            
            authService.redefinirSenha(token, novaSenha);
            
            request.getSession().setAttribute(Constants.MSG_SUCESSO, "Senha redefinida com sucesso! Faça login.");
            response.sendRedirect(request.getContextPath() + "/login");
            
        } catch (BusinessException e) {
            request.getSession().setAttribute(Constants.MSG_ERRO, e.getMessage());
            request.setAttribute("token", token);
            request.getRequestDispatcher("/WEB-INF/views/auth/nova-senha.jsp").forward(request, response);
        }
    }
    
    // ============================================================
    // RECUPERAÇÃO POR CÓDIGO
    // ============================================================
    
    private void showRecuperarSenhaCodigo(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        request.getSession().removeAttribute(Constants.MSG_ERRO);
        request.getSession().removeAttribute(Constants.MSG_SUCESSO);
        request.getSession().removeAttribute(Constants.MSG_INFO);
        
        request.getRequestDispatcher("/WEB-INF/views/auth/recuperar-senha-codigo.jsp").forward(request, response);
    }
    
    private void solicitarCodigo(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String email = request.getParameter("email");
        
        try {
            if (email == null || email.trim().isEmpty()) {
                throw new BusinessException("E-mail é obrigatório");
            }
            
            String codigo = authService.solicitarCodigoVerificacao(email);
            Usuario usuario = authService.buscarPorEmail(email);
            
            System.out.println("========================================");
            System.out.println("🔑 CÓDIGO DE VERIFICAÇÃO:");
            System.out.println("   " + codigo);
            System.out.println("📧 E-mail: " + email);
            System.out.println("⏱️ Válido por 10 minutos");
            System.out.println("========================================");
            
            try {
                EmailService emailService = new EmailService();
                emailService.enviarCodigoVerificacao(email, usuario.getNome(), codigo);
                
                request.getSession().setAttribute(Constants.MSG_SUCESSO, 
                    "Código de verificação enviado para seu e-mail! Verifique sua caixa de entrada e spam.");
            } catch (Exception e) {
                System.out.println("⚠️ E-mail não enviado: " + e.getMessage());
                request.getSession().setAttribute(Constants.MSG_INFO, 
                    "Código gerado! Verifique o console do servidor para obter o código.");
            }
            
            request.setAttribute("email", email);
            request.getRequestDispatcher("/WEB-INF/views/auth/verificar-codigo.jsp").forward(request, response);
            
        } catch (BusinessException e) {
            request.getSession().setAttribute(Constants.MSG_ERRO, e.getMessage());
            request.getRequestDispatcher("/WEB-INF/views/auth/recuperar-senha-codigo.jsp").forward(request, response);
        }
    }
    
    private void showVerificarCodigo(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String email = (String) request.getSession().getAttribute("emailRecuperacao");
        if (email == null) {
            email = request.getParameter("email");
        }
        
        if (email == null || email.trim().isEmpty()) {
            response.sendRedirect(request.getContextPath() + "/auth/recuperar-senha-codigo");
            return;
        }
        
        request.setAttribute("email", email);
        request.getSession().setAttribute("emailRecuperacao", email);
        request.getRequestDispatcher("/WEB-INF/views/auth/verificar-codigo.jsp").forward(request, response);
    }
    
    private void verificarCodigo(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String email = request.getParameter("email");
        String codigo = request.getParameter("codigo");
        
        try {
            if (email == null || email.trim().isEmpty()) {
                throw new BusinessException("E-mail é obrigatório");
            }
            if (codigo == null || codigo.trim().isEmpty()) {
                throw new BusinessException("Código é obrigatório");
            }
            
            authService.validarCodigoVerificacao(email, codigo);
            
            request.getSession().setAttribute("codigoValidado", true);
            request.getSession().setAttribute("emailRecuperacao", email);
            
            request.getSession().setAttribute(Constants.MSG_SUCESSO, "Código verificado com sucesso! Defina sua nova senha.");
            response.sendRedirect(request.getContextPath() + "/auth/nova-senha-codigo");
            
        } catch (BusinessException e) {
            request.getSession().setAttribute(Constants.MSG_ERRO, e.getMessage());
            request.setAttribute("email", email);
            request.getRequestDispatcher("/WEB-INF/views/auth/verificar-codigo.jsp").forward(request, response);
        }
    }
    
    private void showNovaSenhaCodigo(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        Boolean codigoValidado = (Boolean) request.getSession().getAttribute("codigoValidado");
        String email = (String) request.getSession().getAttribute("emailRecuperacao");
        
        if (codigoValidado == null || !codigoValidado || email == null) {
            request.getSession().setAttribute(Constants.MSG_ERRO, "Código não validado. Solicite um novo código.");
            response.sendRedirect(request.getContextPath() + "/auth/recuperar-senha-codigo");
            return;
        }
        
        request.setAttribute("email", email);
        request.getRequestDispatcher("/WEB-INF/views/auth/nova-senha-codigo.jsp").forward(request, response);
    }
    
    private void redefinirSenhaCodigo(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String email = request.getParameter("email");
        String codigo = request.getParameter("codigo");
        String novaSenha = request.getParameter("novaSenha");
        String confirmarSenha = request.getParameter("confirmarSenha");
        
        try {
            if (email == null || email.trim().isEmpty()) {
                throw new BusinessException("E-mail é obrigatório");
            }
            if (codigo == null || codigo.trim().isEmpty()) {
                throw new BusinessException("Código é obrigatório");
            }
            if (novaSenha == null || novaSenha.trim().isEmpty()) {
                throw new BusinessException("Nova senha é obrigatória");
            }
            if (!novaSenha.equals(confirmarSenha)) {
                throw new BusinessException("As senhas não coincidem");
            }
            
            authService.redefinirSenhaComCodigo(email, codigo, novaSenha);
            
            request.getSession().removeAttribute("codigoValidado");
            request.getSession().removeAttribute("emailRecuperacao");
            
            request.getSession().setAttribute(Constants.MSG_SUCESSO, "Senha redefinida com sucesso! Faça login.");
            response.sendRedirect(request.getContextPath() + "/login");
            
        } catch (BusinessException e) {
            request.getSession().setAttribute(Constants.MSG_ERRO, e.getMessage());
            request.setAttribute("email", email);
            request.setAttribute("codigo", codigo);
            request.getRequestDispatcher("/WEB-INF/views/auth/nova-senha-codigo.jsp").forward(request, response);
        }
    }
}
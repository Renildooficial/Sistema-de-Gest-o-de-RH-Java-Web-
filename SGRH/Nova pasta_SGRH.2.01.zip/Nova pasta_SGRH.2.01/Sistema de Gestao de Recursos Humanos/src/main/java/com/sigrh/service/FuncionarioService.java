package com.sigrh.service;

import com.sigrh.dao.*;
import com.sigrh.exception.BusinessException;
import com.sigrh.exception.DatabaseException;
import com.sigrh.model.*;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.math.BigDecimal;
import java.sql.Date;
import java.sql.Timestamp;
import java.util.*;

public class FuncionarioService {
    
    private static final Logger logger = LogManager.getLogger(FuncionarioService.class);
    
    private final FuncionarioDAO funcionarioDAO;
    private final SetorDAO setorDAO;
    private final EnderecoDAO enderecoDAO;
    private final AgregadoFamiliarDAO agregadoDAO;
    private final FormacaoDAO formacaoDAO;
    private final NomeacaoDAO nomeacaoDAO;
    private final UsuarioDAO usuarioDAO;
    private final FolhaPagamentoDAO folhaDAO;
    
    public FuncionarioService() {
        this.funcionarioDAO = new FuncionarioDAO();
        this.setorDAO = new SetorDAO();
        this.enderecoDAO = new EnderecoDAO();
        this.agregadoDAO = new AgregadoFamiliarDAO();
        this.formacaoDAO = new FormacaoDAO();
        this.nomeacaoDAO = new NomeacaoDAO();
        this.usuarioDAO = new UsuarioDAO();
        this.folhaDAO = new FolhaPagamentoDAO();
    }
    
    // ============================================================
    // MÉTODOS PRINCIPAIS - FUNCIONÁRIOS
    // ============================================================
    
    public Funcionario cadastrar(Funcionario funcionario) throws BusinessException {
        logger.info("Cadastrando novo funcionário: {}", funcionario.getNome());
        
        try {
            validarDados(funcionario);
            
            // Verificar NUIT
            if (funcionario.getNuit() != null && !funcionario.getNuit().isEmpty()) {
                if (funcionarioDAO.findByNuit(funcionario.getNuit()) != null) {
                    throw new BusinessException("NUIT já cadastrado");
                }
            }
            
            // Verificar BI
            if (funcionario.getBi() != null && !funcionario.getBi().isEmpty()) {
                if (funcionarioDAO.findByBi(funcionario.getBi()) != null) {
                    throw new BusinessException("BI já cadastrado");
                }
            }
            
            // Garantir que IDs sejam NULL se forem 0
            if (funcionario.getIdUsuario() != null && funcionario.getIdUsuario() == 0) {
                funcionario.setIdUsuario(null);
            }
            
            if (funcionario.getIdSetor() != null && funcionario.getIdSetor() == 0) {
                funcionario.setIdSetor(null);
            }
            
            if (funcionario.getIdSetor() != null) {
                Setor setor = setorDAO.findById(funcionario.getIdSetor());
                if (setor == null) {
                    throw new BusinessException("Setor não encontrado");
                }
                funcionario.setSetor(setor);
            }
            
            funcionario = funcionarioDAO.insert(funcionario);
            logger.info("Funcionário cadastrado com sucesso ID: {}", funcionario.getId());
            return funcionario;
            
        } catch (DatabaseException e) {
            logger.error("Erro ao cadastrar funcionário: {}", funcionario.getNome(), e);
            throw new BusinessException("Erro ao cadastrar funcionário", e);
        }
    }
    
    /**
     * ATUALIZAR FUNCIONÁRIO - MÉTODO ÚNICO (REMOVA O DUPLICADO)
     */
    public Funcionario atualizar(Funcionario funcionario) throws BusinessException {
        logger.info("Atualizando funcionário ID: {}", funcionario.getId());
        
        try {
            validarDados(funcionario);
            
            Funcionario existente = funcionarioDAO.findById(funcionario.getId());
            if (existente == null) {
                throw new BusinessException("Funcionário não encontrado");
            }
            
            // Verificar NUIT duplicado
            if (funcionario.getNuit() != null && !funcionario.getNuit().isEmpty()) {
                Funcionario porNuit = funcionarioDAO.findByNuit(funcionario.getNuit());
                if (porNuit != null && !porNuit.getId().equals(funcionario.getId())) {
                    throw new BusinessException("NUIT já cadastrado por outro funcionário");
                }
            }
            
            // Verificar BI duplicado
            if (funcionario.getBi() != null && !funcionario.getBi().isEmpty()) {
                Funcionario porBi = funcionarioDAO.findByBi(funcionario.getBi());
                if (porBi != null && !porBi.getId().equals(funcionario.getId())) {
                    throw new BusinessException("BI já cadastrado por outro funcionário");
                }
            }
            
            // Garantir que IDs sejam NULL se forem 0
            if (funcionario.getIdUsuario() != null && funcionario.getIdUsuario() == 0) {
                funcionario.setIdUsuario(null);
            }
            
            if (funcionario.getIdSetor() != null && funcionario.getIdSetor() == 0) {
                funcionario.setIdSetor(null);
            }
            
            if (funcionario.getIdSetor() != null) {
                Setor setor = setorDAO.findById(funcionario.getIdSetor());
                if (setor == null) {
                    throw new BusinessException("Setor não encontrado");
                }
                funcionario.setSetor(setor);
            }
            
            funcionario = funcionarioDAO.update(funcionario);
            logger.info("Funcionário atualizado com sucesso ID: {}", funcionario.getId());
            return funcionario;
            
        } catch (DatabaseException e) {
            logger.error("Erro ao atualizar funcionário ID: {}", funcionario.getId(), e);
            throw new BusinessException("Erro ao atualizar funcionário", e);
        }
    }
    
    public Funcionario buscarCompleto(Integer id) throws BusinessException {
        logger.info("Buscando funcionário completo ID: {}", id);
        
        try {
            Funcionario funcionario = funcionarioDAO.findById(id);
            if (funcionario == null) {
                throw new BusinessException("Funcionário não encontrado");
            }
            
            if (funcionario.getIdSetor() != null && funcionario.getIdSetor() > 0) {
                funcionario.setSetor(setorDAO.findById(funcionario.getIdSetor()));
            }
            if (funcionario.getIdUsuario() != null && funcionario.getIdUsuario() > 0) {
                funcionario.setUsuario(usuarioDAO.findById(funcionario.getIdUsuario()));
            }
            
            return funcionario;
            
        } catch (DatabaseException e) {
            logger.error("Erro ao buscar funcionário ID: {}", id, e);
            throw new BusinessException("Erro ao buscar funcionário", e);
        }
    }
    
    public Funcionario buscarPorId(Integer id) throws BusinessException {
        try {
            Funcionario funcionario = funcionarioDAO.findById(id);
            if (funcionario == null) {
                throw new BusinessException("Funcionário não encontrado");
            }
            return funcionario;
        } catch (DatabaseException e) {
            logger.error("Erro ao buscar funcionário ID: {}", id, e);
            throw new BusinessException("Erro ao buscar funcionário", e);
        }
    }
    
    public List<Funcionario> listarTodos() throws BusinessException {
        try {
            List<Funcionario> funcionarios = funcionarioDAO.findAll();
            for (Funcionario f : funcionarios) {
                if (f.getIdSetor() != null && f.getIdSetor() > 0) {
                    try {
                        Setor setor = setorDAO.findById(f.getIdSetor());
                        f.setSetor(setor);
                    } catch (DatabaseException e) {
                        // Ignorar erro - setor fica null
                    }
                }
            }
            return funcionarios;
        } catch (DatabaseException e) {
            logger.error("Erro ao listar funcionários", e);
            throw new BusinessException("Erro ao listar funcionários", e);
        }
    }
    
    public List<Funcionario> listarAtivos() throws BusinessException {
        try {
            return funcionarioDAO.findAtivos();
        } catch (DatabaseException e) {
            logger.error("Erro ao listar funcionários ativos", e);
            throw new BusinessException("Erro ao listar funcionários ativos", e);
        }
    }
    
    public List<Funcionario> listarPorSetor(Integer idSetor) throws BusinessException {
        try {
            if (idSetor == null || idSetor <= 0) {
                return new ArrayList<>();
            }
            Setor setor = setorDAO.findById(idSetor);
            if (setor == null) {
                throw new BusinessException("Setor não encontrado");
            }
            return funcionarioDAO.findBySetor(idSetor);
        } catch (DatabaseException e) {
            logger.error("Erro ao listar funcionários do setor ID: {}", idSetor, e);
            throw new BusinessException("Erro ao listar funcionários do setor", e);
        }
    }
    
    public List<Funcionario> listarPorStatus(String status) throws BusinessException {
        try {
            if (status == null || status.isEmpty()) {
                return funcionarioDAO.findAll();
            }
            return funcionarioDAO.findByStatus(status);
        } catch (DatabaseException e) {
            logger.error("Erro ao listar funcionários por status: {}", status, e);
            throw new BusinessException("Erro ao listar funcionários por status", e);
        }
    }
    
    public List<Funcionario> pesquisarPorNome(String nome) throws BusinessException {
        try {
            if (nome == null || nome.trim().isEmpty()) {
                return funcionarioDAO.findAll();
            }
            return funcionarioDAO.findByNomeContaining(nome.trim());
        } catch (DatabaseException e) {
            logger.error("Erro ao pesquisar funcionários por nome: {}", nome, e);
            throw new BusinessException("Erro ao pesquisar funcionários", e);
        }
    }
    
    public void excluir(Integer id) throws BusinessException {
        logger.info("Excluindo funcionário ID: {}", id);
        
        try {
            Funcionario funcionario = funcionarioDAO.findById(id);
            if (funcionario == null) {
                throw new BusinessException("Funcionário não encontrado");
            }
            
            funcionarioDAO.delete(id);
            logger.info("Funcionário ID {} excluído com sucesso", id);
            
        } catch (DatabaseException e) {
            logger.error("Erro ao excluir funcionário ID: {}", id, e);
            throw new BusinessException("Erro ao excluir funcionário", e);
        }
    }
    
    public FuncionarioDAO.FuncionarioStats getEstatisticas() throws BusinessException {
        try {
            return funcionarioDAO.getStats();
        } catch (DatabaseException e) {
            logger.error("Erro ao obter estatísticas", e);
            throw new BusinessException("Erro ao obter estatísticas", e);
        }
    }
    
    private void validarDados(Funcionario funcionario) throws BusinessException {
        if (funcionario.getNome() == null || funcionario.getNome().trim().isEmpty()) {
            throw new BusinessException("Nome é obrigatório");
        }
        if (funcionario.getNome().length() < 3) {
            throw new BusinessException("Nome deve ter no mínimo 3 caracteres");
        }
        if (funcionario.getDataNascimento() == null) {
            throw new BusinessException("Data de nascimento é obrigatória");
        }
        if (funcionario.getDataAdmissao() == null) {
            throw new BusinessException("Data de admissão é obrigatória");
        }
        if (funcionario.getTelefone() == null || funcionario.getTelefone().trim().isEmpty()) {
            throw new BusinessException("Telefone é obrigatório");
        }
        if (funcionario.getNuit() == null || funcionario.getNuit().trim().isEmpty()) {
            throw new BusinessException("NUIT é obrigatório");
        }
        if (funcionario.getNumeroConta() == null || funcionario.getNumeroConta().trim().isEmpty()) {
            throw new BusinessException("Número de conta é obrigatório");
        }
        if (funcionario.getBanco() == null || funcionario.getBanco().trim().isEmpty()) {
            throw new BusinessException("Banco é obrigatório");
        }
        
        if (funcionario.getDataAdmissao() != null && funcionario.getDataNascimento() != null) {
            if (funcionario.getDataAdmissao().before(funcionario.getDataNascimento())) {
                throw new BusinessException("Data de admissão não pode ser anterior à data de nascimento");
            }
        }
    }
    
    // ============================================================
    // MÉTODOS PARA AGREGADOS FAMILIARES
    // ============================================================
    
    public AgregadoFamiliar buscarAgregado(Integer id) throws BusinessException {
        try {
            return agregadoDAO.findById(id);
        } catch (DatabaseException e) {
            logger.error("Erro ao buscar agregado ID: {}", id, e);
            throw new BusinessException("Erro ao buscar agregado", e);
        }
    }
    
    public List<AgregadoFamiliar> listarAgregados(Integer idFuncionario) throws BusinessException {
        try {
            return agregadoDAO.findByFuncionario(idFuncionario);
        } catch (DatabaseException e) {
            logger.error("Erro ao listar agregados do funcionário ID: {}", idFuncionario, e);
            throw new BusinessException("Erro ao listar agregados", e);
        }
    }
    
    public List<AgregadoFamiliar> listarTodosAgregados() throws BusinessException {
        try {
            List<AgregadoFamiliar> agregados = agregadoDAO.findAll();
            for (AgregadoFamiliar a : agregados) {
                if (a.getIdFuncionario() != null) {
                    a.setFuncionario(funcionarioDAO.findById(a.getIdFuncionario()));
                }
            }
            return agregados;
        } catch (DatabaseException e) {
            logger.error("Erro ao listar todos os agregados", e);
            throw new BusinessException("Erro ao listar agregados", e);
        }
    }
    
    public AgregadoFamiliar adicionarAgregado(AgregadoFamiliar agregado) throws BusinessException {
        logger.info("Adicionando agregado ao funcionário ID: {}", agregado.getIdFuncionario());
        
        try {
            validarAgregado(agregado);
            
            if (funcionarioDAO.findById(agregado.getIdFuncionario()) == null) {
                throw new BusinessException("Funcionário não encontrado");
            }
            
            return agregadoDAO.insert(agregado);
            
        } catch (DatabaseException e) {
            logger.error("Erro ao adicionar agregado", e);
            throw new BusinessException("Erro ao adicionar agregado", e);
        }
    }
    
    public AgregadoFamiliar atualizarAgregado(AgregadoFamiliar agregado) throws BusinessException {
        logger.info("Atualizando agregado ID: {}", agregado.getId());
        
        try {
            validarAgregado(agregado);
            
            if (agregadoDAO.findById(agregado.getId()) == null) {
                throw new BusinessException("Agregado não encontrado");
            }
            
            if (funcionarioDAO.findById(agregado.getIdFuncionario()) == null) {
                throw new BusinessException("Funcionário não encontrado");
            }
            
            return agregadoDAO.update(agregado);
            
        } catch (DatabaseException e) {
            logger.error("Erro ao atualizar agregado ID: {}", agregado.getId(), e);
            throw new BusinessException("Erro ao atualizar agregado", e);
        }
    }
    
    public void excluirAgregado(Integer id) throws BusinessException {
        logger.info("Excluindo agregado ID: {}", id);
        
        try {
            if (agregadoDAO.findById(id) == null) {
                throw new BusinessException("Agregado não encontrado");
            }
            agregadoDAO.delete(id);
            
        } catch (DatabaseException e) {
            logger.error("Erro ao excluir agregado ID: {}", id, e);
            throw new BusinessException("Erro ao excluir agregado", e);
        }
    }
    
    private void validarAgregado(AgregadoFamiliar agregado) throws BusinessException {
        if (agregado.getIdFuncionario() == null) {
            throw new BusinessException("Funcionário é obrigatório");
        }
        if (agregado.getNome() == null || agregado.getNome().trim().isEmpty()) {
            throw new BusinessException("Nome do agregado é obrigatório");
        }
        if (agregado.getNome().length() < 3) {
            throw new BusinessException("Nome deve ter no mínimo 3 caracteres");
        }
        if (agregado.getNome().length() > 100) {
            throw new BusinessException("Nome deve ter no máximo 100 caracteres");
        }
        if (agregado.getGrauParentesco() == null) {
            throw new BusinessException("Grau de parentesco é obrigatório");
        }
        if (agregado.getDataNascimento() == null) {
            throw new BusinessException("Data de nascimento é obrigatória");
        }
    }
    
    // ============================================================
    // MÉTODOS PARA FORMAÇÕES
    // ============================================================
    
    public Formacao buscarFormacao(Integer id) throws BusinessException {
        try {
            return formacaoDAO.findById(id);
        } catch (DatabaseException e) {
            logger.error("Erro ao buscar formação ID: {}", id, e);
            throw new BusinessException("Erro ao buscar formação", e);
        }
    }
    
    public List<Formacao> listarFormacoes(Integer idFuncionario) throws BusinessException {
        try {
            return formacaoDAO.findByFuncionario(idFuncionario);
        } catch (DatabaseException e) {
            logger.error("Erro ao listar formações do funcionário ID: {}", idFuncionario, e);
            throw new BusinessException("Erro ao listar formações", e);
        }
    }
    
    public List<Formacao> listarTodasFormacoes() throws BusinessException {
        try {
            List<Formacao> formacoes = formacaoDAO.findAll();
            for (Formacao f : formacoes) {
                if (f.getIdFuncionario() != null) {
                    f.setFuncionario(funcionarioDAO.findById(f.getIdFuncionario()));
                }
            }
            return formacoes;
        } catch (DatabaseException e) {
            logger.error("Erro ao listar todas as formações", e);
            throw new BusinessException("Erro ao listar formações", e);
        }
    }
    
    public Formacao adicionarFormacao(Formacao formacao) throws BusinessException {
        logger.info("Adicionando formação ao funcionário ID: {}", formacao.getIdFuncionario());
        
        try {
            validarFormacao(formacao);
            
            if (funcionarioDAO.findById(formacao.getIdFuncionario()) == null) {
                throw new BusinessException("Funcionário não encontrado");
            }
            
            return formacaoDAO.insert(formacao);
            
        } catch (DatabaseException e) {
            logger.error("Erro ao adicionar formação", e);
            throw new BusinessException("Erro ao adicionar formação", e);
        }
    }
    
    public Formacao atualizarFormacao(Formacao formacao) throws BusinessException {
        logger.info("Atualizando formação ID: {}", formacao.getId());
        
        try {
            validarFormacao(formacao);
            
            if (formacaoDAO.findById(formacao.getId()) == null) {
                throw new BusinessException("Formação não encontrada");
            }
            
            if (funcionarioDAO.findById(formacao.getIdFuncionario()) == null) {
                throw new BusinessException("Funcionário não encontrado");
            }
            
            return formacaoDAO.update(formacao);
            
        } catch (DatabaseException e) {
            logger.error("Erro ao atualizar formação ID: {}", formacao.getId(), e);
            throw new BusinessException("Erro ao atualizar formação", e);
        }
    }
    
    public void excluirFormacao(Integer id) throws BusinessException {
        logger.info("Excluindo formação ID: {}", id);
        
        try {
            if (formacaoDAO.findById(id) == null) {
                throw new BusinessException("Formação não encontrada");
            }
            formacaoDAO.delete(id);
            
        } catch (DatabaseException e) {
            logger.error("Erro ao excluir formação ID: {}", id, e);
            throw new BusinessException("Erro ao excluir formação", e);
        }
    }
    
    private void validarFormacao(Formacao formacao) throws BusinessException {
        if (formacao.getIdFuncionario() == null) {
            throw new BusinessException("Funcionário é obrigatório");
        }
        if (formacao.getCurso() == null || formacao.getCurso().trim().isEmpty()) {
            throw new BusinessException("Curso é obrigatório");
        }
        if (formacao.getCurso().length() < 3) {
            throw new BusinessException("Curso deve ter no mínimo 3 caracteres");
        }
        if (formacao.getNivel() == null) {
            throw new BusinessException("Nível é obrigatório");
        }
        if (formacao.getInstituicao() == null || formacao.getInstituicao().trim().isEmpty()) {
            throw new BusinessException("Instituição é obrigatória");
        }
        if (formacao.getDataInicio() == null) {
            throw new BusinessException("Data de início é obrigatória");
        }
        if (formacao.getDataConclusao() == null) {
            throw new BusinessException("Data de conclusão é obrigatória");
        }
        if (formacao.getDataConclusao().before(formacao.getDataInicio())) {
            throw new BusinessException("Data de conclusão não pode ser anterior à data de início");
        }
        if (formacao.getCargaHoraria() != null && formacao.getCargaHoraria() <= 0) {
            throw new BusinessException("Carga horária deve ser maior que zero");
        }
    }
    
    // ============================================================
    // MÉTODOS PARA NOMEAÇÕES
    // ============================================================
    
    public Nomeacao buscarNomeacao(Integer id) throws BusinessException {
        try {
            return nomeacaoDAO.findById(id);
        } catch (DatabaseException e) {
            logger.error("Erro ao buscar nomeação ID: {}", id, e);
            throw new BusinessException("Erro ao buscar nomeação", e);
        }
    }
    
    public List<Nomeacao> listarNomeacoes(Integer idFuncionario) throws BusinessException {
        try {
            return nomeacaoDAO.findByFuncionario(idFuncionario);
        } catch (DatabaseException e) {
            logger.error("Erro ao listar nomeações do funcionário ID: {}", idFuncionario, e);
            throw new BusinessException("Erro ao listar nomeações", e);
        }
    }
    
    public List<Nomeacao> listarTodasNomeacoes() throws BusinessException {
        try {
            List<Nomeacao> nomeacoes = nomeacaoDAO.findAll();
            for (Nomeacao n : nomeacoes) {
                if (n.getIdFuncionario() != null) {
                    n.setFuncionario(funcionarioDAO.findById(n.getIdFuncionario()));
                }
            }
            return nomeacoes;
        } catch (DatabaseException e) {
            logger.error("Erro ao listar todas as nomeações", e);
            throw new BusinessException("Erro ao listar nomeações", e);
        }
    }
    
    public List<Nomeacao> listarNomeacoesAtivas() throws BusinessException {
        try {
            return nomeacaoDAO.findAtivas();
        } catch (DatabaseException e) {
            logger.error("Erro ao listar nomeações ativas", e);
            throw new BusinessException("Erro ao listar nomeações ativas", e);
        }
    }
    
    public Nomeacao adicionarNomeacao(Nomeacao nomeacao) throws BusinessException {
        logger.info("Adicionando nomeação ao funcionário ID: {}", nomeacao.getIdFuncionario());
        
        try {
            validarNomeacao(nomeacao);
            
            if (funcionarioDAO.findById(nomeacao.getIdFuncionario()) == null) {
                throw new BusinessException("Funcionário não encontrado");
            }
            
            if (nomeacao.isAtiva()) {
                List<Nomeacao> atuais = nomeacaoDAO.findByFuncionario(nomeacao.getIdFuncionario());
                for (Nomeacao n : atuais) {
                    if (n.isAtiva()) {
                        n.setStatus("ENCERRADA");
                        nomeacaoDAO.update(n);
                    }
                }
            }
            
            return nomeacaoDAO.insert(nomeacao);
            
        } catch (DatabaseException e) {
            logger.error("Erro ao adicionar nomeação", e);
            throw new BusinessException("Erro ao adicionar nomeação", e);
        }
    }
    
    public Nomeacao atualizarNomeacao(Nomeacao nomeacao) throws BusinessException {
        logger.info("Atualizando nomeação ID: {}", nomeacao.getId());
        
        try {
            validarNomeacao(nomeacao);
            
            if (nomeacaoDAO.findById(nomeacao.getId()) == null) {
                throw new BusinessException("Nomeação não encontrada");
            }
            
            if (funcionarioDAO.findById(nomeacao.getIdFuncionario()) == null) {
                throw new BusinessException("Funcionário não encontrado");
            }
            
            return nomeacaoDAO.update(nomeacao);
            
        } catch (DatabaseException e) {
            logger.error("Erro ao atualizar nomeação ID: {}", nomeacao.getId(), e);
            throw new BusinessException("Erro ao atualizar nomeação", e);
        }
    }
    
    public void excluirNomeacao(Integer id) throws BusinessException {
        logger.info("Excluindo nomeação ID: {}", id);
        
        try {
            if (nomeacaoDAO.findById(id) == null) {
                throw new BusinessException("Nomeação não encontrada");
            }
            nomeacaoDAO.delete(id);
            
        } catch (DatabaseException e) {
            logger.error("Erro ao excluir nomeação ID: {}", id, e);
            throw new BusinessException("Erro ao excluir nomeação", e);
        }
    }
    
    public void encerrarNomeacao(Integer id) throws BusinessException {
        logger.info("Encerrando nomeação ID: {}", id);
        
        try {
            Nomeacao nomeacao = nomeacaoDAO.findById(id);
            if (nomeacao == null) {
                throw new BusinessException("Nomeação não encontrada");
            }
            if (!nomeacao.isAtiva()) {
                throw new BusinessException("Nomeação já está encerrada");
            }
            
            nomeacao.setStatus("ENCERRADA");
            nomeacaoDAO.update(nomeacao);
            
        } catch (DatabaseException e) {
            logger.error("Erro ao encerrar nomeação ID: {}", id, e);
            throw new BusinessException("Erro ao encerrar nomeação", e);
        }
    }
    
    private void validarNomeacao(Nomeacao nomeacao) throws BusinessException {
        if (nomeacao.getIdFuncionario() == null) {
            throw new BusinessException("Funcionário é obrigatório");
        }
        if (nomeacao.getFuncao() == null || nomeacao.getFuncao().trim().isEmpty()) {
            throw new BusinessException("Função é obrigatória");
        }
        if (nomeacao.getCargo() == null || nomeacao.getCargo().trim().isEmpty()) {
            throw new BusinessException("Cargo é obrigatório");
        }
        if (nomeacao.getDespacho() == null || nomeacao.getDespacho().trim().isEmpty()) {
            throw new BusinessException("Despacho é obrigatório");
        }
        if (nomeacao.getDataNomeacao() == null) {
            throw new BusinessException("Data de nomeação é obrigatória");
        }
        if (nomeacao.getDataInicio() == null) {
            throw new BusinessException("Data de início é obrigatória");
        }
        if (nomeacao.getDataFim() != null && nomeacao.getDataFim().before(nomeacao.getDataInicio())) {
            throw new BusinessException("Data de fim não pode ser anterior à data de início");
        }
        if (nomeacao.getStatus() == null) {
            throw new BusinessException("Status é obrigatório");
        }
    }
    
    // ============================================================
    // MÉTODOS PARA FOLHA DE PAGAMENTO
    // ============================================================
    
    public FolhaPagamento buscarFolha(Integer id) throws BusinessException {
        try {
            return folhaDAO.findById(id);
        } catch (DatabaseException e) {
            logger.error("Erro ao buscar folha ID: {}", id, e);
            throw new BusinessException("Erro ao buscar folha", e);
        }
    }
    
    public List<FolhaPagamento> listarFolhasPorFuncionario(Integer idFuncionario) throws BusinessException {
        try {
            return folhaDAO.findByFuncionario(idFuncionario);
        } catch (DatabaseException e) {
            logger.error("Erro ao listar folhas do funcionário ID: {}", idFuncionario, e);
            throw new BusinessException("Erro ao listar folhas", e);
        }
    }
    
    public List<FolhaPagamento> listarTodasFolhas() throws BusinessException {
        try {
            List<FolhaPagamento> folhas = folhaDAO.findAll();
            for (FolhaPagamento f : folhas) {
                if (f.getIdFuncionario() != null) {
                    f.setFuncionario(funcionarioDAO.findById(f.getIdFuncionario()));
                }
            }
            return folhas;
        } catch (DatabaseException e) {
            logger.error("Erro ao listar todas as folhas", e);
            throw new BusinessException("Erro ao listar folhas", e);
        }
    }
    
    public List<FolhaPagamento> listarFolhasPorMesAno(Integer mes, Integer ano) throws BusinessException {
        try {
            return folhaDAO.findByMesAno(mes, ano);
        } catch (DatabaseException e) {
            logger.error("Erro ao listar folhas por mês {} e ano {}", mes, ano, e);
            throw new BusinessException("Erro ao listar folhas", e);
        }
    }
    
    public List<FolhaPagamento> processarFolha(Integer mes, Integer ano) throws BusinessException {
        logger.info("Processando folha de pagamento - Mês: {}, Ano: {}", mes, ano);
        
        try {
            List<Funcionario> funcionarios = funcionarioDAO.findAtivos();
            List<FolhaPagamento> folhasProcessadas = new ArrayList<>();
            
            for (Funcionario funcionario : funcionarios) {
                FolhaPagamento existente = folhaDAO.findByFuncionarioMesAno(funcionario.getId(), mes, ano);
                if (existente != null) {
                    logger.warn("Folha já existe para funcionário ID {} - Mês: {}/{}", funcionario.getId(), mes, ano);
                    continue;
                }
                
                FolhaPagamento folha = new FolhaPagamento();
                folha.setIdFuncionario(funcionario.getId());
                folha.setMesReferencia(mes);
                folha.setAnoReferencia(ano);
                
                BigDecimal salarioBase = funcionario.getSalarioBase() != null ? funcionario.getSalarioBase() : BigDecimal.ZERO;
                folha.setSalarioBase(salarioBase);
                folha.setSubsidioAlimentacao(funcionario.getSubsidioAlimentacao() != null ? funcionario.getSubsidioAlimentacao() : BigDecimal.ZERO);
                folha.setSubsidioTransporte(funcionario.getSubsidioTransporte() != null ? funcionario.getSubsidioTransporte() : BigDecimal.ZERO);
                folha.setSubsidioSaude(funcionario.getSubsidioSaude() != null ? funcionario.getSubsidioSaude() : BigDecimal.ZERO);
                folha.setBonus(BigDecimal.ZERO);
                folha.setOutrosGanhos(BigDecimal.ZERO);
                
                folha.setDescontoIrs(calcularIRS(salarioBase));
                folha.setDescontoInss(calcularINSS(salarioBase));
                folha.setDescontoSaude(BigDecimal.ZERO);
                folha.setDescontoOutros(BigDecimal.ZERO);
                
                folha.calcularTotais();
                folha.setStatus(FolhaPagamento.StatusFolha.PROCESSADO);
                folha.setDataProcessamento(new Timestamp(System.currentTimeMillis()));
                
                folhasProcessadas.add(folhaDAO.insert(folha));
            }
            
            logger.info("Folha processada com sucesso - {} registros gerados", folhasProcessadas.size());
            return folhasProcessadas;
            
        } catch (DatabaseException e) {
            logger.error("Erro ao processar folha", e);
            throw new BusinessException("Erro ao processar folha", e);
        }
    }
    
    private BigDecimal calcularIRS(BigDecimal salarioBase) {
        if (salarioBase.compareTo(new BigDecimal("30000")) > 0) {
            return salarioBase.multiply(new BigDecimal("0.20"));
        } else if (salarioBase.compareTo(new BigDecimal("20000")) > 0) {
            return salarioBase.multiply(new BigDecimal("0.15"));
        } else if (salarioBase.compareTo(new BigDecimal("10000")) > 0) {
            return salarioBase.multiply(new BigDecimal("0.10"));
        } else {
            return salarioBase.multiply(new BigDecimal("0.05"));
        }
    }
    
    private BigDecimal calcularINSS(BigDecimal salarioBase) {
        return salarioBase.multiply(new BigDecimal("0.11"));
    }
    
    public Map<String, BigDecimal> getEstatisticasFinanceiras(Integer mes, Integer ano) throws BusinessException {
        try {
            Map<String, BigDecimal> stats = new LinkedHashMap<>();
            
            List<FolhaPagamento> folhas = folhaDAO.findByMesAno(mes, ano);
            BigDecimal totalBruto = BigDecimal.ZERO;
            BigDecimal totalLiquido = BigDecimal.ZERO;
            
            for (FolhaPagamento f : folhas) {
                if (f.getTotalBruto() != null) {
                    totalBruto = totalBruto.add(f.getTotalBruto());
                }
                if (f.getTotalLiquido() != null) {
                    totalLiquido = totalLiquido.add(f.getTotalLiquido());
                }
            }
            
            stats.put("totalBruto", totalBruto);
            stats.put("totalLiquido", totalLiquido);
            stats.put("totalDescontos", totalBruto.subtract(totalLiquido));
            
            return stats;
            
        } catch (DatabaseException e) {
            logger.error("Erro ao obter estatísticas financeiras", e);
            throw new BusinessException("Erro ao obter estatísticas financeiras", e);
        }
    }
    
    public FolhaPagamento atualizarFolha(FolhaPagamento folha) throws BusinessException {
        try {
            return folhaDAO.update(folha);
        } catch (DatabaseException e) {
            logger.error("Erro ao atualizar folha ID: {}", folha.getId(), e);
            throw new BusinessException("Erro ao atualizar folha", e);
        }
    }
    
    // ============================================================
    // MÉTODOS PARA SALÁRIOS
    // ============================================================
    
    public void atualizarSalario(Integer id, BigDecimal salarioBase, 
                                BigDecimal subsidioAlimentacao, 
                                BigDecimal subsidioTransporte, 
                                BigDecimal subsidioSaude) throws BusinessException {
        try {
            Funcionario funcionario = buscarPorId(id);
            if (funcionario == null) {
                throw new BusinessException("Funcionário não encontrado");
            }
            
            funcionario.setSalarioBase(salarioBase);
            funcionario.setSubsidioAlimentacao(subsidioAlimentacao);
            funcionario.setSubsidioTransporte(subsidioTransporte);
            funcionario.setSubsidioSaude(subsidioSaude);
            
            funcionarioDAO.update(funcionario);
            
        } catch (Exception e) {
            throw new BusinessException("Erro ao atualizar salário: " + e.getMessage());
        }
    }
}
package com.sigrh.service;
import java.math.BigDecimal;
import com.sigrh.exception.BusinessException;


import com.sigrh.dao.ConfiguracaoDAO;
import com.sigrh.exception.BusinessException;
import com.sigrh.exception.DatabaseException;
import com.sigrh.model.Configuracao;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.sigrh.exception.BusinessException;

public class ConfiguracaoService {
    
    private static final Logger logger = LogManager.getLogger(ConfiguracaoService.class);
    private final ConfiguracaoDAO configuracaoDAO;
    
    public ConfiguracaoService() {
        this.configuracaoDAO = new ConfiguracaoDAO();
    }
    
    // ============================================================
    // MÉTODOS PRINCIPAIS
    // ============================================================
    
    public List<Configuracao> listarTodos() throws BusinessException {
        try {
            return configuracaoDAO.listarTodos();
        } catch (DatabaseException e) {
            logger.error("Erro ao listar configurações", e);
            throw new BusinessException("Erro ao listar configurações", e);
        }
    }
    
    public Configuracao buscarPorChave(String chave) throws BusinessException {
        try {
            return configuracaoDAO.buscarPorChave(chave);
        } catch (DatabaseException e) {
            logger.error("Erro ao buscar configuração: {}", chave, e);
            throw new BusinessException("Erro ao buscar configuração", e);
        }
    }
    
    public String getValor(String chave) throws BusinessException {
        try {
            return configuracaoDAO.getValor(chave);
        } catch (DatabaseException e) {
            logger.error("Erro ao buscar valor: {}", chave, e);
            throw new BusinessException("Erro ao buscar valor", e);
        }
    }
    
    public String getValor(String chave, String defaultValue) {
        try {
            String valor = configuracaoDAO.getValor(chave);
            return valor != null ? valor : defaultValue;
        } catch (DatabaseException e) {
            logger.error("Erro ao buscar valor: {}", chave, e);
            return defaultValue;
        }
    }
    
    public int getValorInt(String chave, int defaultValue) {
        try {
            String valor = configuracaoDAO.getValor(chave);
            if (valor != null) {
                try {
                    return Integer.parseInt(valor);
                } catch (NumberFormatException e) {
                    return defaultValue;
                }
            }
            return defaultValue;
        } catch (DatabaseException e) {
            logger.error("Erro ao buscar valor int: {}", chave, e);
            return defaultValue;
        }
    }
    
    public boolean getValorBoolean(String chave, boolean defaultValue) {
        try {
            String valor = configuracaoDAO.getValor(chave);
            if (valor != null) {
                return "true".equalsIgnoreCase(valor) || "1".equals(valor) || "on".equalsIgnoreCase(valor);
            }
            return defaultValue;
        } catch (DatabaseException e) {
            logger.error("Erro ao buscar valor boolean: {}", chave, e);
            return defaultValue;
        }
    }
    
    public void salvarConfiguracao(String chave, String valor, String descricao, String categoria, String tipo) 
            throws BusinessException {
        try {
            Configuracao existente = configuracaoDAO.buscarPorChave(chave);
            
            if (existente != null) {
                existente.setValor(valor);
                if (descricao != null) existente.setDescricao(descricao);
                if (categoria != null) existente.setCategoria(categoria);
                if (tipo != null) existente.setTipo(tipo);
                configuracaoDAO.atualizar(existente);
            } else {
                Configuracao nova = new Configuracao();
                nova.setChave(chave);
                nova.setValor(valor);
                nova.setDescricao(descricao != null ? descricao : "");
                nova.setCategoria(categoria != null ? categoria : "GERAL");
                nova.setTipo(tipo != null ? tipo : "TEXT");
                configuracaoDAO.salvar(nova);
            }
            
            logger.info("Configuração salva: {} = {}", chave, valor);
            
        } catch (DatabaseException e) {
            logger.error("Erro ao salvar configuração: {}", chave, e);
            throw new BusinessException("Erro ao salvar configuração", e);
        }
    }
    
    public void salvarConfiguracoes(Map<String, String> configuracoes) throws BusinessException {
        try {
            for (Map.Entry<String, String> entry : configuracoes.entrySet()) {
                String chave = entry.getKey();
                String valor = entry.getValue();
                
                Configuracao existente = configuracaoDAO.buscarPorChave(chave);
                
                if (existente != null) {
                    existente.setValor(valor);
                    configuracaoDAO.atualizar(existente);
                } else {
                    Configuracao nova = new Configuracao();
                    nova.setChave(chave);
                    nova.setValor(valor);
                    nova.setCategoria("GERAL");
                    nova.setTipo("TEXT");
                    configuracaoDAO.salvar(nova);
                }
            }
            
            logger.info("{} configurações salvas", configuracoes.size());
            
        } catch (DatabaseException e) {
            logger.error("Erro ao salvar configurações", e);
            throw new BusinessException("Erro ao salvar configurações", e);
        }
    }
    
    // ============================================================
    // MÉTODOS ESPECÍFICOS
    // ============================================================
    
    public Map<String, Object> getConfiguracoesCompletas() throws BusinessException {
        try {
            Map<String, Object> config = new HashMap<>();
            List<Configuracao> list = configuracaoDAO.listarTodos();
            
            for (Configuracao c : list) {
                String chave = c.getChave();
                String valor = c.getValor();
                
                // Converter para o tipo correto
                if ("BOOLEAN".equals(c.getTipo())) {
                    config.put(chave, "true".equalsIgnoreCase(valor) || "1".equals(valor));
                } else if ("NUMBER".equals(c.getTipo())) {
                    try {
                        config.put(chave, Double.parseDouble(valor));
                    } catch (NumberFormatException e) {
                        config.put(chave, 0);
                    }
                } else {
                    config.put(chave, valor);
                }
            }
            
            return config;
            
        } catch (DatabaseException e) {
            logger.error("Erro ao buscar configurações completas", e);
            throw new BusinessException("Erro ao buscar configurações", e);
        }
    }
    
    public Map<String, String> getConfiguracoesPorCategoria(String categoria) throws BusinessException {
        try {
            Map<String, String> config = new HashMap<>();
            List<Configuracao> list = configuracaoDAO.findByCategoria(categoria);
            
            for (Configuracao c : list) {
                config.put(c.getChave(), c.getValor());
            }
            
            return config;
            
        } catch (DatabaseException e) {
            logger.error("Erro ao buscar configurações por categoria: {}", categoria, e);
            throw new BusinessException("Erro ao buscar configurações", e);
        }
    }
    
    public void atualizarConfiguracoesEmpresa(String nome, String email, String telefone, String logo) 
            throws BusinessException {
        try {
            if (nome != null) configuracaoDAO.setValor("empresa_nome", nome);
            if (email != null) configuracaoDAO.setValor("empresa_email", email);
            if (telefone != null) configuracaoDAO.setValor("empresa_telefone", telefone);
            if (logo != null) configuracaoDAO.setValor("empresa_logo", logo);
            
            logger.info("Configurações da empresa atualizadas");
            
        } catch (DatabaseException e) {
            logger.error("Erro ao atualizar configurações da empresa", e);
            throw new BusinessException("Erro ao atualizar configurações", e);
        }
    }
    
    public void atualizarConfiguracoesFinanceiras(String diasFerias, String taxaIrs, String taxaInss) 
            throws BusinessException {
        try {
            if (diasFerias != null) configuracaoDAO.setValor("dias_ferias", diasFerias);
            if (taxaIrs != null) configuracaoDAO.setValor("taxa_irs", taxaIrs);
            if (taxaInss != null) configuracaoDAO.setValor("taxa_inss", taxaInss);
            
            logger.info("Configurações financeiras atualizadas");
            
        } catch (DatabaseException e) {
            logger.error("Erro ao atualizar configurações financeiras", e);
            throw new BusinessException("Erro ao atualizar configurações", e);
        }
    }
    
    public void atualizarConfiguracoesSeguranca(String expiraSenha, String tentativasLogin, 
                                                  String minCaracteres, String sessaoTimeout) 
            throws BusinessException {
        try {
            if (expiraSenha != null) configuracaoDAO.setValor("expira_senha", expiraSenha);
            if (tentativasLogin != null) configuracaoDAO.setValor("tentativas_login", tentativasLogin);
            if (minCaracteres != null) configuracaoDAO.setValor("min_caracteres_senha", minCaracteres);
            if (sessaoTimeout != null) configuracaoDAO.setValor("sessao_timeout", sessaoTimeout);
            
            logger.info("Configurações de segurança atualizadas");
            
        } catch (DatabaseException e) {
            logger.error("Erro ao atualizar configurações de segurança", e);
            throw new BusinessException("Erro ao atualizar configurações", e);
        }
    }
    
    public void atualizarNotificacoes(Map<String, Boolean> notificacoes) throws BusinessException {
        try {
            for (Map.Entry<String, Boolean> entry : notificacoes.entrySet()) {
                configuracaoDAO.setValor(entry.getKey(), entry.getValue() ? "true" : "false");
            }
            
            logger.info("Configurações de notificações atualizadas");
            
        } catch (DatabaseException e) {
            logger.error("Erro ao atualizar notificações", e);
            throw new BusinessException("Erro ao atualizar notificações", e);
        }
    }
    /**
     * Busca o valor de uma configuração pelo chave
     */
    public String getConfiguracao(String chave) throws BusinessException {
        try {
            Configuracao config = configuracaoDAO.findByChave(chave);
            return config != null ? config.getValor() : null;
        } catch (Exception e) {
            throw new BusinessException("Erro ao buscar configuração: " + e.getMessage());
        }
    }

    /**
     * Busca valor como BigDecimal
     */
    public BigDecimal getConfiguracaoBigDecimal(String chave) {
        try {
            String valor = getConfiguracao(chave);
            if (valor != null && !valor.isEmpty()) {
                return new BigDecimal(valor);
            }
        } catch (Exception e) {
            // Ignorar
        }
        return BigDecimal.ZERO;
    }

    /**
     * Taxa de IRS (em percentual)
     */
    public BigDecimal getTaxaIrs() {
        return getConfiguracaoBigDecimal("taxa_irs");
    }

    /**
     * Taxa de INSS (em percentual)
     */
    public BigDecimal getTaxaInss() {
        return getConfiguracaoBigDecimal("taxa_inss");
    }

    /**
     * Subsídio de Alimentação
     */
    public BigDecimal getSubsidioAlimentacao() {
        return getConfiguracaoBigDecimal("subsidio_alimentacao");
    }

    /**
     * Subsídio de Transporte
     */
    public BigDecimal getSubsidioTransporte() {
        return getConfiguracaoBigDecimal("subsidio_transporte");
    }

    /**
     * Subsídio de Saúde
     */
    public BigDecimal getSubsidioSaude() {
        return getConfiguracaoBigDecimal("subsidio_saude");
    }
}
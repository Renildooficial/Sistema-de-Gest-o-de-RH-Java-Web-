package com.sigrh.dao;

import com.sigrh.model.Formacao;
import com.sigrh.exception.DatabaseException;
import com.sigrh.util.DatabaseUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class FormacaoDAO extends GenericDAO<Formacao> {
    
    // ============================================================
    // MÉTODOS ABSTRATOS OBRIGATÓRIOS
    // ============================================================
    
    @Override
    protected String getTableName() {
        return "formacao";
    }
    
    @Override
    protected Formacao mapResultSetToEntity(ResultSet rs) throws SQLException {
        Formacao f = new Formacao();
        f.setId(rs.getInt("id"));
        f.setIdFuncionario(rs.getInt("id_funcionario"));
        f.setNivel(rs.getString("nivel"));
        f.setCurso(rs.getString("curso"));
        f.setInstituicao(rs.getString("instituicao"));
        f.setLocal(rs.getString("local"));
        f.setDataInicio(rs.getDate("data_inicio"));
        f.setDataConclusao(rs.getDate("data_conclusao"));
        f.setCargaHoraria(rs.getInt("carga_horaria"));
        f.setCertificado(rs.getBoolean("certificado"));
        f.setStatus(rs.getString("status"));
        f.setObservacao(rs.getString("observacao"));
        f.setDataCadastro(rs.getTimestamp("data_cadastro"));
        
        // ============================================================
        // NOVOS CAMPOS
        // ============================================================
        f.setFuncoes(rs.getString("funcoes"));
        f.setCargo(rs.getString("cargo"));
        
        return f;
    }
    
    @Override
    protected void setInsertParameters(PreparedStatement ps, Formacao entity) throws SQLException {
        ps.setInt(1, entity.getIdFuncionario());
        ps.setString(2, entity.getNivel());
        ps.setString(3, entity.getCurso());
        ps.setString(4, entity.getInstituicao());
        ps.setString(5, entity.getLocal());
        ps.setDate(6, new java.sql.Date(entity.getDataInicio().getTime()));
        ps.setDate(7, new java.sql.Date(entity.getDataConclusao().getTime()));
        ps.setInt(8, entity.getCargaHoraria() != null ? entity.getCargaHoraria() : 0);
        ps.setBoolean(9, entity.getCertificado() != null && entity.getCertificado());
        ps.setString(10, entity.getStatus());
        ps.setString(11, entity.getObservacao());
        // ============================================================
        // NOVOS CAMPOS
        // ============================================================
        ps.setString(12, entity.getFuncoes());
        ps.setString(13, entity.getCargo());
    }
    
    @Override
    protected void setUpdateParameters(PreparedStatement ps, Formacao entity) throws SQLException {
        ps.setInt(1, entity.getIdFuncionario());
        ps.setString(2, entity.getNivel());
        ps.setString(3, entity.getCurso());
        ps.setString(4, entity.getInstituicao());
        ps.setString(5, entity.getLocal());
        ps.setDate(6, new java.sql.Date(entity.getDataInicio().getTime()));
        ps.setDate(7, new java.sql.Date(entity.getDataConclusao().getTime()));
        ps.setInt(8, entity.getCargaHoraria() != null ? entity.getCargaHoraria() : 0);
        ps.setBoolean(9, entity.getCertificado() != null && entity.getCertificado());
        ps.setString(10, entity.getStatus());
        ps.setString(11, entity.getObservacao());
        // ============================================================
        // NOVOS CAMPOS
        // ============================================================
        ps.setString(12, entity.getFuncoes());
        ps.setString(13, entity.getCargo());
        ps.setInt(14, entity.getId());
    }
    
    @Override
    protected String getInsertColumns() {
        return "id_funcionario, nivel, curso, instituicao, local, data_inicio, data_conclusao, " +
               "carga_horaria, certificado, status, observacao, funcoes, cargo";
    }
    
    @Override
    protected String getInsertPlaceholders() {
        return "?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?";
    }
    
    @Override
    protected String getUpdateColumns() {
        return "id_funcionario = ?, nivel = ?, curso = ?, instituicao = ?, local = ?, " +
               "data_inicio = ?, data_conclusao = ?, carga_horaria = ?, certificado = ?, " +
               "status = ?, observacao = ?, funcoes = ?, cargo = ?";
    }
    
    @Override
    protected int getUpdateParameterCount() {
        return 13;
    }
    
    @Override
    protected Integer getId(Formacao entity) {
        return entity.getId();
    }
    
    @Override
    protected void setId(Formacao entity, Integer id) {
        entity.setId(id);
    }
    
    // ============================================================
    // MÉTODOS ADICIONAIS
    // ============================================================
    
    public List<Formacao> listarTodos() throws DatabaseException {
        return findAll();
    }
    
    public Formacao buscarPorId(Integer id) throws DatabaseException {
        return findById(id);
    }
    
    public void salvar(Formacao formacao) throws DatabaseException {
        insert(formacao);
    }
    
    public void atualizar(Formacao formacao) throws DatabaseException {
        update(formacao);
    }
    
    public void excluir(Integer id) throws DatabaseException {
        delete(id);
    }
    
    /**
     * Conta o total de formações cadastradas
     * NOVO MÉTODO ADICIONADO
     */
    public int contarTodas() throws DatabaseException {
        String sql = "SELECT COUNT(*) as total FROM " + getTableName();
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt("total");
                }
            }
            return 0;
            
        } catch (SQLException e) {
            logger.error("Erro ao contar formações", e);
            throw new DatabaseException("Erro ao contar formações: " + e.getMessage(), e);
        }
    }
    
    /**
     * Conta formações por status
     */
    public int contarPorStatus(String status) throws DatabaseException {
        String sql = "SELECT COUNT(*) as total FROM " + getTableName() + " WHERE status = ?";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setString(1, status);
            
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt("total");
                }
            }
            return 0;
            
        } catch (SQLException e) {
            logger.error("Erro ao contar formações por status", e);
            throw new DatabaseException("Erro ao contar formações por status: " + e.getMessage(), e);
        }
    }
    
    public List<Formacao> findByFuncionario(Integer idFuncionario) throws DatabaseException {
        List<Formacao> list = new ArrayList<>();
        String sql = "SELECT * FROM " + getTableName() + " WHERE id_funcionario = ? ORDER BY data_inicio DESC";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setInt(1, idFuncionario);
            
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(mapResultSetToEntity(rs));
                }
            }
            
            return list;
            
        } catch (SQLException e) {
            logger.error("Erro ao buscar formações por funcionário", e);
            throw new DatabaseException("Erro ao buscar formações por funcionário: " + e.getMessage(), e);
        }
    }
    
    public List<Formacao> findByNivel(String nivel) throws DatabaseException {
        List<Formacao> list = new ArrayList<>();
        String sql = "SELECT * FROM " + getTableName() + " WHERE nivel = ? ORDER BY data_conclusao DESC";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setString(1, nivel);
            
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(mapResultSetToEntity(rs));
                }
            }
            
            return list;
            
        } catch (SQLException e) {
            logger.error("Erro ao buscar formações por nível", e);
            throw new DatabaseException("Erro ao buscar formações por nível: " + e.getMessage(), e);
        }
    }
}
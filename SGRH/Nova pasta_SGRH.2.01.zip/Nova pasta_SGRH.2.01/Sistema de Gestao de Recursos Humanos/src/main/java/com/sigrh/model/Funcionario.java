package com.sigrh.model;

import java.math.BigDecimal;
import java.sql.Date;
import java.util.Arrays;

public class Funcionario extends BaseModel {
    
    private static final long serialVersionUID = 1L;
    
    public enum EstadoCivil { SOLTEIRO, CASADO, DIVORCIADO, VIUVO, UNIAO_ESTAVEL }
    public enum StatusFuncionario { ATIVO, INATIVO, LICENCA, FERIAS, AFASTADO }
    
    private String nome;
    private Date dataNascimento;
    private String provincia;
    private String distrito;
    private EstadoCivil estadoCivil;
    private String nomeConjuge;
    private Date dataAdmissao;
    private String telefone;
    private String nuit;
    private String numeroConta;
    private String banco;
    private StatusFuncionario status;
    private byte[] foto;
    private Integer idSetor;
    private Integer idUsuario;
    private String emailEmpresa;
    private String rg;
    private String bi;  // ← BI (Bilhete de Identidade) em vez de CPF
    
 // Em Funcionario.java - adicione estes campos
    private BigDecimal salarioBase;
    private BigDecimal subsidioAlimentacao;
    private BigDecimal subsidioTransporte;
    private BigDecimal subsidioSaude;
    
    // Objetos relacionados
    private Setor setor;
    private Usuario usuario;
    
    public Funcionario() {
        super();
        this.status = StatusFuncionario.ATIVO;
    }
    
    // Getters e Setters
    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }
    
    public Date getDataNascimento() { return dataNascimento; }
    public void setDataNascimento(Date dataNascimento) { this.dataNascimento = dataNascimento; }
    
    public String getProvincia() { return provincia; }
    public void setProvincia(String provincia) { this.provincia = provincia; }
    
    public String getDistrito() { return distrito; }
    public void setDistrito(String distrito) { this.distrito = distrito; }
    
    public EstadoCivil getEstadoCivil() { return estadoCivil; }
    public void setEstadoCivil(EstadoCivil estadoCivil) { this.estadoCivil = estadoCivil; }
    public void setEstadoCivil(String estadoCivil) {
        if (estadoCivil != null && !estadoCivil.isEmpty()) {
            try {
                this.estadoCivil = EstadoCivil.valueOf(estadoCivil);
            } catch (IllegalArgumentException e) {
                System.out.println("⚠️ Estado civil inválido: " + estadoCivil + " - Usando SOLTEIRO");
                this.estadoCivil = EstadoCivil.SOLTEIRO;
            }
        } else {
            this.estadoCivil = EstadoCivil.SOLTEIRO;
        }
    }
    public String getNomeConjuge() { return nomeConjuge; }
    public void setNomeConjuge(String nomeConjuge) { this.nomeConjuge = nomeConjuge; }
    
    public Date getDataAdmissao() { return dataAdmissao; }
    public void setDataAdmissao(Date dataAdmissao) { this.dataAdmissao = dataAdmissao; }
    
    public String getTelefone() { return telefone; }
    public void setTelefone(String telefone) { this.telefone = telefone; }
    
    public String getNuit() { return nuit; }
    public void setNuit(String nuit) { this.nuit = nuit; }
    
    public String getNumeroConta() { return numeroConta; }
    public void setNumeroConta(String numeroConta) { this.numeroConta = numeroConta; }
    
    public String getBanco() { return banco; }
    public void setBanco(String banco) { this.banco = banco; }
    
    public StatusFuncionario getStatus() { return status; }
    public void setStatus(StatusFuncionario status) { this.status = status; }
    public void setStatus(String status) { this.status = StatusFuncionario.valueOf(status); }
    
    public byte[] getFoto() { return foto; }
    public void setFoto(byte[] foto) { this.foto = foto; }
    
    public Integer getIdSetor() { return idSetor; }
    public void setIdSetor(Integer idSetor) { this.idSetor = idSetor; }
    
    public Integer getIdUsuario() { return idUsuario; }
    public void setIdUsuario(Integer idUsuario) { this.idUsuario = idUsuario; }
    
    public String getEmailEmpresa() { return emailEmpresa; }
    public void setEmailEmpresa(String emailEmpresa) { this.emailEmpresa = emailEmpresa; }
    
    public String getRg() { return rg; }
    public void setRg(String rg) { this.rg = rg; }
    
    public String getBi() { return bi; }  // ← BI
    public void setBi(String bi) { this.bi = bi; }
    
    // ==================== MÉTODOS DE CONVENIÊNCIA ====================
    public Setor getSetor() { return setor; }
    public void setSetor(Setor setor) { 
        this.setor = setor; 
        if (setor != null) this.idSetor = setor.getId();
    }
    
    public Usuario getUsuario() { return usuario; }
    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
        if (usuario != null) this.idUsuario = usuario.getId();
    }
    public String getFotoBase64() {
        if (this.foto != null && this.foto.length > 0) {
            try {
                return java.util.Base64.getEncoder().encodeToString(this.foto);
            } catch (Exception e) {
                System.err.println("Erro ao converter foto para Base64: " + e.getMessage());
                return null;
            }
        }
        return null;
    }
    
    public BigDecimal getSalarioBase() { return salarioBase; }
    public void setSalarioBase(BigDecimal salarioBase) { this.salarioBase = salarioBase; }

    public BigDecimal getSubsidioAlimentacao() { return subsidioAlimentacao; }
    public void setSubsidioAlimentacao(BigDecimal subsidioAlimentacao) { this.subsidioAlimentacao = subsidioAlimentacao; }

    public BigDecimal getSubsidioTransporte() { return subsidioTransporte; }
    public void setSubsidioTransporte(BigDecimal subsidioTransporte) { this.subsidioTransporte = subsidioTransporte; }

    public BigDecimal getSubsidioSaude() { return subsidioSaude; }
    public void setSubsidioSaude(BigDecimal subsidioSaude) { this.subsidioSaude = subsidioSaude; }
    
    public boolean isAtivo() { return status == StatusFuncionario.ATIVO; }
    
    @Override
    public String toString() {
        return String.format("Funcionario{id=%d, nome='%s', nuit='%s'}", id, nome, nuit);
    }
}
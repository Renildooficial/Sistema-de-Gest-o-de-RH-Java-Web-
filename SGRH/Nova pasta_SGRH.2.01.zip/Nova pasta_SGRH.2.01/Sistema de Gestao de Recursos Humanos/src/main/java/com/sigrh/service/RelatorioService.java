package com.sigrh.service;

import com.sigrh.dao.*;
import com.sigrh.exception.BusinessException;
import com.sigrh.model.*;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.math.BigDecimal;
import java.util.*;

public class RelatorioService {
    
    private static final Logger logger = LogManager.getLogger(RelatorioService.class);
    
    private final FuncionarioDAO funcionarioDAO;
    private final SetorDAO setorDAO;
    private final FeriasDAO feriasDAO;
    private final FolhaPagamentoDAO folhaDAO;
    private final AgregadoFamiliarDAO agregadoDAO;
    private final FormacaoDAO formacaoDAO;
    private final NomeacaoDAO nomeacaoDAO;
    
    public RelatorioService() {
        this.funcionarioDAO = new FuncionarioDAO();
        this.setorDAO = new SetorDAO();
        this.feriasDAO = new FeriasDAO();
        this.folhaDAO = new FolhaPagamentoDAO();
        this.agregadoDAO = new AgregadoFamiliarDAO();
        this.formacaoDAO = new FormacaoDAO();
        this.nomeacaoDAO = new NomeacaoDAO();
    }
    
    // ============================================================
    // RELATÓRIO DE FUNCIONÁRIOS
    // ============================================================
    
    public Map<String, Integer> relatorioFuncionariosPorSetor() throws BusinessException {
        logger.info("Gerando relatório de funcionários por setor");
        
        try {
            Map<String, Integer> resultado = new LinkedHashMap<>();
            List<Setor> setores = setorDAO.findAtivos();
            
            for (Setor setor : setores) {
                int count = funcionarioDAO.countBySetor(setor.getId());
                resultado.put(setor.getNome(), count);
            }
            
            return resultado;
            
        } catch (Exception e) {
            logger.error("Erro ao gerar relatório de funcionários por setor", e);
            throw new BusinessException("Erro ao gerar relatório", e);
        }
    }
    
    public Map<String, Integer> relatorioStatusFuncionarios() throws BusinessException {
        logger.info("Gerando relatório de status dos funcionários");
        
        try {
            FuncionarioDAO.FuncionarioStats stats = funcionarioDAO.getStats();
            
            Map<String, Integer> resultado = new LinkedHashMap<>();
            resultado.put("Ativos", stats.ativos);
            resultado.put("Em Férias", stats.ferias);
            resultado.put("Inativos", stats.inativos);
            resultado.put("Licença", stats.licenca);
            resultado.put("Afastados", stats.afastados);
            
            return resultado;
            
        } catch (Exception e) {
            logger.error("Erro ao gerar relatório de status", e);
            throw new BusinessException("Erro ao gerar relatório", e);
        }
    }
    
    // ============================================================
    // RELATÓRIO DE FÉRIAS
    // ============================================================
    
    public Map<String, Integer> relatorioFeriasPorStatus() throws BusinessException {
        logger.info("Gerando relatório de férias por status");
        
        try {
            Map<String, Integer> resultado = new LinkedHashMap<>();
            resultado.put("SOLICITADA", 0);
            resultado.put("APROVADA", 0);
            resultado.put("REJEITADA", 0);
            resultado.put("EM_ANDAMENTO", 0);
            resultado.put("CONCLUIDA", 0);
            resultado.put("CANCELADA", 0);
            
            // Buscar dados reais se o método existir
            try {
                for (String status : resultado.keySet()) {
                    List<Ferias> lista = feriasDAO.findByStatus(status);
                    resultado.put(status, lista != null ? lista.size() : 0);
                }
            } catch (Exception e) {
                logger.warn("Erro ao buscar dados reais de férias, usando valores padrão", e);
            }
            
            return resultado;
            
        } catch (Exception e) {
            logger.error("Erro ao gerar relatório de férias por status", e);
            throw new BusinessException("Erro ao gerar relatório de férias", e);
        }
    }
    
    // ============================================================
    // RELATÓRIO FINANCEIRO
    // ============================================================
    
    public Map<String, BigDecimal> relatorioFolhaPorMes(int ano) throws BusinessException {
        logger.info("Gerando relatório financeiro para o ano: {}", ano);
        
        try {
            Map<String, BigDecimal> resultado = new LinkedHashMap<>();
            String[] meses = {"Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho",
                             "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"};
            
            for (int mes = 1; mes <= 12; mes++) {
                List<FolhaPagamento> folhas = folhaDAO.findByMesAno(mes, ano);
                
                BigDecimal total = BigDecimal.ZERO;
                if (folhas != null) {
                    for (FolhaPagamento folha : folhas) {
                        if (folha.getTotalLiquido() != null) {
                            total = total.add(folha.getTotalLiquido());
                        }
                    }
                }
                
                resultado.put(meses[mes - 1], total);
            }
            
            return resultado;
            
        } catch (Exception e) {
            logger.error("Erro ao gerar relatório financeiro", e);
            throw new BusinessException("Erro ao gerar relatório financeiro", e);
        }
    }
    
    // ============================================================
    // RELATÓRIO DE AGREGADOS
    // ============================================================
    
    public List<Map<String, Object>> relatorioAgregadosPorFuncionario() throws BusinessException {
        logger.info("Gerando relatório de agregados por funcionário");
        
        try {
            List<Map<String, Object>> resultado = new ArrayList<>();
            List<Funcionario> funcionarios = funcionarioDAO.findAll();
            
            for (Funcionario func : funcionarios) {
                List<AgregadoFamiliar> agregados = agregadoDAO.findByFuncionario(func.getId());
                
                Map<String, Object> item = new LinkedHashMap<>();
                item.put("funcionarioId", func.getId());
                item.put("funcionarioNome", func.getNome());
                item.put("totalAgregados", agregados != null ? agregados.size() : 0);
                item.put("agregados", agregados != null ? agregados : new ArrayList<>());
                
                resultado.add(item);
            }
            
            return resultado;
            
        } catch (Exception e) {
            logger.error("Erro ao gerar relatório de agregados", e);
            throw new BusinessException("Erro ao gerar relatório de agregados", e);
        }
    }
    
    public Map<String, Integer> relatorioAgregadosPorParentesco() throws BusinessException {
        logger.info("Gerando relatório de agregados por parentesco");
        
        try {
            Map<String, Integer> resultado = new LinkedHashMap<>();
            resultado.put("CONJUGE", 0);
            resultado.put("FILHO", 0);
            resultado.put("FILHA", 0);
            resultado.put("PAI", 0);
            resultado.put("MAE", 0);
            resultado.put("IRMAO", 0);
            resultado.put("IRMA", 0);
            resultado.put("AVO", 0);
            resultado.put("OUTRO", 0);
            
            try {
                for (String grau : resultado.keySet()) {
                    List<AgregadoFamiliar> lista = agregadoDAO.findByGrauParentesco(grau);
                    resultado.put(grau, lista != null ? lista.size() : 0);
                }
            } catch (Exception e) {
                logger.warn("Erro ao buscar dados reais de agregados", e);
            }
            
            return resultado;
            
        } catch (Exception e) {
            logger.error("Erro ao gerar relatório de agregados por parentesco", e);
            throw new BusinessException("Erro ao gerar relatório", e);
        }
    }
    
    // ============================================================
    // RELATÓRIO DE FORMAÇÕES
    // ============================================================
    
    public List<Map<String, Object>> relatorioFormacoesPorFuncionario() throws BusinessException {
        logger.info("Gerando relatório de formações por funcionário");
        
        try {
            List<Map<String, Object>> resultado = new ArrayList<>();
            List<Funcionario> funcionarios = funcionarioDAO.findAll();
            
            for (Funcionario func : funcionarios) {
                List<Formacao> formacoes = formacaoDAO.findByFuncionario(func.getId());
                
                Map<String, Object> item = new LinkedHashMap<>();
                item.put("funcionarioId", func.getId());
                item.put("funcionarioNome", func.getNome());
                item.put("totalFormacoes", formacoes != null ? formacoes.size() : 0);
                item.put("formacoes", formacoes != null ? formacoes : new ArrayList<>());
                
                resultado.add(item);
            }
            
            return resultado;
            
        } catch (Exception e) {
            logger.error("Erro ao gerar relatório de formações", e);
            throw new BusinessException("Erro ao gerar relatório de formações", e);
        }
    }
    
    public Map<String, Integer> relatorioFormacoesPorNivel() throws BusinessException {
        logger.info("Gerando relatório de formações por nível");
        
        try {
            Map<String, Integer> resultado = new LinkedHashMap<>();
            resultado.put("FUNDAMENTAL", 0);
            resultado.put("MEDIO", 0);
            resultado.put("TECNICO", 0);
            resultado.put("SUPERIOR", 0);
            resultado.put("POS_GRADUACAO", 0);
            resultado.put("MASTER", 0);
            resultado.put("DOUTORADO", 0);
            resultado.put("OUTRO", 0);
            
            try {
                for (String nivel : resultado.keySet()) {
                    List<Formacao> lista = formacaoDAO.findByNivel(nivel);
                    resultado.put(nivel, lista != null ? lista.size() : 0);
                }
            } catch (Exception e) {
                logger.warn("Erro ao buscar dados reais de formações", e);
            }
            
            return resultado;
            
        } catch (Exception e) {
            logger.error("Erro ao gerar relatório de formações por nível", e);
            throw new BusinessException("Erro ao gerar relatório", e);
        }
    }
    
    // ============================================================
    // RELATÓRIO DE NOMEAÇÕES
    // ============================================================
    
    public List<Map<String, Object>> relatorioNomeacoesPorFuncionario() throws BusinessException {
        logger.info("Gerando relatório de nomeações por funcionário");
        
        try {
            List<Map<String, Object>> resultado = new ArrayList<>();
            List<Funcionario> funcionarios = funcionarioDAO.findAll();
            
            for (Funcionario func : funcionarios) {
                List<Nomeacao> nomeacoes = nomeacaoDAO.findByFuncionario(func.getId());
                
                long ativas = 0;
                if (nomeacoes != null) {
                    ativas = nomeacoes.stream().filter(Nomeacao::isAtiva).count();
                }
                
                Map<String, Object> item = new LinkedHashMap<>();
                item.put("funcionarioId", func.getId());
                item.put("funcionarioNome", func.getNome());
                item.put("totalNomeacoes", nomeacoes != null ? nomeacoes.size() : 0);
                item.put("nomeacoesAtivas", ativas);
                item.put("nomeacoes", nomeacoes != null ? nomeacoes : new ArrayList<>());
                
                resultado.add(item);
            }
            
            return resultado;
            
        } catch (Exception e) {
            logger.error("Erro ao gerar relatório de nomeações", e);
            throw new BusinessException("Erro ao gerar relatório de nomeações", e);
        }
    }
    
    public List<Nomeacao> relatorioNomeacoesAtivas() throws BusinessException {
        logger.info("Gerando relatório de nomeações ativas");
        
        try {
            return nomeacaoDAO.findAtivas();
        } catch (Exception e) {
            logger.error("Erro ao gerar relatório de nomeações ativas", e);
            throw new BusinessException("Erro ao gerar relatório", e);
        }
    }
}
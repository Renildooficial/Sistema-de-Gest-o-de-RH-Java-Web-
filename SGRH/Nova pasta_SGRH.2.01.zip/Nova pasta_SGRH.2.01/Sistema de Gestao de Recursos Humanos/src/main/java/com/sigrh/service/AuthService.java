package com.sigrh.service;

import com.sigrh.dao.UsuarioDAO;
import com.sigrh.exception.BusinessException;
import com.sigrh.exception.DatabaseException;
import com.sigrh.model.Usuario;
import com.sigrh.util.PasswordUtil;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.sql.Timestamp;

public class AuthService {
    
    private static final Logger logger = LogManager.getLogger(AuthService.class);
    private final UsuarioDAO usuarioDAO;
    
    public AuthService() {
        this.usuarioDAO = new UsuarioDAO();
    }
    
    // ============================================================
    // AUTENTICAÇÃO
    // ============================================================
    
    public Usuario autenticar(String usuario, String senha) throws BusinessException {
        System.out.println("🔍 AuthService.autenticar - Usuário: " + usuario);
        
        try {
            Usuario user = usuarioDAO.findByUsuario(usuario);
            
            if (user == null) {
                System.out.println("❌ Usuário não encontrado: " + usuario);
                throw new BusinessException("Usuário não encontrado");
            }
            
            System.out.println("🔍 Usuário encontrado: " + user.getUsuario());
            
            boolean senhaValida = PasswordUtil.verifyPassword(senha, user.getSenha());
            System.out.println("🔍 Senha válida: " + senhaValida);
            
            if (!senhaValida) {
                throw new BusinessException("Senha incorreta");
            }
            
            if (!user.isAtivo()) {
                System.out.println("❌ Usuário inativo: " + user.getStatus());
                throw new BusinessException("Usuário inativo ou bloqueado");
            }
            
            try {
                usuarioDAO.atualizarUltimoLogin(user.getId());
            } catch (Exception e) {
                // Não crítico
            }
            
            System.out.println("✅ Autenticação bem-sucedida!");
            return user;
            
        } catch (DatabaseException e) {
            logger.error("Erro ao autenticar usuário: {}", usuario, e);
            throw new BusinessException("Erro ao autenticar: " + e.getMessage(), e);
        }
    }
    
    // ============================================================
    // ALTERAÇÃO DE SENHA
    // ============================================================
    
    public void alterarSenha(Integer idUsuario, String senhaAtual, String novaSenha) 
            throws BusinessException {
        logger.info("Alterando senha do usuário ID: {}", idUsuario);
        
        try {
            Usuario usuario = usuarioDAO.findById(idUsuario);
            if (usuario == null) {
                throw new BusinessException("Usuário não encontrado");
            }
            
            if (!PasswordUtil.verifyPassword(senhaAtual, usuario.getSenha())) {
                throw new BusinessException("Senha atual incorreta");
            }
            
            validarSenha(novaSenha);
            
            String novaSenhaHash = PasswordUtil.hashPassword(novaSenha);
            usuarioDAO.updateSenha(idUsuario, novaSenhaHash);
            
            logger.info("Senha alterada com sucesso para usuário ID: {}", idUsuario);
            
        } catch (DatabaseException e) {
            logger.error("Erro ao alterar senha do usuário ID: {}", idUsuario, e);
            throw new BusinessException("Erro ao alterar senha", e);
        }
    }
    
    // ============================================================
    // RECUPERAÇÃO POR EMAIL
    // ============================================================
    
    public Usuario buscarPorEmail(String email) throws BusinessException {
        try {
            return usuarioDAO.findByEmail(email);
        } catch (DatabaseException e) {
            logger.error("Erro ao buscar usuário por email: {}", email, e);
            throw new BusinessException("Erro ao buscar usuário", e);
        }
    }
    
    // ============================================================
    // RECUPERAÇÃO POR TOKEN (LINK)
    // ============================================================
    
    public String solicitarRecuperacaoSenha(String email) throws BusinessException {
        logger.info("Solicitando recuperação de senha para: {}", email);
        
        try {
            Usuario usuario = usuarioDAO.findByEmail(email);
            if (usuario == null) {
                throw new BusinessException("E-mail não encontrado no sistema");
            }
            
            if (!usuario.isAtivo()) {
                throw new BusinessException("Usuário inativo. Contate o administrador.");
            }
            
            String token = PasswordUtil.generateToken();
            
            usuario.setTokenRecuperacao(token);
            usuario.setDataToken(new Timestamp(System.currentTimeMillis()));
            usuarioDAO.update(usuario);
            
            logger.info("Token de recuperação gerado para: {}", email);
            return token;
            
        } catch (DatabaseException e) {
            logger.error("Erro ao solicitar recuperação de senha: {}", email, e);
            throw new BusinessException("Erro ao solicitar recuperação de senha", e);
        }
    }
    
    public Usuario validarTokenRecuperacao(String token) throws BusinessException {
        logger.info("Validando token de recuperação");
        
        try {
            Usuario usuario = usuarioDAO.findByTokenRecuperacao(token);
            if (usuario == null) {
                throw new BusinessException("Token inválido");
            }
            
            if (!usuario.isAtivo()) {
                throw new BusinessException("Usuário inativo. Contate o administrador.");
            }
            
            if (usuario.getDataToken() != null) {
                long diff = System.currentTimeMillis() - usuario.getDataToken().getTime();
                if (diff > 24 * 60 * 60 * 1000) {
                    throw new BusinessException("Token expirado. Solicite uma nova recuperação.");
                }
            }
            
            return usuario;
            
        } catch (DatabaseException e) {
            logger.error("Erro ao validar token de recuperação", e);
            throw new BusinessException("Erro ao validar token", e);
        }
    }
    
    public void redefinirSenha(String token, String novaSenha) throws BusinessException {
        logger.info("Redefinindo senha com token");
        
        try {
            Usuario usuario = validarTokenRecuperacao(token);
            validarSenha(novaSenha);
            
            String novaSenhaHash = PasswordUtil.hashPassword(novaSenha);
            usuarioDAO.updateSenha(usuario.getId(), novaSenhaHash);
            
            usuario.setTokenRecuperacao(null);
            usuario.setDataToken(null);
            usuarioDAO.update(usuario);
            
            logger.info("Senha redefinida com sucesso para: {}", usuario.getEmail());
            
        } catch (DatabaseException e) {
            logger.error("Erro ao redefinir senha", e);
            throw new BusinessException("Erro ao redefinir senha", e);
        }
    }
    
    // ============================================================
    // RECUPERAÇÃO POR CÓDIGO (6 DÍGITOS) - NOVOS MÉTODOS
    // ============================================================
    
    /**
     * Solicita código de verificação para recuperação de senha
     */
    public String solicitarCodigoVerificacao(String email) throws BusinessException {
        logger.info("Solicitando código de verificação para: {}", email);
        
        try {
            Usuario usuario = usuarioDAO.findByEmail(email);
            if (usuario == null) {
                throw new BusinessException("E-mail não encontrado no sistema");
            }
            
            if (!usuario.isAtivo()) {
                throw new BusinessException("Usuário inativo. Contate o administrador.");
            }
            
            // Verificar tentativas (máximo 3 por dia)
            if (usuario.getTentativasCodigo() != null && usuario.getTentativasCodigo() >= 3) {
                throw new BusinessException("Limite de tentativas excedido. Tente novamente amanhã.");
            }
            
            // Gerar código de 6 dígitos
            String codigo = PasswordUtil.generateCodigoVerificacao();
            
            // Salvar código no banco
            usuario.setCodigoVerificacao(codigo);
            usuario.setDataCodigo(new Timestamp(System.currentTimeMillis()));
            if (usuario.getTentativasCodigo() == null) {
                usuario.setTentativasCodigo(0);
            }
            usuarioDAO.update(usuario);
            
            logger.info("Código de verificação gerado para: {}", email);
            return codigo;
            
        } catch (DatabaseException e) {
            logger.error("Erro ao solicitar código de verificação: {}", email, e);
            throw new BusinessException("Erro ao solicitar código de verificação", e);
        }
    }
    
    /**
     * Valida código de verificação
     */
    public Usuario validarCodigoVerificacao(String email, String codigo) throws BusinessException {
        logger.info("Validando código de verificação para: {}", email);
        
        try {
            Usuario usuario = usuarioDAO.findByEmail(email);
            if (usuario == null) {
                throw new BusinessException("E-mail não encontrado");
            }
            
            if (usuario.getCodigoVerificacao() == null) {
                throw new BusinessException("Nenhum código de verificação solicitado");
            }
            
            // Verificar se o código expirou (10 minutos)
            if (usuario.getDataCodigo() != null) {
                long diff = System.currentTimeMillis() - usuario.getDataCodigo().getTime();
                if (diff > 10 * 60 * 1000) {
                    throw new BusinessException("Código expirado. Solicite um novo código.");
                }
            }
            
            // Verificar se o código está correto
            if (!usuario.getCodigoVerificacao().equals(codigo)) {
                // Incrementar tentativas
                int tentativas = usuario.getTentativasCodigo() != null ? usuario.getTentativasCodigo() + 1 : 1;
                usuario.setTentativasCodigo(tentativas);
                usuarioDAO.update(usuario);
                
                int restantes = 3 - tentativas;
                throw new BusinessException("Código incorreto. Você tem " + restantes + " tentativa(s) restante(s).");
            }
            
            // Resetar tentativas
            usuario.setTentativasCodigo(0);
            usuarioDAO.update(usuario);
            
            return usuario;
            
        } catch (DatabaseException e) {
            logger.error("Erro ao validar código de verificação: {}", email, e);
            throw new BusinessException("Erro ao validar código", e);
        }
    }
    
    /**
     * Redefine a senha usando código de verificação
     */
    public void redefinirSenhaComCodigo(String email, String codigo, String novaSenha) throws BusinessException {
        logger.info("Redefinindo senha com código para: {}", email);
        
        try {
            // Validar código
            Usuario usuario = validarCodigoVerificacao(email, codigo);
            
            // Validar nova senha
            validarSenha(novaSenha);
            
            // Hash da nova senha
            String novaSenhaHash = PasswordUtil.hashPassword(novaSenha);
            usuarioDAO.updateSenha(usuario.getId(), novaSenhaHash);
            
            // Limpar dados de recuperação
            usuario.setCodigoVerificacao(null);
            usuario.setDataCodigo(null);
            usuario.setTentativasCodigo(0);
            usuarioDAO.update(usuario);
            
            logger.info("Senha redefinida com sucesso para: {}", email);
            
        } catch (DatabaseException e) {
            logger.error("Erro ao redefinir senha com código", e);
            throw new BusinessException("Erro ao redefinir senha", e);
        }
    }
    
    // ============================================================
    // VALIDAÇÕES
    // ============================================================
    
    private void validarSenha(String senha) throws BusinessException {
        if (senha == null || senha.length() < 8) {
            throw new BusinessException("Senha deve ter no mínimo 8 caracteres");
        }
        if (!senha.matches(".*[A-Z].*")) {
            throw new BusinessException("Senha deve conter pelo menos uma letra maiúscula");
        }
        if (!senha.matches(".*[a-z].*")) {
            throw new BusinessException("Senha deve conter pelo menos uma letra minúscula");
        }
        if (!senha.matches(".*[0-9].*")) {
            throw new BusinessException("Senha deve conter pelo menos um número");
        }
    }
    
    // ============================================================
    // PERMISSÕES
    // ============================================================
    
    public boolean temPermissao(Usuario usuario, String... perfisPermitidos) {
        if (usuario == null) return false;
        if (usuario.isAdmin()) return true;
        
        for (String perfil : perfisPermitidos) {
            if (usuario.getPerfil().name().equals(perfil)) {
                return true;
            }
        }
        return false;
    }
}
package com.sigrh.service;

import com.sigrh.dao.ParametroSistemaDAO;
import com.sigrh.exception.BusinessException;
import com.sigrh.exception.DatabaseException;
import com.sigrh.model.ParametroSistema;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.List;
import java.util.Map;

public class ParametroService {
    
    private static final Logger logger = LogManager.getLogger(ParametroService.class);
    private final ParametroSistemaDAO parametroDAO;
    
    public ParametroService() {
        this.parametroDAO = new ParametroSistemaDAO();
    }
    
    /**
     * Salva um parâmetro
     */
    public ParametroSistema salvar(ParametroSistema parametro) throws BusinessException {
        logger.info("Salvando parâmetro: {}", parametro.getChave());
        
        try {
            return parametroDAO.save(parametro);
        } catch (DatabaseException e) {
            logger.error("Erro ao salvar parâmetro: {}", parametro.getChave(), e);
            throw new BusinessException("Erro ao salvar parâmetro", e);
        }
    }
    
    /**
     * Busca parâmetro por chave
     */
    public ParametroSistema buscarPorChave(String chave) throws BusinessException {
        try {
            return parametroDAO.findByChave(chave);
        } catch (DatabaseException e) {
            logger.error("Erro ao buscar parâmetro: {}", chave, e);
            throw new BusinessException("Erro ao buscar parâmetro", e);
        }
    }
    
    /**
     * Busca valor de parâmetro por chave
     */
    public String buscarValor(String chave) throws BusinessException {
        try {
            return parametroDAO.findValorByChave(chave);
        } catch (DatabaseException e) {
            logger.error("Erro ao buscar valor do parâmetro: {}", chave, e);
            throw new BusinessException("Erro ao buscar valor do parâmetro", e);
        }
    }
    
    /**
     * Busca parâmetros por categoria
     */
    public Map<String, ParametroSistema> buscarPorCategoria(String categoria) throws BusinessException {
        try {
            return parametroDAO.findByCategoria(categoria);
        } catch (DatabaseException e) {
            logger.error("Erro ao buscar parâmetros por categoria: {}", categoria, e);
            throw new BusinessException("Erro ao buscar parâmetros", e);
        }
    }
    
    /**
     * Lista todos os parâmetros
     */
    public List<ParametroSistema> listarTodos() throws BusinessException {
        try {
            return parametroDAO.findAll();
        } catch (DatabaseException e) {
            logger.error("Erro ao listar parâmetros", e);
            throw new BusinessException("Erro ao listar parâmetros", e);
        }
    }
    
    /**
     * Exclui um parâmetro
     */
    public void excluir(String chave) throws BusinessException {
        logger.info("Excluindo parâmetro: {}", chave);
        
        try {
            ParametroSistema parametro = parametroDAO.findByChave(chave);
            if (parametro == null) {
                throw new BusinessException("Parâmetro não encontrado");
            }
            parametroDAO.delete(parametro.getId());
        } catch (DatabaseException e) {
            logger.error("Erro ao excluir parâmetro: {}", chave, e);
            throw new BusinessException("Erro ao excluir parâmetro", e);
        }
    }
    
    /**
     * Obtém parâmetros de e-mail
     */
    public Map<String, String> getConfiguracoesEmail() throws BusinessException {
        try {
            Map<String, String> config = new java.util.HashMap<>();
            Map<String, ParametroSistema> params = parametroDAO.findByCategoria("EMAIL");
            
            for (Map.Entry<String, ParametroSistema> entry : params.entrySet()) {
                config.put(entry.getKey(), entry.getValue().getValor());
            }
            
            // Valores padrão se não existirem
            if (!config.containsKey("smtp_host")) {
                config.put("smtp_host", "smtp.gmail.com");
            }
            if (!config.containsKey("smtp_port")) {
                config.put("smtp_port", "587");
            }
            if (!config.containsKey("smtp_username")) {
                config.put("smtp_username", "");
            }
            if (!config.containsKey("smtp_password")) {
                config.put("smtp_password", "");
            }
            if (!config.containsKey("smtp_tls")) {
                config.put("smtp_tls", "true");
            }
            
            return config;
            
        } catch (DatabaseException e) {
            logger.error("Erro ao buscar configurações de e-mail", e);
            throw new BusinessException("Erro ao buscar configurações de e-mail", e);
        }
    }
}
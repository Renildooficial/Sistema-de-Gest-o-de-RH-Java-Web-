package com.sigrh.controller;

import com.sigrh.dao.FuncionarioDAO;
import com.sigrh.dao.UsuarioDAO;
import com.sigrh.model.Funcionario;
import com.sigrh.model.Usuario;
import com.sigrh.service.AuditoriaService;
import com.sigrh.service.SistemaNotificacaoService;
import com.sigrh.util.Constants;
import com.sigrh.util.PasswordUtil;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

@WebServlet(name = "UsuarioController", urlPatterns = {"/usuarios", "/usuarios/*"})
public class UsuarioController extends HttpServlet {
    
    private static final long serialVersionUID = 1L;
    private UsuarioDAO usuarioDAO;
    private FuncionarioDAO funcionarioDAO;
    private AuditoriaService auditoriaService;
    private SistemaNotificacaoService sistemaNotificacaoService; // REMOVER final
    
    @Override
    public void init() {
        this.usuarioDAO = new UsuarioDAO();
        this.funcionarioDAO = new FuncionarioDAO();
        this.auditoriaService = new AuditoriaService();
        this.sistemaNotificacaoService = new SistemaNotificacaoService(); // Inicializar aqui
    }
    

    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String pathInfo = request.getPathInfo();
        System.out.println("🔍 UsuarioController.doGet - Path: " + pathInfo);
        
        Usuario usuario = (Usuario) request.getSession().getAttribute(Constants.SESSION_USER);
        if (usuario == null || !usuario.isAdmin()) {
            request.getSession().setAttribute(Constants.MSG_ERRO, "Acesso negado");
            response.sendRedirect(request.getContextPath() + "/dashboard");
            return;
        }
        
        try {
            if (pathInfo == null || pathInfo.equals("/") || pathInfo.equals("")) {
                listar(request, response);
            } else if (pathInfo.equals("/novo")) {
                novo(request, response);
            } else if (pathInfo.startsWith("/editar/")) {
                editar(request, response);
            } else {
                response.sendError(HttpServletResponse.SC_NOT_FOUND);
            }
        } catch (Exception e) {
            e.printStackTrace();
            request.getSession().setAttribute(Constants.MSG_ERRO, "Erro ao processar requisição: " + e.getMessage());
            response.sendRedirect(request.getContextPath() + "/usuarios");
        }
    }
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String pathInfo = request.getPathInfo();
        System.out.println("🔍 UsuarioController.doPost - Path: " + pathInfo);
        
        Usuario usuario = (Usuario) request.getSession().getAttribute(Constants.SESSION_USER);
        if (usuario == null || !usuario.isAdmin()) {
            response.setContentType("application/json");
            response.getWriter().write("{\"success\": false, \"message\": \"Acesso negado\"}");
            return;
        }
        
        try {
            if (pathInfo == null || pathInfo.equals("/") || pathInfo.equals("")) {
                salvar(request, response);
            } else if (pathInfo.equals("/excluir")) {
                excluir(request, response);
            } else if (pathInfo.equals("/alterar-status")) {
                alterarStatus(request, response);
            } else {
                response.sendError(HttpServletResponse.SC_NOT_FOUND);
            }
        } catch (Exception e) {
            e.printStackTrace();
            response.setContentType("application/json");
            response.getWriter().write("{\"success\": false, \"message\": \"" + e.getMessage() + "\"}");
        }
    }
    
    // ============================================================
    // LISTAR - DEFINITIVAMENTE CORRIGIDO
    // ============================================================
    private void listar(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        try {
            List<Usuario> usuarios = usuarioDAO.listarTodos();
            System.out.println("📝 Total de usuários: " + (usuarios != null ? usuarios.size() : 0));
            
            // Map idUsuario -> nome do funcionário (evita conflito EL com isFuncionario() Boolean no JSP)
            java.util.Map<Integer, String> nomesFuncionarios = new java.util.HashMap<>();
            
            if (usuarios != null && !usuarios.isEmpty()) {
                for (Usuario u : usuarios) {
                    // SEMPRE iniciar com null (nunca Boolean)
                    u.setFuncionario(null);
                    
                    if (u.getIdFuncionario() != null && u.getIdFuncionario() > 0) {
                        try {
                            Funcionario f = funcionarioDAO.buscarPorId(u.getIdFuncionario());
                            if (f != null) {
                                u.setFuncionario(f);
                                nomesFuncionarios.put(u.getId(), f.getNome());
                                System.out.println("✅ Funcionário carregado: " + f.getNome() + " para usuário " + u.getId());
                            } else {
                                System.out.println("⚠️ Funcionário não encontrado para ID: " + u.getIdFuncionario());
                            }
                        } catch (Exception e) {
                            System.err.println("❌ Erro ao carregar funcionário: " + e.getMessage());
                        }
                    } else {
                        System.out.println("ℹ️ Usuário " + u.getId() + " não tem funcionário associado");
                    }
                }
            } else {
                usuarios = new ArrayList<>();
            }
            
            // Estatísticas
            int total = usuarios.size();
            int ativos = 0;
            for (Usuario u : usuarios) {
                if (u.getStatus() == Usuario.Status.ATIVO) {
                    ativos++;
                }
            }
            
            request.setAttribute("usuarios", usuarios);
            request.setAttribute("nomesFuncionarios", nomesFuncionarios);
            request.setAttribute("total", total);
            request.setAttribute("ativos", ativos);
            
            request.getSession().removeAttribute(Constants.MSG_ERRO);
            request.getSession().removeAttribute(Constants.MSG_SUCESSO);
            request.getSession().removeAttribute(Constants.MSG_INFO);
            
            // Forward - NUNCA usar sendRedirect depois do forward!
            request.getRequestDispatcher("/WEB-INF/views/admin/usuarios.jsp").forward(request, response);
            
        } catch (Exception e) {
            e.printStackTrace();
            request.getSession().setAttribute(Constants.MSG_ERRO, "Erro ao listar usuários: " + e.getMessage());
            response.sendRedirect(request.getContextPath() + "/dashboard");
        }
    }
    
    // ============================================================
    // NOVO
    // ============================================================
    private void novo(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        try {
            List<Funcionario> funcionarios = funcionarioDAO.listarTodos();
            request.setAttribute("funcionarios", funcionarios);
            request.setAttribute("usuario", new Usuario());
            request.setAttribute("acao", "cadastrar");
            request.setAttribute("perfis", Usuario.Perfil.values());
            request.setAttribute("statusList", Usuario.Status.values());
            
            request.getRequestDispatcher("/WEB-INF/views/admin/usuario-form.jsp").forward(request, response);
            
        } catch (Exception e) {
            e.printStackTrace();
            request.getSession().setAttribute(Constants.MSG_ERRO, "Erro ao carregar formulário: " + e.getMessage());
            response.sendRedirect(request.getContextPath() + "/usuarios");
        }
    }
    
    // ============================================================
    // EDITAR
    // ============================================================
    private void editar(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String pathInfo = request.getPathInfo();
        String[] parts = pathInfo.split("/");
        
        if (parts.length < 3) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST);
            return;
        }
        
        try {
            Integer id = Integer.parseInt(parts[2]);
            System.out.println("🔍 Editando usuário ID: " + id);
            
            Usuario usuario = usuarioDAO.buscarPorId(id);
            
            if (usuario == null) {
                request.getSession().setAttribute(Constants.MSG_ERRO, "Usuário não encontrado");
                response.sendRedirect(request.getContextPath() + "/usuarios");
                return;
            }
            
            // Carregar funcionário associado - SEMPRE iniciar com null
            usuario.setFuncionario(null);
            if (usuario.getIdFuncionario() != null && usuario.getIdFuncionario() > 0) {
                try {
                    Funcionario f = funcionarioDAO.buscarPorId(usuario.getIdFuncionario());
                    if (f != null) {
                        usuario.setFuncionario(f);
                    }
                } catch (Exception e) {
                    System.err.println("Erro ao carregar funcionário: " + e.getMessage());
                }
            }
            
            List<Funcionario> funcionarios = funcionarioDAO.listarTodos();
            request.setAttribute("funcionarios", funcionarios);
            request.setAttribute("usuario", usuario);
            request.setAttribute("acao", "editar");
            request.setAttribute("perfis", Usuario.Perfil.values());
            request.setAttribute("statusList", Usuario.Status.values());
            
            request.getRequestDispatcher("/WEB-INF/views/admin/usuario-form.jsp").forward(request, response);
            
        } catch (NumberFormatException e) {
            System.err.println("❌ ID inválido: " + e.getMessage());
            response.sendError(HttpServletResponse.SC_BAD_REQUEST);
        } catch (Exception e) {
            e.printStackTrace();
            request.getSession().setAttribute(Constants.MSG_ERRO, "Erro ao carregar usuário: " + e.getMessage());
            response.sendRedirect(request.getContextPath() + "/usuarios");
        }
    }
    
 // ============================================================
 // SALVAR - COM NOTIFICAÇÃO
 // ============================================================
 private void salvar(HttpServletRequest request, HttpServletResponse response) 
         throws ServletException, IOException {
     
     System.out.println("🔥🔥🔥 SALVANDO USUÁRIO 🔥🔥🔥");
     
     try {
         String idStr = request.getParameter("id");
         Integer id = idStr != null && !idStr.isEmpty() ? Integer.parseInt(idStr) : null;
         
         String nome = request.getParameter("nome");
         String usuarioNome = request.getParameter("usuario");
         String email = request.getParameter("email");
         String senha = request.getParameter("senha");
         String perfil = request.getParameter("perfil");
         String status = request.getParameter("status");
         String idFuncionarioStr = request.getParameter("idFuncionario");
         
         // VALIDAÇÕES
         if (nome == null || nome.trim().isEmpty()) {
             request.getSession().setAttribute(Constants.MSG_ERRO, "Nome é obrigatório");
             request.getRequestDispatcher("/WEB-INF/views/admin/usuario-form.jsp").forward(request, response);
             return;
         }
         
         if (usuarioNome == null || usuarioNome.trim().isEmpty()) {
             request.getSession().setAttribute(Constants.MSG_ERRO, "Usuário é obrigatório");
             request.getRequestDispatcher("/WEB-INF/views/admin/usuario-form.jsp").forward(request, response);
             return;
         }
         
         if (email == null || email.trim().isEmpty()) {
             request.getSession().setAttribute(Constants.MSG_ERRO, "E-mail é obrigatório");
             request.getRequestDispatcher("/WEB-INF/views/admin/usuario-form.jsp").forward(request, response);
             return;
         }
         
         // Criar objeto
         Usuario usuario = new Usuario();
         if (id != null) {
             usuario.setId(id);
         }
         usuario.setNome(nome.trim());
         usuario.setUsuario(usuarioNome.trim());
         usuario.setEmail(email.trim());
         
         try {
             usuario.setPerfil(Usuario.Perfil.valueOf(perfil));
         } catch (IllegalArgumentException e) {
             usuario.setPerfil(Usuario.Perfil.FUNCIONARIO);
         }
         
         try {
             usuario.setStatus(Usuario.Status.valueOf(status));
         } catch (IllegalArgumentException e) {
             usuario.setStatus(Usuario.Status.ATIVO);
         }
         
         if (idFuncionarioStr != null && !idFuncionarioStr.isEmpty()) {
             usuario.setIdFuncionario(Integer.parseInt(idFuncionarioStr));
         } else {
             usuario.setIdFuncionario(null);
         }
         
         // Senha
         Usuario usuarioExistente = null;
         if (id != null) {
             usuarioExistente = usuarioDAO.buscarPorId(id);
         }
         
         if (senha != null && !senha.isEmpty()) {
             if (senha.length() < 8) {
                 request.getSession().setAttribute(Constants.MSG_ERRO, "Senha deve ter no mínimo 8 caracteres");
                 request.getRequestDispatcher("/WEB-INF/views/admin/usuario-form.jsp").forward(request, response);
                 return;
             }
             usuario.setSenha(PasswordUtil.hashPassword(senha));
         } else if (usuarioExistente != null) {
             usuario.setSenha(usuarioExistente.getSenha());
         } else {
             request.getSession().setAttribute(Constants.MSG_ERRO, "Senha é obrigatória para cadastro");
             request.getRequestDispatcher("/WEB-INF/views/admin/usuario-form.jsp").forward(request, response);
             return;
         }
         
         // SALVAR
         Usuario usuarioLogado = (Usuario) request.getSession().getAttribute(Constants.SESSION_USER);
         
         if (id == null) {
             usuarioDAO.salvar(usuario);
             
             // =============================================================
             // NOTIFICAR NOVO USUÁRIO - ENVIAR BEM-VINDO
             // =============================================================
             try {
                 String titulo = "👋 Bem-vindo ao SIGRH!";
                 String mensagem = String.format(
                     "Olá %s!\n\n" +
                     "Seu usuário foi criado com sucesso no sistema.\n" +
                     "Usuário: %s\n" +
                     "Perfil: %s\n\n" +
                     "Acesse o sistema com suas credenciais.",
                     usuario.getNome(),
                     usuario.getUsuario(),
                     usuario.getPerfil().name()
                 );
                 sistemaNotificacaoService.enviarNotificacao(usuario.getId(), titulo, mensagem, "SUCESSO");
             } catch (Exception e) {
                 System.err.println("⚠️ Erro ao notificar novo usuário: " + e.getMessage());
             }
             
             request.getSession().setAttribute(Constants.MSG_SUCESSO, "Usuário cadastrado com sucesso!");
             
             if (usuarioLogado != null) {
                 auditoriaService.registrar(usuarioLogado, "CREATE", "usuario", usuario.getId(), 
                     null, "ID: " + usuario.getId() + ", Nome: " + usuario.getNome(), request);
             }
         } else {
             usuarioDAO.atualizar(usuario);
             request.getSession().setAttribute(Constants.MSG_SUCESSO, "Usuário atualizado com sucesso!");
             
             if (usuarioLogado != null) {
                 auditoriaService.registrar(usuarioLogado, "UPDATE", "usuario", usuario.getId(), 
                     null, "ID: " + usuario.getId() + ", Nome: " + usuario.getNome(), request);
             }
         }
         
         response.sendRedirect(request.getContextPath() + "/usuarios");
         
     } catch (Exception e) {
         e.printStackTrace();
         request.getSession().setAttribute(Constants.MSG_ERRO, "Erro ao salvar usuário: " + e.getMessage());
         request.getRequestDispatcher("/WEB-INF/views/admin/usuario-form.jsp").forward(request, response);
     }
 }

 // ============================================================
 // ALTERAR STATUS - COM NOTIFICAÇÃO
 // ============================================================
 private void alterarStatus(HttpServletRequest request, HttpServletResponse response) 
         throws IOException {
     
     response.setContentType("application/json");
     PrintWriter out = response.getWriter();
     
     try {
         String idStr = request.getParameter("id");
         if (idStr == null || idStr.isEmpty()) {
             out.print("{\"success\": false, \"message\": \"ID não informado\"}");
             out.flush();
             return;
         }
         
         Integer id = Integer.parseInt(idStr);
         System.out.println("🔍 Alterando status do usuário ID: " + id);
         
         Usuario usuarioLogado = (Usuario) request.getSession().getAttribute(Constants.SESSION_USER);
         if (usuarioLogado != null && usuarioLogado.getId().equals(id)) {
             out.print("{\"success\": false, \"message\": \"Não é possível alterar o status do próprio usuário\"}");
             out.flush();
             return;
         }
         
         Usuario usuario = usuarioDAO.buscarPorId(id);
         
         if (usuario == null) {
             out.print("{\"success\": false, \"message\": \"Usuário não encontrado\"}");
             out.flush();
             return;
         }
         
         // Alternar status
         Usuario.Status novoStatus = usuario.getStatus() == Usuario.Status.ATIVO ? 
             Usuario.Status.INATIVO : Usuario.Status.ATIVO;
         usuario.setStatus(novoStatus);
         
         usuarioDAO.atualizar(usuario);
         
         if (usuarioLogado != null) {
             auditoriaService.registrar(usuarioLogado, "UPDATE", "usuario", usuario.getId(), 
                 null, "Status alterado para: " + usuario.getStatus().name(), request);
         }
         
         // =============================================================
         // NOTIFICAR MUDANÇA DE STATUS
         // =============================================================
         try {
             String titulo = usuario.getStatus() == Usuario.Status.ATIVO ? 
                 "✅ Usuário Ativado" : "⛔ Usuário Desativado";
             String mensagem = String.format(
                 "Seu usuário foi %s pelo administrador.\n" +
                 "Data: %s",
                 usuario.getStatus() == Usuario.Status.ATIVO ? "ativado" : "desativado",
                 new java.text.SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(new java.util.Date())
             );
             sistemaNotificacaoService.enviarNotificacao(usuario.getId(), titulo, mensagem, "INFO");
         } catch (Exception e) {
             System.err.println("⚠️ Erro ao notificar mudança de status: " + e.getMessage());
         }
         
         out.print("{\"success\": true, \"message\": \"Status alterado com sucesso!\"}");
         
     } catch (NumberFormatException e) {
         out.print("{\"success\": false, \"message\": \"ID inválido\"}");
     } catch (Exception e) {
         e.printStackTrace();
         out.print("{\"success\": false, \"message\": \"Erro ao alterar status: " + e.getMessage() + "\"}");
     }
     
     out.flush();
 }
    
    // ============================================================
    // EXCLUIR
    // ============================================================
    private void excluir(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        
        response.setContentType("application/json");
        PrintWriter out = response.getWriter();
        
        try {
            String idStr = request.getParameter("id");
            if (idStr == null || idStr.isEmpty()) {
                out.print("{\"success\": false, \"message\": \"ID não informado\"}");
                out.flush();
                return;
            }
            
            Integer id = Integer.parseInt(idStr);
            System.out.println("🔍 Excluindo usuário ID: " + id);
            
            Usuario usuarioLogado = (Usuario) request.getSession().getAttribute(Constants.SESSION_USER);
            if (usuarioLogado != null && usuarioLogado.getId().equals(id)) {
                out.print("{\"success\": false, \"message\": \"Não é possível excluir o próprio usuário\"}");
                out.flush();
                return;
            }
            
            usuarioDAO.excluir(id);
            
            if (usuarioLogado != null) {
                auditoriaService.registrar(usuarioLogado, "DELETE", "usuario", id, 
                    null, "ID: " + id, request);
            }
            
            out.print("{\"success\": true, \"message\": \"Usuário excluído com sucesso!\"}");
            
        } catch (NumberFormatException e) {
            out.print("{\"success\": false, \"message\": \"ID inválido\"}");
        } catch (Exception e) {
            e.printStackTrace();
            out.print("{\"success\": false, \"message\": \"Erro ao excluir usuário: " + e.getMessage() + "\"}");
        }
        
        out.flush();
    }
    
    
}
package com.sigrh.dao;

import com.sigrh.model.Notificacao;
import com.sigrh.util.DatabaseUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class NotificacaoDAO {
    
    public void salvar(Notificacao notificacao) throws SQLException {
        String sql = "INSERT INTO notificacao (id_usuario, titulo, mensagem, tipo, lida, data_criacao) " +
                     "VALUES (?, ?, ?, ?, ?, ?)";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            
            stmt.setInt(1, notificacao.getIdUsuario());
            stmt.setString(2, notificacao.getTitulo());
            stmt.setString(3, notificacao.getMensagem());
            stmt.setString(4, notificacao.getTipo());
            stmt.setBoolean(5, notificacao.isLida());
            stmt.setTimestamp(6, notificacao.getDataCriacao());
            
            stmt.executeUpdate();
            
            ResultSet rs = stmt.getGeneratedKeys();
            if (rs.next()) {
                notificacao.setId(rs.getInt(1));
            }
        }
    }
    
    public List<Notificacao> buscarPorUsuario(Integer idUsuario) throws SQLException {
        List<Notificacao> notificacoes = new ArrayList<>();
        String sql = "SELECT * FROM notificacao WHERE id_usuario = ? ORDER BY data_criacao DESC";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, idUsuario);
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                notificacoes.add(mapear(rs));
            }
        }
        return notificacoes;
    }
    
    public List<Notificacao> buscarNaoLidas(Integer idUsuario) throws SQLException {
        List<Notificacao> notificacoes = new ArrayList<>();
        String sql = "SELECT * FROM notificacao WHERE id_usuario = ? AND lida = FALSE ORDER BY data_criacao DESC";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, idUsuario);
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                notificacoes.add(mapear(rs));
            }
        }
        return notificacoes;
    }
    
    public List<Notificacao> buscarRecentes(Integer idUsuario, int limite) throws SQLException {
        List<Notificacao> notificacoes = new ArrayList<>();
        String sql = "SELECT * FROM notificacao WHERE id_usuario = ? ORDER BY data_criacao DESC LIMIT ?";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, idUsuario);
            stmt.setInt(2, limite);
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                notificacoes.add(mapear(rs));
            }
        }
        return notificacoes;
    }
    
    public int contarNaoLidas(Integer idUsuario) throws SQLException {
        String sql = "SELECT COUNT(*) FROM notificacao WHERE id_usuario = ? AND lida = FALSE";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, idUsuario);
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                return rs.getInt(1);
            }
        }
        return 0;
    }
    
    public void marcarComoLida(Integer id) throws SQLException {
        String sql = "UPDATE notificacao SET lida = TRUE WHERE id = ?";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, id);
            stmt.executeUpdate();
        }
    }
    
    public void marcarTodasComoLidas(Integer idUsuario) throws SQLException {
        String sql = "UPDATE notificacao SET lida = TRUE WHERE id_usuario = ? AND lida = FALSE";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, idUsuario);
            stmt.executeUpdate();
        }
    }
    
    public void deletarPorUsuario(Integer idUsuario) throws SQLException {
        String sql = "DELETE FROM notificacao WHERE id_usuario = ?";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, idUsuario);
            stmt.executeUpdate();
        }
    }
    
    public void deletarAntigas(Integer idUsuario, int dias) throws SQLException {
        String sql = "DELETE FROM notificacao WHERE id_usuario = ? AND data_criacao < DATE_SUB(NOW(), INTERVAL ? DAY)";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, idUsuario);
            stmt.setInt(2, dias);
            stmt.executeUpdate();
        }
    }
    
    private Notificacao mapear(ResultSet rs) throws SQLException {
        Notificacao n = new Notificacao();
        n.setId(rs.getInt("id"));
        n.setIdUsuario(rs.getInt("id_usuario"));
        n.setTitulo(rs.getString("titulo"));
        n.setMensagem(rs.getString("mensagem"));
        n.setTipo(rs.getString("tipo"));
        n.setLida(rs.getBoolean("lida"));
        n.setDataCriacao(rs.getTimestamp("data_criacao"));
        return n;
    }
}
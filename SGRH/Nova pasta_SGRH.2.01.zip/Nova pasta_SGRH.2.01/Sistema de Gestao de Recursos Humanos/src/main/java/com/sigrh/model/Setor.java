package com.sigrh.model;

public class Setor extends BaseModel {
    
    private static final long serialVersionUID = 1L;
    
    private String nome;
    private String descricao;
    private String responsavel;
    
    public Setor() {}
    
    public Setor(Integer id, String nome) {
        this.id = id;
        this.nome = nome;
    }
    
    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }
    
    public String getDescricao() { return descricao; }
    public void setDescricao(String descricao) { this.descricao = descricao; }
    
    public String getResponsavel() { return responsavel; }
    public void setResponsavel(String responsavel) { this.responsavel = responsavel; }
    
    @Override
    public String toString() { return nome; }
}
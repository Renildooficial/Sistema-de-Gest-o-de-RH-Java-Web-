package com.sigrh.service;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import jakarta.mail.*;
import jakarta.mail.internet.InternetAddress;
import jakarta.mail.internet.MimeMessage;

import java.util.Properties;

/**
 * Serviço para envio de e-mails
 */
public class EmailService {
    
    private static final Logger logger = LogManager.getLogger(EmailService.class);
    
    private String smtpHost;
    private String smtpPort;
    private String username;
    private String password;
    private boolean useSSL;
    private boolean useTLS;
    
    public EmailService() {
        // Configurações padrão (devem vir do banco de dados em produção)
        this.smtpHost = "smtp.gmail.com";
        this.smtpPort = "587";
        this.username = "Renildooficial3@gmail.com";
        this.password = "";
        this.useSSL = false;
        this.useTLS = true;
    }
    
    /**
     * Envia e-mail para recuperação de senha (via link)
     */
    public void enviarRecuperacaoSenha(String email, String nome, String token, String baseUrl) {
        String assunto = "SIGRH - Recuperação de Senha";
        String link = baseUrl + "/auth/nova-senha?token=" + token;
        
        String corpo = String.format("""
            <html>
            <head>
                <style>
                    body { font-family: Arial, sans-serif; color: #333; }
                    .container { max-width: 600px; margin: 0 auto; padding: 20px; }
                    .header { background: linear-gradient(135deg, #4F46E5, #7C3AED); color: white; padding: 20px; text-align: center; border-radius: 10px 10px 0 0; }
                    .content { background: #f8fafc; padding: 30px; border-radius: 0 0 10px 10px; }
                    .btn { display: inline-block; padding: 12px 24px; background: linear-gradient(135deg, #4F46E5, #7C3AED); color: white; text-decoration: none; border-radius: 8px; font-weight: 600; }
                    .footer { text-align: center; padding: 20px; font-size: 12px; color: #94A3B8; }
                    .info { background: #f1f5f9; padding: 12px; border-radius: 8px; font-size: 14px; }
                </style>
            </head>
            <body>
                <div class="container">
                    <div class="header">
                        <h1 style="margin: 0;">🔐 Recuperação de Senha</h1>
                        <p style="margin: 5px 0 0; opacity: 0.8;">SIGRH - Sistema Integrado de RH</p>
                    </div>
                    <div class="content">
                        <h2>Olá, %s!</h2>
                        <p>Recebemos uma solicitação para redefinir sua senha no sistema SIGRH.</p>
                        <p>Clique no botão abaixo para criar uma nova senha:</p>
                        <div style="text-align: center; margin: 30px 0;">
                            <a href="%s" class="btn">Redefinir Senha</a>
                        </div>
                        <div class="info">
                            <p><strong>⚠️ Importante:</strong></p>
                            <ul style="margin: 0; padding-left: 20px;">
                                <li>Este link é válido por <strong>24 horas</strong></li>
                                <li>Se você não solicitou esta alteração, ignore este e-mail</li>
                                <li>Para segurança, nunca compartilhe este link</li>
                            </ul>
                        </div>
                        <p style="margin-top: 20px;">Se o botão não funcionar, copie e cole este link no navegador:</p>
                        <p style="word-break: break-all; font-size: 12px; color: #4F46E5;">%s</p>
                    </div>
                    <div class="footer">
                        <p>© 2024 SIGRH - Sistema Integrado de Gestão de Recursos Humanos</p>
                        <p>Este é um e-mail automático, por favor não responda.</p>
                    </div>
                </div>
            </body>
            </html>
            """, nome, link, link);
        
        enviarEmail(email, assunto, corpo);
    }
    
    /**
     * Envia e-mail com código de verificação para recuperação de senha
     */
    public void enviarCodigoVerificacao(String email, String nome, String codigo) {
        String assunto = "SIGRH - Código de Verificação";
        
        String corpo = String.format("""
            <html>
            <head>
                <style>
                    body { font-family: Arial, sans-serif; color: #333; }
                    .container { max-width: 600px; margin: 0 auto; padding: 20px; }
                    .header { background: linear-gradient(135deg, #4F46E5, #7C3AED); color: white; padding: 20px; text-align: center; border-radius: 10px 10px 0 0; }
                    .content { background: #f8fafc; padding: 30px; border-radius: 0 0 10px 10px; }
                    .codigo-box { background: #1E293B; color: #fff; padding: 20px; text-align: center; border-radius: 12px; font-size: 32px; letter-spacing: 8px; font-weight: 700; margin: 20px 0; }
                    .footer { text-align: center; padding: 20px; font-size: 12px; color: #94A3B8; }
                    .info { background: #f1f5f9; padding: 12px; border-radius: 8px; font-size: 14px; }
                    .warning { color: #EF4444; font-weight: 600; }
                </style>
            </head>
            <body>
                <div class="container">
                    <div class="header">
                        <h1 style="margin: 0;">🔐 Código de Verificação</h1>
                        <p style="margin: 5px 0 0; opacity: 0.8;">SIGRH - Sistema Integrado de RH</p>
                    </div>
                    <div class="content">
                        <h2>Olá, %s!</h2>
                        <p>Recebemos uma solicitação para redefinir sua senha no sistema SIGRH.</p>
                        <p>Use o código abaixo para verificar sua identidade:</p>
                        
                        <div class="codigo-box">%s</div>
                        
                        <div class="info">
                            <p><strong>⚠️ Importante:</strong></p>
                            <ul style="margin: 0; padding-left: 20px;">
                                <li>Este código é válido por <strong>10 minutos</strong></li>
                                <li>Você tem <strong>3 tentativas</strong> para acertar o código</li>
                                <li>Se você não solicitou esta alteração, ignore este e-mail</li>
                                <li>Nunca compartilhe este código com ninguém</li>
                            </ul>
                        </div>
                        <p style="margin-top: 20px; color: var(--gray);">
                            <span class="warning">🔒</span> Por segurança, não compartilhe este código.
                        </p>
                    </div>
                    <div class="footer">
                        <p>© 2024 SIGRH - Sistema Integrado de Gestão de Recursos Humanos</p>
                        <p>Este é um e-mail automático, por favor não responda.</p>
                    </div>
                </div>
            </body>
            </html>
            """, nome, codigo);
        
        enviarEmail(email, assunto, corpo);
    }
    
    /**
     * Envia e-mail genérico
     */
    public void enviarEmail(String destinatario, String assunto, String corpo) {
        logger.info("Enviando e-mail para: {}", destinatario);
        
        try {
            Properties props = new Properties();
            props.put("mail.smtp.host", smtpHost);
            props.put("mail.smtp.port", smtpPort);
            props.put("mail.smtp.auth", "true");
            
            if (useTLS) {
                props.put("mail.smtp.starttls.enable", "true");
            }
            if (useSSL) {
                props.put("mail.smtp.ssl.enable", "true");
            }
            
            Session session = Session.getInstance(props, new Authenticator() {
                @Override
                protected PasswordAuthentication getPasswordAuthentication() {
                    return new PasswordAuthentication(username, password);
                }
            });
            
            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress(username));
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(destinatario));
            message.setSubject(assunto);
            message.setContent(corpo, "text/html; charset=utf-8");
            
            Transport.send(message);
            logger.info("E-mail enviado com sucesso para: {}", destinatario);
            
        } catch (MessagingException e) {
            logger.error("Erro ao enviar e-mail para: {}", destinatario, e);
        }
    }
}
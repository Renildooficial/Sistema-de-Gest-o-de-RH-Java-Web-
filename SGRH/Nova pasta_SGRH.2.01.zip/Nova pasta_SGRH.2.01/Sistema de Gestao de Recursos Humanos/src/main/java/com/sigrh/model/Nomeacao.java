package com.sigrh.model;

import java.sql.Timestamp;
import java.util.Date;

public class Nomeacao extends BaseModel {
    
    private Integer id;
    private Integer idFuncionario;
    private Funcionario funcionario;
    private String funcao;
    private String funcoes;
    private String cargo;
    private String despacho;
    private String local;
    private Date dataNomeacao;
    private Date dataInicio;
    private Date dataFim;
    private String status;
    private String observacao;
    private Timestamp dataCadastro;
    
    // ============================================================
    // CONSTRUTORES
    // ============================================================
    public Nomeacao() {}
    
    public Nomeacao(Integer id, Integer idFuncionario, String funcao, String funcoes, 
                    String cargo, String despacho, String local, Date dataNomeacao,
                    Date dataInicio, Date dataFim, String status, String observacao) {
        this.id = id;
        this.idFuncionario = idFuncionario;
        this.funcao = funcao;
        this.funcoes = funcoes;
        this.cargo = cargo;
        this.despacho = despacho;
        this.local = local;
        this.dataNomeacao = dataNomeacao;
        this.dataInicio = dataInicio;
        this.dataFim = dataFim;
        this.status = status;
        this.observacao = observacao;
    }
    
    // ============================================================
    // GETTERS E SETTERS
    // ============================================================
    public Integer getId() {
        return id;
    }
    
    public void setId(Integer id) {
        this.id = id;
    }
    
    public Integer getIdFuncionario() {
        return idFuncionario;
    }
    
    public void setIdFuncionario(Integer idFuncionario) {
        this.idFuncionario = idFuncionario;
    }
    
    public Funcionario getFuncionario() {
        return funcionario;
    }
    
    public void setFuncionario(Funcionario funcionario) {
        this.funcionario = funcionario;
    }
    
    public String getFuncao() {
        return funcao;
    }
    
    public void setFuncao(String funcao) {
        this.funcao = funcao;
    }
    
    public String getFuncoes() {
        return funcoes;
    }
    
    public void setFuncoes(String funcoes) {
        this.funcoes = funcoes;
    }
    
    public String getCargo() {
        return cargo;
    }
    
    public void setCargo(String cargo) {
        this.cargo = cargo;
    }
    
    public String getDespacho() {
        return despacho;
    }
    
    public void setDespacho(String despacho) {
        this.despacho = despacho;
    }
    
    public String getLocal() {
        return local;
    }
    
    public void setLocal(String local) {
        this.local = local;
    }
    
    public Date getDataNomeacao() {
        return dataNomeacao;
    }
    
    public void setDataNomeacao(Date dataNomeacao) {
        this.dataNomeacao = dataNomeacao;
    }
    
    public Date getDataInicio() {
        return dataInicio;
    }
    
    public void setDataInicio(Date dataInicio) {
        this.dataInicio = dataInicio;
    }
    
    public Date getDataFim() {
        return dataFim;
    }
    
    public void setDataFim(Date dataFim) {
        this.dataFim = dataFim;
    }
    
    public String getStatus() {
        return status;
    }
    
    public void setStatus(String status) {
        this.status = status;
    }
    
    public String getObservacao() {
        return observacao;
    }
    
    public void setObservacao(String observacao) {
        this.observacao = observacao;
    }
    
    @Override
    public Timestamp getDataCadastro() {
        return dataCadastro;
    }
    
    public void setDataCadastro(Timestamp dataCadastro) {
        this.dataCadastro = dataCadastro;
    }
    
    // ============================================================
    // MÉTODOS AUXILIARES
    // ============================================================
    public boolean isAtiva() {
        return "ATIVA".equals(this.status);
    }
}
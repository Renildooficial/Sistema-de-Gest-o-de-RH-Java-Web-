package com.sigrh.service;

import com.sigrh.dao.NomeacaoDAO;
import com.sigrh.model.Nomeacao;
import com.sigrh.exception.BusinessException;
import java.util.List;

public class NomeacaoService {
    
    private NomeacaoDAO nomeacaoDAO;
    
    public NomeacaoService() {
        this.nomeacaoDAO = new NomeacaoDAO();
    }
    
    /**
     * Busca todas as nomeações de um funcionário
     */
    public List<Nomeacao> buscarPorFuncionario(Integer idFuncionario) throws BusinessException {
        if (idFuncionario == null || idFuncionario <= 0) {
            throw new BusinessException("ID do funcionário inválido");
        }
        return nomeacaoDAO.findByFuncionario(idFuncionario);
    }
    
    /**
     * Busca uma nomeação por ID
     */
    public Nomeacao buscarPorId(Integer id) throws BusinessException {
        if (id == null || id <= 0) {
            throw new BusinessException("ID da nomeação inválido");
        }
        Nomeacao nomeacao = nomeacaoDAO.buscarPorId(id);
        if (nomeacao == null) {
            throw new BusinessException("Nomeação não encontrada");
        }
        return nomeacao;
    }
    
    /**
     * Busca todas as nomeações ativas
     */
    public List<Nomeacao> buscarAtivas() throws BusinessException {
        return nomeacaoDAO.listarAtivas();
    }
    
    /**
     * Salva uma nova nomeação
     */
    public void salvar(Nomeacao nomeacao) throws BusinessException {
        if (nomeacao == null) {
            throw new BusinessException("Nomeação não pode ser nula");
        }
        if (nomeacao.getIdFuncionario() == null || nomeacao.getIdFuncionario() <= 0) {
            throw new BusinessException("Funcionário é obrigatório");
        }
        if (nomeacao.getFuncao() == null || nomeacao.getFuncao().trim().isEmpty()) {
            throw new BusinessException("Função é obrigatória");
        }
        if (nomeacao.getCargo() == null || nomeacao.getCargo().trim().isEmpty()) {
            throw new BusinessException("Cargo é obrigatório");
        }
        nomeacaoDAO.salvar(nomeacao);
    }
    
    /**
     * Atualiza uma nomeação existente
     */
    public void atualizar(Nomeacao nomeacao) throws BusinessException {
        if (nomeacao == null) {
            throw new BusinessException("Nomeação não pode ser nula");
        }
        if (nomeacao.getId() == null || nomeacao.getId() <= 0) {
            throw new BusinessException("ID da nomeação inválido");
        }
        nomeacaoDAO.atualizar(nomeacao);
    }
    
    /**
     * Encerra uma nomeação (muda status para INATIVA)
     */
    public void encerrar(Integer id) throws BusinessException {
        if (id == null || id <= 0) {
            throw new BusinessException("ID da nomeação inválido");
        }
        Nomeacao nomeacao = buscarPorId(id);
        nomeacao.setStatus("INATIVA");
        nomeacaoDAO.atualizar(nomeacao);
    }
    
    /**
     * Exclui uma nomeação
     */
    public void excluir(Integer id) throws BusinessException {
        if (id == null || id <= 0) {
            throw new BusinessException("ID da nomeação inválido");
        }
        nomeacaoDAO.excluir(id);
    }
}
package com.sigrh.controller;

import com.sigrh.dao.PlanoFeriasDAO;
import com.sigrh.dao.FuncionarioDAO;
import com.sigrh.exception.BusinessException;
import com.sigrh.model.PlanoFerias;
import com.sigrh.model.Usuario;
import com.sigrh.model.Funcionario;
import com.sigrh.service.AuditoriaService;
import com.sigrh.service.FuncionarioService;
import com.sigrh.util.Constants;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.io.PrintWriter;
import java.time.Year;
import java.util.ArrayList;
import java.util.List;

@WebServlet(name = "PlanoFeriasController", urlPatterns = {"/plano-ferias", "/plano-ferias/*"})
public class PlanoFeriasController extends HttpServlet {
    
    private static final long serialVersionUID = 1L;
    private PlanoFeriasDAO planoFeriasDAO;
    private FuncionarioDAO funcionarioDAO;
    private FuncionarioService funcionarioService;
    private AuditoriaService auditoriaService;
    
    // Nomes dos meses em português
    private static final String[] MESES = {
        "Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho",
        "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"
    };
    
    @Override
    public void init() {
        this.planoFeriasDAO = new PlanoFeriasDAO();
        this.funcionarioDAO = new FuncionarioDAO();
        this.funcionarioService = new FuncionarioService();
        this.auditoriaService = new AuditoriaService();
    }
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String pathInfo = request.getPathInfo();
        System.out.println("🔍 PlanoFeriasController.doGet - Path: " + pathInfo);
        
        Usuario usuario = (Usuario) request.getSession().getAttribute(Constants.SESSION_USER);
        if (usuario == null) {
            request.getSession().setAttribute(Constants.MSG_ERRO, "Faça login primeiro");
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }
        
        try {
            if (pathInfo == null || pathInfo.equals("/") || pathInfo.equals("")) {
                listar(request, response);
            } else if (pathInfo.equals("/novo")) {
                novo(request, response);
            } else if (pathInfo.startsWith("/editar/")) {
                editar(request, response);
            } else if (pathInfo.equals("/api/listar")) {
                listarApi(request, response);
            } else {
                response.sendError(HttpServletResponse.SC_NOT_FOUND);
            }
        } catch (Exception e) {
            e.printStackTrace();
            request.getSession().setAttribute(Constants.MSG_ERRO, "Erro: " + e.getMessage());
            response.sendRedirect(request.getContextPath() + "/plano-ferias");
        }
    }
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String pathInfo = request.getPathInfo();
        System.out.println("🔍 PlanoFeriasController.doPost - Path: " + pathInfo);
        
        Usuario usuario = (Usuario) request.getSession().getAttribute(Constants.SESSION_USER);
        if (usuario == null) {
            response.setContentType("application/json");
            response.getWriter().write("{\"success\": false, \"message\": \"Usuário não logado\"}");
            return;
        }
        
        try {
            if (pathInfo == null || pathInfo.equals("/") || pathInfo.equals("")) {
                salvar(request, response);
            } else if (pathInfo.equals("/excluir")) {
                excluir(request, response);
            } else if (pathInfo.equals("/atualizar-status")) {
                atualizarStatus(request, response);
            } else {
                response.sendError(HttpServletResponse.SC_NOT_FOUND);
            }
        } catch (Exception e) {
            e.printStackTrace();
            response.setContentType("application/json");
            response.getWriter().write("{\"success\": false, \"message\": \"" + e.getMessage() + "\"}");
        }
    }
    
    // ============================================================
    // LISTAR - VERSÃO CORRIGIDA
    // ============================================================
    private void listar(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        Usuario usuario = (Usuario) request.getSession().getAttribute(Constants.SESSION_USER);
        if (usuario == null || !(usuario.isAdmin() || usuario.isRH() || usuario.isGestor())) {
            request.getSession().setAttribute(Constants.MSG_ERRO, "Acesso negado");
            response.sendRedirect(request.getContextPath() + "/dashboard");
            return;
        }
        
        try {
            // Pegar o ano da requisição ou usar o ano atual
            String anoParam = request.getParameter("ano");
            int ano;
            if (anoParam != null && !anoParam.isEmpty()) {
                ano = Integer.parseInt(anoParam);
            } else {
                ano = Year.now().getValue();
            }
            
            System.out.println("📅 Listando planos para o ano: " + ano);
            
            // Buscar planos do ano
            List<PlanoFerias> planos = planoFeriasDAO.findByAno(ano);
            
            // Carregar funcionários para cada plano
            if (planos != null && !planos.isEmpty()) {
                for (PlanoFerias p : planos) {
                    if (p.getIdFuncionario() != null) {
                        try {
                            Funcionario f = funcionarioDAO.buscarPorId(p.getIdFuncionario());
                            p.setFuncionario(f);
                        } catch (Exception e) {
                            System.err.println("Erro ao carregar funcionário: " + e.getMessage());
                        }
                    }
                }
            } else {
                planos = new ArrayList<>();
            }
            
            // Estatísticas
            int total = planos.size();
            int pendentes = 0, aprovados = 0, execucao = 0, concluidos = 0, cancelados = 0;
            
            for (PlanoFerias p : planos) {
                String status = p.getStatus();
                if (status == null) status = "PENDENTE";
                switch (status) {
                    case "PENDENTE": pendentes++; break;
                    case "APROVADO": aprovados++; break;
                    case "EM_EXECUCAO": execucao++; break;
                    case "CONCLUIDO": concluidos++; break;
                    case "CANCELADO": cancelados++; break;
                }
                // Definir nome do mês
                if (p.getMesPlanejado() != null && p.getMesPlanejado() >= 1 && p.getMesPlanejado() <= 12) {
                    p.setNomeMes(MESES[p.getMesPlanejado() - 1]);
                }
            }
            
            request.setAttribute("planos", planos);
            request.setAttribute("total", total);
            request.setAttribute("pendentes", pendentes);
            request.setAttribute("aprovados", aprovados);
            request.setAttribute("execucao", execucao);
            request.setAttribute("concluidos", concluidos);
            request.setAttribute("cancelados", cancelados);
            request.setAttribute("ano", ano);
            request.setAttribute("anoAtual", Year.now().getValue());
            request.setAttribute("anos", getAnosDisponiveis(ano));
            
            request.getSession().removeAttribute(Constants.MSG_ERRO);
            request.getSession().removeAttribute(Constants.MSG_SUCESSO);
            
            request.getRequestDispatcher("/WEB-INF/views/rh/plano-ferias.jsp").forward(request, response);
            
        } catch (NumberFormatException e) {
            request.getSession().setAttribute(Constants.MSG_ERRO, "Ano inválido");
            response.sendRedirect(request.getContextPath() + "/plano-ferias");
        } catch (Exception e) {
            e.printStackTrace();
            request.getSession().setAttribute(Constants.MSG_ERRO, "Erro ao listar planos: " + e.getMessage());
            response.sendRedirect(request.getContextPath() + "/dashboard");
        }
    }
    
    // ============================================================
    // LISTAR API (JSON)
    // ============================================================
    private void listarApi(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();
        
        try {
            String anoParam = request.getParameter("ano");
            int ano = (anoParam != null && !anoParam.isEmpty()) ? Integer.parseInt(anoParam) : Year.now().getValue();
            
            List<PlanoFerias> planos = planoFeriasDAO.findByAno(ano);
            
            // Carregar funcionários
            for (PlanoFerias p : planos) {
                if (p.getIdFuncionario() != null) {
                    try {
                        Funcionario f = funcionarioDAO.buscarPorId(p.getIdFuncionario());
                        p.setFuncionario(f);
                    } catch (Exception e) { /* Ignorar */ }
                }
                if (p.getMesPlanejado() != null && p.getMesPlanejado() >= 1 && p.getMesPlanejado() <= 12) {
                    p.setNomeMes(MESES[p.getMesPlanejado() - 1]);
                }
            }
            
            // Construir JSON
            StringBuilder json = new StringBuilder();
            json.append("{\"success\":true,\"planos\":[");
            for (int i = 0; i < planos.size(); i++) {
                PlanoFerias p = planos.get(i);
                if (i > 0) json.append(",");
                json.append("{");
                json.append("\"id\":").append(p.getId()).append(",");
                json.append("\"idFuncionario\":").append(p.getIdFuncionario()).append(",");
                json.append("\"funcionarioNome\":\"").append(p.getFuncionario() != null ? p.getFuncionario().getNome() : "").append("\",");
                json.append("\"mesPlanejado\":").append(p.getMesPlanejado()).append(",");
                json.append("\"nomeMes\":\"").append(p.getNomeMes() != null ? p.getNomeMes() : "").append("\",");
                json.append("\"ano\":").append(p.getAno()).append(",");
                json.append("\"prioridade\":").append(p.getPrioridade()).append(",");
                json.append("\"status\":\"").append(p.getStatus() != null ? p.getStatus() : "PENDENTE").append("\",");
                json.append("\"observacao\":\"").append(p.getObservacao() != null ? p.getObservacao() : "").append("\"");
                json.append("}");
            }
            json.append("]}");
            
            out.print(json.toString());
            
        } catch (Exception e) {
            e.printStackTrace();
            out.print("{\"success\":false,\"message\":\"" + e.getMessage() + "\"}");
        }
        
        out.flush();
    }
    
    // ============================================================
    // NOVO
    // ============================================================
    private void novo(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        Usuario usuario = (Usuario) request.getSession().getAttribute(Constants.SESSION_USER);
        if (usuario == null || !(usuario.isAdmin() || usuario.isRH())) {
            request.getSession().setAttribute(Constants.MSG_ERRO, "Acesso negado");
            response.sendRedirect(request.getContextPath() + "/dashboard");
            return;
        }
        
        try {
            List<Funcionario> funcionarios = funcionarioService.listarTodos();
            request.setAttribute("funcionarios", funcionarios);
            request.setAttribute("plano", new PlanoFerias());
            request.setAttribute("acao", "cadastrar");
            request.setAttribute("meses", MESES);
            request.setAttribute("anoAtual", Year.now().getValue());
            request.setAttribute("statusOptions", getStatusOptions());
            
            request.getSession().removeAttribute(Constants.MSG_ERRO);
            request.getSession().removeAttribute(Constants.MSG_SUCESSO);
            
            request.getRequestDispatcher("/WEB-INF/views/rh/plano-ferias-form.jsp").forward(request, response);
            
        } catch (BusinessException e) {
            request.getSession().setAttribute(Constants.MSG_ERRO, e.getMessage());
            response.sendRedirect(request.getContextPath() + "/plano-ferias");
        }
    }
    
    // ============================================================
    // EDITAR
    // ============================================================
    private void editar(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        Usuario usuario = (Usuario) request.getSession().getAttribute(Constants.SESSION_USER);
        if (usuario == null || !(usuario.isAdmin() || usuario.isRH())) {
            request.getSession().setAttribute(Constants.MSG_ERRO, "Acesso negado");
            response.sendRedirect(request.getContextPath() + "/dashboard");
            return;
        }
        
        String pathInfo = request.getPathInfo();
        String[] parts = pathInfo.split("/");
        
        if (parts.length < 3) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST);
            return;
        }
        
        try {
            Integer id = Integer.parseInt(parts[2]);
            System.out.println("🔍 Editando plano ID: " + id);
            
            PlanoFerias plano = planoFeriasDAO.buscarPorId(id);
            
            if (plano == null) {
                request.getSession().setAttribute(Constants.MSG_ERRO, "Plano não encontrado");
                response.sendRedirect(request.getContextPath() + "/plano-ferias");
                return;
            }
            
            if (plano.getIdFuncionario() != null) {
                try {
                    Funcionario f = funcionarioDAO.buscarPorId(plano.getIdFuncionario());
                    plano.setFuncionario(f);
                } catch (Exception e) { /* Ignorar */ }
            }
            
            List<Funcionario> funcionarios = funcionarioService.listarTodos();
            request.setAttribute("funcionarios", funcionarios);
            request.setAttribute("plano", plano);
            request.setAttribute("acao", "editar");
            request.setAttribute("meses", MESES);
            request.setAttribute("anoAtual", Year.now().getValue());
            request.setAttribute("statusOptions", getStatusOptions());
            
            request.getRequestDispatcher("/WEB-INF/views/rh/plano-ferias-form.jsp").forward(request, response);
            
        } catch (NumberFormatException e) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST);
        } catch (Exception e) {
            e.printStackTrace();
            request.getSession().setAttribute(Constants.MSG_ERRO, "Erro ao carregar plano: " + e.getMessage());
            response.sendRedirect(request.getContextPath() + "/plano-ferias");
        }
    }
    
    // ============================================================
    // SALVAR - CORRIGIDO
    // ============================================================
    private void salvar(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        
        Usuario usuario = (Usuario) request.getSession().getAttribute(Constants.SESSION_USER);
        if (usuario == null || !(usuario.isAdmin() || usuario.isRH())) {
            response.setContentType("application/json");
            response.getWriter().write("{\"success\":false,\"message\":\"Acesso negado\"}");
            return;
        }
        
        response.setContentType("application/json");
        PrintWriter out = response.getWriter();
        
        try {
            String idStr = request.getParameter("id");
            String idFuncionarioStr = request.getParameter("idFuncionario");
            String mesPlanejadoStr = request.getParameter("mesPlanejado");
            String anoStr = request.getParameter("ano");
            String prioridadeStr = request.getParameter("prioridade");
            String status = request.getParameter("status");
            String observacao = request.getParameter("observacao");
            
            // VALIDAÇÕES
            if (idFuncionarioStr == null || idFuncionarioStr.isEmpty()) {
                out.print("{\"success\":false,\"message\":\"Funcionário é obrigatório\"}");
                out.flush();
                return;
            }
            
            if (mesPlanejadoStr == null || mesPlanejadoStr.isEmpty()) {
                out.print("{\"success\":false,\"message\":\"Mês planejado é obrigatório\"}");
                out.flush();
                return;
            }
            
            if (anoStr == null || anoStr.isEmpty()) {
                out.print("{\"success\":false,\"message\":\"Ano é obrigatório\"}");
                out.flush();
                return;
            }
            
            if (prioridadeStr == null || prioridadeStr.isEmpty()) {
                out.print("{\"success\":false,\"message\":\"Prioridade é obrigatória\"}");
                out.flush();
                return;
            }
            
            // Criar objeto
            Integer id = (idStr != null && !idStr.isEmpty()) ? Integer.parseInt(idStr) : null;
            PlanoFerias plano = new PlanoFerias();
            
            if (id != null) {
                plano.setId(id);
            }
            plano.setIdFuncionario(Integer.parseInt(idFuncionarioStr));
            plano.setMesPlanejado(Integer.parseInt(mesPlanejadoStr));
            plano.setAno(Integer.parseInt(anoStr));
            plano.setPrioridade(Integer.parseInt(prioridadeStr));
            // CORRIGIDO: Garantir que status seja salvo
            plano.setStatus(status != null && !status.isEmpty() ? status : "PENDENTE");
            plano.setObservacao(observacao);
            
            // SALVAR
            if (id == null) {
                planoFeriasDAO.salvar(plano);
                out.print("{\"success\":true,\"message\":\"Plano cadastrado com sucesso!\"}");
            } else {
                planoFeriasDAO.atualizar(plano);
                out.print("{\"success\":true,\"message\":\"Plano atualizado com sucesso!\"}");
            }
            
        } catch (NumberFormatException e) {
            out.print("{\"success\":false,\"message\":\"Dados inválidos: " + e.getMessage() + "\"}");
        } catch (Exception e) {
            e.printStackTrace();
            out.print("{\"success\":false,\"message\":\"Erro ao salvar: " + e.getMessage() + "\"}");
        }
        
        out.flush();
    }
    
    // ============================================================
    // EXCLUIR
    // ============================================================
    private void excluir(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        
        response.setContentType("application/json");
        PrintWriter out = response.getWriter();
        
        Usuario usuario = (Usuario) request.getSession().getAttribute(Constants.SESSION_USER);
        if (usuario == null || !(usuario.isAdmin() || usuario.isRH())) {
            out.print("{\"success\":false,\"message\":\"Acesso negado\"}");
            out.flush();
            return;
        }
        
        try {
            String idStr = request.getParameter("id");
            if (idStr == null || idStr.isEmpty()) {
                out.print("{\"success\":false,\"message\":\"ID não informado\"}");
                out.flush();
                return;
            }
            
            Integer id = Integer.parseInt(idStr);
            System.out.println("🔍 Excluindo plano ID: " + id);
            
            planoFeriasDAO.excluir(id);
            
            out.print("{\"success\":true,\"message\":\"Plano excluído com sucesso!\"}");
            
        } catch (Exception e) {
            e.printStackTrace();
            out.print("{\"success\":false,\"message\":\"Erro ao excluir: " + e.getMessage() + "\"}");
        }
        
        out.flush();
    }
    
    // ============================================================
    // ATUALIZAR STATUS
    // ============================================================
    private void atualizarStatus(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        
        response.setContentType("application/json");
        PrintWriter out = response.getWriter();
        
        Usuario usuario = (Usuario) request.getSession().getAttribute(Constants.SESSION_USER);
        if (usuario == null || !(usuario.isAdmin() || usuario.isRH() || usuario.isGestor())) {
            out.print("{\"success\":false,\"message\":\"Acesso negado\"}");
            out.flush();
            return;
        }
        
        try {
            String idStr = request.getParameter("id");
            String status = request.getParameter("status");
            
            if (idStr == null || idStr.isEmpty()) {
                out.print("{\"success\":false,\"message\":\"ID não informado\"}");
                out.flush();
                return;
            }
            
            if (status == null || status.isEmpty()) {
                out.print("{\"success\":false,\"message\":\"Status não informado\"}");
                out.flush();
                return;
            }
            
            Integer id = Integer.parseInt(idStr);
            planoFeriasDAO.atualizarStatus(id, status);
            
            out.print("{\"success\":true,\"message\":\"Status atualizado com sucesso!\"}");
            
        } catch (Exception e) {
            e.printStackTrace();
            out.print("{\"success\":false,\"message\":\"Erro ao atualizar status: " + e.getMessage() + "\"}");
        }
        
        out.flush();
    }
    
    // ============================================================
    // MÉTODOS AUXILIARES
    // ============================================================
    
    private List<Integer> getAnosDisponiveis(int anoAtual) {
        List<Integer> anos = new ArrayList<>();
        for (int i = anoAtual - 3; i <= anoAtual + 2; i++) {
            anos.add(i);
        }
        return anos;
    }
    
    private List<String> getStatusOptions() {
        List<String> status = new ArrayList<>();
        status.add("PENDENTE");
        status.add("APROVADO");
        status.add("EM_EXECUCAO");
        status.add("CONCLUIDO");
        status.add("CANCELADO");
        return status;
    }
    
}
package com.sigrh.service;

import com.sigrh.dao.AuditoriaDAO;
import com.sigrh.exception.BusinessException;
import com.sigrh.exception.DatabaseException;
import com.sigrh.model.Auditoria;
import com.sigrh.model.Usuario;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import jakarta.servlet.http.HttpServletRequest;

import java.sql.Timestamp;
import java.util.List;

public class AuditoriaService {
    
    private static final Logger logger = LogManager.getLogger(AuditoriaService.class);
    private final AuditoriaDAO auditoriaDAO;
    
    public AuditoriaService() {
        this.auditoriaDAO = new AuditoriaDAO();
    }
    
    // ============================================================
    // REGISTRAR AUDITORIA
    // ============================================================
    
    public void registrar(Usuario usuario, String acao, String tabela, Integer idRegistro, 
                          String dadosAntigos, String dadosNovos, HttpServletRequest request) 
                          throws BusinessException {
        try {
            Auditoria auditoria = new Auditoria();
            auditoria.setIdUsuario(usuario.getId());
            auditoria.setAcao(acao);
            auditoria.setTabela(tabela);
            auditoria.setIdRegistro(idRegistro); // Pode ser null
            auditoria.setDadosAntigos(dadosAntigos);
            auditoria.setDadosNovos(dadosNovos);
            auditoria.setDataHora(new Timestamp(System.currentTimeMillis()));
            
            if (request != null) {
                auditoria.setIp(obterIp(request));
                auditoria.setUserAgent(request.getHeader("User-Agent"));
            } else {
                auditoria.setIp("SISTEMA");
                auditoria.setUserAgent("SISTEMA");
            }
            
            auditoriaDAO.salvar(auditoria);
            logger.info("Auditoria registrada: {} - {} em {}", acao, usuario.getUsuario(), tabela);
            
        } catch (DatabaseException e) {
            logger.error("Erro ao registrar auditoria", e);
            throw new BusinessException("Erro ao registrar auditoria", e);
        }
    }
    
    public void registrar(Usuario usuario, String acao, String tabela, Integer idRegistro,
                          String dadosAntigos, String dadosNovos) throws BusinessException {
        registrar(usuario, acao, tabela, idRegistro, dadosAntigos, dadosNovos, null);
    }
    
    public void registrar(Usuario usuario, String acao, String tabela, Integer idRegistro,
                          HttpServletRequest request) throws BusinessException {
        registrar(usuario, acao, tabela, idRegistro, null, null, request);
    }
    
    // ============================================================
    // CONSULTAS
    // ============================================================
    
    public List<Auditoria> listarTodos() throws BusinessException {
        try {
            return auditoriaDAO.listarTodos();
        } catch (DatabaseException e) {
            logger.error("Erro ao listar auditorias", e);
            throw new BusinessException("Erro ao listar auditorias", e);
        }
    }
    
    public List<Auditoria> listarComUsuarios() throws BusinessException {
        try {
            return auditoriaDAO.findAllWithUser();
        } catch (DatabaseException e) {
            logger.error("Erro ao listar auditorias com usuários", e);
            throw new BusinessException("Erro ao listar auditorias", e);
        }
    }
    
    public List<Auditoria> buscarPorUsuario(Integer idUsuario) throws BusinessException {
        try {
            return auditoriaDAO.findByUsuario(idUsuario);
        } catch (DatabaseException e) {
            logger.error("Erro ao buscar auditorias por usuário", e);
            throw new BusinessException("Erro ao buscar auditorias", e);
        }
    }
    
    public List<Auditoria> buscarPorTabela(String tabela) throws BusinessException {
        try {
            return auditoriaDAO.findByTabela(tabela);
        } catch (DatabaseException e) {
            logger.error("Erro ao buscar auditorias por tabela", e);
            throw new BusinessException("Erro ao buscar auditorias", e);
        }
    }
    
    public List<Auditoria> buscarPorAcao(String acao) throws BusinessException {
        try {
            return auditoriaDAO.findByAcao(acao);
        } catch (DatabaseException e) {
            logger.error("Erro ao buscar auditorias por ação", e);
            throw new BusinessException("Erro ao buscar auditorias", e);
        }
    }
    
    public int contar() throws BusinessException {
        try {
            return auditoriaDAO.contar();
        } catch (DatabaseException e) {
            logger.error("Erro ao contar auditorias", e);
            throw new BusinessException("Erro ao contar auditorias", e);
        }
    }
    
    // ============================================================
    // MÉTODOS AUXILIARES
    // ============================================================
    
    private String obterIp(HttpServletRequest request) {
        String ip = request.getHeader("X-Forwarded-For");
        if (ip == null || ip.isEmpty() || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("Proxy-Client-IP");
        }
        if (ip == null || ip.isEmpty() || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("WL-Proxy-Client-IP");
        }
        if (ip == null || ip.isEmpty() || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getRemoteAddr();
        }
        if (ip != null && ip.contains(",")) {
            ip = ip.split(",")[0].trim();
        }
        return ip != null ? ip : "0.0.0.0";
    }
}
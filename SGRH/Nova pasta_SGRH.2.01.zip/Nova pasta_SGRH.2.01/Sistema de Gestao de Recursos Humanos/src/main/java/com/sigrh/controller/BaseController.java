package com.sigrh.controller;

import com.sigrh.model.Usuario;
import com.sigrh.util.Constants;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.IOException;

/**
 * Classe base para todos os controllers
 */
public abstract class BaseController {
    
    protected static final Logger logger = LogManager.getLogger(BaseController.class);
    
    /**
     * Obtém o usuário da sessão
     */
    protected Usuario getUsuarioLogado(HttpServletRequest request) {
        HttpSession session = request.getSession(false);
        if (session != null) {
            return (Usuario) session.getAttribute(Constants.SESSION_USER);
        }
        return null;
    }
    
    /**
     * Verifica se o usuário está logado
     */
    protected boolean isLogado(HttpServletRequest request) {
        return getUsuarioLogado(request) != null;
    }
    
    /**
     * Verifica se o usuário tem permissão
     */
    protected boolean temPermissao(HttpServletRequest request, String... perfis) {
        Usuario usuario = getUsuarioLogado(request);
        if (usuario == null) return false;
        if (usuario.isAdmin()) return true;
        
        for (String perfil : perfis) {
            if (usuario.getPerfil().name().equals(perfil)) {
                return true;
            }
        }
        return false;
    }
    
    /**
     * Redireciona para uma página
     */
    protected void redirect(HttpServletRequest request, HttpServletResponse response, String url) 
            throws IOException {
        response.sendRedirect(request.getContextPath() + url);
    }
    
    /**
     * Encaminha para uma página (forward)
     */
    protected void forward(HttpServletRequest request, HttpServletResponse response, String path) 
            throws IOException, jakarta.servlet.ServletException {
        request.getRequestDispatcher(path).forward(request, response);
    }
    
    /**
     * Define uma mensagem de sucesso na sessão
     */
    protected void setSuccessMessage(HttpServletRequest request, String message) {
        request.getSession().setAttribute(Constants.MSG_SUCESSO, message);
    }
    
    /**
     * Define uma mensagem de erro na sessão
     */
    protected void setErrorMessage(HttpServletRequest request, String message) {
        request.getSession().setAttribute(Constants.MSG_ERRO, message);
    }
    
    /**
     * Define uma mensagem informativa na sessão
     */
    protected void setInfoMessage(HttpServletRequest request, String message) {
        request.getSession().setAttribute(Constants.MSG_INFO, message);
    }
    
    /**
     * Remove mensagens da sessão
     */
    protected void clearMessages(HttpServletRequest request) {
        HttpSession session = request.getSession();
        session.removeAttribute(Constants.MSG_SUCESSO);
        session.removeAttribute(Constants.MSG_ERRO);
        session.removeAttribute(Constants.MSG_INFO);
    }
}
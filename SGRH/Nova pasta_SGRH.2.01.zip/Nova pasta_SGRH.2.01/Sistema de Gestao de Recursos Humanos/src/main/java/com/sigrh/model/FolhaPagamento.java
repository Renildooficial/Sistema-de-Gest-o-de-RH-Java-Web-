package com.sigrh.model;

import java.math.BigDecimal;
import java.sql.Timestamp;

public class FolhaPagamento extends BaseModel {
    
    private static final long serialVersionUID = 1L;
    
    public enum StatusFolha { PENDENTE, PROCESSADO, PAGO, CANCELADO }
    
    private Integer idFuncionario;
    private Integer mesReferencia;
    private Integer anoReferencia;
    
    private BigDecimal salarioBase;
    private BigDecimal subsidioAlimentacao;
    private BigDecimal subsidioTransporte;
    private BigDecimal subsidioSaude;
    private BigDecimal bonus;
    private BigDecimal outrosGanhos;
    
    private BigDecimal descontoIrs;
    private BigDecimal descontoInss;
    private BigDecimal descontoSaude;
    private BigDecimal descontoOutros;
    
    private BigDecimal totalBruto;
    private BigDecimal totalDescontos;
    private BigDecimal totalLiquido;
    
    private StatusFolha status;
    private Timestamp dataProcessamento;
    private Timestamp dataPagamento;
    private String observacao;
    
    private Funcionario funcionario;
    
    public FolhaPagamento() {
        super();
        this.status = StatusFolha.PENDENTE;
        this.salarioBase = BigDecimal.ZERO;
        this.subsidioAlimentacao = BigDecimal.ZERO;
        this.subsidioTransporte = BigDecimal.ZERO;
        this.subsidioSaude = BigDecimal.ZERO;
        this.bonus = BigDecimal.ZERO;
        this.outrosGanhos = BigDecimal.ZERO;
        this.descontoIrs = BigDecimal.ZERO;
        this.descontoInss = BigDecimal.ZERO;
        this.descontoSaude = BigDecimal.ZERO;
        this.descontoOutros = BigDecimal.ZERO;
    }
    
    // Getters e Setters
    public Integer getIdFuncionario() { return idFuncionario; }
    public void setIdFuncionario(Integer idFuncionario) { this.idFuncionario = idFuncionario; }
    
    public Integer getMesReferencia() { return mesReferencia; }
    public void setMesReferencia(Integer mesReferencia) { this.mesReferencia = mesReferencia; }
    
    public Integer getAnoReferencia() { return anoReferencia; }
    public void setAnoReferencia(Integer anoReferencia) { this.anoReferencia = anoReferencia; }
    
    public BigDecimal getSalarioBase() { return salarioBase; }
    public void setSalarioBase(BigDecimal salarioBase) { this.salarioBase = salarioBase; }
    
    public BigDecimal getSubsidioAlimentacao() { return subsidioAlimentacao; }
    public void setSubsidioAlimentacao(BigDecimal subsidioAlimentacao) { this.subsidioAlimentacao = subsidioAlimentacao; }
    
    public BigDecimal getSubsidioTransporte() { return subsidioTransporte; }
    public void setSubsidioTransporte(BigDecimal subsidioTransporte) { this.subsidioTransporte = subsidioTransporte; }
    
    public BigDecimal getSubsidioSaude() { return subsidioSaude; }
    public void setSubsidioSaude(BigDecimal subsidioSaude) { this.subsidioSaude = subsidioSaude; }
    
    public BigDecimal getBonus() { return bonus; }
    public void setBonus(BigDecimal bonus) { this.bonus = bonus; }
    
    public BigDecimal getOutrosGanhos() { return outrosGanhos; }
    public void setOutrosGanhos(BigDecimal outrosGanhos) { this.outrosGanhos = outrosGanhos; }
    
    public BigDecimal getDescontoIrs() { return descontoIrs; }
    public void setDescontoIrs(BigDecimal descontoIrs) { this.descontoIrs = descontoIrs; }
    
    public BigDecimal getDescontoInss() { return descontoInss; }
    public void setDescontoInss(BigDecimal descontoInss) { this.descontoInss = descontoInss; }
    
    public BigDecimal getDescontoSaude() { return descontoSaude; }
    public void setDescontoSaude(BigDecimal descontoSaude) { this.descontoSaude = descontoSaude; }
    
    public BigDecimal getDescontoOutros() { return descontoOutros; }
    public void setDescontoOutros(BigDecimal descontoOutros) { this.descontoOutros = descontoOutros; }
    
    public BigDecimal getTotalBruto() { return totalBruto; }
    public void setTotalBruto(BigDecimal totalBruto) { this.totalBruto = totalBruto; }
    
    public BigDecimal getTotalDescontos() { return totalDescontos; }
    public void setTotalDescontos(BigDecimal totalDescontos) { this.totalDescontos = totalDescontos; }
    
    public BigDecimal getTotalLiquido() { return totalLiquido; }
    public void setTotalLiquido(BigDecimal totalLiquido) { this.totalLiquido = totalLiquido; }
    
    public StatusFolha getStatus() { return status; }
    public void setStatus(StatusFolha status) { this.status = status; }
    public void setStatus(String status) { this.status = StatusFolha.valueOf(status); }
    
    public Timestamp getDataProcessamento() { return dataProcessamento; }
    public void setDataProcessamento(Timestamp dataProcessamento) { this.dataProcessamento = dataProcessamento; }
    
    public Timestamp getDataPagamento() { return dataPagamento; }
    public void setDataPagamento(Timestamp dataPagamento) { this.dataPagamento = dataPagamento; }
    
    public String getObservacao() { return observacao; }
    public void setObservacao(String observacao) { this.observacao = observacao; }
    
    public Funcionario getFuncionario() { return funcionario; }
    public void setFuncionario(Funcionario funcionario) {
        this.funcionario = funcionario;
        if (funcionario != null) this.idFuncionario = funcionario.getId();
    }
    
    public void calcularTotais() {
        if (salarioBase == null) salarioBase = BigDecimal.ZERO;
        if (subsidioAlimentacao == null) subsidioAlimentacao = BigDecimal.ZERO;
        if (subsidioTransporte == null) subsidioTransporte = BigDecimal.ZERO;
        if (subsidioSaude == null) subsidioSaude = BigDecimal.ZERO;
        if (bonus == null) bonus = BigDecimal.ZERO;
        if (outrosGanhos == null) outrosGanhos = BigDecimal.ZERO;
        if (descontoIrs == null) descontoIrs = BigDecimal.ZERO;
        if (descontoInss == null) descontoInss = BigDecimal.ZERO;
        if (descontoSaude == null) descontoSaude = BigDecimal.ZERO;
        if (descontoOutros == null) descontoOutros = BigDecimal.ZERO;
        
        this.totalBruto = salarioBase.add(subsidioAlimentacao)
                .add(subsidioTransporte).add(subsidioSaude)
                .add(bonus).add(outrosGanhos);
        
        this.totalDescontos = descontoIrs.add(descontoInss)
                .add(descontoSaude).add(descontoOutros);
        
        this.totalLiquido = totalBruto.subtract(totalDescontos);
    }
}
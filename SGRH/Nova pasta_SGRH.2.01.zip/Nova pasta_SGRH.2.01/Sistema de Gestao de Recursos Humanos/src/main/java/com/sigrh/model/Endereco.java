package com.sigrh.model;

public class Endereco extends BaseModel {
    
    private static final long serialVersionUID = 1L;
    
    public enum TipoEndereco { RESIDENCIAL, COMERCIAL, OUTRO }
    
    private Integer idFuncionario;
    private String logradouro;
    private String numero;
    private String bairro;
    private String cidade;
    private String provincia;
    private String cep;
    private String complemento;
    private TipoEndereco tipo;
    private Boolean principal;
    
    private Funcionario funcionario;
    
    public Endereco() {
        super();
        this.principal = true;
        this.tipo = TipoEndereco.RESIDENCIAL;
    }
    
    // Getters e Setters
    public Integer getIdFuncionario() { return idFuncionario; }
    public void setIdFuncionario(Integer idFuncionario) { this.idFuncionario = idFuncionario; }
    
    public String getLogradouro() { return logradouro; }
    public void setLogradouro(String logradouro) { this.logradouro = logradouro; }
    
    public String getNumero() { return numero; }
    public void setNumero(String numero) { this.numero = numero; }
    
    public String getBairro() { return bairro; }
    public void setBairro(String bairro) { this.bairro = bairro; }
    
    public String getCidade() { return cidade; }
    public void setCidade(String cidade) { this.cidade = cidade; }
    
    public String getProvincia() { return provincia; }
    public void setProvincia(String provincia) { this.provincia = provincia; }
    
    public String getCep() { return cep; }
    public void setCep(String cep) { this.cep = cep; }
    
    public String getComplemento() { return complemento; }
    public void setComplemento(String complemento) { this.complemento = complemento; }
    
    public TipoEndereco getTipo() { return tipo; }
    public void setTipo(TipoEndereco tipo) { this.tipo = tipo; }
    public void setTipo(String tipo) { this.tipo = TipoEndereco.valueOf(tipo); }
    
    public Boolean getPrincipal() { return principal; }
    public void setPrincipal(Boolean principal) { this.principal = principal; }
    
    public Funcionario getFuncionario() { return funcionario; }
    public void setFuncionario(Funcionario funcionario) {
        this.funcionario = funcionario;
        if (funcionario != null) this.idFuncionario = funcionario.getId();
    }
    
    public String getEnderecoCompleto() {
        StringBuilder sb = new StringBuilder();
        sb.append(logradouro);
        if (numero != null && !numero.isEmpty()) sb.append(", ").append(numero);
        if (bairro != null && !bairro.isEmpty()) sb.append(", ").append(bairro);
        sb.append(" - ").append(cidade).append(", ").append(provincia);
        return sb.toString();
    }
}
package com.sigrh.controller;

import com.sigrh.exception.BusinessException;
import com.sigrh.model.Ferias;
import com.sigrh.model.Funcionario;
import com.sigrh.model.Usuario;
import com.sigrh.service.ExportacaoService;
import com.sigrh.service.FeriasService;
import com.sigrh.service.FuncionarioService;
import com.sigrh.service.RelatorioService;
import com.sigrh.util.Constants;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.Calendar;
import java.util.List;
import java.util.Map;

@WebServlet(urlPatterns = "/relatorios/*")
public class RelatoriosController extends HttpServlet {
    
    private static final long serialVersionUID = 1L;
    
    private final RelatorioService relatorioService;
    private final FuncionarioService funcionarioService;
    private final FeriasService feriasService;
    private final ExportacaoService exportacaoService;
    
    public RelatoriosController() {
        this.relatorioService = new RelatorioService();
        this.funcionarioService = new FuncionarioService();
        this.feriasService = new FeriasService();
        this.exportacaoService = new ExportacaoService();
    }
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String path = request.getPathInfo();
        
        if (path == null || path.equals("/")) {
            listar(request, response);
        } else if (path.equals("/funcionarios")) {
            relatorioFuncionarios(request, response);
        } else if (path.equals("/ferias")) {
            relatorioFerias(request, response);
        } else if (path.equals("/financeiro")) {
            relatorioFinanceiro(request, response);
        } else if (path.equals("/agregados")) {
            relatorioAgregados(request, response);
        } else if (path.equals("/formacoes")) {
            relatorioFormacoes(request, response);
        } else if (path.equals("/nomeacoes")) {
            relatorioNomeacoes(request, response);
        } else if (path.equals("/exportar/funcionarios/excel")) {
            exportarFuncionariosExcel(request, response);
        } else if (path.equals("/exportar/ferias/excel")) {
            exportarFeriasExcel(request, response);
        } else if (path.equals("/exportar/financeiro/excel")) {
            exportarFinanceiroExcel(request, response);
        } else if (path.equals("/exportar/agregados/pdf")) {
            exportarAgregadosPDF(request, response);
        } else {
            response.sendError(HttpServletResponse.SC_NOT_FOUND);
        }
    }
    
    private void listar(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        Usuario usuario = (Usuario) request.getSession().getAttribute(Constants.SESSION_USER);
        if (usuario == null || !(usuario.isAdmin() || usuario.isRH() || usuario.isGestor())) {
            request.getSession().setAttribute(Constants.MSG_ERRO, "Acesso negado");
            response.sendRedirect(request.getContextPath() + "/dashboard");
            return;
        }
        
        request.getSession().removeAttribute(Constants.MSG_ERRO);
        request.getSession().removeAttribute(Constants.MSG_SUCESSO);
        request.getSession().removeAttribute(Constants.MSG_INFO);
        
        request.getRequestDispatcher("/WEB-INF/views/admin/relatorios.jsp").forward(request, response);
    }
    
    private void relatorioFuncionarios(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        Usuario usuario = (Usuario) request.getSession().getAttribute(Constants.SESSION_USER);
        if (usuario == null || !(usuario.isAdmin() || usuario.isRH() || usuario.isGestor())) {
            request.getSession().setAttribute(Constants.MSG_ERRO, "Acesso negado");
            response.sendRedirect(request.getContextPath() + "/dashboard");
            return;
        }
        
        try {
            Map<String, Integer> funcionariosPorSetor = relatorioService.relatorioFuncionariosPorSetor();
            Map<String, Integer> statusFuncionarios = relatorioService.relatorioStatusFuncionarios();
            
            request.setAttribute("funcionariosPorSetor", funcionariosPorSetor);
            request.setAttribute("statusFuncionarios", statusFuncionarios);
            request.setAttribute("titulo", "Relatório de Funcionários");
            
            request.getSession().removeAttribute(Constants.MSG_ERRO);
            request.getSession().removeAttribute(Constants.MSG_SUCESSO);
            request.getSession().removeAttribute(Constants.MSG_INFO);
            
            request.getRequestDispatcher("/WEB-INF/views/admin/relatorio-funcionarios.jsp").forward(request, response);
            
        } catch (BusinessException e) {
            request.getSession().setAttribute(Constants.MSG_ERRO, e.getMessage());
            response.sendRedirect(request.getContextPath() + "/relatorios");
        }
    }
    
    private void relatorioFerias(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        Usuario usuario = (Usuario) request.getSession().getAttribute(Constants.SESSION_USER);
        if (usuario == null || !(usuario.isAdmin() || usuario.isRH() || usuario.isGestor())) {
            request.getSession().setAttribute(Constants.MSG_ERRO, "Acesso negado");
            response.sendRedirect(request.getContextPath() + "/dashboard");
            return;
        }
        
        try {
            Map<String, Integer> feriasPorStatus = relatorioService.relatorioFeriasPorStatus();
            
            request.setAttribute("feriasPorStatus", feriasPorStatus);
            request.setAttribute("titulo", "Relatório de Férias");
            
            request.getSession().removeAttribute(Constants.MSG_ERRO);
            request.getSession().removeAttribute(Constants.MSG_SUCESSO);
            request.getSession().removeAttribute(Constants.MSG_INFO);
            
            request.getRequestDispatcher("/WEB-INF/views/admin/relatorio-ferias.jsp").forward(request, response);
            
        } catch (BusinessException e) {
            request.getSession().setAttribute(Constants.MSG_ERRO, e.getMessage());
            response.sendRedirect(request.getContextPath() + "/relatorios");
        }
    }
    
    private void relatorioFinanceiro(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        Usuario usuario = (Usuario) request.getSession().getAttribute(Constants.SESSION_USER);
        if (usuario == null || !(usuario.isAdmin() || usuario.isFinanceiro())) {
            request.getSession().setAttribute(Constants.MSG_ERRO, "Acesso negado");
            response.sendRedirect(request.getContextPath() + "/dashboard");
            return;
        }
        
        try {
            int ano = Calendar.getInstance().get(Calendar.YEAR);
            Map<String, BigDecimal> folhaPorMes = relatorioService.relatorioFolhaPorMes(ano);
            
            request.setAttribute("folhaPorMes", folhaPorMes);
            request.setAttribute("ano", ano);
            request.setAttribute("titulo", "Relatório Financeiro");
            
            request.getSession().removeAttribute(Constants.MSG_ERRO);
            request.getSession().removeAttribute(Constants.MSG_SUCESSO);
            request.getSession().removeAttribute(Constants.MSG_INFO);
            
            request.getRequestDispatcher("/WEB-INF/views/admin/relatorio-financeiro.jsp").forward(request, response);
            
        } catch (BusinessException e) {
            request.getSession().setAttribute(Constants.MSG_ERRO, e.getMessage());
            response.sendRedirect(request.getContextPath() + "/relatorios");
        }
    }
    
    private void relatorioAgregados(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        Usuario usuario = (Usuario) request.getSession().getAttribute(Constants.SESSION_USER);
        if (usuario == null || !(usuario.isAdmin() || usuario.isRH())) {
            request.getSession().setAttribute(Constants.MSG_ERRO, "Acesso negado");
            response.sendRedirect(request.getContextPath() + "/dashboard");
            return;
        }
        
        try {
            var agregadosPorFuncionario = relatorioService.relatorioAgregadosPorFuncionario();
            var agregadosPorParentesco = relatorioService.relatorioAgregadosPorParentesco();
            
            request.setAttribute("agregadosPorFuncionario", agregadosPorFuncionario);
            request.setAttribute("agregadosPorParentesco", agregadosPorParentesco);
            request.setAttribute("titulo", "Relatório de Agregados");
            
            request.getSession().removeAttribute(Constants.MSG_ERRO);
            request.getSession().removeAttribute(Constants.MSG_SUCESSO);
            request.getSession().removeAttribute(Constants.MSG_INFO);
            
            request.getRequestDispatcher("/WEB-INF/views/admin/relatorio-agregados.jsp").forward(request, response);
            
        } catch (BusinessException e) {
            request.getSession().setAttribute(Constants.MSG_ERRO, e.getMessage());
            response.sendRedirect(request.getContextPath() + "/relatorios");
        }
    }
    
    private void relatorioFormacoes(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        Usuario usuario = (Usuario) request.getSession().getAttribute(Constants.SESSION_USER);
        if (usuario == null || !(usuario.isAdmin() || usuario.isRH())) {
            request.getSession().setAttribute(Constants.MSG_ERRO, "Acesso negado");
            response.sendRedirect(request.getContextPath() + "/dashboard");
            return;
        }
        
        try {
            var formacoesPorFuncionario = relatorioService.relatorioFormacoesPorFuncionario();
            var formacoesPorNivel = relatorioService.relatorioFormacoesPorNivel();
            
            request.setAttribute("formacoesPorFuncionario", formacoesPorFuncionario);
            request.setAttribute("formacoesPorNivel", formacoesPorNivel);
            request.setAttribute("titulo", "Relatório de Formações");
            
            request.getSession().removeAttribute(Constants.MSG_ERRO);
            request.getSession().removeAttribute(Constants.MSG_SUCESSO);
            request.getSession().removeAttribute(Constants.MSG_INFO);
            
            request.getRequestDispatcher("/WEB-INF/views/admin/relatorio-formacoes.jsp").forward(request, response);
            
        } catch (BusinessException e) {
            request.getSession().setAttribute(Constants.MSG_ERRO, e.getMessage());
            response.sendRedirect(request.getContextPath() + "/relatorios");
        }
    }
    
    private void relatorioNomeacoes(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        Usuario usuario = (Usuario) request.getSession().getAttribute(Constants.SESSION_USER);
        if (usuario == null || !(usuario.isAdmin() || usuario.isRH())) {
            request.getSession().setAttribute(Constants.MSG_ERRO, "Acesso negado");
            response.sendRedirect(request.getContextPath() + "/dashboard");
            return;
        }
        
        try {
            var nomeacoesPorFuncionario = relatorioService.relatorioNomeacoesPorFuncionario();
            var nomeacoesAtivas = relatorioService.relatorioNomeacoesAtivas();
            
            request.setAttribute("nomeacoesPorFuncionario", nomeacoesPorFuncionario);
            request.setAttribute("nomeacoesAtivas", nomeacoesAtivas);
            request.setAttribute("titulo", "Relatório de Nomeações");
            
            request.getSession().removeAttribute(Constants.MSG_ERRO);
            request.getSession().removeAttribute(Constants.MSG_SUCESSO);
            request.getSession().removeAttribute(Constants.MSG_INFO);
            
            request.getRequestDispatcher("/WEB-INF/views/admin/relatorio-nomeacoes.jsp").forward(request, response);
            
        } catch (BusinessException e) {
            request.getSession().setAttribute(Constants.MSG_ERRO, e.getMessage());
            response.sendRedirect(request.getContextPath() + "/relatorios");
        }
    }
    
    // ==================== EXPORTAÇÃO ====================
    
    private void exportarFuncionariosExcel(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        
        try {
            List<Funcionario> funcionarios = funcionarioService.listarTodos();
            byte[] dados = exportacaoService.exportarFuncionariosExcel(funcionarios);
            
            response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
            response.setHeader("Content-Disposition", "attachment; filename=funcionarios.xlsx");
            response.setContentLength(dados.length);
            response.getOutputStream().write(dados);
            response.getOutputStream().flush();
            
        } catch (BusinessException e) {
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, e.getMessage());
        }
    }
    
    private void exportarFeriasExcel(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        
        try {
            List<Ferias> ferias = feriasService.listarTodasFerias();
            byte[] dados = exportacaoService.exportarFeriasExcel(ferias);
            
            response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
            response.setHeader("Content-Disposition", "attachment; filename=ferias.xlsx");
            response.setContentLength(dados.length);
            response.getOutputStream().write(dados);
            response.getOutputStream().flush();
            
        } catch (BusinessException e) {
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, e.getMessage());
        }
    }
    
    private void exportarFinanceiroExcel(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        
        try {
            int ano = Calendar.getInstance().get(Calendar.YEAR);
            Map<String, BigDecimal> dados = relatorioService.relatorioFolhaPorMes(ano);
            byte[] excel = exportacaoService.exportarFinanceiroExcel(dados, ano);
            
            response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
            response.setHeader("Content-Disposition", "attachment; filename=financeiro_" + ano + ".xlsx");
            response.setContentLength(excel.length);
            response.getOutputStream().write(excel);
            response.getOutputStream().flush();
            
        } catch (BusinessException e) {
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, e.getMessage());
        }
    }
    
    private void exportarAgregadosPDF(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        
        try {
            List<Map<String, Object>> dados = relatorioService.relatorioAgregadosPorFuncionario();
            byte[] pdf = exportacaoService.exportarAgregadosPDF(dados);
            
            response.setContentType("application/pdf");
            response.setHeader("Content-Disposition", "attachment; filename=agregados.pdf");
            response.setContentLength(pdf.length);
            response.getOutputStream().write(pdf);
            response.getOutputStream().flush();
            
        } catch (BusinessException e) {
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, e.getMessage());
        }
    }
}
package com.sigrh.filter;

import com.sigrh.model.Usuario;
import com.sigrh.util.Constants;
import jakarta.servlet.*;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

@WebFilter("/*")
public class AuthFilter implements Filter {
    
    // ============================================================
    // URLS PÚBLICAS - Todos podem acessar sem login
    // ============================================================
    private static final Set<String> PUBLIC_URLS = new HashSet<>(Arrays.asList(
        "/login", "/login.jsp", "/auth/login",
        "/auth/recuperar-senha", "/auth/recuperar-senha-codigo",
        "/auth/nova-senha", "/auth/nova-senha-codigo",
        "/auth/verificar-codigo", "/auth/solicitar-codigo",
        "/auth/redefinir-senha-codigo",
        "/css/", "/js/", "/img/", "/assets/", "/fonts/",
        "/favicon.ico", "/webjars/"
    ));
    
    // ============================================================
    // URLS PERMITIDAS PARA QUALQUER UTILIZADOR AUTENTICADO
    // ============================================================
    private static final Set<String> AUTHENTICATED_COMMON_URLS = new HashSet<>(Arrays.asList(
        "/logout",
        "/notificacoes", "/notificacoes/",
        "/dashboard",
        "/api/", "/api/notificacoes"
    ));
    
    // ============================================================
    // URLS POR PERFIL
    // ============================================================
    
    // URLs que ADMIN pode acessar (todos) - ADMIN já tem return true
    @SuppressWarnings("unused")
    private static final Set<String> ADMIN_URLS = new HashSet<>(Arrays.asList(
        "/admin/", "/dashboard",
        "/funcionarios", "/funcionarios/", "/funcionarios/novo", "/funcionarios/editar/",
        "/funcionarios/api/", "/funcionarios/excluir/",
        "/agregados", "/agregados/", "/agregados/novo", "/agregados/editar/",
        "/formacoes", "/formacoes/", "/formacoes/novo", "/formacoes/editar/", "/formacoes/excluir",
        "/nomeacoes", "/nomeacoes/", "/nomeacoes/novo", "/nomeacoes/editar/", "/nomeacoes/excluir",
        "/nomeacao", "/nomeacao/", "/nomeacao/novo", "/nomeacao/editar/", "/nomeacao/excluir",
        "/nomeacao/encerrar", "/nomeacao/ativas",
        "/ferias", "/ferias/", "/ferias/pendentes", "/ferias/editar/",
        "/ferias/aprovar", "/ferias/rejeitar", "/ferias/checkout", "/ferias/checkin",
        "/ferias/cancelar", "/ferias/interromper", "/ferias/detalhes",
        "/ferias/saldo", "/ferias/api/", "/api/calendario-eventos",
        "/plano-ferias", "/plano-ferias/", "/plano-ferias/novo", "/plano-ferias/editar/",
        "/plano-ferias/excluir", "/plano-ferias/api/", "/plano-ferias/atualizar-status",
        "/setores", "/setores/", "/setores/novo", "/setores/editar/",
        "/usuarios", "/usuarios/", "/usuarios/novo", "/usuarios/editar/",
        "/auditoria", "/auditoria/",
        "/parametros", "/parametros/",
        "/configuracoes", "/configuracoes/",
        "/relatorios", "/relatorios/",
        "/notificacoes", "/notificacoes/",
        "/logout",
        "/financeiro/", "/financeiro/dashboard", 
        "/financeiro/folha-pagamento", "/financeiro/folha-pagamento/",
        "/financeiro/salarios", "/financeiro/salarios/",
        "/folha-pagamento", "/folha-pagamento/",
        "/salarios", "/salarios/"
    ));
    
    // URLs que RH pode acessar
    private static final Set<String> RH_URLS = new HashSet<>(Arrays.asList(
        "/rh/", "/dashboard",
        "/funcionarios", "/funcionarios/", "/funcionarios/novo", "/funcionarios/editar/",
        "/funcionarios/api/", "/funcionarios/excluir/",
        "/agregados", "/agregados/", "/agregados/novo", "/agregados/editar/",
        "/formacoes", "/formacoes/", "/formacoes/novo", "/formacoes/editar/", "/formacoes/excluir",
        "/nomeacoes", "/nomeacoes/", "/nomeacoes/novo", "/nomeacoes/editar/", "/nomeacoes/excluir",
        "/nomeacao", "/nomeacao/", "/nomeacao/novo", "/nomeacao/editar/", "/nomeacao/excluir",
        "/nomeacao/encerrar", "/nomeacao/ativas",
        "/ferias", "/ferias/", "/ferias/pendentes", "/ferias/editar/",
        "/ferias/aprovar", "/ferias/rejeitar", "/ferias/checkout", "/ferias/checkin",
        "/ferias/cancelar", "/ferias/interromper", "/ferias/detalhes",
        "/ferias/saldo", "/ferias/api/", "/api/calendario-eventos",
        "/plano-ferias", "/plano-ferias/", "/plano-ferias/novo", "/plano-ferias/editar/",
        "/plano-ferias/excluir", "/plano-ferias/api/", "/plano-ferias/atualizar-status",
        "/relatorios", "/relatorios/",
        "/notificacoes", "/notificacoes/",
        "/logout"
    ));
    
 // URLs que FINANCEIRO pode acessar
    private static final Set<String> FINANCEIRO_URLS = new HashSet<>(Arrays.asList(
        "/financeiro/", "/dashboard",
        "/financeiro/dashboard",
        "/financeiro/folha-pagamento", "/financeiro/folha-pagamento/",
        "/financeiro/folha-detalhes/", "/financeiro/folha-detalhes/*",
        "/financeiro/folha-pagar",      // NOVO
        "/financeiro/folha-cancelar",   // NOVO
        "/financeiro/folha-pagamento/novo",
        "/financeiro/folha-pagamento/processar",
        "/financeiro/salarios", "/financeiro/salarios/",
        "/folha-pagamento", "/folha-pagamento/",
        "/salarios", "/salarios/",
        "/funcionarios", "/funcionarios/",
        "/relatorios", "/relatorios/", "/relatorios/financeiro",
        "/notificacoes", "/notificacoes/",
        "/logout"
    ));
    
    // URLs que GESTOR pode acessar - CORRIGIDO
    private static final Set<String> GESTOR_URLS = new HashSet<>(Arrays.asList(
        "/gestor/", "/dashboard",
        // FUNCIONÁRIOS
        "/funcionarios", "/funcionarios/", "/funcionarios/novo", "/funcionarios/editar/",
        "/funcionarios/api/", "/funcionarios/excluir/", "/funcionarios/buscar",
        "/funcionario/", "/funcionario/meus-dados",
        // FÉRIAS
        "/ferias", "/ferias/", "/ferias/pendentes",
        "/ferias/aprovar", "/ferias/rejeitar",
        "/ferias/detalhes", "/ferias/api/", "/api/calendario-eventos",
        "/ferias/checkout", "/ferias/checkin", "/ferias/cancelar",
        // PLANO DE FÉRIAS
        "/plano-ferias", "/plano-ferias/",
        "/plano-ferias/editar/", "/plano-ferias/atualizar-status",
        // RELATÓRIOS
        "/relatorios", "/relatorios/",
        // NOTIFICAÇÕES
        "/notificacoes", "/notificacoes/",
        // LOGOUT
        "/logout"
    ));
    
    // URLs que FUNCIONARIO pode acessar
    private static final Set<String> FUNCIONARIO_URLS = new HashSet<>(Arrays.asList(
        "/funcionario/", "/dashboard",
        "/funcionario/meus-dados", "/funcionario/meus-dados/",
        "/funcionario/minhas-ferias", "/funcionario/minhas-ferias/",
        "/funcionario/minhas-formacoes", "/funcionario/minhas-formacoes/",
        "/funcionario/minhas-nomeacoes", "/funcionario/minhas-nomeacoes/",
        "/funcionario/alterar-senha",
        "/ferias", "/ferias/",
        "/ferias/solicitar", "/ferias/nova", "/ferias/minhas",
        "/ferias/cancelar", "/ferias/saldo",
        "/ferias/checkout", "/ferias/checkin",
        "/ferias/detalhes", "/ferias/api/", "/api/calendario-eventos",
        "/notificacoes", "/notificacoes/",
        "/logout"
    ));
    
    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {
        
        HttpServletRequest req = (HttpServletRequest) request;
        HttpServletResponse res = (HttpServletResponse) response;
        HttpSession session = req.getSession(false);
        
        String uri = req.getRequestURI();
        String contextPath = req.getContextPath();
        String path = uri.substring(contextPath.length());
        
        // ============================================================
        // 1. VERIFICAR SE É URL PÚBLICA
        // ============================================================
        if (isPublicUrl(path)) {
            chain.doFilter(request, response);
            return;
        }
        
        // ============================================================
        // 2. VERIFICAR SE USUÁRIO ESTÁ LOGADO
        // ============================================================
        Usuario usuario = (session != null) ? (Usuario) session.getAttribute(Constants.SESSION_USER) : null;
        
        if (usuario == null) {
            session = req.getSession();
            session.setAttribute(Constants.MSG_ERRO, "Faça login para acessar esta página.");
            res.sendRedirect(contextPath + "/login");
            return;
        }
        
        // ============================================================
        // 3. URLS COMUNS A TODOS OS AUTENTICADOS
        // ============================================================
        if (isAuthenticatedCommonUrl(path)) {
            chain.doFilter(request, response);
            return;
        }
        
        // ============================================================
        // 4. VERIFICAR PERMISSÃO POR PERFIL
        // ============================================================
        if (!temPermissao(usuario, path)) {
            req.getSession().setAttribute(Constants.MSG_ERRO, "Acesso negado. Você não tem permissão para acessar esta página.");
            res.sendRedirect(contextPath + "/dashboard");
            return;
        }
        
        // ============================================================
        // 5. PERMITIR ACESSO
        // ============================================================
        chain.doFilter(request, response);
    }
    
    // ============================================================
    // VERIFICAR SE É URL PÚBLICA
    // ============================================================
    private boolean isPublicUrl(String path) {
        if (path == null || path.isEmpty()) return false;
        if (path.equals("/") || path.equals("/index.jsp") || path.equals("/index")) return true;
        
        for (String url : PUBLIC_URLS) {
            if (path.equals(url) || path.startsWith(url)) {
                return true;
            }
        }
        return false;
    }
    
    // ============================================================
    // URLS PERMITIDAS A QUALQUER UTILIZADOR AUTENTICADO
    // ============================================================
    private boolean isAuthenticatedCommonUrl(String path) {
        if (path == null || path.isEmpty()) return false;
        
        // Caso especial para logout
        if (path.equals("/logout") || path.startsWith("/logout/")) {
            return true;
        }
        
        for (String url : AUTHENTICATED_COMMON_URLS) {
            if (path.equals(url) || path.startsWith(url + "/") || path.startsWith(url)) {
                return true;
            }
        }
        return false;
    }
    
    // ============================================================
    // VERIFICAR PERMISSÃO POR PERFIL
    // ============================================================
    private boolean temPermissao(Usuario usuario, String path) {
        if (usuario == null) return false;
        
        // ADMIN tem acesso a tudo
        if (usuario.getPerfil() == Usuario.Perfil.ADMIN) {
            return true;
        }
        
        switch (usuario.getPerfil()) {
            case RH:
                return matchesAny(path, RH_URLS);
            case FINANCEIRO:
                return matchesAny(path, FINANCEIRO_URLS);
            case GESTOR:
                return matchesAny(path, GESTOR_URLS);
            case FUNCIONARIO:
                return matchesAny(path, FUNCIONARIO_URLS);
            default:
                return false;
        }
    }
    
    // ============================================================
    // VERIFICAR SE PATH CORRESPONDE A ALGUMA URL DO SET
    // ============================================================
    private boolean matchesAny(String path, Set<String> urls) {
        if (path == null || path.isEmpty()) return false;
        
        for (String url : urls) {
            if (path.equals(url) || path.startsWith(url)) {
                return true;
            }
        }
        return false;
    }
}
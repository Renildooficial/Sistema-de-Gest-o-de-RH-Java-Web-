package com.sigrh.controller;

import com.sigrh.util.Constants;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;

/**
 * LogoutController
 *
 * NÃO usar @WebServlet("/logout") aqui.
 * O AuthController já está mapeado para /logout — ter dois mapeamentos
 * causa IllegalArgumentException e o Tomcat não arranca.
 *
 * Se quiser usar exclusivamente este controller:
 * 1. Remova "/logout" (e o método de logout) do AuthController
 * 2. Descomente a anotação @WebServlet abaixo
 * 3. Ou mapeie apenas este servlet no web.xml
 */
// @WebServlet("/logout")  // MANTER COMENTADO enquanto AuthController também mapeia /logout
public class LogoutController extends HttpServlet {
    
    private static final long serialVersionUID = 1L;
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        doPost(request, response);
    }
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        System.out.println("👋 LogoutController - Realizando logout...");
        
        HttpSession session = request.getSession(false);
        if (session != null) {
            session.removeAttribute(Constants.SESSION_USER);
            session.removeAttribute(Constants.SESSION_PERFIL);
            session.removeAttribute(Constants.MSG_SUCESSO);
            session.removeAttribute(Constants.MSG_ERRO);
            session.removeAttribute(Constants.MSG_INFO);
            session.invalidate();
            System.out.println("✅ Sessão invalidada");
        }
        
        HttpSession newSession = request.getSession(true);
        newSession.setAttribute(Constants.MSG_INFO, "Sessão encerrada com sucesso");
        
        System.out.println("🔄 Redirecionando para login...");
        response.sendRedirect(request.getContextPath() + "/login");
    }
}
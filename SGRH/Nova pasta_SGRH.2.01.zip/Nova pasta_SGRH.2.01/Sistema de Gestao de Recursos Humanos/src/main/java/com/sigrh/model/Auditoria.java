package com.sigrh.model;

import java.sql.Timestamp;

public class Auditoria extends BaseModel {
    
    private Integer id;
    private Integer idUsuario;
    private Usuario usuario;
    private String acao;
    private String tabela;
    private Integer idRegistro;  // Usar Integer (pode ser null)
    private String dadosAntigos;
    private String dadosNovos;
    private String ip;
    private String userAgent;
    private Timestamp dataHora;
    
    // ============================================================
    // GETTERS E SETTERS
    // ============================================================
    
    public Integer getId() {
        return id;
    }
    
    public void setId(Integer id) {
        this.id = id;
    }
    
    public Integer getIdUsuario() {
        return idUsuario;
    }
    
    public void setIdUsuario(Integer idUsuario) {
        this.idUsuario = idUsuario;
    }
    
    public Usuario getUsuario() {
        return usuario;
    }
    
    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }
    
    public String getAcao() {
        return acao;
    }
    
    public void setAcao(String acao) {
        this.acao = acao;
    }
    
    public String getTabela() {
        return tabela;
    }
    
    public void setTabela(String tabela) {
        this.tabela = tabela;
    }
    
    public Integer getIdRegistro() {
        return idRegistro;
    }
    
    public void setIdRegistro(Integer idRegistro) {
        this.idRegistro = idRegistro;
    }
    
    public String getDadosAntigos() {
        return dadosAntigos;
    }
    
    public void setDadosAntigos(String dadosAntigos) {
        this.dadosAntigos = dadosAntigos;
    }
    
    public String getDadosNovos() {
        return dadosNovos;
    }
    
    public void setDadosNovos(String dadosNovos) {
        this.dadosNovos = dadosNovos;
    }
    
    public String getIp() {
        return ip;
    }
    
    public void setIp(String ip) {
        this.ip = ip;
    }
    
    public String getUserAgent() {
        return userAgent;
    }
    
    public void setUserAgent(String userAgent) {
        this.userAgent = userAgent;
    }
    
    public Timestamp getDataHora() {
        return dataHora;
    }
    
    public void setDataHora(Timestamp dataHora) {
        this.dataHora = dataHora;
    }
}
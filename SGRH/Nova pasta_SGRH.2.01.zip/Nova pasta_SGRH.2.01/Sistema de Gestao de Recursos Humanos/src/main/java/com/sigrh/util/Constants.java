package com.sigrh.util;

public class Constants {
    
    // Sessão
    public static final String SESSION_USER = "usuario";
    public static final String SESSION_PERFIL = "perfil";
    public static final String SESSION_FUNCIONARIO = "funcionario";
    
    // URLs
    public static final String URL_LOGIN = "/login";
    public static final String URL_LOGOUT = "/logout";
    public static final String URL_DASHBOARD = "/dashboard";
    public static final String URL_HOME = "/";
    
    // Perfis
    public static final String PERFIL_ADMIN = "ADMIN";
    public static final String PERFIL_RH = "RH";
    public static final String PERFIL_FINANCEIRO = "FINANCEIRO";
    public static final String PERFIL_GESTOR = "GESTOR";
    public static final String PERFIL_FUNCIONARIO = "FUNCIONARIO";
    
    // Mensagens
    public static final String MSG_SUCESSO = "sucesso";
    public static final String MSG_ERRO = "erro";
    public static final String MSG_INFO = "info";
    
    // Diretórios de views
    public static final String VIEW_AUTH = "/WEB-INF/views/auth/";
    public static final String VIEW_ADMIN = "/WEB-INF/views/admin/";
    public static final String VIEW_RH = "/WEB-INF/views/rh/";
    public static final String VIEW_FINANCEIRO = "/WEB-INF/views/financeiro/";
    public static final String VIEW_GESTOR = "/WEB-INF/views/gestor/";
    public static final String VIEW_FUNCIONARIO = "/WEB-INF/views/funcionario/";
    public static final String VIEW_ERROR = "/WEB-INF/views/error/";
}
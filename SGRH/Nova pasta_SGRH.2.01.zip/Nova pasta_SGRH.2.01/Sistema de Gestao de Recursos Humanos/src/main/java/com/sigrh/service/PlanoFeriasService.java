package com.sigrh.service;

import com.sigrh.exception.BusinessException;
import com.sigrh.model.PlanoFerias;
import com.sigrh.dao.PlanoFeriasDAO;

import java.sql.Date;
import java.util.Calendar;
import java.util.List;

public class PlanoFeriasService {

    private PlanoFeriasDAO planoFeriasDAO;

    public PlanoFeriasService() {
        this.planoFeriasDAO = new PlanoFeriasDAO();
    }

    /**
     * Busca todos os planos de férias de um funcionário
     */
    public List<PlanoFerias> buscarPorFuncionario(Integer idFuncionario) throws BusinessException {
        if (idFuncionario == null || idFuncionario <= 0) {
            throw new BusinessException("ID do funcionário inválido");
        }
        return planoFeriasDAO.findByFuncionario(idFuncionario);
    }

    /**
     * Busca plano de férias de um funcionário para uma data específica
     * NOVO MÉTODO ADICIONADO
     */
    public PlanoFerias buscarPorFuncionarioEMes(Integer idFuncionario, Date data) throws BusinessException {
        if (idFuncionario == null || idFuncionario <= 0) {
            throw new BusinessException("ID do funcionário inválido");
        }
        if (data == null) {
            throw new BusinessException("Data inválida");
        }
        
        Calendar cal = Calendar.getInstance();
        cal.setTime(data);
        int mes = cal.get(Calendar.MONTH) + 1;
        int ano = cal.get(Calendar.YEAR);
        
        // Buscar planos do funcionário para o mês/ano
        List<PlanoFerias> planos = planoFeriasDAO.findByFuncionario(idFuncionario);
        for (PlanoFerias plano : planos) {
            if (plano.getMesPlanejado() == mes && plano.getAno() == ano) {
                return plano;
            }
        }
        return null;
    }

    /**
     * Busca planos por ano
     */
    public List<PlanoFerias> buscarPorAno(Integer ano) throws BusinessException {
        if (ano == null || ano <= 0) {
            throw new BusinessException("Ano inválido");
        }
        return planoFeriasDAO.findByAno(ano);
    }

    /**
     * Busca plano por ID
     */
    public PlanoFerias buscarPorId(Integer id) throws BusinessException {
        if (id == null || id <= 0) {
            throw new BusinessException("ID inválido");
        }
        PlanoFerias plano = planoFeriasDAO.buscarPorId(id);
        if (plano == null) {
            throw new BusinessException("Plano não encontrado");
        }
        return plano;
    }

    /**
     * Salva um novo plano
     */
    public void salvar(PlanoFerias plano) throws BusinessException {
        if (plano == null) {
            throw new BusinessException("Plano não pode ser nulo");
        }
        if (plano.getIdFuncionario() == null || plano.getIdFuncionario() <= 0) {
            throw new BusinessException("Funcionário é obrigatório");
        }
        if (plano.getMesPlanejado() == null || plano.getMesPlanejado() < 1 || plano.getMesPlanejado() > 12) {
            throw new BusinessException("Mês inválido");
        }
        if (plano.getAno() == null || plano.getAno() <= 0) {
            throw new BusinessException("Ano inválido");
        }
        planoFeriasDAO.salvar(plano);
    }

    /**
     * Atualiza um plano existente
     */
    public void atualizar(PlanoFerias plano) throws BusinessException {
        if (plano == null) {
            throw new BusinessException("Plano não pode ser nulo");
        }
        if (plano.getId() == null || plano.getId() <= 0) {
            throw new BusinessException("ID do plano inválido");
        }
        planoFeriasDAO.atualizar(plano);
    }

    /**
     * Exclui um plano
     */
    public void excluir(Integer id) throws BusinessException {
        if (id == null || id <= 0) {
            throw new BusinessException("ID inválido");
        }
        planoFeriasDAO.excluir(id);
    }

    /**
     * Atualiza o status de um plano
     */
    public void atualizarStatus(Integer id, String status) throws BusinessException {
        if (id == null || id <= 0) {
            throw new BusinessException("ID inválido");
        }
        if (status == null || status.trim().isEmpty()) {
            throw new BusinessException("Status é obrigatório");
        }
        planoFeriasDAO.atualizarStatus(id, status);
    }

    /**
     * Busca planos por status
     */
    public List<PlanoFerias> buscarPorStatus(String status) throws BusinessException {
        if (status == null || status.trim().isEmpty()) {
            throw new BusinessException("Status é obrigatório");
        }
        return planoFeriasDAO.findByStatus(status);
    }
}
package com.sigrh.dao;

import com.sigrh.exception.DatabaseException;
import com.sigrh.model.ParametroSistema;
import com.sigrh.util.DatabaseUtil;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.sql.*;
import java.util.HashMap;
import java.util.Map;

public class ParametroSistemaDAO extends GenericDAO<ParametroSistema> {
    
    private static final Logger logger = LogManager.getLogger(ParametroSistemaDAO.class);
    
    @Override
    protected String getTableName() {
        return "parametros_sistema";
    }
    
    @Override
    protected ParametroSistema mapResultSetToEntity(ResultSet rs) throws SQLException {
        ParametroSistema parametro = new ParametroSistema();
        parametro.setId(rs.getInt("id"));
        parametro.setChave(rs.getString("chave"));
        parametro.setValor(rs.getString("valor"));
        parametro.setDescricao(rs.getString("descricao"));
        parametro.setCategoria(rs.getString("categoria"));
        parametro.setDataAtualizacao(rs.getTimestamp("data_atualizacao"));
        // REMOVER: parametro.setDataCadastro(rs.getTimestamp("data_cadastro"));
        return parametro;
    }
    
    @Override
    protected void setInsertParameters(PreparedStatement ps, ParametroSistema entity) throws SQLException {
        ps.setString(1, entity.getChave());
        ps.setString(2, entity.getValor());
        ps.setString(3, entity.getDescricao());
        ps.setString(4, entity.getCategoria());
    }
    
    @Override
    protected void setUpdateParameters(PreparedStatement ps, ParametroSistema entity) throws SQLException {
        ps.setString(1, entity.getChave());
        ps.setString(2, entity.getValor());
        ps.setString(3, entity.getDescricao());
        ps.setString(4, entity.getCategoria());
        ps.setInt(5, entity.getId());
    }
    
    @Override
    protected String getInsertColumns() {
        return "chave, valor, descricao, categoria";
    }
    
    @Override
    protected String getInsertPlaceholders() {
        return "?, ?, ?, ?";
    }
    
    @Override
    protected String getUpdateColumns() {
        return "chave = ?, valor = ?, descricao = ?, categoria = ?";
    }
    
    @Override
    protected int getUpdateParameterCount() {
        return 4;
    }
    
    @Override
    protected Integer getId(ParametroSistema entity) {
        return entity.getId();
    }
    
    @Override
    protected void setId(ParametroSistema entity, Integer id) {
        entity.setId(id);
    }
    
    /**
     * Busca parâmetro por chave
     */
    public ParametroSistema findByChave(String chave) throws DatabaseException {
        String sql = "SELECT * FROM " + getTableName() + " WHERE chave = ?";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setString(1, chave);
            
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToEntity(rs);
                }
            }
            return null;
            
        } catch (SQLException e) {
            logger.error("Erro ao buscar parâmetro por chave: {}", chave, e);
            throw new DatabaseException("Erro ao buscar parâmetro: " + e.getMessage(), e);
        }
    }
    
    /**
     * Busca parâmetros por categoria
     */
    public Map<String, ParametroSistema> findByCategoria(String categoria) throws DatabaseException {
        Map<String, ParametroSistema> resultado = new HashMap<>();
        String sql = "SELECT * FROM " + getTableName() + " WHERE categoria = ?";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setString(1, categoria);
            
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    ParametroSistema p = mapResultSetToEntity(rs);
                    resultado.put(p.getChave(), p);
                }
            }
            return resultado;
            
        } catch (SQLException e) {
            logger.error("Erro ao buscar parâmetros por categoria: {}", categoria, e);
            throw new DatabaseException("Erro ao buscar parâmetros: " + e.getMessage(), e);
        }
    }
    
    /**
     * Busca valor de parâmetro por chave (retorna null se não encontrado)
     */
    public String findValorByChave(String chave) throws DatabaseException {
        ParametroSistema parametro = findByChave(chave);
        return parametro != null ? parametro.getValor() : null;
    }
    
    /**
     * Salva ou atualiza um parâmetro (UPSERT)
     */
    public ParametroSistema save(ParametroSistema parametro) throws DatabaseException {
        ParametroSistema existente = findByChave(parametro.getChave());
        
        if (existente != null) {
            parametro.setId(existente.getId());
            return update(parametro);
        } else {
            return insert(parametro);
        }
    }
}
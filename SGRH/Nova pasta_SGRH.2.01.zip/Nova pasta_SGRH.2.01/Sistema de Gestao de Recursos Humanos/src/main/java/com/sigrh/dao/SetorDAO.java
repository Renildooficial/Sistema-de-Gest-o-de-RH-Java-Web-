package com.sigrh.dao;

import com.sigrh.exception.DatabaseException;
import com.sigrh.model.Setor;
import com.sigrh.util.DatabaseUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class SetorDAO extends GenericDAO<Setor> {
    
    @Override
    protected String getTableName() {
        return "setor";
    }
    
    @Override
    protected Setor mapResultSetToEntity(ResultSet rs) throws SQLException {
        Setor setor = new Setor();
        setor.setId(rs.getInt("id"));
        setor.setNome(rs.getString("nome"));
        setor.setDescricao(rs.getString("descricao"));
        setor.setResponsavel(rs.getString("responsavel"));
        setor.setAtivo(rs.getBoolean("ativo"));
        setor.setDataCadastro(rs.getTimestamp("data_cadastro"));
        return setor;
    }
    
    @Override
    protected void setInsertParameters(PreparedStatement ps, Setor entity) throws SQLException {
        ps.setString(1, entity.getNome());
        ps.setString(2, entity.getDescricao());
        ps.setString(3, entity.getResponsavel());
        ps.setBoolean(4, entity.getAtivo() != null && entity.getAtivo());
    }
    
    @Override
    protected void setUpdateParameters(PreparedStatement ps, Setor entity) throws SQLException {
        ps.setString(1, entity.getNome());
        ps.setString(2, entity.getDescricao());
        ps.setString(3, entity.getResponsavel());
        ps.setBoolean(4, entity.getAtivo() != null && entity.getAtivo());
        ps.setInt(5, entity.getId());
    }
    
    @Override
    protected String getInsertColumns() {
        return "nome, descricao, responsavel, ativo";
    }
    
    @Override
    protected String getInsertPlaceholders() {
        return "?, ?, ?, ?";
    }
    
    @Override
    protected String getUpdateColumns() {
        return "nome = ?, descricao = ?, responsavel = ?, ativo = ?";
    }
    
    @Override
    protected int getUpdateParameterCount() {
        return 4;
    }
    
    @Override
    protected Integer getId(Setor entity) {
        return entity.getId();
    }
    
    @Override
    protected void setId(Setor entity, Integer id) {
        entity.setId(id);
    }
    
    // ============================================================
    // MÉTODOS ADICIONAIS (ALIAS PARA COMPATIBILIDADE)
    // ============================================================
    
    public List<Setor> listarTodos() throws DatabaseException {
        return findAll();
    }
    
    public Setor buscarPorId(Integer id) throws DatabaseException {
        return findById(id);
    }
    
    public void salvar(Setor setor) throws DatabaseException {
        insert(setor);
    }
    
    public void atualizar(Setor setor) throws DatabaseException {
        update(setor);
    }
    
    public void excluir(Integer id) throws DatabaseException {
        delete(id);
    }
    
    public int contar() throws DatabaseException {
        return count();
    }
    
    public int contarAtivos() throws DatabaseException {
        String sql = "SELECT COUNT(*) as total FROM " + getTableName() + " WHERE ativo = TRUE";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            
            if (rs.next()) {
                return rs.getInt("total");
            }
            return 0;
            
        } catch (SQLException e) {
            logger.error("Erro ao contar setores ativos", e);
            throw new DatabaseException("Erro ao contar setores ativos: " + e.getMessage(), e);
        }
    }
    
    // ============================================================
    // MÉTODOS ESPECÍFICOS
    // ============================================================
    
    public Setor findByNome(String nome) throws DatabaseException {
        String sql = "SELECT * FROM " + getTableName() + " WHERE nome = ?";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setString(1, nome);
            
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToEntity(rs);
                }
            }
            return null;
            
        } catch (SQLException e) {
            logger.error("Erro ao buscar setor por nome: {}", nome, e);
            throw new DatabaseException("Erro ao buscar setor: " + e.getMessage(), e);
        }
    }
    
    public Setor findByNomeIgnoreCase(String nome) throws DatabaseException {
        String sql = "SELECT * FROM " + getTableName() + " WHERE LOWER(nome) = LOWER(?)";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setString(1, nome);
            
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToEntity(rs);
                }
            }
            return null;
            
        } catch (SQLException e) {
            logger.error("Erro ao buscar setor por nome: {}", nome, e);
            throw new DatabaseException("Erro ao buscar setor: " + e.getMessage(), e);
        }
    }
    
    public List<Setor> findAtivos() throws DatabaseException {
        List<Setor> list = new ArrayList<>();
        String sql = "SELECT * FROM " + getTableName() + " WHERE ativo = TRUE ORDER BY nome";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            
            while (rs.next()) {
                list.add(mapResultSetToEntity(rs));
            }
            return list;
            
        } catch (SQLException e) {
            logger.error("Erro ao buscar setores ativos", e);
            throw new DatabaseException("Erro ao buscar setores: " + e.getMessage(), e);
        }
    }
    
    public List<Setor> findInativos() throws DatabaseException {
        List<Setor> list = new ArrayList<>();
        String sql = "SELECT * FROM " + getTableName() + " WHERE ativo = FALSE ORDER BY nome";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            
            while (rs.next()) {
                list.add(mapResultSetToEntity(rs));
            }
            return list;
            
        } catch (SQLException e) {
            logger.error("Erro ao buscar setores inativos", e);
            throw new DatabaseException("Erro ao buscar setores: " + e.getMessage(), e);
        }
    }
    
    public List<Setor> findByNomeContaining(String nome) throws DatabaseException {
        List<Setor> list = new ArrayList<>();
        String sql = "SELECT * FROM " + getTableName() + " WHERE nome LIKE ? ORDER BY nome";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setString(1, "%" + nome + "%");
            
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(mapResultSetToEntity(rs));
                }
            }
            return list;
            
        } catch (SQLException e) {
            logger.error("Erro ao buscar setores por nome: {}", nome, e);
            throw new DatabaseException("Erro ao buscar setores: " + e.getMessage(), e);
        }
    }
    
    public boolean existsByNome(String nome) throws DatabaseException {
        String sql = "SELECT COUNT(*) as total FROM " + getTableName() + " WHERE nome = ?";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setString(1, nome);
            
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt("total") > 0;
                }
            }
            return false;
            
        } catch (SQLException e) {
            logger.error("Erro ao verificar existência de setor: {}", nome, e);
            throw new DatabaseException("Erro ao verificar setor: " + e.getMessage(), e);
        }
    }
}
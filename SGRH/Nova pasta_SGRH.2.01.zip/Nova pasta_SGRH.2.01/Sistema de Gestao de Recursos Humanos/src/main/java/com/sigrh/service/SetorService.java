package com.sigrh.service;

import com.sigrh.dao.SetorDAO;
import com.sigrh.exception.BusinessException;
import com.sigrh.exception.DatabaseException;
import com.sigrh.model.Setor;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.List;

public class SetorService {
    
    private static final Logger logger = LogManager.getLogger(SetorService.class);
    private final SetorDAO setorDAO;
    
    public SetorService() {
        this.setorDAO = new SetorDAO();
    }
    
    public Setor cadastrar(Setor setor) throws BusinessException {
        logger.info("Cadastrando novo setor: {}", setor.getNome());
        
        try {
            validarDados(setor);
            
            if (setorDAO.findByNome(setor.getNome()) != null) {
                throw new BusinessException("Setor já cadastrado");
            }
            
            return setorDAO.insert(setor);
            
        } catch (DatabaseException e) {
            logger.error("Erro ao cadastrar setor: {}", setor.getNome(), e);
            throw new BusinessException("Erro ao cadastrar setor", e);
        }
    }
    
    public Setor atualizar(Setor setor) throws BusinessException {
        logger.info("Atualizando setor ID: {}", setor.getId());
        
        try {
            validarDados(setor);
            
            Setor existente = setorDAO.findById(setor.getId());
            if (existente == null) {
                throw new BusinessException("Setor não encontrado");
            }
            
            // Verificar se nome já existe (exceto o próprio)
            Setor porNome = setorDAO.findByNome(setor.getNome());
            if (porNome != null && !porNome.getId().equals(setor.getId())) {
                throw new BusinessException("Já existe um setor com este nome");
            }
            
            return setorDAO.update(setor);
            
        } catch (DatabaseException e) {
            logger.error("Erro ao atualizar setor ID: {}", setor.getId(), e);
            throw new BusinessException("Erro ao atualizar setor", e);
        }
    }
    
    public Setor buscarPorId(Integer id) throws BusinessException {
        try {
            Setor setor = setorDAO.findById(id);
            if (setor == null) {
                throw new BusinessException("Setor não encontrado");
            }
            return setor;
        } catch (DatabaseException e) {
            logger.error("Erro ao buscar setor ID: {}", id, e);
            throw new BusinessException("Erro ao buscar setor", e);
        }
    }
    
    public List<Setor> listarTodos() throws BusinessException {
        try {
            return setorDAO.findAll();
        } catch (DatabaseException e) {
            logger.error("Erro ao listar setores", e);
            throw new BusinessException("Erro ao listar setores", e);
        }
    }
    
    public List<Setor> listarAtivos() throws BusinessException {
        try {
            return setorDAO.findAtivos();
        } catch (DatabaseException e) {
            logger.error("Erro ao listar setores ativos", e);
            throw new BusinessException("Erro ao listar setores ativos", e);
        }
    }
    
    public void excluir(Integer id) throws BusinessException {
        logger.info("Excluindo setor ID: {}", id);
        
        try {
            Setor setor = setorDAO.findById(id);
            if (setor == null) {
                throw new BusinessException("Setor não encontrado");
            }
            
            // Verificar se há funcionários no setor (usando FuncionarioService)
            FuncionarioService funcionarioService = new FuncionarioService();
            int count = funcionarioService.listarPorSetor(id).size();
            if (count > 0) {
                throw new BusinessException("Não é possível excluir o setor pois há " + count + " funcionários vinculados");
            }
            
            setorDAO.delete(id);
            logger.info("Setor ID {} excluído com sucesso", id);
            
        } catch (DatabaseException e) {
            logger.error("Erro ao excluir setor ID: {}", id, e);
            throw new BusinessException("Erro ao excluir setor", e);
        }
    }
    
    private void validarDados(Setor setor) throws BusinessException {
        if (setor.getNome() == null || setor.getNome().trim().isEmpty()) {
            throw new BusinessException("Nome do setor é obrigatório");
        }
        if (setor.getNome().length() < 3) {
            throw new BusinessException("Nome do setor deve ter no mínimo 3 caracteres");
        }
        if (setor.getNome().length() > 50) {
            throw new BusinessException("Nome do setor deve ter no máximo 50 caracteres");
        }
    }
}
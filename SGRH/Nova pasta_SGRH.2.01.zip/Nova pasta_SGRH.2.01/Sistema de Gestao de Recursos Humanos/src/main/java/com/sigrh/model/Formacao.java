package com.sigrh.model;

import java.sql.Timestamp;
import java.util.Date;

public class Formacao extends BaseModel {
    
    private Integer id;
    private Integer idFuncionario;
    private Funcionario funcionario;
    private String nivel;
    private String curso;
    private String instituicao;
    private String local;
    private Date dataInicio;
    private Date dataConclusao;
    private Integer cargaHoraria;
    private Boolean certificado;
    private String status;
    private String observacao;
    private Timestamp dataCadastro;
    
    // ============================================================
    // NOVOS CAMPOS
    // ============================================================
    private String funcoes;
    private String cargo;
    
    // ============================================================
    // CONSTRUTORES
    // ============================================================
    public Formacao() {}
    
    public Formacao(Integer id, Integer idFuncionario, String nivel, String curso,
                    String instituicao, String local, Date dataInicio, Date dataConclusao,
                    Integer cargaHoraria, Boolean certificado, String status, 
                    String observacao, String funcoes, String cargo) {
        this.id = id;
        this.idFuncionario = idFuncionario;
        this.nivel = nivel;
        this.curso = curso;
        this.instituicao = instituicao;
        this.local = local;
        this.dataInicio = dataInicio;
        this.dataConclusao = dataConclusao;
        this.cargaHoraria = cargaHoraria;
        this.certificado = certificado;
        this.status = status;
        this.observacao = observacao;
        this.funcoes = funcoes;
        this.cargo = cargo;
    }
    
    // ============================================================
    // GETTERS E SETTERS
    // ============================================================
    public Integer getId() {
        return id;
    }
    
    public void setId(Integer id) {
        this.id = id;
    }
    
    public Integer getIdFuncionario() {
        return idFuncionario;
    }
    
    public void setIdFuncionario(Integer idFuncionario) {
        this.idFuncionario = idFuncionario;
    }
    
    public Funcionario getFuncionario() {
        return funcionario;
    }
    
    public void setFuncionario(Funcionario funcionario) {
        this.funcionario = funcionario;
    }
    
    public String getNivel() {
        return nivel;
    }
    
    public void setNivel(String nivel) {
        this.nivel = nivel;
    }
    
    public String getCurso() {
        return curso;
    }
    
    public void setCurso(String curso) {
        this.curso = curso;
    }
    
    public String getInstituicao() {
        return instituicao;
    }
    
    public void setInstituicao(String instituicao) {
        this.instituicao = instituicao;
    }
    
    public String getLocal() {
        return local;
    }
    
    public void setLocal(String local) {
        this.local = local;
    }
    
    public Date getDataInicio() {
        return dataInicio;
    }
    
    public void setDataInicio(Date dataInicio) {
        this.dataInicio = dataInicio;
    }
    
    public Date getDataConclusao() {
        return dataConclusao;
    }
    
    public void setDataConclusao(Date dataConclusao) {
        this.dataConclusao = dataConclusao;
    }
    
    public Integer getCargaHoraria() {
        return cargaHoraria;
    }
    
    public void setCargaHoraria(Integer cargaHoraria) {
        this.cargaHoraria = cargaHoraria;
    }
    
    public Boolean getCertificado() {
        return certificado;
    }
    
    public void setCertificado(Boolean certificado) {
        this.certificado = certificado;
    }
    
    public String getStatus() {
        return status;
    }
    
    public void setStatus(String status) {
        this.status = status;
    }
    
    public String getObservacao() {
        return observacao;
    }
    
    public void setObservacao(String observacao) {
        this.observacao = observacao;
    }
    
    // ============================================================
    // CORRIGIDO: Retorna Timestamp (compatível com BaseModel)
    // ============================================================
    @Override
    public Timestamp getDataCadastro() {
        return dataCadastro;
    }
    
    public void setDataCadastro(Timestamp dataCadastro) {
        this.dataCadastro = dataCadastro;
    }
    
    // ============================================================
    // GETTERS E SETTERS - NOVOS CAMPOS
    // ============================================================
    public String getFuncoes() {
        return funcoes;
    }
    
    public void setFuncoes(String funcoes) {
        this.funcoes = funcoes;
    }
    
    public String getCargo() {
        return cargo;
    }
    
    public void setCargo(String cargo) {
        this.cargo = cargo;
    }
    
    // ============================================================
    // MÉTODOS AUXILIARES
    // ============================================================
    public boolean isConcluido() {
        return "CONCLUIDO".equals(this.status);
    }
    
    public boolean isCursando() {
        return "CURSANDO".equals(this.status);
    }
}
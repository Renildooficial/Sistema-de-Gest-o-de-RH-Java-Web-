package com.sigrh.model;

import java.io.Serializable;
import java.sql.Timestamp;

public abstract class BaseModel implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    protected Integer id;
    protected Timestamp dataCadastro;
    protected Boolean ativo;
    
    public BaseModel() {
        this.ativo = true;
    }
    
    public Integer getId() { return id; }
    public void setId(Integer id) { this.id = id; }
    
    public Timestamp getDataCadastro() { return dataCadastro; }
    public void setDataCadastro(Timestamp dataCadastro) { this.dataCadastro = dataCadastro; }
    
    public Boolean getAtivo() { return ativo; }
    public void setAtivo(Boolean ativo) { this.ativo = ativo; }
}
package com.sigrh.controller;

import com.sigrh.exception.BusinessException;
import com.sigrh.model.Usuario;
import com.sigrh.service.AuthService;
import com.sigrh.service.EmailService;
import com.sigrh.util.Constants;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

@WebServlet(urlPatterns = {"/auth/recuperar-senha-codigo", "/auth/solicitar-codigo", 
                           "/auth/verificar-codigo", "/auth/nova-senha-codigo", 
                           "/auth/redefinir-senha-codigo"})
public class RecuperarSenhaController extends HttpServlet {
    
    private static final long serialVersionUID = 1L;
    private final AuthService authService;
    
    public RecuperarSenhaController() {
        this.authService = new AuthService();
    }
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String path = request.getRequestURI().substring(request.getContextPath().length());
        System.out.println("🔍 RecuperarSenhaController.doGet - Path: " + path);
        
        if (path.equals("/auth/recuperar-senha-codigo")) {
            request.getSession().removeAttribute(Constants.MSG_ERRO);
            request.getSession().removeAttribute(Constants.MSG_SUCESSO);
            request.getSession().removeAttribute(Constants.MSG_INFO);
            request.getRequestDispatcher("/WEB-INF/views/auth/recuperar-senha-codigo.jsp").forward(request, response);
        } else if (path.equals("/auth/verificar-codigo")) {
            String email = (String) request.getSession().getAttribute("emailRecuperacao");
            if (email == null) {
                email = request.getParameter("email");
            }
            if (email == null || email.trim().isEmpty()) {
                response.sendRedirect(request.getContextPath() + "/auth/recuperar-senha-codigo");
                return;
            }
            request.setAttribute("email", email);
            request.getSession().setAttribute("emailRecuperacao", email);
            request.getRequestDispatcher("/WEB-INF/views/auth/verificar-codigo.jsp").forward(request, response);
        } else if (path.equals("/auth/nova-senha-codigo")) {
            Boolean codigoValidado = (Boolean) request.getSession().getAttribute("codigoValidado");
            String email = (String) request.getSession().getAttribute("emailRecuperacao");
            if (codigoValidado == null || !codigoValidado || email == null) {
                request.getSession().setAttribute(Constants.MSG_ERRO, "Código não validado. Solicite um novo código.");
                response.sendRedirect(request.getContextPath() + "/auth/recuperar-senha-codigo");
                return;
            }
            request.setAttribute("email", email);
            request.getRequestDispatcher("/WEB-INF/views/auth/nova-senha-codigo.jsp").forward(request, response);
        } else {
            response.sendError(HttpServletResponse.SC_NOT_FOUND);
        }
    }
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String path = request.getRequestURI().substring(request.getContextPath().length());
        System.out.println("🔍 RecuperarSenhaController.doPost - Path: " + path);
        
        try {
            if (path.equals("/auth/solicitar-codigo")) {
                solicitarCodigo(request, response);
            } else if (path.equals("/auth/verificar-codigo")) {
                verificarCodigo(request, response);
            } else if (path.equals("/auth/redefinir-senha-codigo")) {
                redefinirSenhaCodigo(request, response);
            } else {
                response.sendError(HttpServletResponse.SC_NOT_FOUND);
            }
        } catch (Exception e) {
            e.printStackTrace();
            request.getSession().setAttribute(Constants.MSG_ERRO, "Erro: " + e.getMessage());
            response.sendRedirect(request.getContextPath() + "/auth/recuperar-senha-codigo");
        }
    }
    
    private void solicitarCodigo(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String email = request.getParameter("email");
        
        if (email == null || email.trim().isEmpty()) {
            request.getSession().setAttribute(Constants.MSG_ERRO, "E-mail é obrigatório");
            request.getRequestDispatcher("/WEB-INF/views/auth/recuperar-senha-codigo.jsp").forward(request, response);
            return;
        }
        
        try {
            String codigo = authService.solicitarCodigoVerificacao(email);
            Usuario usuario = authService.buscarPorEmail(email);
            
            System.out.println("========================================");
            System.out.println("🔑 CÓDIGO DE VERIFICAÇÃO:");
            System.out.println("   " + codigo);
            System.out.println("📧 E-mail: " + email);
            System.out.println("⏱️ Válido por 10 minutos");
            System.out.println("========================================");
            
            try {
                EmailService emailService = new EmailService();
                emailService.enviarCodigoVerificacao(email, usuario.getNome(), codigo);
                request.getSession().setAttribute(Constants.MSG_SUCESSO, 
                    "Código de verificação enviado para seu e-mail!");
            } catch (Exception e) {
                request.getSession().setAttribute(Constants.MSG_INFO, 
                    "Código gerado! Verifique o console do servidor para obter o código.");
            }
            
            request.setAttribute("email", email);
            request.getRequestDispatcher("/WEB-INF/views/auth/verificar-codigo.jsp").forward(request, response);
            
        } catch (BusinessException e) {
            request.getSession().setAttribute(Constants.MSG_ERRO, e.getMessage());
            request.getRequestDispatcher("/WEB-INF/views/auth/recuperar-senha-codigo.jsp").forward(request, response);
        }
    }
    
    private void verificarCodigo(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String email = request.getParameter("email");
        String codigo = request.getParameter("codigo");
        
        if (email == null || email.trim().isEmpty()) {
            request.getSession().setAttribute(Constants.MSG_ERRO, "E-mail é obrigatório");
            request.setAttribute("email", email);
            request.getRequestDispatcher("/WEB-INF/views/auth/verificar-codigo.jsp").forward(request, response);
            return;
        }
        if (codigo == null || codigo.trim().isEmpty()) {
            request.getSession().setAttribute(Constants.MSG_ERRO, "Código é obrigatório");
            request.setAttribute("email", email);
            request.getRequestDispatcher("/WEB-INF/views/auth/verificar-codigo.jsp").forward(request, response);
            return;
        }
        
        try {
            authService.validarCodigoVerificacao(email, codigo);
            
            request.getSession().setAttribute("codigoValidado", true);
            request.getSession().setAttribute("emailRecuperacao", email);
            
            request.getSession().setAttribute(Constants.MSG_SUCESSO, "Código verificado com sucesso!");
            response.sendRedirect(request.getContextPath() + "/auth/nova-senha-codigo");
            
        } catch (BusinessException e) {
            request.getSession().setAttribute(Constants.MSG_ERRO, e.getMessage());
            request.setAttribute("email", email);
            request.getRequestDispatcher("/WEB-INF/views/auth/verificar-codigo.jsp").forward(request, response);
        }
    }
    
    private void redefinirSenhaCodigo(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String email = request.getParameter("email");
        String codigo = request.getParameter("codigo");
        String novaSenha = request.getParameter("novaSenha");
        String confirmarSenha = request.getParameter("confirmarSenha");
        
        if (email == null || email.trim().isEmpty()) {
            request.getSession().setAttribute(Constants.MSG_ERRO, "E-mail é obrigatório");
            request.setAttribute("email", email);
            request.setAttribute("codigo", codigo);
            request.getRequestDispatcher("/WEB-INF/views/auth/nova-senha-codigo.jsp").forward(request, response);
            return;
        }
        if (codigo == null || codigo.trim().isEmpty()) {
            request.getSession().setAttribute(Constants.MSG_ERRO, "Código é obrigatório");
            request.setAttribute("email", email);
            request.setAttribute("codigo", codigo);
            request.getRequestDispatcher("/WEB-INF/views/auth/nova-senha-codigo.jsp").forward(request, response);
            return;
        }
        if (novaSenha == null || novaSenha.trim().isEmpty()) {
            request.getSession().setAttribute(Constants.MSG_ERRO, "Nova senha é obrigatória");
            request.setAttribute("email", email);
            request.setAttribute("codigo", codigo);
            request.getRequestDispatcher("/WEB-INF/views/auth/nova-senha-codigo.jsp").forward(request, response);
            return;
        }
        if (!novaSenha.equals(confirmarSenha)) {
            request.getSession().setAttribute(Constants.MSG_ERRO, "As senhas não coincidem");
            request.setAttribute("email", email);
            request.setAttribute("codigo", codigo);
            request.getRequestDispatcher("/WEB-INF/views/auth/nova-senha-codigo.jsp").forward(request, response);
            return;
        }
        
        try {
            authService.redefinirSenhaComCodigo(email, codigo, novaSenha);
            
            request.getSession().removeAttribute("codigoValidado");
            request.getSession().removeAttribute("emailRecuperacao");
            
            request.getSession().setAttribute(Constants.MSG_SUCESSO, "Senha redefinida com sucesso! Faça login.");
            response.sendRedirect(request.getContextPath() + "/login");
            
        } catch (BusinessException e) {
            request.getSession().setAttribute(Constants.MSG_ERRO, e.getMessage());
            request.setAttribute("email", email);
            request.setAttribute("codigo", codigo);
            request.getRequestDispatcher("/WEB-INF/views/auth/nova-senha-codigo.jsp").forward(request, response);
        }
    }
}
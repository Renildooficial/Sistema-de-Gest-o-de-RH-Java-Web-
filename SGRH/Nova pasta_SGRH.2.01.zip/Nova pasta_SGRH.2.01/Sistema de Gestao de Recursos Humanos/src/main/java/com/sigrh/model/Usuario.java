package com.sigrh.model;

import java.sql.Date;
import java.sql.Timestamp;

public class Usuario extends BaseModel {
    
    private static final long serialVersionUID = 1L;
    
    public enum Perfil { ADMIN, RH, FINANCEIRO, GESTOR, FUNCIONARIO }
    public enum Status { ATIVO, INATIVO, BLOQUEADO }
    
    private String nome;
    private String usuario;
    private String email;
    private String senha;
    private Perfil perfil;
    private Status status;
    private Timestamp ultimoLogin;
    private Date expiraSenha;
    private Integer idFuncionario;
    private String tokenRecuperacao;
    private Timestamp dataToken;
    
    // ==================== RELACIONAMENTOS ====================
    private Funcionario funcionario;
    
    // ==================== CONSTRUTORES ====================
    public Usuario() {
        super();
        this.status = Status.ATIVO;
    }
    
    public Usuario(Integer id, String nome, String usuario, String email, Perfil perfil) {
        this();
        this.id = id;
        this.nome = nome;
        this.usuario = usuario;
        this.email = email;
        this.perfil = perfil;
    }
    
    // ==================== GETTERS E SETTERS ====================
    public String getNome() { 
        return nome; 
    }
    
    public void setNome(String nome) { 
        this.nome = nome; 
    }
    
    public String getUsuario() { 
        return usuario; 
    }
    
    public void setUsuario(String usuario) { 
        this.usuario = usuario; 
    }
    
    public String getEmail() { 
        return email; 
    }
    
    public void setEmail(String email) { 
        this.email = email; 
    }
    
    public String getSenha() { 
        return senha; 
    }
    
    public void setSenha(String senha) { 
        this.senha = senha; 
    }
    
    public Perfil getPerfil() { 
        return perfil; 
    }
    
    public void setPerfil(Perfil perfil) { 
        this.perfil = perfil; 
    }
    
    public void setPerfil(String perfil) { 
        this.perfil = Perfil.valueOf(perfil); 
    }
    
    public Status getStatus() { 
        return status; 
    }
    
    public void setStatus(Status status) { 
        this.status = status; 
    }
    
    public void setStatus(String status) { 
        this.status = Status.valueOf(status); 
    }
    
    public Timestamp getUltimoLogin() { 
        return ultimoLogin; 
    }
    
    public void setUltimoLogin(Timestamp ultimoLogin) { 
        this.ultimoLogin = ultimoLogin; 
    }
    
    public Date getExpiraSenha() { 
        return expiraSenha; 
    }
    
    public void setExpiraSenha(Date expiraSenha) { 
        this.expiraSenha = expiraSenha; 
    }
    
    public Integer getIdFuncionario() { 
        return idFuncionario; 
    }
    
    public void setIdFuncionario(Integer idFuncionario) { 
        this.idFuncionario = idFuncionario; 
    }
    
    public String getTokenRecuperacao() { 
        return tokenRecuperacao; 
    }
    
    public void setTokenRecuperacao(String tokenRecuperacao) { 
        this.tokenRecuperacao = tokenRecuperacao; 
    }
    
    public Timestamp getDataToken() { 
        return dataToken; 
    }
    
    public void setDataToken(Timestamp dataToken) { 
        this.dataToken = dataToken; 
    }
    
    // ==================== RELACIONAMENTOS ====================
    public Funcionario getFuncionario() {
        return funcionario;
    }
    
    public void setFuncionario(Funcionario funcionario) {
        this.funcionario = funcionario;
        if (funcionario != null) {
            this.idFuncionario = funcionario.getId();
        }
    }
    
    // ==================== MÉTODOS DE CONVENIÊNCIA ====================
    public boolean isAdmin() { 
        return perfil == Perfil.ADMIN; 
    }
    
    public boolean isRH() { 
        return perfil == Perfil.RH; 
    }
    
    public boolean isFinanceiro() { 
        return perfil == Perfil.FINANCEIRO; 
    }
    
    public boolean isGestor() { 
        return perfil == Perfil.GESTOR; 
    }
    
    public boolean isFuncionario() { 
        return perfil == Perfil.FUNCIONARIO; 
    }
    
    public boolean isAtivo() { 
        return status == Status.ATIVO; 
    }
    
    public boolean isBloqueado() {
        return status == Status.BLOQUEADO;
    }
    
    public boolean isInativo() {
        return status == Status.INATIVO;
    }
    
    /**
     * Verifica se o usuário tem permissão para acessar um determinado recurso
     * @param perfisPermitidos Lista de perfis que têm permissão
     * @return true se o usuário tem permissão
     */
    public boolean temPermissao(String... perfisPermitidos) {
        if (isAdmin()) {
            return true; // Admin tem acesso total
        }
        for (String perfil : perfisPermitidos) {
            if (this.perfil.name().equals(perfil)) {
                return true;
            }
        }
        return false;
    }
    
    /**
     * Obtém o nome do perfil formatado
     */
    public String getPerfilFormatado() {
        return switch (perfil) {
            case ADMIN -> "Administrador";
            case RH -> "Recursos Humanos";
            case FINANCEIRO -> "Financeiro";
            case GESTOR -> "Gestor";
            case FUNCIONARIO -> "Funcionário";
        };
    }
    
    /**
     * Obtém o status formatado
     */
    public String getStatusFormatado() {
        return switch (status) {
            case ATIVO -> "Ativo";
            case INATIVO -> "Inativo";
            case BLOQUEADO -> "Bloqueado";
        };
    }
    
    // ==================== OVERRIDES ====================
    @Override
    public String toString() {
        return String.format("Usuario{id=%d, nome='%s', usuario='%s', email='%s', perfil=%s, status=%s}", 
                id, nome, usuario, email, perfil, status);
    }
    
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;
        Usuario usuario = (Usuario) o;
        return id != null && id.equals(usuario.id);
    }
    
    @Override
    public int hashCode() {
        return id != null ? id.hashCode() : 0;
    }
 // ==================== CAMPOS PARA CÓDIGO DE VERIFICAÇÃO ====================
    private String codigoVerificacao;
    private Timestamp dataCodigo;
    private Integer tentativasCodigo;

    // Getters e Setters
    public String getCodigoVerificacao() { return codigoVerificacao; }
    public void setCodigoVerificacao(String codigoVerificacao) { this.codigoVerificacao = codigoVerificacao; }

    public Timestamp getDataCodigo() { return dataCodigo; }
    public void setDataCodigo(Timestamp dataCodigo) { this.dataCodigo = dataCodigo; }

    public Integer getTentativasCodigo() { return tentativasCodigo; }
    public void setTentativasCodigo(Integer tentativasCodigo) { this.tentativasCodigo = tentativasCodigo; }
}
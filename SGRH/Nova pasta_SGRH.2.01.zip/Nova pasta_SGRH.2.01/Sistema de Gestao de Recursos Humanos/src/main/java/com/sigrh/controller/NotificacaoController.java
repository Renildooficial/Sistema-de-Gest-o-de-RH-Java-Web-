package com.sigrh.controller;

import com.sigrh.model.Notificacao;
import com.sigrh.model.Usuario;
import com.sigrh.service.NotificacaoService;
import com.sigrh.util.Constants;
import com.sigrh.util.ConfiguracaoUtil;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

@WebServlet("/notificacoes/*")
public class NotificacaoController extends HttpServlet {
    
    private static final long serialVersionUID = 1L;
    private final NotificacaoService notificacaoService;
    private final ConfiguracaoUtil configuracaoUtil;
    
    public NotificacaoController() {
        this.notificacaoService = new NotificacaoService();
        this.configuracaoUtil = new ConfiguracaoUtil();
    }
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        Usuario usuario = (Usuario) request.getSession().getAttribute(Constants.SESSION_USER);
        if (usuario == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }
        
        String path = request.getPathInfo();
        
        if (path == null || path.equals("/")) {
            listar(request, response);
        } else if (path.equals("/nao-lidas")) {
            naoLidas(request, response);
        } else if (path.equals("/contar")) {
            contar(request, response);
        } else if (path.equals("/api")) {
            apiListar(request, response);
        } else {
            response.sendError(HttpServletResponse.SC_NOT_FOUND);
        }
    }
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        Usuario usuario = (Usuario) request.getSession().getAttribute(Constants.SESSION_USER);
        if (usuario == null) {
            response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            response.getWriter().write("{\"success\":false,\"message\":\"Não autenticado\"}");
            return;
        }
        
        String path = request.getPathInfo();
        
        try {
            if (path.equals("/marcar-lida")) {
                marcarLida(request, response);
            } else if (path.equals("/marcar-todas")) {
                marcarTodas(request, response);
            } else if (path.equals("/enviar")) {
                enviar(request, response);
            } else if (path.equals("/deletar-antigas")) {
                deletarAntigas(request, response);
            } else {
                response.sendError(HttpServletResponse.SC_NOT_FOUND);
            }
        } catch (Exception e) {
            response.setContentType("application/json");
            response.getWriter().write("{\"success\":false,\"message\":\"" + e.getMessage() + "\"}");
        }
    }
    
    private void listar(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        Usuario usuario = (Usuario) request.getSession().getAttribute(Constants.SESSION_USER);
        if (usuario == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }
        
        try {
            List<Notificacao> notificacoes = notificacaoService.buscarPorUsuario(usuario.getId());
            int naoLidas = notificacaoService.contarNaoLidas(usuario.getId());
            
            request.setAttribute("notificacoes", notificacoes);
            request.setAttribute("total", notificacoes.size());
            request.setAttribute("naoLidas", naoLidas);
            
            request.getSession().removeAttribute(Constants.MSG_ERRO);
            request.getSession().removeAttribute(Constants.MSG_SUCESSO);
            request.getSession().removeAttribute(Constants.MSG_INFO);
            
            // APENAS FORWARD - SEM REDIRECT
            request.getRequestDispatcher("/WEB-INF/views/notificacoes/lista.jsp").forward(request, response);
            
        } catch (Exception e) {
            e.printStackTrace();
            request.getSession().setAttribute(Constants.MSG_ERRO, "Erro ao carregar notificações: " + e.getMessage());
            // REMOVA este sendRedirect - já estamos no meio do processamento
            // response.sendRedirect(request.getContextPath() + "/dashboard");
            // Em vez disso, faça forward para uma página de erro ou mantenha no dashboard
            response.sendRedirect(request.getContextPath() + "/dashboard");
        }
    }
    private void naoLidas(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        Usuario usuario = (Usuario) request.getSession().getAttribute(Constants.SESSION_USER);
        
        try {
            List<Notificacao> notificacoes = notificacaoService.buscarNaoLidas(usuario.getId());
            
            request.setAttribute("notificacoes", notificacoes);
            request.setAttribute("total", notificacoes.size());
            
            request.getRequestDispatcher("/WEB-INF/views/notificacoes/nao-lidas.jsp").forward(request, response);
            
        } catch (Exception e) {
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, e.getMessage());
        }
    }
    
    private void contar(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        
        response.setContentType("application/json");
        PrintWriter out = response.getWriter();
        
        Usuario usuario = (Usuario) request.getSession().getAttribute(Constants.SESSION_USER);
        if (usuario == null) {
            out.print("{\"success\":false,\"count\":0,\"message\":\"Não autenticado\"}");
            out.flush();
            return;
        }
        
        try {
            int count = notificacaoService.contarNaoLidas(usuario.getId());
            out.print("{\"success\":true,\"count\":" + count + "}");
            
        } catch (Exception e) {
            out.print("{\"success\":false,\"count\":0,\"message\":\"" + e.getMessage() + "\"}");
        }
        
        out.flush();
    }
    
    private void apiListar(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        
        response.setContentType("application/json");
        PrintWriter out = response.getWriter();
        
        Usuario usuario = (Usuario) request.getSession().getAttribute(Constants.SESSION_USER);
        if (usuario == null) {
            out.print("[]");
            out.flush();
            return;
        }
        
        try {
            List<Notificacao> notificacoes = notificacaoService.buscarRecentes(usuario.getId(), 10);
            
            StringBuilder json = new StringBuilder("[");
            for (int i = 0; i < notificacoes.size(); i++) {
                Notificacao n = notificacoes.get(i);
                json.append("{");
                json.append("\"id\":").append(n.getId()).append(",");
                json.append("\"titulo\":\"").append(escapeJson(n.getTitulo())).append("\",");
                json.append("\"mensagem\":\"").append(escapeJson(n.getMensagem())).append("\",");
                json.append("\"tipo\":\"").append(n.getTipo()).append("\",");
                json.append("\"icone\":\"").append(n.getIcone()).append("\",");
                json.append("\"lida\":").append(n.isLida()).append(",");
                json.append("\"dataCriacao\":\"").append(n.getDataCriacao()).append("\"");
                json.append("}");
                if (i < notificacoes.size() - 1) json.append(",");
            }
            json.append("]");
            
            out.print(json.toString());
            
        } catch (Exception e) {
            out.print("[]");
        }
        
        out.flush();
    }
    
    private void marcarLida(HttpServletRequest request, HttpServletResponse response) 
            throws IOException, Exception {
        
        response.setContentType("application/json");
        PrintWriter out = response.getWriter();
        
        try {
            Integer id = Integer.parseInt(request.getParameter("id"));
            notificacaoService.marcarComoLida(id);
            
            out.print("{\"success\":true,\"message\":\"Notificação marcada como lida\"}");
            
        } catch (NumberFormatException e) {
            out.print("{\"success\":false,\"message\":\"ID inválido\"}");
        } catch (Exception e) {
            out.print("{\"success\":false,\"message\":\"" + e.getMessage() + "\"}");
        }
        
        out.flush();
    }
    
    private void marcarTodas(HttpServletRequest request, HttpServletResponse response) 
            throws IOException, Exception {
        
        response.setContentType("application/json");
        PrintWriter out = response.getWriter();
        
        Usuario usuario = (Usuario) request.getSession().getAttribute(Constants.SESSION_USER);
        
        try {
            notificacaoService.marcarTodasComoLidas(usuario.getId());
            
            out.print("{\"success\":true,\"message\":\"Todas notificações marcadas como lidas\"}");
            
        } catch (Exception e) {
            out.print("{\"success\":false,\"message\":\"" + e.getMessage() + "\"}");
        }
        
        out.flush();
    }
    
    private void enviar(HttpServletRequest request, HttpServletResponse response) 
            throws IOException, Exception {
        
        response.setContentType("application/json");
        PrintWriter out = response.getWriter();
        
        Usuario usuario = (Usuario) request.getSession().getAttribute(Constants.SESSION_USER);
        if (usuario == null || usuario.getPerfil() != Usuario.Perfil.ADMIN) {
            out.print("{\"success\":false,\"message\":\"Acesso negado. Apenas administradores podem enviar notificações em massa.\"}");
            out.flush();
            return;
        }
        
        try {
            String idUsuario = request.getParameter("idUsuario");
            String titulo = request.getParameter("titulo");
            String mensagem = request.getParameter("mensagem");
            String tipo = request.getParameter("tipo");
            
            if (titulo == null || titulo.isEmpty() || mensagem == null || mensagem.isEmpty()) {
                out.print("{\"success\":false,\"message\":\"Título e mensagem são obrigatórios\"}");
                out.flush();
                return;
            }
            
            if (idUsuario != null && !idUsuario.isEmpty()) {
                // Enviar para um usuário específico
                notificacaoService.enviarNotificacao(Integer.parseInt(idUsuario), titulo, mensagem, tipo);
                out.print("{\"success\":true,\"message\":\"Notificação enviada com sucesso!\"}");
            } else {
                // Enviar para todos os usuários
                notificacaoService.enviarParaTodos(titulo, mensagem, tipo);
                out.print("{\"success\":true,\"message\":\"Notificação enviada para todos os usuários!\"}");
            }
            
        } catch (Exception e) {
            out.print("{\"success\":false,\"message\":\"" + e.getMessage() + "\"}");
        }
        
        out.flush();
    }
    
    private void deletarAntigas(HttpServletRequest request, HttpServletResponse response) 
            throws IOException, Exception {
        
        response.setContentType("application/json");
        PrintWriter out = response.getWriter();
        
        Usuario usuario = (Usuario) request.getSession().getAttribute(Constants.SESSION_USER);
        
        try {
            int dias = 30; // padrão
            String diasParam = request.getParameter("dias");
            if (diasParam != null && !diasParam.isEmpty()) {
                dias = Integer.parseInt(diasParam);
            }
            
            notificacaoService.deletarAntigas(usuario.getId(), dias);
            
            out.print("{\"success\":true,\"message\":\"Notificações com mais de " + dias + " dias foram removidas\"}");
            
        } catch (Exception e) {
            out.print("{\"success\":false,\"message\":\"" + e.getMessage() + "\"}");
        }
        
        out.flush();
    }
    
    private String escapeJson(String text) {
        if (text == null) return "";
        return text.replace("\\", "\\\\")
                   .replace("\"", "\\\"")
                   .replace("\n", "\\n")
                   .replace("\r", "\\r")
                   .replace("\t", "\\t");
    }
}
package com.sigrh.model;

import java.sql.Timestamp;

public class Configuracao extends BaseModel {
    
    private Integer id;
    private String chave;
    private String valor;
    private String descricao;
    private String categoria;
    private String tipo;
    private Timestamp dataAtualizacao;
    
    // ============================================================
    // CONSTRUTORES
    // ============================================================
    public Configuracao() {}
    
    public Configuracao(Integer id, String chave, String valor, String descricao, 
                        String categoria, String tipo) {
        this.id = id;
        this.chave = chave;
        this.valor = valor;
        this.descricao = descricao;
        this.categoria = categoria;
        this.tipo = tipo;
    }
    
    // ============================================================
    // GETTERS E SETTERS
    // ============================================================
    public Integer getId() {
        return id;
    }
    
    public void setId(Integer id) {
        this.id = id;
    }
    
    public String getChave() {
        return chave;
    }
    
    public void setChave(String chave) {
        this.chave = chave;
    }
    
    public String getValor() {
        return valor;
    }
    
    public void setValor(String valor) {
        this.valor = valor;
    }
    
    public String getDescricao() {
        return descricao;
    }
    
    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }
    
    public String getCategoria() {
        return categoria;
    }
    
    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }
    
    public String getTipo() {
        return tipo;
    }
    
    public void setTipo(String tipo) {
        this.tipo = tipo;
    }
    
    public Timestamp getDataAtualizacao() {
        return dataAtualizacao;
    }
    
    public void setDataAtualizacao(Timestamp dataAtualizacao) {
        this.dataAtualizacao = dataAtualizacao;
    }
    
    // ============================================================
    // MÉTODOS AUXILIARES
    // ============================================================
    public boolean getValorBoolean() {
        return "true".equalsIgnoreCase(valor);
    }
    
    public Integer getValorInteger() {
        try {
            return Integer.parseInt(valor);
        } catch (NumberFormatException e) {
            return 0;
        }
    }
    
    public Double getValorDouble() {
        try {
            return Double.parseDouble(valor);
        } catch (NumberFormatException e) {
            return 0.0;
        }
    }
}
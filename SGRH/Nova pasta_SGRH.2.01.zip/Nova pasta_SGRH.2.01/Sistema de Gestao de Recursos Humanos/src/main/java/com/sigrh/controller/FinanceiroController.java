package com.sigrh.controller;

import com.sigrh.dao.FolhaPagamentoDAO;
import com.sigrh.exception.BusinessException;
import com.sigrh.model.FolhaPagamento;
import com.sigrh.model.Funcionario;
import com.sigrh.model.Usuario;
import com.sigrh.service.FolhaPagamentoService;
import com.sigrh.service.FuncionarioService;
import com.sigrh.service.SistemaNotificacaoService;
import com.sigrh.service.ConfiguracaoService;
import com.sigrh.util.Constants;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.io.PrintWriter;
import java.math.BigDecimal;
import java.util.Calendar;
import java.util.List;

@WebServlet(urlPatterns = {"/financeiro/*", "/folha-pagamento/*"})
public class FinanceiroController extends HttpServlet {

    private static final long serialVersionUID = 1L;
    
    private final FolhaPagamentoService folhaService;
    private final FuncionarioService funcionarioService;
    private final ConfiguracaoService configuracaoService;
    private final FolhaPagamentoDAO folhaDAO;
    private final SistemaNotificacaoService sistemaNotificacaoService;

    public FinanceiroController() {
        this.folhaService = new FolhaPagamentoService();
        this.funcionarioService = new FuncionarioService();
        this.configuracaoService = new ConfiguracaoService();
        this.folhaDAO = new FolhaPagamentoDAO();
        this.sistemaNotificacaoService = new SistemaNotificacaoService();

    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String path = request.getPathInfo();
        System.out.println("🔍 FinanceiroController.doGet - Path: " + path);
        
        Usuario usuario = (Usuario) request.getSession().getAttribute(Constants.SESSION_USER);
        if (usuario == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }
        
        if (!(usuario.getPerfil() == Usuario.Perfil.FINANCEIRO || usuario.isAdmin())) {
            request.getSession().setAttribute(Constants.MSG_ERRO, "Acesso negado");
            response.sendRedirect(request.getContextPath() + "/dashboard");
            return;
        }
        
        try {
            if (path == null || path.equals("/") || path.equals("/dashboard")) {
                dashboard(request, response);
            } else if (path.equals("/folha-pagamento") || path.equals("/folha")) {
                folhaPagamento(request, response);
            } else if (path.equals("/salarios")) {
                salarios(request, response);
            } else if (path.startsWith("/folha-detalhes/")) {
                folhaDetalhes(request, response);
            } else if (path.equals("/editar-salario")) {
                editarSalario(request, response);
            } else {
                response.sendError(HttpServletResponse.SC_NOT_FOUND);
            }
        } catch (Exception e) {
            e.printStackTrace();
            request.getSession().setAttribute(Constants.MSG_ERRO, "Erro: " + e.getMessage());
            response.sendRedirect(request.getContextPath() + "/dashboard");
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String path = request.getPathInfo();
        System.out.println("🚀 FinanceiroController.doPost - Path: " + path);
        
        Usuario usuario = (Usuario) request.getSession().getAttribute(Constants.SESSION_USER);
        if (usuario == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }
        
        if (!(usuario.getPerfil() == Usuario.Perfil.FINANCEIRO || usuario.isAdmin())) {
            request.getSession().setAttribute(Constants.MSG_ERRO, "Acesso negado");
            response.sendRedirect(request.getContextPath() + "/dashboard");
            return;
        }
        
        try {
            if (path.equals("/processar-folha")) {
                processarFolha(request, response);
            } else if (path.equals("/salvar-salario")) {
                salvarSalario(request, response);
            } else if (path.equals("/folha-pagar")) {
                pagarFolha(request, response);
            } else if (path.equals("/folha-cancelar")) {
                cancelarFolha(request, response);
            } else {
                response.sendError(HttpServletResponse.SC_NOT_FOUND);
            }
        } catch (Exception e) {
            e.printStackTrace();
            request.getSession().setAttribute(Constants.MSG_ERRO, "Erro: " + e.getMessage());
            response.sendRedirect(request.getContextPath() + "/financeiro/folha-pagamento");
        }
    }

    // ============================================================
    // DASHBOARD FINANCEIRO
    // ============================================================
    private void dashboard(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        try {
            int mesAtual = Calendar.getInstance().get(Calendar.MONTH) + 1;
            int anoAtual = Calendar.getInstance().get(Calendar.YEAR);
            
            var resumo = folhaService.obterResumo(mesAtual, anoAtual);
            request.setAttribute("resumo", resumo);
            
            int totalFuncionarios = funcionarioService.listarTodos().size();
            request.setAttribute("totalFuncionarios", totalFuncionarios);
            
            request.setAttribute("taxaIrs", configuracaoService.getTaxaIrs());
            request.setAttribute("taxaInss", configuracaoService.getTaxaInss());
            
            request.getRequestDispatcher("/WEB-INF/views/financeiro/dashboard.jsp").forward(request, response);
            
        } catch (BusinessException e) {
            request.getSession().setAttribute(Constants.MSG_ERRO, e.getMessage());
            response.sendRedirect(request.getContextPath() + "/dashboard");
        }
    }

    // ============================================================
    // FOLHA DE PAGAMENTO
    // ============================================================
    private void folhaPagamento(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        try {
            String mesStr = request.getParameter("mes");
            String anoStr = request.getParameter("ano");
            
            int mes = (mesStr != null && !mesStr.isEmpty()) ? Integer.parseInt(mesStr) : Calendar.getInstance().get(Calendar.MONTH) + 1;
            int ano = (anoStr != null && !anoStr.isEmpty()) ? Integer.parseInt(anoStr) : Calendar.getInstance().get(Calendar.YEAR);
            
            List<FolhaPagamento> folhas = folhaService.buscarPorMesAno(mes, ano);
            
            for (FolhaPagamento f : folhas) {
                try {
                    var func = funcionarioService.buscarPorId(f.getIdFuncionario());
                    f.setFuncionario(func);
                } catch (Exception e) {
                    // Ignorar
                }
            }
            
            var resumo = folhaService.obterResumo(mes, ano);
            
            request.setAttribute("folhas", folhas);
            request.setAttribute("resumo", resumo);
            request.setAttribute("mes", mes);
            request.setAttribute("ano", ano);
            request.setAttribute("total", folhas.size());
            request.setAttribute("meses", getMeses());
            
            Calendar cal = Calendar.getInstance();
            request.setAttribute("mesAtual", cal.get(Calendar.MONTH) + 1);
            request.setAttribute("anoAtual", cal.get(Calendar.YEAR));
            
            request.getRequestDispatcher("/WEB-INF/views/financeiro/folha-pagamento.jsp").forward(request, response);
            
        } catch (BusinessException e) {
            request.getSession().setAttribute(Constants.MSG_ERRO, e.getMessage());
            response.sendRedirect(request.getContextPath() + "/financeiro/dashboard");
        } catch (Exception e) {
            e.printStackTrace();
            request.getSession().setAttribute(Constants.MSG_ERRO, "Erro ao carregar folha: " + e.getMessage());
            response.sendRedirect(request.getContextPath() + "/financeiro/dashboard");
        }
    }

    // ============================================================
    // PROCESSAR FOLHA
    // ============================================================
    private void processarFolha(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        try {
            int mes = Integer.parseInt(request.getParameter("mes"));
            int ano = Integer.parseInt(request.getParameter("ano"));
            String observacao = request.getParameter("observacao");
            
            int processados = folhaService.processarFolha(mes, ano, observacao);
            
            try {
                var resumo = folhaService.obterResumo(mes, ano);
                BigDecimal totalLiquido = resumo != null ? resumo.getTotalLiquido() : BigDecimal.ZERO;
                sistemaNotificacaoService.notificarFolhaProcessada(mes, ano, processados, totalLiquido);
            } catch (Exception e) {
                System.err.println("⚠️ Erro ao notificar folha processada: " + e.getMessage());
            }
            
            request.getSession().setAttribute(Constants.MSG_SUCESSO, 
                "Folha de pagamento processada com sucesso! " + processados + " funcionários processados.");
            
            response.sendRedirect(request.getContextPath() + "/financeiro/folha-pagamento?mes=" + mes + "&ano=" + ano);
            
        } catch (BusinessException e) {
            request.getSession().setAttribute(Constants.MSG_ERRO, e.getMessage());
            response.sendRedirect(request.getContextPath() + "/financeiro/folha-pagamento");
        } catch (Exception e) {
            e.printStackTrace();
            request.getSession().setAttribute(Constants.MSG_ERRO, "Erro ao processar folha: " + e.getMessage());
            response.sendRedirect(request.getContextPath() + "/financeiro/folha-pagamento");
        }
    }

    // ============================================================
    // SALÁRIOS (LISTA DE FUNCIONÁRIOS COM SALÁRIOS)
    // ============================================================
    private void salarios(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        try {
            var funcionarios = funcionarioService.listarTodos();
            request.setAttribute("funcionarios", funcionarios);
            request.setAttribute("total", funcionarios.size());
            
            request.getRequestDispatcher("/WEB-INF/views/financeiro/salarios.jsp").forward(request, response);
            
        } catch (BusinessException e) {
            request.getSession().setAttribute(Constants.MSG_ERRO, e.getMessage());
            response.sendRedirect(request.getContextPath() + "/financeiro/dashboard");
        }
    }

    // ============================================================
    // EDITAR SALÁRIO (GET - Mostra o formulário)
    // ============================================================
    private void editarSalario(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        try {
            String idStr = request.getParameter("id");
            if (idStr == null || idStr.isEmpty()) {
                response.sendRedirect(request.getContextPath() + "/financeiro/salarios");
                return;
            }
            
            Integer id = Integer.parseInt(idStr);
            Funcionario funcionario = funcionarioService.buscarPorId(id);
            
            if (funcionario == null) {
                request.getSession().setAttribute(Constants.MSG_ERRO, "Funcionário não encontrado");
                response.sendRedirect(request.getContextPath() + "/financeiro/salarios");
                return;
            }
            
            request.setAttribute("funcionario", funcionario);
            request.getRequestDispatcher("/WEB-INF/views/financeiro/editar-salario.jsp").forward(request, response);
            
        } catch (Exception e) {
            e.printStackTrace();
            request.getSession().setAttribute(Constants.MSG_ERRO, "Erro ao carregar salário: " + e.getMessage());
            response.sendRedirect(request.getContextPath() + "/financeiro/salarios");
        }
    }

 // ============================================================
 // SALVAR SALÁRIO (POST)
 // ============================================================
 private void salvarSalario(HttpServletRequest request, HttpServletResponse response) 
         throws ServletException, IOException {
     
     try {
         // Pegar os parâmetros
         String idFuncionarioStr = request.getParameter("idFuncionario");
         String salarioBaseStr = request.getParameter("salarioBase");
         String subsidioAlimentacaoStr = request.getParameter("subsidioAlimentacao");
         String subsidioTransporteStr = request.getParameter("subsidioTransporte");
         String subsidioSaudeStr = request.getParameter("subsidioSaude");
         
         System.out.println("📝 Salvar Salário - Funcionário ID: " + idFuncionarioStr);
         System.out.println("📝 Salário Base: " + salarioBaseStr);
         System.out.println("📝 Subsídio Alimentação: " + subsidioAlimentacaoStr);
         System.out.println("📝 Subsídio Transporte: " + subsidioTransporteStr);
         System.out.println("📝 Subsídio Saúde: " + subsidioSaudeStr);
         
         // Validar parâmetros obrigatórios
         if (idFuncionarioStr == null || idFuncionarioStr.isEmpty()) {
             throw new BusinessException("ID do funcionário é obrigatório");
         }
         
         if (salarioBaseStr == null || salarioBaseStr.isEmpty()) {
             throw new BusinessException("Salário base é obrigatório");
         }
         
         Integer idFuncionario = Integer.parseInt(idFuncionarioStr);
         
         // Converter para BigDecimal (tratar vírgula e ponto)
         BigDecimal salarioBase = converterParaBigDecimal(salarioBaseStr);
         BigDecimal subsidioAlimentacao = converterParaBigDecimal(subsidioAlimentacaoStr);
         BigDecimal subsidioTransporte = converterParaBigDecimal(subsidioTransporteStr);
         BigDecimal subsidioSaude = converterParaBigDecimal(subsidioSaudeStr);
         
         System.out.println("📝 Salário Base (convertido): " + salarioBase);
         
         // Buscar funcionário
         Funcionario funcionario = funcionarioService.buscarPorId(idFuncionario);
         if (funcionario == null) {
             throw new BusinessException("Funcionário não encontrado");
         }
         
         System.out.println("📝 Funcionário encontrado: " + funcionario.getNome());
         
         // Atualizar salários
         funcionario.setSalarioBase(salarioBase);
         funcionario.setSubsidioAlimentacao(subsidioAlimentacao);
         funcionario.setSubsidioTransporte(subsidioTransporte);
         funcionario.setSubsidioSaude(subsidioSaude);
         
         // Salvar via service
         funcionarioService.atualizar(funcionario);
         
         System.out.println("✅ Salário atualizado com sucesso!");
         
         request.getSession().setAttribute(Constants.MSG_SUCESSO, 
             "Salário do funcionário " + funcionario.getNome() + " atualizado com sucesso!");
         
         response.sendRedirect(request.getContextPath() + "/financeiro/salarios");
         
     } catch (BusinessException e) {
         System.err.println("❌ Erro de negócio: " + e.getMessage());
         request.getSession().setAttribute(Constants.MSG_ERRO, e.getMessage());
         response.sendRedirect(request.getContextPath() + "/financeiro/salarios");
     } catch (NumberFormatException e) {
         System.err.println("❌ Erro de formato: " + e.getMessage());
         request.getSession().setAttribute(Constants.MSG_ERRO, "Formato de número inválido. Use ponto (.) como separador decimal.");
         response.sendRedirect(request.getContextPath() + "/financeiro/salarios");
     } catch (Exception e) {
         System.err.println("❌ Erro ao salvar salário: " + e.getMessage());
         e.printStackTrace();
         request.getSession().setAttribute(Constants.MSG_ERRO, "Erro ao salvar salário: " + e.getMessage());
         response.sendRedirect(request.getContextPath() + "/financeiro/salarios");
     }
 }

 /**
  * Converte uma string para BigDecimal, tratando vírgula e ponto
  */
 private BigDecimal converterParaBigDecimal(String valor) {
     if (valor == null || valor.trim().isEmpty()) {
         return BigDecimal.ZERO;
     }
     
     // Remover espaços
     valor = valor.trim();
     
     // Se tiver vírgula, substituir por ponto (para formatação brasileira)
     if (valor.contains(",") && !valor.contains(".")) {
         valor = valor.replace(",", ".");
     }
     
     // Remover caracteres não numéricos (exceto ponto)
     valor = valor.replaceAll("[^0-9.]", "");
     
     try {
         return new BigDecimal(valor);
     } catch (NumberFormatException e) {
         return BigDecimal.ZERO;
     }
 }

    // ============================================================
    // DETALHES DA FOLHA
    // ============================================================
    private void folhaDetalhes(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        try {
            String path = request.getPathInfo();
            String idStr = path.substring("/folha-detalhes/".length());
            Integer id = Integer.parseInt(idStr);
            
            FolhaPagamento folha = folhaService.buscarPorId(id);
            
            if (folha == null) {
                request.getSession().setAttribute(Constants.MSG_ERRO, "Folha não encontrada");
                response.sendRedirect(request.getContextPath() + "/financeiro/folha-pagamento");
                return;
            }
            
            if (folha.getIdFuncionario() != null) {
                try {
                    var func = funcionarioService.buscarPorId(folha.getIdFuncionario());
                    folha.setFuncionario(func);
                } catch (Exception e) {
                    // Ignorar
                }
            }
            
            request.setAttribute("folha", folha);
            request.getRequestDispatcher("/WEB-INF/views/financeiro/folha-detalhes.jsp").forward(request, response);
            
        } catch (BusinessException e) {
            request.getSession().setAttribute(Constants.MSG_ERRO, e.getMessage());
            response.sendRedirect(request.getContextPath() + "/financeiro/folha-pagamento");
        } catch (Exception e) {
            e.printStackTrace();
            request.getSession().setAttribute(Constants.MSG_ERRO, "Erro ao carregar detalhes: " + e.getMessage());
            response.sendRedirect(request.getContextPath() + "/financeiro/folha-pagamento");
        }
    }

    // ============================================================
    // MARCAR COMO PAGO (POST)
    // ============================================================
    private void pagarFolha(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        
        response.setContentType("application/json");
        PrintWriter out = response.getWriter();
        
        try {
            Integer id = Integer.parseInt(request.getParameter("id"));
            
            FolhaPagamento folha = folhaService.buscarPorId(id);
            if (folha == null) {
                out.print("{\"success\":false,\"message\":\"Folha não encontrada\"}");
                out.flush();
                return;
            }
            
            if (!"PROCESSADO".equals(folha.getStatus())) {
                out.print("{\"success\":false,\"message\":\"Apenas folhas processadas podem ser pagas\"}");
                out.flush();
                return;
            }
            
            folha.setStatus(FolhaPagamento.StatusFolha.PAGO);
            folhaDAO.atualizar(folha);
            
            // =============================================================
            // NOTIFICAR FOLHA PAGA
            // =============================================================
            try {
                if (folha.getIdFuncionario() != null) {
                    Funcionario func = funcionarioService.buscarPorId(folha.getIdFuncionario());
                    if (func != null) {
                        sistemaNotificacaoService.notificarFolhaPaga(
                            folha.getIdFuncionario(), 
                            func.getNome(), 
                            folha.getTotalLiquido()
                        );
                    }
                }
            } catch (Exception e) {
                System.err.println("⚠️ Erro ao notificar folha paga: " + e.getMessage());
            }
            
            out.print("{\"success\":true,\"message\":\"Folha marcada como PAGA com sucesso!\"}");
            
        } catch (Exception e) {
            e.printStackTrace();
            out.print("{\"success\":false,\"message\":\"" + e.getMessage() + "\"}");
        }
        
        out.flush();
    }

    // ============================================================
    // CANCELAR FOLHA (POST)
    // ============================================================
    private void cancelarFolha(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        
        response.setContentType("application/json");
        PrintWriter out = response.getWriter();
        
        try {
            Integer id = Integer.parseInt(request.getParameter("id"));
            
            FolhaPagamento folha = folhaService.buscarPorId(id);
            if (folha == null) {
                out.print("{\"success\":false,\"message\":\"Folha não encontrada\"}");
                out.flush();
                return;
            }
            
            if ("CANCELADO".equals(folha.getStatus())) {
                out.print("{\"success\":false,\"message\":\"Esta folha já está cancelada\"}");
                out.flush();
                return;
            }
            
            folha.setStatus(FolhaPagamento.StatusFolha.CANCELADO);
            folhaDAO.atualizar(folha);
            
            out.print("{\"success\":true,\"message\":\"Folha cancelada com sucesso!\"}");
            
        } catch (Exception e) {
            e.printStackTrace();
            out.print("{\"success\":false,\"message\":\"" + e.getMessage() + "\"}");
        }
        
        out.flush();
    }

    // ============================================================
    // UTILITÁRIOS
    // ============================================================
    private String[][] getMeses() {
        return new String[][] {
            {"1", "Janeiro"}, {"2", "Fevereiro"}, {"3", "Março"},
            {"4", "Abril"}, {"5", "Maio"}, {"6", "Junho"},
            {"7", "Julho"}, {"8", "Agosto"}, {"9", "Setembro"},
            {"10", "Outubro"}, {"11", "Novembro"}, {"12", "Dezembro"}
        };
    }
    
}
package com.sigrh.dao;

import com.sigrh.model.Usuario;
import com.sigrh.exception.DatabaseException;
import com.sigrh.util.DatabaseUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class UsuarioDAO extends GenericDAO<Usuario> {
    
    // ============================================================
    // MÉTODOS ABSTRATOS OBRIGATÓRIOS
    // ============================================================
    
    @Override
    protected String getTableName() {
        return "usuario";
    }
    
    @Override
    protected Usuario mapResultSetToEntity(ResultSet rs) throws SQLException {
        Usuario u = new Usuario();
        u.setId(rs.getInt("id"));
        u.setNome(rs.getString("nome"));
        u.setUsuario(rs.getString("usuario"));
        u.setEmail(rs.getString("email"));
        u.setSenha(rs.getString("senha"));
        u.setPerfil(rs.getString("perfil"));
        u.setStatus(rs.getString("status"));
        u.setUltimoLogin(rs.getTimestamp("ultimo_login"));
        u.setDataCadastro(rs.getTimestamp("data_cadastro"));
        u.setExpiraSenha(rs.getDate("expira_senha"));
        u.setIdFuncionario(rs.getInt("id_funcionario"));
        u.setTokenRecuperacao(rs.getString("token_recuperacao"));
        u.setDataToken(rs.getTimestamp("data_token"));
        return u;
    }
    
    @Override
    protected void setInsertParameters(PreparedStatement ps, Usuario entity) throws SQLException {
        ps.setString(1, entity.getNome());
        ps.setString(2, entity.getUsuario());
        ps.setString(3, entity.getEmail());
        ps.setString(4, entity.getSenha());
        ps.setString(5, entity.getPerfil() != null ? entity.getPerfil().name() : null);
        ps.setString(6, entity.getStatus() != null ? entity.getStatus().name() : null);
        ps.setTimestamp(7, entity.getUltimoLogin() != null ? new Timestamp(entity.getUltimoLogin().getTime()) : null);
        ps.setDate(8, entity.getExpiraSenha() != null ? new java.sql.Date(entity.getExpiraSenha().getTime()) : null);
        if (entity.getIdFuncionario() != null && entity.getIdFuncionario() > 0) {
            ps.setInt(9, entity.getIdFuncionario());
        } else {
            ps.setNull(9, Types.INTEGER);
        }
        ps.setString(10, entity.getTokenRecuperacao());
        ps.setTimestamp(11, entity.getDataToken() != null ? new Timestamp(entity.getDataToken().getTime()) : null);
    }
    
    @Override
    protected void setUpdateParameters(PreparedStatement ps, Usuario entity) throws SQLException {
        ps.setString(1, entity.getNome());
        ps.setString(2, entity.getUsuario());
        ps.setString(3, entity.getEmail());
        ps.setString(4, entity.getSenha());
        ps.setString(5, entity.getPerfil() != null ? entity.getPerfil().name() : null);
        ps.setString(6, entity.getStatus() != null ? entity.getStatus().name() : null);
        ps.setTimestamp(7, entity.getUltimoLogin() != null ? new Timestamp(entity.getUltimoLogin().getTime()) : null);
        ps.setDate(8, entity.getExpiraSenha() != null ? new java.sql.Date(entity.getExpiraSenha().getTime()) : null);
        if (entity.getIdFuncionario() != null && entity.getIdFuncionario() > 0) {
            ps.setInt(9, entity.getIdFuncionario());
        } else {
            ps.setNull(9, Types.INTEGER);
        }
        ps.setString(10, entity.getTokenRecuperacao());
        ps.setTimestamp(11, entity.getDataToken() != null ? new Timestamp(entity.getDataToken().getTime()) : null);
        ps.setInt(12, entity.getId());
    }
    
    @Override
    protected String getInsertColumns() {
        return "nome, usuario, email, senha, perfil, status, ultimo_login, expira_senha, id_funcionario, token_recuperacao, data_token";
    }
    
    @Override
    protected String getInsertPlaceholders() {
        return "?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?";
    }
    
    @Override
    protected String getUpdateColumns() {
        return "nome = ?, usuario = ?, email = ?, senha = ?, perfil = ?, status = ?, " +
               "ultimo_login = ?, expira_senha = ?, id_funcionario = ?, token_recuperacao = ?, data_token = ?";
    }
    
    @Override
    protected int getUpdateParameterCount() {
        return 11;
    }
    
    @Override
    protected Integer getId(Usuario entity) {
        return entity.getId();
    }
    
    @Override
    protected void setId(Usuario entity, Integer id) {
        entity.setId(id);
    }
    
    // ============================================================
    // MÉTODOS ADICIONAIS (ALIAS PARA COMPATIBILIDADE)
    // ============================================================
    
    public List<Usuario> listarTodos() throws DatabaseException {
        return findAll();
    }
    
    public Usuario buscarPorId(Integer id) throws DatabaseException {
        return findById(id);
    }
    
    public void salvar(Usuario usuario) throws DatabaseException {
        insert(usuario);
    }
    
    public void atualizar(Usuario usuario) throws DatabaseException {
        update(usuario);
    }
    
    public void excluir(Integer id) throws DatabaseException {
        delete(id);
    }
    
    public int contar() throws DatabaseException {
        return count();
    }
    
    public int contarAtivos() throws DatabaseException {
        String sql = "SELECT COUNT(*) as total FROM " + getTableName() + " WHERE status = 'ATIVO'";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            
            if (rs.next()) {
                return rs.getInt("total");
            }
            return 0;
            
        } catch (SQLException e) {
            logger.error("Erro ao contar usuários ativos", e);
            throw new DatabaseException("Erro ao contar usuários ativos: " + e.getMessage(), e);
        }
    }
    
    // ============================================================
    // MÉTODOS ESPECÍFICOS
    // ============================================================
    
    public Usuario findByUsuario(String username) throws DatabaseException {
        String sql = "SELECT * FROM " + getTableName() + " WHERE usuario = ?";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setString(1, username);
            
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToEntity(rs);
                }
            }
            
            return null;
            
        } catch (SQLException e) {
            logger.error("Erro ao buscar usuário por username", e);
            throw new DatabaseException("Erro ao buscar usuário: " + e.getMessage(), e);
        }
    }
    
    public Usuario findByEmail(String email) throws DatabaseException {
        String sql = "SELECT * FROM " + getTableName() + " WHERE email = ?";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setString(1, email);
            
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToEntity(rs);
                }
            }
            
            return null;
            
        } catch (SQLException e) {
            logger.error("Erro ao buscar usuário por email", e);
            throw new DatabaseException("Erro ao buscar usuário: " + e.getMessage(), e);
        }
    }
    
    public Usuario findByTokenRecuperacao(String token) throws DatabaseException {
        String sql = "SELECT * FROM " + getTableName() + " WHERE token_recuperacao = ?";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setString(1, token);
            
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToEntity(rs);
                }
            }
            
            return null;
            
        } catch (SQLException e) {
            logger.error("Erro ao buscar usuário por token", e);
            throw new DatabaseException("Erro ao buscar usuário por token: " + e.getMessage(), e);
        }
    }
    
    public void updateSenha(Integer id, String novaSenhaHash) throws DatabaseException {
        String sql = "UPDATE " + getTableName() + " SET senha = ? WHERE id = ?";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setString(1, novaSenhaHash);
            ps.setInt(2, id);
            ps.executeUpdate();
            
        } catch (SQLException e) {
            logger.error("Erro ao atualizar senha do usuário ID: {}", id, e);
            throw new DatabaseException("Erro ao atualizar senha: " + e.getMessage(), e);
        }
    }
    
    public List<Usuario> findByPerfil(String perfil) throws DatabaseException {
        List<Usuario> list = new ArrayList<>();
        String sql = "SELECT * FROM " + getTableName() + " WHERE perfil = ? ORDER BY nome";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setString(1, perfil);
            
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(mapResultSetToEntity(rs));
                }
            }
            
            return list;
            
        } catch (SQLException e) {
            logger.error("Erro ao buscar usuários por perfil", e);
            throw new DatabaseException("Erro ao buscar usuários por perfil: " + e.getMessage(), e);
        }
    }
    
 // No UsuarioDAO.java, corrija os métodos:

    public List<Usuario> buscarPorPerfil(Usuario.Perfil perfil) throws SQLException {
        List<Usuario> usuarios = new ArrayList<>();
        String sql = "SELECT * FROM usuario WHERE perfil = ? ORDER BY nome";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, perfil.name());
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                usuarios.add(mapResultSetToEntity(rs));  // <-- CORRIGIDO: usar mapResultSetToEntity
            }
        }
        return usuarios;
    }

    public Usuario buscarPorFuncionario(Integer idFuncionario) throws SQLException {
        String sql = "SELECT * FROM usuario WHERE id_funcionario = ?";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, idFuncionario);
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                return mapResultSetToEntity(rs);  // <-- CORRIGIDO: usar mapResultSetToEntity
            }
        }
        return null;
    }

    
    public List<Usuario> findByStatus(String status) throws DatabaseException {
        List<Usuario> list = new ArrayList<>();
        String sql = "SELECT * FROM " + getTableName() + " WHERE status = ? ORDER BY nome";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setString(1, status);
            
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(mapResultSetToEntity(rs));
                }
            }
            
            return list;
            
        } catch (SQLException e) {
            logger.error("Erro ao buscar usuários por status", e);
            throw new DatabaseException("Erro ao buscar usuários por status: " + e.getMessage(), e);
        }
    }
    
    public void atualizarUltimoLogin(Integer id) throws DatabaseException {
        String sql = "UPDATE " + getTableName() + " SET ultimo_login = NOW() WHERE id = ?";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setInt(1, id);
            ps.executeUpdate();
            
        } catch (SQLException e) {
            logger.error("Erro ao atualizar último login", e);
            throw new DatabaseException("Erro ao atualizar último login: " + e.getMessage(), e);
        }
    }
    
}
package com.sigrh.dao;

import com.sigrh.model.Auditoria;
import com.sigrh.model.Usuario;
import com.sigrh.exception.DatabaseException;
import com.sigrh.util.DatabaseUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class AuditoriaDAO extends GenericDAO<Auditoria> {
    
    // ============================================================
    // MÉTODOS ABSTRATOS OBRIGATÓRIOS
    // ============================================================
    
    @Override
    protected String getTableName() {
        return "auditoria";
    }
    
    @Override
    protected Auditoria mapResultSetToEntity(ResultSet rs) throws SQLException {
        Auditoria a = new Auditoria();
        a.setId(rs.getInt("id"));
        a.setIdUsuario(rs.getInt("id_usuario"));
        a.setAcao(rs.getString("acao"));
        a.setTabela(rs.getString("tabela"));
        a.setIdRegistro(rs.getInt("id_registro"));
        if (rs.wasNull()) {
            a.setIdRegistro(null);
        }
        a.setDadosAntigos(rs.getString("dados_antigos"));
        a.setDadosNovos(rs.getString("dados_novos"));
        a.setIp(rs.getString("ip"));
        a.setUserAgent(rs.getString("user_agent"));
        a.setDataHora(rs.getTimestamp("data_hora"));
        return a;
    }
    
    @Override
    protected void setInsertParameters(PreparedStatement ps, Auditoria entity) throws SQLException {
        ps.setInt(1, entity.getIdUsuario());
        ps.setString(2, entity.getAcao());
        ps.setString(3, entity.getTabela());
        // CORRIGIDO: Verifica se idRegistro é null
        if (entity.getIdRegistro() != null) {
            ps.setInt(4, entity.getIdRegistro());
        } else {
            ps.setNull(4, Types.INTEGER);
        }
        ps.setString(5, entity.getDadosAntigos());
        ps.setString(6, entity.getDadosNovos());
        ps.setString(7, entity.getIp());
        ps.setString(8, entity.getUserAgent());
        ps.setTimestamp(9, entity.getDataHora() != null ? new Timestamp(entity.getDataHora().getTime()) : new Timestamp(System.currentTimeMillis()));
    }
    
    @Override
    protected void setUpdateParameters(PreparedStatement ps, Auditoria entity) throws SQLException {
        ps.setInt(1, entity.getIdUsuario());
        ps.setString(2, entity.getAcao());
        ps.setString(3, entity.getTabela());
        if (entity.getIdRegistro() != null) {
            ps.setInt(4, entity.getIdRegistro());
        } else {
            ps.setNull(4, Types.INTEGER);
        }
        ps.setString(5, entity.getDadosAntigos());
        ps.setString(6, entity.getDadosNovos());
        ps.setString(7, entity.getIp());
        ps.setString(8, entity.getUserAgent());
        ps.setTimestamp(9, entity.getDataHora() != null ? new Timestamp(entity.getDataHora().getTime()) : new Timestamp(System.currentTimeMillis()));
        ps.setInt(10, entity.getId());
    }
    
    @Override
    protected String getInsertColumns() {
        return "id_usuario, acao, tabela, id_registro, dados_antigos, dados_novos, ip, user_agent, data_hora";
    }
    
    @Override
    protected String getInsertPlaceholders() {
        return "?, ?, ?, ?, ?, ?, ?, ?, ?";
    }
    
    @Override
    protected String getUpdateColumns() {
        return "id_usuario = ?, acao = ?, tabela = ?, id_registro = ?, dados_antigos = ?, dados_novos = ?, ip = ?, user_agent = ?, data_hora = ?";
    }
    
    @Override
    protected int getUpdateParameterCount() {
        return 9;
    }
    
    @Override
    protected Integer getId(Auditoria entity) {
        return entity.getId();
    }
    
    @Override
    protected void setId(Auditoria entity, Integer id) {
        entity.setId(id);
    }
    
    // ============================================================
    // MÉTODOS ADICIONAIS
    // ============================================================
    
    public List<Auditoria> listarTodos() throws DatabaseException {
        return findAll();
    }
    
    public Auditoria buscarPorId(Integer id) throws DatabaseException {
        return findById(id);
    }
    
    public void salvar(Auditoria auditoria) throws DatabaseException {
        insert(auditoria);
    }
    
    public void excluir(Integer id) throws DatabaseException {
        delete(id);
    }
    
    public int contar() throws DatabaseException {
        return count();
    }
    
    // ============================================================
    // MÉTODOS ESPECÍFICOS
    // ============================================================
    
    public List<Auditoria> findByUsuario(Integer idUsuario) throws DatabaseException {
        List<Auditoria> list = new ArrayList<>();
        String sql = "SELECT * FROM " + getTableName() + " WHERE id_usuario = ? ORDER BY data_hora DESC";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setInt(1, idUsuario);
            
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(mapResultSetToEntity(rs));
                }
            }
            return list;
            
        } catch (SQLException e) {
            logger.error("Erro ao buscar auditoria por usuário ID: {}", idUsuario, e);
            throw new DatabaseException("Erro ao buscar auditoria: " + e.getMessage(), e);
        }
    }
    
    public List<Auditoria> findByTabela(String tabela) throws DatabaseException {
        List<Auditoria> list = new ArrayList<>();
        String sql = "SELECT * FROM " + getTableName() + " WHERE tabela = ? ORDER BY data_hora DESC";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setString(1, tabela);
            
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(mapResultSetToEntity(rs));
                }
            }
            return list;
            
        } catch (SQLException e) {
            logger.error("Erro ao buscar auditoria por tabela: {}", tabela, e);
            throw new DatabaseException("Erro ao buscar auditoria: " + e.getMessage(), e);
        }
    }
    
    public List<Auditoria> findByAcao(String acao) throws DatabaseException {
        List<Auditoria> list = new ArrayList<>();
        String sql = "SELECT * FROM " + getTableName() + " WHERE acao = ? ORDER BY data_hora DESC";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setString(1, acao);
            
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(mapResultSetToEntity(rs));
                }
            }
            return list;
            
        } catch (SQLException e) {
            logger.error("Erro ao buscar auditoria por ação: {}", acao, e);
            throw new DatabaseException("Erro ao buscar auditoria: " + e.getMessage(), e);
        }
    }
    
    public List<Auditoria> findAllWithUser() throws DatabaseException {
        List<Auditoria> list = new ArrayList<>();
        String sql = "SELECT a.*, u.nome as usuario_nome, u.usuario as usuario_login " +
                     "FROM " + getTableName() + " a " +
                     "LEFT JOIN usuario u ON a.id_usuario = u.id " +
                     "ORDER BY a.data_hora DESC LIMIT 100";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            
            while (rs.next()) {
                Auditoria a = mapResultSetToEntity(rs);
                
                String nomeUsuario = rs.getString("usuario_nome");
                String loginUsuario = rs.getString("usuario_login");
                
                if (nomeUsuario != null || loginUsuario != null) {
                    Usuario u = new Usuario();
                    u.setId(rs.getInt("id_usuario"));
                    u.setNome(nomeUsuario != null ? nomeUsuario : "Usuário");
                    u.setUsuario(loginUsuario != null ? loginUsuario : "sistema");
                    a.setUsuario(u);
                }
                
                list.add(a);
            }
            return list;
            
        } catch (SQLException e) {
            logger.error("Erro ao buscar auditorias com usuário", e);
            throw new DatabaseException("Erro ao buscar auditorias: " + e.getMessage(), e);
        }
    }
}
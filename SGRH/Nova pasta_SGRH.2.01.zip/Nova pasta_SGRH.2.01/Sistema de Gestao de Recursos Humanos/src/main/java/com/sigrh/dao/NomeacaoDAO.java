package com.sigrh.dao;

import com.sigrh.model.Nomeacao;
import com.sigrh.exception.DatabaseException;
import com.sigrh.util.DatabaseUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class NomeacaoDAO extends GenericDAO<Nomeacao> {
    
    // ============================================================
    // MÉTODOS ABSTRATOS OBRIGATÓRIOS
    // ============================================================
    
    @Override
    protected String getTableName() {
        return "nomeacao";
    }
    
    @Override
    protected Nomeacao mapResultSetToEntity(ResultSet rs) throws SQLException {
        Nomeacao n = new Nomeacao();
        n.setId(rs.getInt("id"));
        n.setIdFuncionario(rs.getInt("id_funcionario"));
        n.setFuncao(rs.getString("funcao"));
        n.setFuncoes(rs.getString("funcoes"));
        n.setCargo(rs.getString("cargo"));
        n.setDespacho(rs.getString("despacho"));
        n.setLocal(rs.getString("local"));
        n.setDataNomeacao(rs.getDate("data_nomeacao"));
        n.setDataInicio(rs.getDate("data_inicio"));
        n.setDataFim(rs.getDate("data_fim"));
        n.setStatus(rs.getString("status"));
        n.setObservacao(rs.getString("observacao"));
        n.setDataCadastro(rs.getTimestamp("data_cadastro"));
        return n;
    }
    
    @Override
    protected void setInsertParameters(PreparedStatement ps, Nomeacao entity) throws SQLException {
        ps.setInt(1, entity.getIdFuncionario());
        ps.setString(2, entity.getFuncao());
        ps.setString(3, entity.getFuncoes());
        ps.setString(4, entity.getCargo());
        ps.setString(5, entity.getDespacho());
        ps.setString(6, entity.getLocal());
        ps.setDate(7, new java.sql.Date(entity.getDataNomeacao().getTime()));
        ps.setDate(8, new java.sql.Date(entity.getDataInicio().getTime()));
        ps.setDate(9, entity.getDataFim() != null ? new java.sql.Date(entity.getDataFim().getTime()) : null);
        ps.setString(10, entity.getStatus());
        ps.setString(11, entity.getObservacao());
    }
    
    @Override
    protected void setUpdateParameters(PreparedStatement ps, Nomeacao entity) throws SQLException {
        ps.setInt(1, entity.getIdFuncionario());
        ps.setString(2, entity.getFuncao());
        ps.setString(3, entity.getFuncoes());
        ps.setString(4, entity.getCargo());
        ps.setString(5, entity.getDespacho());
        ps.setString(6, entity.getLocal());
        ps.setDate(7, new java.sql.Date(entity.getDataNomeacao().getTime()));
        ps.setDate(8, new java.sql.Date(entity.getDataInicio().getTime()));
        ps.setDate(9, entity.getDataFim() != null ? new java.sql.Date(entity.getDataFim().getTime()) : null);
        ps.setString(10, entity.getStatus());
        ps.setString(11, entity.getObservacao());
        ps.setInt(12, entity.getId());
    }
    
    @Override
    protected String getInsertColumns() {
        return "id_funcionario, funcao, funcoes, cargo, despacho, local, " +
               "data_nomeacao, data_inicio, data_fim, status, observacao";
    }
    
    @Override
    protected String getInsertPlaceholders() {
        return "?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?";
    }
    
    @Override
    protected String getUpdateColumns() {
        return "id_funcionario = ?, funcao = ?, funcoes = ?, cargo = ?, despacho = ?, " +
               "local = ?, data_nomeacao = ?, data_inicio = ?, data_fim = ?, status = ?, observacao = ?";
    }
    
    @Override
    protected int getUpdateParameterCount() {
        return 11;
    }
    
    @Override
    protected Integer getId(Nomeacao entity) {
        return entity.getId();
    }
    
    @Override
    protected void setId(Nomeacao entity, Integer id) {
        entity.setId(id);
    }
    
    // ============================================================
    // MÉTODOS ADICIONAIS (ALIAS PARA COMPATIBILIDADE)
    // ============================================================
    
    public List<Nomeacao> listarTodos() throws DatabaseException {
        return findAll();
    }
    
    public Nomeacao buscarPorId(Integer id) throws DatabaseException {
        return findById(id);
    }
    
    public void salvar(Nomeacao nomeacao) throws DatabaseException {
        insert(nomeacao);
    }
    
    public void atualizar(Nomeacao nomeacao) throws DatabaseException {
        update(nomeacao);
    }
    
    public void excluir(Integer id) throws DatabaseException {
        delete(id);
    }
    
    public int contar() throws DatabaseException {
        return count();
    }
    
    public int contarAtivas() throws DatabaseException {
        return countAtivas();
    }
    
    public List<Nomeacao> listarAtivas() throws DatabaseException {
        return findAtivas();
    }
    
    // ============================================================
    // MÉTODOS ESPECÍFICOS
    // ============================================================
    
    public List<Nomeacao> findAtivas() throws DatabaseException {
        List<Nomeacao> list = new ArrayList<>();
        String sql = "SELECT * FROM " + getTableName() + " WHERE status = 'ATIVA' ORDER BY data_cadastro DESC";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            
            while (rs.next()) {
                list.add(mapResultSetToEntity(rs));
            }
            
            logger.debug("Buscadas {} nomeações ativas", list.size());
            return list;
            
        } catch (SQLException e) {
            logger.error("Erro ao buscar nomeações ativas", e);
            throw new DatabaseException("Erro ao buscar nomeações ativas: " + e.getMessage(), e);
        }
    }
    
    public List<Nomeacao> findByFuncionario(Integer idFuncionario) throws DatabaseException {
        List<Nomeacao> list = new ArrayList<>();
        String sql = "SELECT * FROM " + getTableName() + " WHERE id_funcionario = ? ORDER BY data_cadastro DESC";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setInt(1, idFuncionario);
            
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(mapResultSetToEntity(rs));
                }
            }
            
            logger.debug("Buscadas {} nomeações para o funcionário ID {}", list.size(), idFuncionario);
            return list;
            
        } catch (SQLException e) {
            logger.error("Erro ao buscar nomeações por funcionário", e);
            throw new DatabaseException("Erro ao buscar nomeações por funcionário: " + e.getMessage(), e);
        }
    }
    
    public void encerrar(Integer id) throws DatabaseException {
        String sql = "UPDATE " + getTableName() + " SET status = 'ENCERRADA', data_fim = NOW() WHERE id = ?";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setInt(1, id);
            ps.executeUpdate();
            
            logger.debug("Nomeação ID {} encerrada", id);
            
        } catch (SQLException e) {
            logger.error("Erro ao encerrar nomeação ID {}", id, e);
            throw new DatabaseException("Erro ao encerrar nomeação: " + e.getMessage(), e);
        }
    }
    
    public int countAtivas() throws DatabaseException {
        String sql = "SELECT COUNT(*) as total FROM " + getTableName() + " WHERE status = 'ATIVA'";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            
            if (rs.next()) {
                return rs.getInt("total");
            }
            return 0;
            
        } catch (SQLException e) {
            logger.error("Erro ao contar nomeações ativas", e);
            throw new DatabaseException("Erro ao contar nomeações ativas: " + e.getMessage(), e);
        }
    }
}
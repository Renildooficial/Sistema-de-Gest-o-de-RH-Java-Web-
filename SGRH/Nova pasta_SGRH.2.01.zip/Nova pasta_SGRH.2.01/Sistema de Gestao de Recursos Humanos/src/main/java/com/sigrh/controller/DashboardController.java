package com.sigrh.controller;

import com.sigrh.model.Ferias;
import com.sigrh.model.FolhaPagamento;
import com.sigrh.model.Formacao;
import com.sigrh.model.Funcionario;
import com.sigrh.model.Nomeacao;
import com.sigrh.model.PlanoFerias;
import com.sigrh.service.PlanoFeriasService;

import com.sigrh.model.Usuario;
import java.math.RoundingMode;
import com.sigrh.service.*;
import com.sigrh.util.Constants;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.*;

@WebServlet("/dashboard")
public class DashboardController extends HttpServlet {
    
    private static final long serialVersionUID = 1L;
    
    private final FuncionarioService funcionarioService;
    private final RelatorioService relatorioService;
    private final SetorService setorService;
    private final FeriasService feriasService;
    private final NotificacaoService notificacaoService;
    private final FormacaoService formacaoService;
    private final NomeacaoService nomeacaoService;
    private final PlanoFeriasService planoFeriasService;
    private final FolhaPagamentoService folhaPagamentoService; // NOVO
    
    public DashboardController() {
        this.funcionarioService = new FuncionarioService();
        this.relatorioService = new RelatorioService();
        this.setorService = new SetorService();
        this.feriasService = new FeriasService();
        this.notificacaoService = new NotificacaoService();
        this.formacaoService = new FormacaoService();   // NOVO
        this.nomeacaoService = new NomeacaoService();   // NOVO
        this.planoFeriasService = new PlanoFeriasService();
        this.folhaPagamentoService = new FolhaPagamentoService(); // NOVO
    }
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        try {
            Usuario usuario = (Usuario) request.getSession().getAttribute(Constants.SESSION_USER);
            
            if (usuario == null) {
                response.sendRedirect(request.getContextPath() + "/login");
                return;
            }
            
            request.getSession().removeAttribute(Constants.MSG_ERRO);
            request.getSession().removeAttribute(Constants.MSG_SUCESSO);
            request.getSession().removeAttribute(Constants.MSG_INFO);
            
            request.setAttribute("usuario", usuario);
            
            // ========== CARREGAR DADOS REAIS ==========
            carregarDadosReais(request, usuario);
            
            // ========== CARREGAR DADOS POR PERFIL ==========
            carregarDadosPorPerfil(request, usuario);
            
            // ========== REDIRECIONAR PARA VIEW ==========
            String viewPath = getViewPathPorPerfil(usuario);
            request.getRequestDispatcher(viewPath).forward(request, response);
            
        } catch (Exception e) {
            e.printStackTrace();
            request.getSession().setAttribute(Constants.MSG_ERRO, "Erro ao carregar dashboard: " + e.getMessage());
            response.sendRedirect(request.getContextPath() + "/login");
        }
    }
    
    private void carregarDadosReais(HttpServletRequest request, Usuario usuario) {
        try {
            // 1. Estatísticas de funcionários
            var stats = funcionarioService.getEstatisticas();
            request.setAttribute("totalFuncionarios", stats.total);
            request.setAttribute("ativos", stats.ativos);
            request.setAttribute("inativos", stats.inativos);
            request.setAttribute("ferias", stats.ferias);
            request.setAttribute("licenca", stats.licenca);
            request.setAttribute("afastados", stats.afastados);
            
            // 2. Total de setores
            int totalSetores = setorService.listarTodos().size();
            request.setAttribute("totalSetores", totalSetores);
            
            // 3. Funcionários por setor (gráfico)
            Map<String, Integer> funcionariosPorSetor = relatorioService.relatorioFuncionariosPorSetor();
            request.setAttribute("funcionariosPorSetor", funcionariosPorSetor);
            
            // 4. Status dos funcionários (gráfico)
            Map<String, Integer> statusFuncionarios = relatorioService.relatorioStatusFuncionarios();
            request.setAttribute("statusFuncionarios", statusFuncionarios);
            
            // 5. Últimos funcionários cadastrados
            var ultimos = funcionarioService.listarTodos();
            if (ultimos != null && ultimos.size() > 5) {
                ultimos = ultimos.subList(0, 5);
            }
            request.setAttribute("ultimosFuncionarios", ultimos != null ? ultimos : new ArrayList<>());
            
            // 6. Notificações não lidas
            int notificacoesNaoLidas = notificacaoService.contarNaoLidas(usuario.getId());
            request.setAttribute("notificacoesNaoLidas", notificacoesNaoLidas);
            
            // ============================================================
            // 7. CORRIGIDO: Buscar solicitações de férias com funcionário
            // ============================================================
            try {
                List<Ferias> solicitacoes = new ArrayList<>();
                
                // Busca solicitações pendentes
                List<Ferias> pendentes = feriasService.buscarPendentes();
                
                if (pendentes != null && !pendentes.isEmpty()) {
                    solicitacoes = pendentes;
                } else {
                    // Se não houver pendentes, busca as últimas 5 solicitações
                    solicitacoes = feriasService.buscarTodas();
                }
                
                // ============================================================
                // CARREGAR FUNCIONÁRIO PARA CADA SOLICITAÇÃO
                // ============================================================
                if (solicitacoes != null && !solicitacoes.isEmpty()) {
                    // Limita a 5
                    if (solicitacoes.size() > 5) {
                        solicitacoes = solicitacoes.subList(0, 5);
                    }
                    
                    for (Ferias f : solicitacoes) {
                        if (f.getIdFuncionario() != null) {
                            try {
                                Funcionario func = funcionarioService.buscarPorId(f.getIdFuncionario());
                                f.setFuncionario(func);
                            } catch (Exception e) {
                                System.out.println("⚠️ Erro ao carregar funcionário da solicitação " + f.getId() + ": " + e.getMessage());
                            }
                        }
                    }
                }
                
                request.setAttribute("ultimasSolicitacoes", solicitacoes != null ? solicitacoes : new ArrayList<>());
                
            } catch (Exception e) {
                System.out.println("⚠️ Erro ao buscar solicitações de férias: " + e.getMessage());
                request.setAttribute("ultimasSolicitacoes", new ArrayList<>());
            }
            
        } catch (Exception e) {
            e.printStackTrace();
            usarDadosExemplo(request);
        }
    }
    
    private void usarDadosExemplo(HttpServletRequest request) {
        request.setAttribute("totalFuncionarios", 0);
        request.setAttribute("ativos", 0);
        request.setAttribute("inativos", 0);
        request.setAttribute("ferias", 0);
        request.setAttribute("licenca", 0);
        request.setAttribute("afastados", 0);
        request.setAttribute("totalSetores", 0);
        request.setAttribute("notificacoesNaoLidas", 0);
        
        Map<String, Integer> setores = new LinkedHashMap<>();
        setores.put("Direção Geral", 0);
        setores.put("Recursos Humanos", 0);
        setores.put("Financeiro", 0);
        setores.put("Tecnologia", 0);
        request.setAttribute("funcionariosPorSetor", setores);
        
        Map<String, Integer> status = new LinkedHashMap<>();
        status.put("Ativos", 0);
        status.put("Em Férias", 0);
        status.put("Inativos", 0);
        status.put("Licença", 0);
        status.put("Afastados", 0);
        request.setAttribute("statusFuncionarios", status);
        
        request.setAttribute("ultimosFuncionarios", new ArrayList<>());
    }
    
    private void carregarDadosPorPerfil(HttpServletRequest request, Usuario usuario) {
        try {
            switch (usuario.getPerfil()) {
                case ADMIN:
                    break;
                    
                case RH:
                    try {
                        int pendentes = feriasService.buscarPendentes().size();
                        request.setAttribute("feriasPendentes", pendentes);
                    } catch (Exception e) {
                        request.setAttribute("feriasPendentes", 0);
                    }
                    
                    // ===== CORRIGIDO: CARREGAR TOTAL DE FORMAÇÕES =====
                    try {
                        int totalFormacoes = formacaoService.contarTodas(); // ou listarTodas().size()
                        request.setAttribute("totalFormacoes", totalFormacoes);
                    } catch (Exception e) {
                        request.setAttribute("totalFormacoes", 0);
                    }
                    break;
                    
                case FINANCEIRO:
                    int mes = Calendar.getInstance().get(Calendar.MONTH) + 1;
                    int ano = Calendar.getInstance().get(Calendar.YEAR);
                    
                    System.out.println("📊 Carregando dados financeiros para: " + mes + "/" + ano);
                    
                    try {
                        // Buscar resumo da folha do mês atual
                        FolhaPagamentoService.ResumoFolha resumo = folhaPagamentoService.obterResumo(mes, ano);
                        if (resumo != null) {
                            System.out.println("📊 Resumo encontrado: Total Líquido = " + resumo.getTotalLiquido());
                            request.setAttribute("totalFolha", resumo.getTotalLiquido());
                        } else {
                            System.out.println("⚠️ Resumo é null");
                            request.setAttribute("totalFolha", BigDecimal.ZERO);
                        }
                    } catch (Exception e) {
                        System.err.println("❌ Erro ao buscar resumo financeiro: " + e.getMessage());
                        e.printStackTrace();
                        request.setAttribute("totalFolha", BigDecimal.ZERO);
                    }
                    
                 
                    
                    // Folhas processadas
                    int processados = 0;
                    try {
                        processados = folhaPagamentoService.contarProcessadas(mes, ano);
                    } catch (Exception e) {
                        processados = 0;
                    }
                    request.setAttribute("processados", processados);
                    
                    // Média salarial
                    BigDecimal mediaSalarial = BigDecimal.ZERO;
                    try {
                        BigDecimal totalFolha = (BigDecimal) request.getAttribute("totalFolha");
                        Integer totalFuncionarios = (Integer) request.getAttribute("totalFuncionarios");
                        if (totalFolha != null && totalFuncionarios != null && totalFuncionarios > 0) {
                            mediaSalarial = totalFolha.divide(new BigDecimal(totalFuncionarios), 2, RoundingMode.HALF_UP);
                        }
                    } catch (Exception e) {
                        mediaSalarial = BigDecimal.ZERO;
                    }
                    request.setAttribute("mediaSalarial", mediaSalarial);
                    
                    // Últimas folhas
                    try {
                        List<FolhaPagamento> ultimasFolhas = folhaPagamentoService.listarUltimas(5);
                        if (ultimasFolhas == null) {
                            ultimasFolhas = new ArrayList<>();
                        }
                        request.setAttribute("ultimasFolhas", ultimasFolhas);
                    } catch (Exception e) {
                        System.err.println("Erro ao carregar últimas folhas: " + e.getMessage());
                        request.setAttribute("ultimasFolhas", new ArrayList<>());
                    }
                    
                    // Dados para gráficos
                    try {
                        Map<String, BigDecimal> custoPorSetor = folhaPagamentoService.getCustoPorSetor(mes, ano);
                        if (custoPorSetor == null) {
                            custoPorSetor = new LinkedHashMap<>();
                        }
                        request.setAttribute("custoPorSetor", custoPorSetor);
                    } catch (Exception e) {
                        System.err.println("Erro ao carregar custo por setor: " + e.getMessage());
                        request.setAttribute("custoPorSetor", new LinkedHashMap<>());
                    }
                    
                    try {
                        Map<String, BigDecimal> evolucao = folhaPagamentoService.getEvolucaoMensal(6);
                        if (evolucao == null) {
                            evolucao = new LinkedHashMap<>();
                        }
                        request.setAttribute("evolucaoFolha", evolucao);
                    } catch (Exception e) {
                        System.err.println("Erro ao carregar evolução mensal: " + e.getMessage());
                        request.setAttribute("evolucaoFolha", new LinkedHashMap<>());
                    }
                    break;
                    
                   
                    
                case GESTOR:
                    // ===== DADOS REAIS PARA O GESTOR =====
                    // As variáveis de estatísticas gerais (totalFuncionarios, ativos, inativos, etc.)
                    // já foram carregadas no carregarDadosReais()
                    
                    // 1. Férias pendentes
                    try {
                        int pendentes = feriasService.buscarPendentes().size();
                        request.setAttribute("feriasPendentes", pendentes);
                    } catch (Exception e) {
                        request.setAttribute("feriasPendentes", 0);
                    }
                    
                    // 2. Férias aprovadas
                    try {
                        List<Ferias> aprovadas = feriasService.buscarPorStatus("APROVADA");
                        request.setAttribute("aprovadas", aprovadas != null ? aprovadas.size() : 0);
                    } catch (Exception e) {
                        request.setAttribute("aprovadas", 0);
                    }
                    
                    // 3. Plano de férias
                    try {
                        int anoAtual = Calendar.getInstance().get(Calendar.YEAR);
                        int planos = planoFeriasService.buscarPorAno(anoAtual).size();
                        request.setAttribute("planoFerias", planos);
                    } catch (Exception e) {
                        request.setAttribute("planoFerias", 0);
                    }
                    
                    // 4. Solicitações pendentes (para a tabela)
                    try {
                        List<Ferias> solicitacoes = feriasService.buscarPendentes();
                        // Carregar funcionário para cada solicitação
                        for (Ferias f : solicitacoes) {
                            if (f.getIdFuncionario() != null) {
                                try {
                                    Funcionario func = funcionarioService.buscarPorId(f.getIdFuncionario());
                                    f.setFuncionario(func);
                                } catch (Exception e) {
                                    // Ignorar
                                }
                            }
                        }
                        request.setAttribute("solicitacoes", solicitacoes != null ? solicitacoes : new ArrayList<>());
                    } catch (Exception e) {
                        request.setAttribute("solicitacoes", new ArrayList<>());
                    }
                    break;
                    
                case FUNCIONARIO:
                    if (usuario.getIdFuncionario() != null) {
                        try {
                            int saldo = feriasService.calcularSaldoFerias(usuario.getIdFuncionario());
                            request.setAttribute("saldoFerias", saldo);
                        } catch (Exception e) {
                            request.setAttribute("saldoFerias", 0);
                        }
                        
                        try {
                            var minhasFerias = feriasService.buscarPorFuncionario(usuario.getIdFuncionario());
                            request.setAttribute("minhasFerias", minhasFerias != null ? minhasFerias : new ArrayList<>());
                        } catch (Exception e) {
                            request.setAttribute("minhasFerias", new ArrayList<>());
                        }

                        // ===== NOVO: CARREGAR FORMAÇÕES E NOMEAÇÕES =====
                        try {
                            List<Formacao> formacoes = formacaoService.buscarPorFuncionario(usuario.getIdFuncionario());
                            request.setAttribute("formacoes", formacoes != null ? formacoes : new ArrayList<>());
                            request.setAttribute("totalFormacoes", formacoes != null ? formacoes.size() : 0);
                            
                            List<Nomeacao> nomeacoes = nomeacaoService.buscarPorFuncionario(usuario.getIdFuncionario());
                            request.setAttribute("nomeacoes", nomeacoes != null ? nomeacoes : new ArrayList<>());
                            request.setAttribute("totalNomeacoes", nomeacoes != null ? nomeacoes.size() : 0);
                            
                        } catch (Exception e) {
                            e.printStackTrace();
                            request.setAttribute("formacoes", new ArrayList<>());
                            request.setAttribute("totalFormacoes", 0);
                            request.setAttribute("nomeacoes", new ArrayList<>());
                            request.setAttribute("totalNomeacoes", 0);
                        }
                    } else {
                        request.setAttribute("saldoFerias", 0);
                        request.setAttribute("minhasFerias", new ArrayList<>());
                        request.setAttribute("formacoes", new ArrayList<>());
                        request.setAttribute("totalFormacoes", 0);
                        request.setAttribute("nomeacoes", new ArrayList<>());
                        request.setAttribute("totalNomeacoes", 0);
                    }
                    break;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    private String getViewPathPorPerfil(Usuario usuario) {
        return switch (usuario.getPerfil()) {
            case ADMIN -> "/WEB-INF/views/admin/dashboard.jsp";
            case RH -> "/WEB-INF/views/rh/dashboard.jsp";
            case FINANCEIRO -> "/WEB-INF/views/financeiro/dashboard.jsp";
            case GESTOR -> "/WEB-INF/views/gestor/dashboard.jsp";
            case FUNCIONARIO -> "/WEB-INF/views/funcionario/dashboard.jsp";
        };
    }
}
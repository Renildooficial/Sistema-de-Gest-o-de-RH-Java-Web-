package com.sigrh.dao;

import com.sigrh.exception.DatabaseException;
import com.sigrh.model.FolhaPagamento;
import com.sigrh.util.DatabaseUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class FolhaPagamentoDAO extends GenericDAO<FolhaPagamento> {
    
    @Override
    protected String getTableName() {
        return "folha_pagamento";
    }
    
    @Override
    protected FolhaPagamento mapResultSetToEntity(ResultSet rs) throws SQLException {
        FolhaPagamento folha = new FolhaPagamento();
        folha.setId(rs.getInt("id"));
        folha.setIdFuncionario(rs.getInt("id_funcionario"));
        folha.setMesReferencia(rs.getInt("mes_referencia"));
        folha.setAnoReferencia(rs.getInt("ano_referencia"));
        folha.setSalarioBase(rs.getBigDecimal("salario_base"));
        folha.setSubsidioAlimentacao(rs.getBigDecimal("subsidio_alimentacao"));
        folha.setSubsidioTransporte(rs.getBigDecimal("subsidio_transporte"));
        folha.setSubsidioSaude(rs.getBigDecimal("subsidio_saude"));
        folha.setBonus(rs.getBigDecimal("bonus"));
        folha.setOutrosGanhos(rs.getBigDecimal("outros_ganhos"));
        folha.setDescontoIrs(rs.getBigDecimal("desconto_irs"));
        folha.setDescontoInss(rs.getBigDecimal("desconto_inss"));
        folha.setDescontoSaude(rs.getBigDecimal("desconto_saude"));
        folha.setDescontoOutros(rs.getBigDecimal("desconto_outros"));
        folha.setTotalBruto(rs.getBigDecimal("total_bruto"));
        folha.setTotalDescontos(rs.getBigDecimal("total_descontos"));
        folha.setTotalLiquido(rs.getBigDecimal("total_liquido"));
        folha.setStatus(rs.getString("status"));
        folha.setDataProcessamento(rs.getTimestamp("data_processamento"));
        folha.setDataPagamento(rs.getTimestamp("data_pagamento"));
        folha.setObservacao(rs.getString("observacao"));
        folha.setDataCadastro(rs.getTimestamp("data_cadastro"));
        return folha;
    }
    
    @Override
    protected void setInsertParameters(PreparedStatement ps, FolhaPagamento entity) throws SQLException {
        ps.setInt(1, entity.getIdFuncionario());
        ps.setInt(2, entity.getMesReferencia());
        ps.setInt(3, entity.getAnoReferencia());
        ps.setBigDecimal(4, entity.getSalarioBase());
        ps.setBigDecimal(5, entity.getSubsidioAlimentacao());
        ps.setBigDecimal(6, entity.getSubsidioTransporte());
        ps.setBigDecimal(7, entity.getSubsidioSaude());
        ps.setBigDecimal(8, entity.getBonus());
        ps.setBigDecimal(9, entity.getOutrosGanhos());
        ps.setBigDecimal(10, entity.getDescontoIrs());
        ps.setBigDecimal(11, entity.getDescontoInss());
        ps.setBigDecimal(12, entity.getDescontoSaude());
        ps.setBigDecimal(13, entity.getDescontoOutros());
        ps.setString(14, entity.getStatus().name());
        ps.setTimestamp(15, entity.getDataProcessamento());
        ps.setTimestamp(16, entity.getDataPagamento());
        ps.setString(17, entity.getObservacao());
    }
    
    @Override
    protected void setUpdateParameters(PreparedStatement ps, FolhaPagamento entity) throws SQLException {
        ps.setInt(1, entity.getIdFuncionario());
        ps.setInt(2, entity.getMesReferencia());
        ps.setInt(3, entity.getAnoReferencia());
        ps.setBigDecimal(4, entity.getSalarioBase());
        ps.setBigDecimal(5, entity.getSubsidioAlimentacao());
        ps.setBigDecimal(6, entity.getSubsidioTransporte());
        ps.setBigDecimal(7, entity.getSubsidioSaude());
        ps.setBigDecimal(8, entity.getBonus());
        ps.setBigDecimal(9, entity.getOutrosGanhos());
        ps.setBigDecimal(10, entity.getDescontoIrs());
        ps.setBigDecimal(11, entity.getDescontoInss());
        ps.setBigDecimal(12, entity.getDescontoSaude());
        ps.setBigDecimal(13, entity.getDescontoOutros());
        ps.setString(14, entity.getStatus().name());
        ps.setTimestamp(15, entity.getDataProcessamento());
        ps.setTimestamp(16, entity.getDataPagamento());
        ps.setString(17, entity.getObservacao());
    }
    
    @Override
    protected String getInsertColumns() {
        return "id_funcionario, mes_referencia, ano_referencia, salario_base, subsidio_alimentacao, " +
               "subsidio_transporte, subsidio_saude, bonus, outros_ganhos, desconto_irs, desconto_inss, " +
               "desconto_saude, desconto_outros, status, data_processamento, data_pagamento, observacao";
    }
    
    @Override
    protected String getInsertPlaceholders() {
        return "?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?";
    }
    
    @Override
    protected String getUpdateColumns() {
        return "id_funcionario = ?, mes_referencia = ?, ano_referencia = ?, salario_base = ?, " +
               "subsidio_alimentacao = ?, subsidio_transporte = ?, subsidio_saude = ?, bonus = ?, " +
               "outros_ganhos = ?, desconto_irs = ?, desconto_inss = ?, desconto_saude = ?, " +
               "desconto_outros = ?, status = ?, data_processamento = ?, data_pagamento = ?, observacao = ?";
    }
    
    @Override
    protected int getUpdateParameterCount() {
        return 17;
    }
    
    @Override
    protected Integer getId(FolhaPagamento entity) {
        return entity.getId();
    }
    
    @Override
    protected void setId(FolhaPagamento entity, Integer id) {
        entity.setId(id);
    }
    
    /**
     * Busca folhas de pagamento de um funcionário
     */
    public List<FolhaPagamento> findByFuncionario(Integer idFuncionario) throws DatabaseException {
        List<FolhaPagamento> list = new ArrayList<>();
        String sql = "SELECT * FROM " + getTableName() + 
                    " WHERE id_funcionario = ? ORDER BY ano_referencia DESC, mes_referencia DESC";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setInt(1, idFuncionario);
            
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(mapResultSetToEntity(rs));
                }
            }
            return list;
            
        } catch (SQLException e) {
            logger.error("Erro ao buscar folhas do funcionário ID {}", idFuncionario, e);
            throw new DatabaseException("Erro ao buscar folhas: " + e.getMessage(), e);
        }
    }
    
    /**
     * Busca folha de pagamento por mês e ano
     */
    public List<FolhaPagamento> findByMesAno(Integer mes, Integer ano) throws DatabaseException {
        List<FolhaPagamento> list = new ArrayList<>();
        String sql = "SELECT * FROM " + getTableName() + 
                    " WHERE mes_referencia = ? AND ano_referencia = ? ORDER BY id_funcionario";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setInt(1, mes);
            ps.setInt(2, ano);
            
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(mapResultSetToEntity(rs));
                }
            }
            return list;
            
        } catch (SQLException e) {
            logger.error("Erro ao buscar folhas por mês {} e ano {}", mes, ano, e);
            throw new DatabaseException("Erro ao buscar folhas: " + e.getMessage(), e);
        }
    }
    
    /**
     * Busca folha de pagamento de um funcionário em um mês/ano específico
     */
    public FolhaPagamento findByFuncionarioMesAno(Integer idFuncionario, Integer mes, Integer ano) 
            throws DatabaseException {
        String sql = "SELECT * FROM " + getTableName() + 
                    " WHERE id_funcionario = ? AND mes_referencia = ? AND ano_referencia = ?";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setInt(1, idFuncionario);
            ps.setInt(2, mes);
            ps.setInt(3, ano);
            
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToEntity(rs);
                }
            }
            return null;
            
        } catch (SQLException e) {
            logger.error("Erro ao buscar folha do funcionário ID {} mês {} ano {}", idFuncionario, mes, ano, e);
            throw new DatabaseException("Erro ao buscar folha: " + e.getMessage(), e);
        }
    }
    
    /**
     * Processa uma folha de pagamento (calcula totais e atualiza status)
     */
    public void processar(Integer id) throws DatabaseException {
        // Primeiro calcula os totais
        String sqlCalc = "UPDATE " + getTableName() + 
                        " SET total_bruto = salario_base + subsidio_alimentacao + subsidio_transporte + " +
                        "subsidio_saude + bonus + outros_ganhos, " +
                        "total_descontos = desconto_irs + desconto_inss + desconto_saude + desconto_outros, " +
                        "total_liquido = (salario_base + subsidio_alimentacao + subsidio_transporte + " +
                        "subsidio_saude + bonus + outros_ganhos) - " +
                        "(desconto_irs + desconto_inss + desconto_saude + desconto_outros) " +
                        "WHERE id = ?";
        
        // Depois atualiza status
        String sqlStatus = "UPDATE " + getTableName() + 
                          " SET status = 'PROCESSADO', data_processamento = CURRENT_TIMESTAMP WHERE id = ?";
        
        try (Connection conn = DatabaseUtil.getConnection()) {
            conn.setAutoCommit(false);
            
            try (PreparedStatement psCalc = conn.prepareStatement(sqlCalc)) {
                psCalc.setInt(1, id);
                psCalc.executeUpdate();
            }
            
            try (PreparedStatement psStatus = conn.prepareStatement(sqlStatus)) {
                psStatus.setInt(1, id);
                psStatus.executeUpdate();
            }
            
            conn.commit();
            logger.debug("Folha ID {} processada com sucesso", id);
            
        } catch (SQLException e) {
            logger.error("Erro ao processar folha ID {}", id, e);
            throw new DatabaseException("Erro ao processar folha: " + e.getMessage(), e);
        }
    }
 // Em FolhaPagamentoDAO.java - este método já existe (herdado do GenericDAO)
 // Se não existir, adicione:
 public void salvar(FolhaPagamento folha) throws DatabaseException {
     insert(folha);
 }
//Em FolhaPagamentoDAO.java
public void atualizar(FolhaPagamento folha) throws DatabaseException {
  update(folha);
}
/**
 * Atualizar apenas o status da folha
 */
public void atualizarStatus(Integer id, FolhaPagamento.StatusFolha status) throws SQLException {
    String sql = "UPDATE folha_pagamento SET status = ?, data_pagamento = ? WHERE id = ?";
    
    try (Connection conn = DatabaseUtil.getConnection();
         PreparedStatement stmt = conn.prepareStatement(sql)) {
        
        stmt.setString(1, status.name());
        stmt.setTimestamp(2, new Timestamp(System.currentTimeMillis()));
        stmt.setInt(3, id);
        
        stmt.executeUpdate();
    }
}
}
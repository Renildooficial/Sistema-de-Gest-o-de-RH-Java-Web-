package com.sigrh.service;

import com.sigrh.exception.BusinessException;
import com.sigrh.model.AgregadoFamiliar;
import com.sigrh.model.Ferias;
import com.sigrh.model.Funcionario;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.ByteArrayOutputStream;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

public class ExportacaoService {
    
    private static final Logger logger = LogManager.getLogger(ExportacaoService.class);
    private final SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
    
    /**
     * Exporta lista de funcionários para Excel (CSV simplificado)
     */
    public byte[] exportarFuncionariosExcel(List<Funcionario> funcionarios) throws BusinessException {
        logger.info("Exportando funcionários - {} registros", funcionarios.size());
        
        try {
            StringBuilder sb = new StringBuilder();
            
            // Cabeçalho
            sb.append("ID,Nome,Setor,Telefone,E-mail,Status,Admissão\n");
            
            // Dados
            for (Funcionario f : funcionarios) {
                sb.append(f.getId()).append(",");
                sb.append(escapeCsv(f.getNome())).append(",");
                sb.append(escapeCsv(f.getSetor() != null ? f.getSetor().getNome() : "-")).append(",");
                sb.append(escapeCsv(f.getTelefone() != null ? f.getTelefone() : "-")).append(",");
                sb.append(escapeCsv(f.getEmailEmpresa() != null ? f.getEmailEmpresa() : "-")).append(",");
                // CORRIGIDO: status é String, não Enum
                sb.append(f.getStatus() != null ? f.getStatus() : "-").append(",");
                sb.append(f.getDataAdmissao() != null ? sdf.format(f.getDataAdmissao()) : "-");
                sb.append("\n");
            }
            
            return sb.toString().getBytes("UTF-8");
            
        } catch (Exception e) {
            logger.error("Erro ao exportar funcionários", e);
            throw new BusinessException("Erro ao exportar relatório", e);
        }
    }
    
    /**
     * Exporta relatório de férias para Excel (CSV simplificado)
     */
    public byte[] exportarFeriasExcel(List<Ferias> ferias) throws BusinessException {
        logger.info("Exportando férias - {} registros", ferias.size());
        
        try {
            StringBuilder sb = new StringBuilder();
            
            // Cabeçalho
            sb.append("ID,Funcionário,Início,Fim,Dias Úteis,Status,Solicitação\n");
            
            // Dados
            for (Ferias f : ferias) {
                sb.append(f.getId()).append(",");
                sb.append(escapeCsv(f.getFuncionario() != null ? f.getFuncionario().getNome() : "-")).append(",");
                sb.append(f.getDataInicio() != null ? sdf.format(f.getDataInicio()) : "-").append(",");
                sb.append(f.getDataFim() != null ? sdf.format(f.getDataFim()) : "-").append(",");
                sb.append(f.getDiasUteis() != null ? f.getDiasUteis() : 0).append(",");
                // CORRIGIDO: status é String, não Enum
                sb.append(f.getStatus() != null ? f.getStatus() : "-").append(",");
                sb.append(f.getDataSolicitacao() != null ? sdf.format(f.getDataSolicitacao()) : "-");
                sb.append("\n");
            }
            
            return sb.toString().getBytes("UTF-8");
            
        } catch (Exception e) {
            logger.error("Erro ao exportar férias", e);
            throw new BusinessException("Erro ao exportar relatório", e);
        }
    }
    
    /**
     * Exporta relatório financeiro para Excel (CSV simplificado)
     */
    public byte[] exportarFinanceiroExcel(Map<String, BigDecimal> dados, int ano) throws BusinessException {
        logger.info("Exportando relatório financeiro - Ano: {}", ano);
        
        try {
            StringBuilder sb = new StringBuilder();
            
            // Cabeçalho
            sb.append("Mês,Total Líquido\n");
            
            // Dados
            for (Map.Entry<String, BigDecimal> entry : dados.entrySet()) {
                sb.append(entry.getKey()).append(",");
                sb.append(entry.getValue() != null ? entry.getValue().toString() : "0.00");
                sb.append("\n");
            }
            
            return sb.toString().getBytes("UTF-8");
            
        } catch (Exception e) {
            logger.error("Erro ao exportar relatório financeiro", e);
            throw new BusinessException("Erro ao exportar relatório", e);
        }
    }
    
    /**
     * Exporta relatório de agregados para PDF (Texto simples)
     */
    public byte[] exportarAgregadosPDF(List<Map<String, Object>> dados) throws BusinessException {
        logger.info("Exportando agregados para PDF - {} registros", dados.size());
        
        try {
            StringBuilder sb = new StringBuilder();
            
            sb.append("========================================\n");
            sb.append("RELATÓRIO DE AGREGADOS FAMILIARES\n");
            sb.append("========================================\n\n");
            sb.append("Gerado em: ").append(new Date()).append("\n\n");
            
            sb.append("Funcionário          | Nome              | Parentesco | Nascimento  | Idade\n");
            sb.append("---------------------|-------------------|------------|-------------|-------\n");
            
            for (Map<String, Object> item : dados) {
                String funcionario = (String) item.get("funcionarioNome");
                List<AgregadoFamiliar> agregados = (List<AgregadoFamiliar>) item.get("agregados");
                
                for (AgregadoFamiliar a : agregados) {
                    sb.append(String.format("%-20s | %-17s | %-10s | %-11s | %d\n",
                        funcionario != null ? funcionario : "-",
                        a.getNome() != null ? a.getNome() : "-",
                        a.getGrauParentesco() != null ? a.getGrauParentesco().name() : "-",
                        a.getDataNascimento() != null ? sdf.format(a.getDataNascimento()) : "-",
                        a.getIdade()));
                }
            }
            
            sb.append("\n========================================\n");
            sb.append("FIM DO RELATÓRIO\n");
            sb.append("========================================\n");
            
            return sb.toString().getBytes("UTF-8");
            
        } catch (Exception e) {
            logger.error("Erro ao exportar agregados para PDF", e);
            throw new BusinessException("Erro ao exportar relatório", e);
        }
    }
    
    private String escapeCsv(String value) {
        if (value == null) return "";
        if (value.contains(",") || value.contains("\"") || value.contains("\n")) {
            return "\"" + value.replace("\"", "\"\"") + "\"";
        }
        return value;
    }
}
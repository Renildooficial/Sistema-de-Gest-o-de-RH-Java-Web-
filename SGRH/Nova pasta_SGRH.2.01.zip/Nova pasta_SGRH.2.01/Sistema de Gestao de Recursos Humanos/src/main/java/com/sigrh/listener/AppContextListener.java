package com.sigrh.listener;

import com.sigrh.util.DatabaseUtil;
import jakarta.servlet.ServletContextEvent;
import jakarta.servlet.ServletContextListener;
import jakarta.servlet.annotation.WebListener;

@WebListener
public class AppContextListener implements ServletContextListener {
    
    @Override
    public void contextInitialized(ServletContextEvent sce) {
        System.out.println("========================================");
        System.out.println("  🚀 SIGRH - Iniciando aplicação...");
        System.out.println("  Sistema Integrado de Gestão de RH");
        System.out.println("  Versão: 1.0.0");
        System.out.println("  Data/Hora: " + new java.util.Date());
        System.out.println("========================================");
        
        // Testar conexão com banco
        System.out.println("🔌 Testando conexão com banco de dados...");
        boolean connected = DatabaseUtil.testConnection();
        
        if (connected) {
            System.out.println("✅ Conexão com banco de dados estabelecida com sucesso!");
            System.out.println("   Database: sigrh");
            System.out.println("   User: root@localhost");
        } else {
            System.out.println("❌ ERRO: Não foi possível conectar ao banco de dados!");
            System.out.println("   Verifique se o MySQL está rodando e as credenciais estão corretas.");
        }
        
        System.out.println("========================================");
        if (connected) {
            System.out.println("  ✅ SIGRH iniciado com sucesso!");
        } else {
            System.out.println("  ⚠️ SIGRH iniciado com problemas de conexão!");
        }
        System.out.println("  📍 Acesse: http://localhost:8080/sigrh/login");
        System.out.println("========================================");
    }
    
    @Override
    public void contextDestroyed(ServletContextEvent sce) {
        System.out.println("SIGRH - Encerrando aplicação...");
        DatabaseUtil.closeDataSource();
        System.out.println("✅ SIGRH encerrado com sucesso!");
    }
}
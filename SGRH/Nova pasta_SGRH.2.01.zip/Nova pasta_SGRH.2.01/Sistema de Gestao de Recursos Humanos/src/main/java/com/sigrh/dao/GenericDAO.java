package com.sigrh.dao;

import com.sigrh.exception.DatabaseException;
import com.sigrh.util.DatabaseUtil;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Classe genérica para operações CRUD básicas
 * @param <T> Tipo da entidade
 */
public abstract class GenericDAO<T> {
    
    protected static final Logger logger = LogManager.getLogger(GenericDAO.class);
    
    /**
     * Obtém o nome da tabela
     */
    protected abstract String getTableName();
    
    /**
     * Mapeia um ResultSet para um objeto da entidade
     */
    protected abstract T mapResultSetToEntity(ResultSet rs) throws SQLException;
    
    /**
     * Prepara o PreparedStatement para INSERT
     */
    protected abstract void setInsertParameters(PreparedStatement ps, T entity) throws SQLException;
    
    /**
     * Prepara o PreparedStatement para UPDATE
     */
    protected abstract void setUpdateParameters(PreparedStatement ps, T entity) throws SQLException;
    
    /**
     * Busca todos os registros (SEM filtro de 'ativo')
     */
    public List<T> findAll() throws DatabaseException {
        List<T> list = new ArrayList<>();
        String sql = "SELECT * FROM " + getTableName() + " ORDER BY id";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            
            while (rs.next()) {
                list.add(mapResultSetToEntity(rs));
            }
            
            logger.debug("Buscados {} registros de {}", list.size(), getTableName());
            return list;
            
        } catch (SQLException e) {
            logger.error("Erro ao buscar todos os registros de {}", getTableName(), e);
            throw new DatabaseException("Erro ao buscar dados: " + e.getMessage(), e);
        }
    }
    
    /**
     * Busca registro por ID
     */
    public T findById(Integer id) throws DatabaseException {
        if (id == null) return null;
        
        String sql = "SELECT * FROM " + getTableName() + " WHERE id = ?";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setInt(1, id);
            
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToEntity(rs);
                }
            }
            
            logger.debug("Registro ID {} não encontrado em {}", id, getTableName());
            return null;
            
        } catch (SQLException e) {
            logger.error("Erro ao buscar registro ID {} em {}", id, getTableName(), e);
            throw new DatabaseException("Erro ao buscar registro: " + e.getMessage(), e);
        }
    }
    
    /**
     * Insere um novo registro
     */
    public T insert(T entity) throws DatabaseException {
        String sql = "INSERT INTO " + getTableName() + " (";
        sql += getInsertColumns() + ") VALUES (";
        sql += getInsertPlaceholders() + ")";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            
            setInsertParameters(ps, entity);
            
            int affectedRows = ps.executeUpdate();
            
            if (affectedRows == 0) {
                throw new DatabaseException("Falha ao inserir registro em " + getTableName());
            }
            
            try (ResultSet generatedKeys = ps.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    setId(entity, generatedKeys.getInt(1));
                }
            }
            
            logger.debug("Registro inserido em {} com ID {}", getTableName(), getId(entity));
            return entity;
            
        } catch (SQLException e) {
            logger.error("Erro ao inserir registro em {}", getTableName(), e);
            throw new DatabaseException("Erro ao inserir registro: " + e.getMessage(), e);
        }
    }
    
    /**
     * Atualiza um registro existente
     */
    public T update(T entity) throws DatabaseException {
        String sql = "UPDATE " + getTableName() + " SET ";
        sql += getUpdateColumns() + " WHERE id = ?";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            setUpdateParameters(ps, entity);
            ps.setInt(getUpdateParameterCount() + 1, getId(entity));
            
            int affectedRows = ps.executeUpdate();
            
            if (affectedRows == 0) {
                throw new DatabaseException("Falha ao atualizar registro em " + getTableName());
            }
            
            logger.debug("Registro ID {} atualizado em {}", getId(entity), getTableName());
            return entity;
            
        } catch (SQLException e) {
            logger.error("Erro ao atualizar registro ID {} em {}", getId(entity), getTableName(), e);
            throw new DatabaseException("Erro ao atualizar registro: " + e.getMessage(), e);
        }
    }
    
    /**
     * Exclui logicamente um registro (soft delete)
     * ATENÇÃO: Este método só funciona se a tabela tiver a coluna 'ativo'
     */
    public boolean delete(Integer id) throws DatabaseException {
        // Verificar se a tabela tem a coluna 'ativo'
        String sql = "UPDATE " + getTableName() + " SET ativo = FALSE WHERE id = ?";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setInt(1, id);
            int affectedRows = ps.executeUpdate();
            
            logger.debug("Registro ID {} excluído logicamente de {}", id, getTableName());
            return affectedRows > 0;
            
        } catch (SQLException e) {
            // Se a coluna 'ativo' não existir, fazer delete físico
            if (e.getMessage().contains("Unknown column 'ativo'")) {
                logger.warn("Coluna 'ativo' não existe em {}, realizando delete físico", getTableName());
                return deletePhysical(id);
            }
            logger.error("Erro ao excluir registro ID {} de {}", id, getTableName(), e);
            throw new DatabaseException("Erro ao excluir registro: " + e.getMessage(), e);
        }
    }
    
    /**
     * Exclui fisicamente um registro
     */
    public boolean deletePhysical(Integer id) throws DatabaseException {
        String sql = "DELETE FROM " + getTableName() + " WHERE id = ?";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setInt(1, id);
            int affectedRows = ps.executeUpdate();
            
            logger.debug("Registro ID {} excluído fisicamente de {}", id, getTableName());
            return affectedRows > 0;
            
        } catch (SQLException e) {
            logger.error("Erro ao excluir fisicamente registro ID {} de {}", id, getTableName(), e);
            throw new DatabaseException("Erro ao excluir registro: " + e.getMessage(), e);
        }
    }
    
    /**
     * Conta o total de registros
     */
    public int count() throws DatabaseException {
        String sql = "SELECT COUNT(*) as total FROM " + getTableName();
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            
            if (rs.next()) {
                return rs.getInt("total");
            }
            return 0;
            
        } catch (SQLException e) {
            logger.error("Erro ao contar registros de {}", getTableName(), e);
            throw new DatabaseException("Erro ao contar registros: " + e.getMessage(), e);
        }
    }
    
    /**
     * Verifica se existe registro com determinado campo
     */
    public boolean existsByField(String field, Object value) throws DatabaseException {
        String sql = "SELECT COUNT(*) as total FROM " + getTableName() + " WHERE " + field + " = ?";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setObject(1, value);
            
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt("total") > 0;
                }
            }
            return false;
            
        } catch (SQLException e) {
            logger.error("Erro ao verificar existência em {}", getTableName(), e);
            throw new DatabaseException("Erro ao verificar existência: " + e.getMessage(), e);
        }
    }
 // Adicione este método à classe GenericDAO.java

    public List<T> findAll(String orderBy) throws DatabaseException {
        List<T> list = new ArrayList<>();
        String sql = "SELECT * FROM " + getTableName() + " " + (orderBy != null ? orderBy : "");
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            
            while (rs.next()) {
                list.add(mapResultSetToEntity(rs));
            }
            return list;
            
        } catch (SQLException e) {
            logger.error("Erro ao buscar todos os registros de {}", getTableName(), e);
            throw new DatabaseException("Erro ao buscar registros: " + e.getMessage(), e);
        }
    }
    
    // Métodos abstratos auxiliares
    protected abstract String getInsertColumns();
    protected abstract String getInsertPlaceholders();
    protected abstract String getUpdateColumns();
    protected abstract int getUpdateParameterCount();
    protected abstract Integer getId(T entity);
    protected abstract void setId(T entity, Integer id);
}
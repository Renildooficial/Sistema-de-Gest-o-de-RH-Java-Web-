package com.sigrh.service;

import com.sigrh.dao.SolicitacaoDiaDAO;
import com.sigrh.exception.BusinessException;
import com.sigrh.model.SolicitacaoDia;
import com.sigrh.model.Usuario;
import com.sigrh.model.Ferias;
import com.sigrh.model.PlanoFerias;

import java.sql.Date;
import java.sql.Timestamp;
import java.util.List;

public class SolicitacaoDiaService {

    private final SolicitacaoDiaDAO dao;
    private final FeriasService feriasService;
    private final PlanoFeriasService planoFeriasService;
    private final AuditoriaService auditoriaService;

    public SolicitacaoDiaService() {
        this.dao = new SolicitacaoDiaDAO();
        this.feriasService = new FeriasService();
        this.planoFeriasService = new PlanoFeriasService();
        this.auditoriaService = new AuditoriaService();
    }

    /**
     * Solicita um dia (folga/compensação) para o funcionário.
     */
    public SolicitacaoDia solicitar(Integer idFuncionario, Date data, String tipo, String periodo,
                                    String justificativa, Usuario solicitante) throws BusinessException {
        if (idFuncionario == null) throw new BusinessException("Funcionário não identificado");
        if (data == null) throw new BusinessException("Data é obrigatória");

        try {
            // 1. Verificar se já existe solicitação para essa data
            if (dao.existeSolicitacaoParaData(idFuncionario, data)) {
                throw new BusinessException("Já existe uma solicitação para esta data");
            }

            // 2. Verificar conflitos com férias
            List<Ferias> feriasConflitantes = feriasService.buscarPorFuncionarioPeriodo(idFuncionario, data, data);
            if (!feriasConflitantes.isEmpty()) {
                throw new BusinessException("Conflito com férias! O funcionário possui férias na data " + data);
            }

            // 3. Verificar conflitos com plano de férias (apenas alerta)
            try {
                PlanoFerias plano = planoFeriasService.buscarPorFuncionarioEMes(idFuncionario, data);
                if (plano != null) {
                    System.out.println("⚠️ Funcionário tem plano de férias para o mês: " + data);
                }
            } catch (Exception e) {
                System.out.println("⚠️ Erro ao verificar plano de férias: " + e.getMessage());
            }

            // 4. Criar a solicitação
            SolicitacaoDia sd = new SolicitacaoDia();
            sd.setIdFuncionario(idFuncionario);
            sd.setData(data);
            sd.setTipo(tipo);
            sd.setPeriodo(periodo);
            sd.setJustificativa(justificativa);
            sd.setStatus("SOLICITADA");
            sd.setDataSolicitacao(new Timestamp(System.currentTimeMillis()));

            dao.salvar(sd);

            // 5. Auditoria
            if (auditoriaService != null) {
                auditoriaService.registrar(solicitante, "CREATE", "solicitacao_dias", sd.getId(),
                        null, "Solicitação de dia " + data + " (" + tipo + ")");
            }

            return sd;

        } catch (BusinessException e) {
            throw e;
        } catch (Exception e) {
            throw new BusinessException("Erro ao solicitar dia: " + e.getMessage());
        }
    }

    public void aprovar(Integer idSolicitacao, Usuario aprovador) throws BusinessException {
        try {
            SolicitacaoDia sd = dao.buscarPorId(idSolicitacao);
            if (sd == null) throw new BusinessException("Solicitação não encontrada");
            if (!"SOLICITADA".equals(sd.getStatus())) {
                throw new BusinessException("Apenas solicitações pendentes podem ser aprovadas");
            }

            // Verificar novamente conflitos
            List<Ferias> conflitos = feriasService.buscarPorFuncionarioPeriodo(sd.getIdFuncionario(), sd.getData(), sd.getData());
            if (!conflitos.isEmpty()) {
                throw new BusinessException("Não é possível aprovar: conflito com férias na data " + sd.getData());
            }

            sd.setStatus("APROVADA");
            sd.setAprovadoPor(aprovador.getId());
            sd.setDataAprovacao(new Timestamp(System.currentTimeMillis()));
            dao.atualizar(sd);

            if (auditoriaService != null) {
                auditoriaService.registrar(aprovador, "UPDATE", "solicitacao_dias", sd.getId(),
                        "Status: SOLICITADA", "Status: APROVADA por " + aprovador.getNome());
            }

        } catch (BusinessException e) {
            throw e;
        } catch (Exception e) {
            throw new BusinessException("Erro ao aprovar solicitação: " + e.getMessage());
        }
    }

    public void rejeitar(Integer idSolicitacao, String motivo, Usuario rejeitador) throws BusinessException {
        try {
            SolicitacaoDia sd = dao.buscarPorId(idSolicitacao);
            if (sd == null) throw new BusinessException("Solicitação não encontrada");
            if (!"SOLICITADA".equals(sd.getStatus())) {
                throw new BusinessException("Apenas solicitações pendentes podem ser rejeitadas");
            }
            if (motivo == null || motivo.trim().isEmpty()) {
                throw new BusinessException("Motivo da rejeição é obrigatório");
            }

            sd.setStatus("REJEITADA");
            sd.setMotivoRejeicao(motivo);
            sd.setAprovadoPor(rejeitador.getId());
            sd.setDataAprovacao(new Timestamp(System.currentTimeMillis()));
            dao.atualizar(sd);

            if (auditoriaService != null) {
                auditoriaService.registrar(rejeitador, "UPDATE", "solicitacao_dias", sd.getId(),
                        "Status: SOLICITADA", "Status: REJEITADA. Motivo: " + motivo);
            }

        } catch (BusinessException e) {
            throw e;
        } catch (Exception e) {
            throw new BusinessException("Erro ao rejeitar solicitação: " + e.getMessage());
        }
    }

    public void cancelar(Integer idSolicitacao, Usuario cancelador) throws BusinessException {
        try {
            SolicitacaoDia sd = dao.buscarPorId(idSolicitacao);
            if (sd == null) throw new BusinessException("Solicitação não encontrada");
            if (!"SOLICITADA".equals(sd.getStatus()) && !"APROVADA".equals(sd.getStatus())) {
                throw new BusinessException("Apenas solicitações pendentes ou aprovadas podem ser canceladas");
            }

            sd.setStatus("CANCELADA");
            dao.atualizar(sd);

            if (auditoriaService != null) {
                auditoriaService.registrar(cancelador, "UPDATE", "solicitacao_dias", sd.getId(),
                        null, "Solicitação cancelada por " + cancelador.getNome());
            }

        } catch (BusinessException e) {
            throw e;
        } catch (Exception e) {
            throw new BusinessException("Erro ao cancelar solicitação: " + e.getMessage());
        }
    }

    public List<SolicitacaoDia> listarPorFuncionario(Integer idFuncionario) throws BusinessException {
        try {
            return dao.findByFuncionario(idFuncionario);
        } catch (Exception e) {
            throw new BusinessException("Erro ao listar solicitações: " + e.getMessage());
        }
    }

    public List<SolicitacaoDia> listarPorStatus(String status) throws BusinessException {
        try {
            return dao.findByStatus(status);
        } catch (Exception e) {
            throw new BusinessException("Erro ao listar solicitações por status: " + e.getMessage());
        }
    }

    public List<SolicitacaoDia> listarTodas() throws BusinessException {
        try {
            return dao.listarTodas();
        } catch (Exception e) {
            throw new BusinessException("Erro ao listar todas as solicitações: " + e.getMessage());
        }
    }

    public SolicitacaoDia buscarPorId(Integer id) throws BusinessException {
        try {
            return dao.buscarPorId(id);
        } catch (Exception e) {
            throw new BusinessException("Erro ao buscar solicitação: " + e.getMessage());
        }
    }

    public boolean verificarConflito(Integer idFuncionario, Date data) throws BusinessException {
        try {
            List<Ferias> ferias = feriasService.buscarPorFuncionarioPeriodo(idFuncionario, data, data);
            if (!ferias.isEmpty()) return true;
            return dao.existeSolicitacaoParaData(idFuncionario, data);
        } catch (Exception e) {
            throw new BusinessException("Erro ao verificar conflito: " + e.getMessage());
        }
    }
}
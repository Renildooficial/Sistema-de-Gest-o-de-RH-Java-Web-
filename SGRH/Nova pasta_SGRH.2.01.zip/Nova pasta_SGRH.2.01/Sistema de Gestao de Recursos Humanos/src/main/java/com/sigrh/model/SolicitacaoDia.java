package com.sigrh.model;

import java.sql.Date;
import java.sql.Timestamp;

public class SolicitacaoDia {

    private Integer id;
    private Integer idFuncionario;
    private Date data;
    private String tipo;           // "FOLGA", "COMPENSACAO", "OUTRO"
    private String periodo;        // "MANHA", "TARDE", "INTEGRAL"
    private String justificativa;
    private String status;         // "SOLICITADA", "APROVADA", "REJEITADA", "CANCELADA"
    private Timestamp dataSolicitacao;
    private Integer aprovadoPor;
    private Timestamp dataAprovacao;
    private String motivoRejeicao;

    // Relacionamentos (opcionais)
    private Funcionario funcionario;
    private Usuario usuarioAprovador;

    // Getters e Setters
    public Integer getId() { return id; }
    public void setId(Integer id) { this.id = id; }

    public Integer getIdFuncionario() { return idFuncionario; }
    public void setIdFuncionario(Integer idFuncionario) { this.idFuncionario = idFuncionario; }

    public Date getData() { return data; }
    public void setData(Date data) { this.data = data; }

    public String getTipo() { return tipo; }
    public void setTipo(String tipo) { this.tipo = tipo; }

    public String getPeriodo() { return periodo; }
    public void setPeriodo(String periodo) { this.periodo = periodo; }

    public String getJustificativa() { return justificativa; }
    public void setJustificativa(String justificativa) { this.justificativa = justificativa; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public Timestamp getDataSolicitacao() { return dataSolicitacao; }
    public void setDataSolicitacao(Timestamp dataSolicitacao) { this.dataSolicitacao = dataSolicitacao; }

    public Integer getAprovadoPor() { return aprovadoPor; }
    public void setAprovadoPor(Integer aprovadoPor) { this.aprovadoPor = aprovadoPor; }

    public Timestamp getDataAprovacao() { return dataAprovacao; }
    public void setDataAprovacao(Timestamp dataAprovacao) { this.dataAprovacao = dataAprovacao; }

    public String getMotivoRejeicao() { return motivoRejeicao; }
    public void setMotivoRejeicao(String motivoRejeicao) { this.motivoRejeicao = motivoRejeicao; }

    public Funcionario getFuncionario() { return funcionario; }
    public void setFuncionario(Funcionario funcionario) { this.funcionario = funcionario; }

    public Usuario getUsuarioAprovador() { return usuarioAprovador; }
    public void setUsuarioAprovador(Usuario usuarioAprovador) { this.usuarioAprovador = usuarioAprovador; }
}
package com.sigrh.dao;

import com.sigrh.exception.DatabaseException;
import com.sigrh.model.SolicitacaoDia;
import com.sigrh.util.DatabaseUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class SolicitacaoDiaDAO extends GenericDAO<SolicitacaoDia> {

    @Override
    protected String getTableName() {
        return "solicitacao_dias";
    }

    @Override
    protected SolicitacaoDia mapResultSetToEntity(ResultSet rs) throws SQLException {
        SolicitacaoDia sd = new SolicitacaoDia();
        sd.setId(rs.getInt("id"));
        sd.setIdFuncionario(rs.getInt("id_funcionario"));
        sd.setData(rs.getDate("data"));
        sd.setTipo(rs.getString("tipo"));
        sd.setPeriodo(rs.getString("periodo"));
        sd.setJustificativa(rs.getString("justificativa"));
        sd.setStatus(rs.getString("status"));
        sd.setDataSolicitacao(rs.getTimestamp("data_solicitacao"));
        sd.setAprovadoPor(rs.getInt("aprovado_por"));
        if (rs.wasNull()) sd.setAprovadoPor(null);
        sd.setDataAprovacao(rs.getTimestamp("data_aprovacao"));
        sd.setMotivoRejeicao(rs.getString("motivo_rejeicao"));
        return sd;
    }

    @Override
    protected void setInsertParameters(PreparedStatement ps, SolicitacaoDia entity) throws SQLException {
        ps.setInt(1, entity.getIdFuncionario());
        ps.setDate(2, entity.getData());
        ps.setString(3, entity.getTipo());
        ps.setString(4, entity.getPeriodo());
        ps.setString(5, entity.getJustificativa());
        ps.setString(6, entity.getStatus() != null ? entity.getStatus() : "SOLICITADA");
        ps.setTimestamp(7, entity.getDataSolicitacao() != null ? entity.getDataSolicitacao() : new Timestamp(System.currentTimeMillis()));
        if (entity.getAprovadoPor() != null) {
            ps.setInt(8, entity.getAprovadoPor());
        } else {
            ps.setNull(8, Types.INTEGER);
        }
        ps.setTimestamp(9, entity.getDataAprovacao());
        ps.setString(10, entity.getMotivoRejeicao());
    }

    @Override
    protected void setUpdateParameters(PreparedStatement ps, SolicitacaoDia entity) throws SQLException {
        ps.setInt(1, entity.getIdFuncionario());
        ps.setDate(2, entity.getData());
        ps.setString(3, entity.getTipo());
        ps.setString(4, entity.getPeriodo());
        ps.setString(5, entity.getJustificativa());
        ps.setString(6, entity.getStatus());
        ps.setTimestamp(7, entity.getDataSolicitacao());
        if (entity.getAprovadoPor() != null) {
            ps.setInt(8, entity.getAprovadoPor());
        } else {
            ps.setNull(8, Types.INTEGER);
        }
        ps.setTimestamp(9, entity.getDataAprovacao());
        ps.setString(10, entity.getMotivoRejeicao());
        ps.setInt(11, entity.getId());
    }

    @Override
    protected String getInsertColumns() {
        return "id_funcionario, data, tipo, periodo, justificativa, status, data_solicitacao, aprovado_por, data_aprovacao, motivo_rejeicao";
    }

    @Override
    protected String getInsertPlaceholders() {
        return "?, ?, ?, ?, ?, ?, ?, ?, ?, ?";
    }

    @Override
    protected String getUpdateColumns() {
        return "id_funcionario = ?, data = ?, tipo = ?, periodo = ?, justificativa = ?, status = ?, data_solicitacao = ?, aprovado_por = ?, data_aprovacao = ?, motivo_rejeicao = ?";
    }

    @Override
    protected int getUpdateParameterCount() {
        return 10;
    }

    @Override
    protected Integer getId(SolicitacaoDia entity) {
        return entity.getId();
    }

    @Override
    protected void setId(SolicitacaoDia entity, Integer id) {
        entity.setId(id);
    }

    // ============================================================
    // MÉTODOS CRUD IMPLEMENTADOS DIRETAMENTE
    // ============================================================
    
    /**
     * Salva uma nova solicitação no banco de dados.
     */
    public void salvar(SolicitacaoDia entity) throws DatabaseException {
        String sql = "INSERT INTO " + getTableName() + 
                     " (" + getInsertColumns() + ") VALUES (" + getInsertPlaceholders() + ")";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            
            setInsertParameters(ps, entity);
            
            int affectedRows = ps.executeUpdate();
            if (affectedRows == 0) {
                throw new DatabaseException("Falha ao salvar solicitação, nenhuma linha afetada.");
            }
            
            try (ResultSet generatedKeys = ps.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    setId(entity, generatedKeys.getInt(1));
                } else {
                    throw new DatabaseException("Falha ao salvar solicitação, nenhum ID gerado.");
                }
            }
            
        } catch (SQLException e) {
            throw new DatabaseException("Erro ao salvar solicitação: " + e.getMessage(), e);
        }
    }
    
    /**
     * Atualiza uma solicitação existente no banco de dados.
     */
    public void atualizar(SolicitacaoDia entity) throws DatabaseException {
        String sql = "UPDATE " + getTableName() + " SET " + getUpdateColumns() + " WHERE id = ?";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            setUpdateParameters(ps, entity);
            
            int affectedRows = ps.executeUpdate();
            if (affectedRows == 0) {
                throw new DatabaseException("Falha ao atualizar solicitação, nenhuma linha afetada.");
            }
            
        } catch (SQLException e) {
            throw new DatabaseException("Erro ao atualizar solicitação: " + e.getMessage(), e);
        }
    }
    
    /**
     * Exclui uma solicitação do banco de dados.
     */
    public void excluir(Integer id) throws DatabaseException {
        String sql = "DELETE FROM " + getTableName() + " WHERE id = ?";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setInt(1, id);
            
            int affectedRows = ps.executeUpdate();
            if (affectedRows == 0) {
                throw new DatabaseException("Falha ao excluir solicitação, nenhuma linha afetada.");
            }
            
        } catch (SQLException e) {
            throw new DatabaseException("Erro ao excluir solicitação: " + e.getMessage(), e);
        }
    }
    
    /**
     * Busca uma solicitação pelo ID.
     */
    public SolicitacaoDia buscarPorId(Integer id) throws DatabaseException {
        String sql = "SELECT * FROM " + getTableName() + " WHERE id = ?";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setInt(1, id);
            
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToEntity(rs);
                }
            }
            return null;
            
        } catch (SQLException e) {
            throw new DatabaseException("Erro ao buscar solicitação por ID: " + e.getMessage(), e);
        }
    }

    // ============================================================
    // MÉTODOS DE CONSULTA
    // ============================================================

    public List<SolicitacaoDia> findByFuncionario(Integer idFuncionario) throws DatabaseException {
        String sql = "SELECT * FROM " + getTableName() + " WHERE id_funcionario = ? ORDER BY data DESC";
        List<SolicitacaoDia> list = new ArrayList<>();
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, idFuncionario);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(mapResultSetToEntity(rs));
                }
            }
        } catch (SQLException e) {
            throw new DatabaseException("Erro ao buscar solicitações do funcionário", e);
        }
        return list;
    }

    public List<SolicitacaoDia> findByStatus(String status) throws DatabaseException {
        String sql = "SELECT * FROM " + getTableName() + " WHERE status = ? ORDER BY data_solicitacao DESC";
        List<SolicitacaoDia> list = new ArrayList<>();
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, status);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(mapResultSetToEntity(rs));
                }
            }
        } catch (SQLException e) {
            throw new DatabaseException("Erro ao buscar solicitações por status", e);
        }
        return list;
    }

    public boolean existeSolicitacaoParaData(Integer idFuncionario, Date data, String... statusIgnorar) throws DatabaseException {
        String sql = "SELECT COUNT(*) FROM " + getTableName() + 
                     " WHERE id_funcionario = ? AND data = ? AND status NOT IN ('REJEITADA', 'CANCELADA')";
        
        if (statusIgnorar != null && statusIgnorar.length > 0) {
            StringBuilder sb = new StringBuilder();
            sb.append("SELECT COUNT(*) FROM ").append(getTableName())
              .append(" WHERE id_funcionario = ? AND data = ? AND status NOT IN (");
            for (int i = 0; i < statusIgnorar.length; i++) {
                sb.append("?");
                if (i < statusIgnorar.length - 1) sb.append(", ");
            }
            sb.append(")");
            sql = sb.toString();
        }
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, idFuncionario);
            ps.setDate(2, data);
            for (int i = 0; i < statusIgnorar.length; i++) {
                ps.setString(i + 3, statusIgnorar[i]);
            }
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1) > 0;
                }
            }
        } catch (SQLException e) {
            throw new DatabaseException("Erro ao verificar existência de solicitação", e);
        }
        return false;
    }

    public List<SolicitacaoDia> listarTodas() throws DatabaseException {
        String sql = "SELECT * FROM " + getTableName() + " ORDER BY data DESC";
        List<SolicitacaoDia> list = new ArrayList<>();
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                list.add(mapResultSetToEntity(rs));
            }
        } catch (SQLException e) {
            throw new DatabaseException("Erro ao listar todas as solicitações", e);
        }
        return list;
    }
}
package com.sigrh.model;

import java.sql.Timestamp;

public class Notificacao {
    
    private Integer id;
    private Integer idUsuario;
    private String titulo;
    private String mensagem;
    private String tipo; // INFO, SUCESSO, AVISO, ERRO
    private boolean lida;
    private Timestamp dataCriacao;
    
    // Campos adicionais para exibição
    private String icone;
    private String link;
    private Usuario usuario;
    
    // Construtores
    public Notificacao() {
        this.lida = false;
        this.dataCriacao = new Timestamp(System.currentTimeMillis());
    }
    
    public Notificacao(Integer idUsuario, String titulo, String mensagem, String tipo) {
        this.idUsuario = idUsuario;
        this.titulo = titulo;
        this.mensagem = mensagem;
        this.tipo = tipo;
        this.lida = false;
        this.dataCriacao = new Timestamp(System.currentTimeMillis());
    }
    
    // Getters e Setters
    public Integer getId() { return id; }
    public void setId(Integer id) { this.id = id; }
    
    public Integer getIdUsuario() { return idUsuario; }
    public void setIdUsuario(Integer idUsuario) { this.idUsuario = idUsuario; }
    
    public String getTitulo() { return titulo; }
    public void setTitulo(String titulo) { this.titulo = titulo; }
    
    public String getMensagem() { return mensagem; }
    public void setMensagem(String mensagem) { this.mensagem = mensagem; }
    
    public String getTipo() { return tipo; }
    public void setTipo(String tipo) { 
        this.tipo = tipo;
        this.icone = getIconePorTipo(tipo);
    }
    
    public boolean isLida() { return lida; }
    public void setLida(boolean lida) { this.lida = lida; }
    
    public Timestamp getDataCriacao() { return dataCriacao; }
    public void setDataCriacao(Timestamp dataCriacao) { this.dataCriacao = dataCriacao; }
    
    public String getIcone() { 
        if (icone == null) {
            icone = getIconePorTipo(tipo);
        }
        return icone; 
    }
    public void setIcone(String icone) { this.icone = icone; }
    
    public String getLink() { return link; }
    public void setLink(String link) { this.link = link; }
    
    public Usuario getUsuario() { return usuario; }
    public void setUsuario(Usuario usuario) { this.usuario = usuario; }
    
    // Métodos auxiliares
    public String getStatus() {
        return lida ? "LIDA" : "NAO_LIDA";
    }
    
    private String getIconePorTipo(String tipo) {
        if (tipo == null) return "fa-bell";
        switch (tipo.toUpperCase()) {
            case "SUCESSO": return "fa-check-circle";
            case "AVISO": return "fa-exclamation-triangle";
            case "ERRO": return "fa-times-circle";
            case "INFO":
            default: return "fa-info-circle";
        }
    }
    
    public String getCor() {
        if (tipo == null) return "var(--info)";
        switch (tipo.toUpperCase()) {
            case "SUCESSO": return "var(--success)";
            case "AVISO": return "var(--warning)";
            case "ERRO": return "var(--danger)";
            case "INFO":
            default: return "var(--info)";
        }
    }
    
    public String getBadgeClass() {
        if (tipo == null) return "info";
        switch (tipo.toUpperCase()) {
            case "SUCESSO": return "success";
            case "AVISO": return "warning";
            case "ERRO": return "danger";
            case "INFO":
            default: return "info";
        }
    }
}
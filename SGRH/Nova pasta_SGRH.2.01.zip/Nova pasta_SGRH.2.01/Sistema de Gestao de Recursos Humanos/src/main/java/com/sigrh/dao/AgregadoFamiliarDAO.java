package com.sigrh.dao;

import com.sigrh.exception.DatabaseException;
import com.sigrh.model.AgregadoFamiliar;
import com.sigrh.util.DatabaseUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class AgregadoFamiliarDAO extends GenericDAO<AgregadoFamiliar> {
    
    @Override
    protected String getTableName() {
        return "agregado_familiar";
    }
    
    @Override
    protected AgregadoFamiliar mapResultSetToEntity(ResultSet rs) throws SQLException {
        AgregadoFamiliar agregado = new AgregadoFamiliar();
        agregado.setId(rs.getInt("id"));
        agregado.setIdFuncionario(rs.getInt("id_funcionario"));
        agregado.setNome(rs.getString("nome"));
        agregado.setGrauParentesco(rs.getString("grau_parentesco"));
        agregado.setDataNascimento(rs.getDate("data_nascimento"));
        agregado.setDocumento(rs.getString("documento"));
        agregado.setObservacao(rs.getString("observacao"));
        agregado.setAtivo(rs.getBoolean("ativo"));
        agregado.setDataCadastro(rs.getTimestamp("data_cadastro"));
        return agregado;
    }
    
    @Override
    protected void setInsertParameters(PreparedStatement ps, AgregadoFamiliar entity) throws SQLException {
        ps.setInt(1, entity.getIdFuncionario());
        ps.setString(2, entity.getNome());
        ps.setString(3, entity.getGrauParentesco().name());
        ps.setDate(4, entity.getDataNascimento());
        ps.setString(5, entity.getDocumento());
        ps.setString(6, entity.getObservacao());
        ps.setBoolean(7, entity.getAtivo());
    }
    
    @Override
    protected void setUpdateParameters(PreparedStatement ps, AgregadoFamiliar entity) throws SQLException {
        ps.setInt(1, entity.getIdFuncionario());
        ps.setString(2, entity.getNome());
        ps.setString(3, entity.getGrauParentesco().name());
        ps.setDate(4, entity.getDataNascimento());
        ps.setString(5, entity.getDocumento());
        ps.setString(6, entity.getObservacao());
        ps.setBoolean(7, entity.getAtivo());
    }
    
    @Override
    protected String getInsertColumns() {
        return "id_funcionario, nome, grau_parentesco, data_nascimento, documento, observacao, ativo";
    }
    
    @Override
    protected String getInsertPlaceholders() {
        return "?, ?, ?, ?, ?, ?, ?";
    }
    
    @Override
    protected String getUpdateColumns() {
        return "id_funcionario = ?, nome = ?, grau_parentesco = ?, data_nascimento = ?, " +
               "documento = ?, observacao = ?, ativo = ?";
    }
    
    @Override
    protected int getUpdateParameterCount() {
        return 7;
    }
    
    @Override
    protected Integer getId(AgregadoFamiliar entity) {
        return entity.getId();
    }
    
    @Override
    protected void setId(AgregadoFamiliar entity, Integer id) {
        entity.setId(id);
    }
    
    /**
     * Busca agregados de um funcionário
     */
    public List<AgregadoFamiliar> findByFuncionario(Integer idFuncionario) throws DatabaseException {
        List<AgregadoFamiliar> list = new ArrayList<>();
        String sql = "SELECT * FROM " + getTableName() + " WHERE id_funcionario = ? AND ativo = TRUE ORDER BY nome";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setInt(1, idFuncionario);
            
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(mapResultSetToEntity(rs));
                }
            }
            return list;
            
        } catch (SQLException e) {
            logger.error("Erro ao buscar agregados do funcionário ID {}", idFuncionario, e);
            throw new DatabaseException("Erro ao buscar agregados: " + e.getMessage(), e);
        }
    }
    
    /**
     * Busca agregados por grau de parentesco
     */
    public List<AgregadoFamiliar> findByGrauParentesco(String grau) throws DatabaseException {
        List<AgregadoFamiliar> list = new ArrayList<>();
        String sql = "SELECT * FROM " + getTableName() + " WHERE grau_parentesco = ? AND ativo = TRUE ORDER BY nome";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setString(1, grau);
            
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(mapResultSetToEntity(rs));
                }
            }
            return list;
            
        } catch (SQLException e) {
            logger.error("Erro ao buscar agregados por grau: {}", grau, e);
            throw new DatabaseException("Erro ao buscar agregados: " + e.getMessage(), e);
        }
    }
}
package com.sigrh.controller;

import com.sigrh.dao.FeriasDAO;
import com.sigrh.exception.BusinessException;
import com.sigrh.model.Ferias;
import com.sigrh.model.Usuario;
import com.sigrh.model.Funcionario;
import com.sigrh.service.FeriasService;
import com.sigrh.service.FuncionarioService;
import com.sigrh.service.SistemaNotificacaoService;
import com.sigrh.service.AuditoriaService;
import com.sigrh.util.Constants;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;
import java.sql.Timestamp;
import java.util.Calendar;
import java.util.List;
import java.util.Map;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

@WebServlet(urlPatterns = {"/ferias", "/ferias/*", "/api/calendario-eventos"})
public class FeriasController extends HttpServlet {
    
    private static final long serialVersionUID = 1L;
    private final FeriasService feriasService;
    private final FuncionarioService funcionarioService;
    private final AuditoriaService auditoriaService;
    private final FeriasDAO feriasDAO;
    private final Gson gson;
    private final SistemaNotificacaoService sistemaNotificacaoService;
    
    public FeriasController() {
        this.feriasService = new FeriasService();
        this.funcionarioService = new FuncionarioService();
        this.auditoriaService = new AuditoriaService();
        this.feriasDAO = new FeriasDAO();
        this.gson = new GsonBuilder().setDateFormat("dd/MM/yyyy HH:mm").create();
        this.sistemaNotificacaoService = new SistemaNotificacaoService();

    }
    
    // ============================================================
    // MÉTODO PARA DETALHES - REMOVER A ANOTAÇÃO @WebServlet
    // ============================================================
    private void detalhes(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        try {
            String path = request.getPathInfo();
            // Verifica se path é null ou vazio
            if (path == null || path.isEmpty()) {
                response.sendRedirect(request.getContextPath() + "/ferias");
                return;
            }
            
            String idStr = path.substring("/detalhes/".length());
            Integer id = Integer.parseInt(idStr);
            
            Ferias ferias = feriasService.buscarPorId(id);
            
            if (ferias == null) {
                request.getSession().setAttribute(Constants.MSG_ERRO, "Solicitação não encontrada");
                response.sendRedirect(request.getContextPath() + "/ferias");
                return;
            }
            
            // Carregar funcionário
            if (ferias.getIdFuncionario() != null) {
                try {
                    Funcionario func = funcionarioService.buscarPorId(ferias.getIdFuncionario());
                    ferias.setFuncionario(func);
                } catch (Exception e) {
                    // Ignorar se não encontrar
                }
            }
            
            request.setAttribute("ferias", ferias);
            request.getRequestDispatcher("/WEB-INF/views/rh/ferias-detalhes.jsp").forward(request, response);
            
        } catch (NumberFormatException e) {
            response.sendRedirect(request.getContextPath() + "/ferias");
        } catch (BusinessException e) {
            request.getSession().setAttribute(Constants.MSG_ERRO, e.getMessage());
            response.sendRedirect(request.getContextPath() + "/ferias");
        } catch (Exception e) {
            e.printStackTrace();
            request.getSession().setAttribute(Constants.MSG_ERRO, "Erro ao carregar detalhes: " + e.getMessage());
            response.sendRedirect(request.getContextPath() + "/ferias");
        }
    }
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String path = request.getPathInfo();
        System.out.println("🔍 FeriasController.doGet - Path: " + path);
        
        Usuario usuario = (Usuario) request.getSession().getAttribute(Constants.SESSION_USER);
        if (usuario == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }
        
        try {
            // API para eventos do calendário
            if (path != null && path.equals("/api/calendario-eventos")) {
                buscarEventosCalendario(request, response, usuario);
                return;
            }
            
            // Detalhes de uma solicitação (GET - página HTML)
            if (path != null && path.startsWith("/detalhes/")) {
                detalhes(request, response);
                return;
            }
            
            if (path == null || path.equals("/")) {
                listar(request, response, usuario);
            } else if (path.equals("/pendentes")) {
                pendentes(request, response, usuario);
            } else if (path.equals("/minhas")) {
                minhasFerias(request, response, usuario);
            } else if (path.equals("/nova") || path.equals("/solicitar")) {
                novaSolicitacao(request, response, usuario);
            } else if (path.equals("/saldo")) {
                saldoFerias(request, response, usuario);
            } else if (path.equals("/cancelar")) {
                cancelar(request, response, usuario);
            } else if (path.equals("/interromper")) {
                mostrarInterromper(request, response, usuario);
            } else {
                response.sendError(HttpServletResponse.SC_NOT_FOUND);
            }
        } catch (Exception e) {
            e.printStackTrace();
            request.getSession().setAttribute(Constants.MSG_ERRO, "Erro: " + e.getMessage());
            response.sendRedirect(request.getContextPath() + "/dashboard");
        }
    }
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String path = request.getPathInfo();
        System.out.println("==========================================");
        System.out.println("🚀 FeriasController.doPost - Path: " + path);
        System.out.println("📋 Request URI: " + request.getRequestURI());
        System.out.println("==========================================");
                            
        Usuario usuario = (Usuario) request.getSession().getAttribute(Constants.SESSION_USER);
        if (usuario == null) {
            response.setContentType("application/json");
            response.getWriter().write("{\"success\":false,\"message\":\"Usuário não logado\"}");
            return;
        }
        
        try {
            if (path == null || path.equals("/")) {
                solicitar(request, response, usuario);
            } else if (path.equals("/aprovar")) {
                aprovar(request, response, usuario);
            } else if (path.equals("/rejeitar")) {
                rejeitar(request, response, usuario);
            } else if (path.equals("/checkout")) {
                checkout(request, response, usuario);
            } else if (path.equals("/checkin")) {
                checkin(request, response, usuario);
            } else if (path.equals("/cancelar")) {
                cancelarPost(request, response, usuario);
            } else if (path.equals("/interromper")) {
                interromper(request, response, usuario);
            } else {
                response.sendError(HttpServletResponse.SC_NOT_FOUND);
            }
        } catch (Exception e) {
            e.printStackTrace();
            response.setContentType("application/json");
            response.getWriter().write("{\"success\":false,\"message\":\"" + e.getMessage() + "\"}");
        }
    }
    
    // ============================================================
    // API - BUSCAR EVENTOS DO CALENDÁRIO (JSON)
    // ============================================================
    private void buscarEventosCalendario(HttpServletRequest request, HttpServletResponse response, Usuario usuario) 
            throws IOException {
        
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();
        
        try {
            int mes = Integer.parseInt(request.getParameter("mes"));
            int ano = Integer.parseInt(request.getParameter("ano"));
            Integer idFuncionario = null;
            
            // Se for funcionário, usar o ID do funcionário logado
            if (usuario.getPerfil() == Usuario.Perfil.FUNCIONARIO) {
                if (usuario.getIdFuncionario() == null) {
                    out.print("{\"dias\": []}");
                    return;
                }
                idFuncionario = usuario.getIdFuncionario();
            } else {
                // Para RH/Gestor/Admin, usar filtro se fornecido
                String idFuncParam = request.getParameter("idFuncionario");
                if (idFuncParam != null && !idFuncParam.isEmpty()) {
                    idFuncionario = Integer.parseInt(idFuncParam);
                }
            }
            
            // Buscar eventos
            Map<String, Object> eventos = feriasService.buscarEventosMes(idFuncionario, mes, ano);
            
            // Adicionar informações do mês/ano
            eventos.put("mes", mes);
            eventos.put("ano", ano);
            
            out.print(gson.toJson(eventos));
            
        } catch (Exception e) {
            e.printStackTrace();
            out.print("{\"dias\": [], \"erro\": \"" + e.getMessage() + "\"}");
        }
        
        out.flush();
    }
    
    // ============================================================
    // LISTAR (RH/ADMIN)
    // ============================================================
    private void listar(HttpServletRequest request, HttpServletResponse response, Usuario usuario) 
            throws ServletException, IOException {
        
        if (!(usuario.isAdmin() || usuario.isRH() || usuario.isGestor())) {
            request.getSession().setAttribute(Constants.MSG_ERRO, "Acesso negado");
            response.sendRedirect(request.getContextPath() + "/dashboard");
            return;
        }
        
        try {
            String status = request.getParameter("status");
            if (status == null || status.isEmpty()) {
                status = "TODOS";
            }
            
            List<Ferias> ferias;
            if ("TODOS".equals(status)) {
                ferias = feriasService.listarTodasFerias();
            } else {
                ferias = feriasService.buscarPorStatus(status);
            }
            
            for (Ferias f : ferias) {
                if (f.getIdFuncionario() != null) {
                    try {
                        Funcionario func = funcionarioService.buscarPorId(f.getIdFuncionario());
                        f.setFuncionario(func);
                    } catch (Exception e) {
                        // Ignorar
                    }
                }
            }
            
            request.setAttribute("ferias", ferias);
            request.setAttribute("total", ferias.size());
            request.setAttribute("statusFiltro", status);
            
            int pendentes = feriasService.buscarPendentes().size();
            request.setAttribute("pendentes", pendentes);
            
            request.getSession().removeAttribute(Constants.MSG_ERRO);
            request.getSession().removeAttribute(Constants.MSG_SUCESSO);
            request.getSession().removeAttribute(Constants.MSG_INFO);
            
            request.getRequestDispatcher("/WEB-INF/views/rh/ferias.jsp").forward(request, response);
            
        } catch (BusinessException e) {
            request.getSession().setAttribute(Constants.MSG_ERRO, e.getMessage());
            response.sendRedirect(request.getContextPath() + "/dashboard");
        }
    }
    
    // ============================================================
    // PENDENTES (RH/GESTOR)
    // ============================================================
    private void pendentes(HttpServletRequest request, HttpServletResponse response, Usuario usuario) 
            throws ServletException, IOException {
        
        if (!(usuario.isAdmin() || usuario.isRH() || usuario.isGestor())) {
            request.getSession().setAttribute(Constants.MSG_ERRO, "Acesso negado");
            response.sendRedirect(request.getContextPath() + "/dashboard");
            return;
        }
        
        try {
            List<Ferias> ferias = feriasService.buscarPendentes();
            
            for (Ferias f : ferias) {
                if (f.getIdFuncionario() != null) {
                    try {
                        Funcionario func = funcionarioService.buscarPorId(f.getIdFuncionario());
                        f.setFuncionario(func);
                    } catch (Exception e) {
                        // Ignorar
                    }
                }
            }
            
            request.setAttribute("ferias", ferias);
            request.setAttribute("total", ferias.size());
            
            request.getSession().removeAttribute(Constants.MSG_ERRO);
            request.getSession().removeAttribute(Constants.MSG_SUCESSO);
            request.getSession().removeAttribute(Constants.MSG_INFO);
            
            request.getRequestDispatcher("/WEB-INF/views/rh/ferias-pendentes.jsp").forward(request, response);
            
        } catch (BusinessException e) {
            request.getSession().setAttribute(Constants.MSG_ERRO, e.getMessage());
            response.sendRedirect(request.getContextPath() + "/dashboard");
        }
    }
    
    // ============================================================
    // MINHAS FÉRIAS (FUNCIONÁRIO)
    // ============================================================
    private void minhasFerias(HttpServletRequest request, HttpServletResponse response, Usuario usuario) 
            throws ServletException, IOException {
        
        try {
            if (usuario.getIdFuncionario() == null) {
                request.getSession().setAttribute(Constants.MSG_ERRO, "Usuário não tem funcionário associado");
                response.sendRedirect(request.getContextPath() + "/dashboard");
                return;
            }
            
            List<Ferias> ferias = feriasService.buscarPorFuncionario(usuario.getIdFuncionario());
            int saldo = feriasService.calcularSaldoFerias(usuario.getIdFuncionario());
            
            int pendentes = 0, aprovadas = 0, emAndamento = 0;
            for (Ferias f : ferias) {
                if ("SOLICITADA".equals(f.getStatus())) pendentes++;
                else if ("APROVADA".equals(f.getStatus())) aprovadas++;
                else if ("EM_ANDAMENTO".equals(f.getStatus())) emAndamento++;
            }
            
            request.setAttribute("ferias", ferias);
            request.setAttribute("saldoFerias", saldo);
            request.setAttribute("pendentes", pendentes);
            request.setAttribute("aprovadas", aprovadas);
            request.setAttribute("emAndamento", emAndamento);
            request.setAttribute("total", ferias.size());
            
            request.getSession().removeAttribute(Constants.MSG_ERRO);
            request.getSession().removeAttribute(Constants.MSG_SUCESSO);
            request.getSession().removeAttribute(Constants.MSG_INFO);
            
            request.getRequestDispatcher("/WEB-INF/views/funcionario/minhas-ferias.jsp").forward(request, response);
            
        } catch (BusinessException e) {
            request.getSession().setAttribute(Constants.MSG_ERRO, e.getMessage());
            response.sendRedirect(request.getContextPath() + "/dashboard");
        }
    }
    
    // ============================================================
    // NOVA SOLICITAÇÃO (FUNCIONÁRIO)
    // ============================================================
    private void novaSolicitacao(HttpServletRequest request, HttpServletResponse response, Usuario usuario) 
            throws ServletException, IOException {
        
        if (usuario.getIdFuncionario() == null) {
            request.getSession().setAttribute(Constants.MSG_ERRO, "Usuário não tem funcionário associado");
            response.sendRedirect(request.getContextPath() + "/dashboard");
            return;
        }
        
        try {
            int saldo = feriasService.calcularSaldoFerias(usuario.getIdFuncionario());
            
            if (saldo <= 0) {
                request.getSession().setAttribute(Constants.MSG_ERRO, "Você não tem saldo de férias disponível");
                response.sendRedirect(request.getContextPath() + "/funcionario/minhas-ferias");
                return;
            }
            
            request.setAttribute("saldo", saldo);
            request.setAttribute("ferias", new Ferias());
            
            request.getSession().removeAttribute(Constants.MSG_ERRO);
            request.getSession().removeAttribute(Constants.MSG_SUCESSO);
            request.getSession().removeAttribute(Constants.MSG_INFO);
            
            request.getRequestDispatcher("/WEB-INF/views/funcionario/solicitar-ferias.jsp").forward(request, response);
            
        } catch (BusinessException e) {
            request.getSession().setAttribute(Constants.MSG_ERRO, e.getMessage());
            response.sendRedirect(request.getContextPath() + "/funcionario/minhas-ferias");
        }
    }
    
    // ============================================================
    // SALDO DE FÉRIAS (API / PÁGINA)
    // ============================================================
    private void saldoFerias(HttpServletRequest request, HttpServletResponse response, Usuario usuario) 
            throws ServletException, IOException {
        
        try {
            Integer idFuncionario = null;
            
            if (usuario.getPerfil() == Usuario.Perfil.FUNCIONARIO) {
                idFuncionario = usuario.getIdFuncionario();
            } else {
                String idParam = request.getParameter("idFuncionario");
                if (idParam != null && !idParam.isEmpty()) {
                    idFuncionario = Integer.parseInt(idParam);
                }
            }
            
            if (idFuncionario == null) {
                response.setContentType("application/json");
                response.getWriter().write("{\"success\":false,\"message\":\"Funcionário não identificado\"}");
                return;
            }
            
            int saldo = feriasService.calcularSaldoFerias(idFuncionario);
            
            // Se for requisição AJAX, retorna JSON
            String accept = request.getHeader("Accept");
            if (accept != null && accept.contains("application/json")) {
                response.setContentType("application/json");
                response.setCharacterEncoding("UTF-8");
                response.getWriter().write("{\"success\":true,\"saldo\":" + saldo + "}");
                return;
            }
            
            // Caso contrário, redireciona / mostra página
            request.setAttribute("saldoFerias", saldo);
            request.getRequestDispatcher("/WEB-INF/views/funcionario/minhas-ferias.jsp").forward(request, response);
            
        } catch (Exception e) {
            e.printStackTrace();
            request.getSession().setAttribute(Constants.MSG_ERRO, "Erro ao calcular saldo: " + e.getMessage());
            response.sendRedirect(request.getContextPath() + "/dashboard");
        }
    }
    
    // ============================================================
    // SOLICITAR (POST - FUNCIONÁRIO) - COM NOTIFICAÇÃO
    // ============================================================
    private void solicitar(HttpServletRequest request, HttpServletResponse response, Usuario usuario) 
            throws ServletException, IOException {
        
        System.out.println("📝 SOLICITANDO FÉRIAS - USUÁRIO: " + usuario.getId());
          
        if (usuario.getIdFuncionario() == null) {
            request.getSession().setAttribute(Constants.MSG_ERRO, "Usuário não tem funcionário associado");
            response.sendRedirect(request.getContextPath() + "/dashboard");
            return;
        }
        
        try {
            String dataInicioStr = request.getParameter("dataInicio");
            String dataFimStr = request.getParameter("dataFim");
            String observacao = request.getParameter("observacao");
             
            if (dataInicioStr == null || dataInicioStr.isEmpty() || 
                dataFimStr == null || dataFimStr.isEmpty()) {
                throw new BusinessException("Datas de início e fim são obrigatórias");
            }
            
            Date dataInicio = Date.valueOf(dataInicioStr);
            Date dataFim = Date.valueOf(dataFimStr);
            
            Date dataAtual = new Date(System.currentTimeMillis());
            if (dataInicio.before(dataAtual)) {
                throw new BusinessException("A data de início não pode ser anterior à data atual");
            }
            
            if (dataFim.before(dataInicio)) {
                throw new BusinessException("A data de fim não pode ser anterior à data de início");
            }
            
            Calendar calInicio = Calendar.getInstance();
            calInicio.setTime(dataInicio);
            Calendar calAtual = Calendar.getInstance();
            if (calInicio.get(Calendar.YEAR) < calAtual.get(Calendar.YEAR)) {
                throw new BusinessException("Não é possível solicitar férias para anos anteriores");
            }
            
            int diasUteis = calcularDiasUteis(dataInicio, dataFim);
            
            if (diasUteis > 15) {
                throw new BusinessException("Não é possível solicitar mais de 15 dias de férias numa única solicitação");
            }
            
            int saldo = feriasService.calcularSaldoFerias(usuario.getIdFuncionario());
            if (diasUteis > saldo) {
                throw new BusinessException("Saldo insuficiente. Saldo disponível: " + saldo + " dias");
            }
            
            if (feriasService.existeConflito(usuario.getIdFuncionario(), dataInicio, dataFim)) {
                throw new BusinessException("Já existe uma solicitação de férias para este período");
            }
            
            Ferias ferias = new Ferias();
            ferias.setIdFuncionario(usuario.getIdFuncionario());
            ferias.setDataInicio(dataInicio);
            ferias.setDataFim(dataFim);
            ferias.setObservacao(observacao);
            
            long diff = ferias.getDataFim().getTime() - ferias.getDataInicio().getTime();
            int diasCalendario = (int) (diff / (1000 * 60 * 60 * 24)) + 1;
            ferias.setDiasCalendario(diasCalendario);
            ferias.setDiasUteis(diasUteis);
            
            ferias.setStatus("SOLICITADA");
            ferias.setDataSolicitacao(new Timestamp(System.currentTimeMillis()));
            
            feriasDAO.salvar(ferias);
            
            auditoriaService.registrar(
                usuario, 
                "CREATE", 
                "ferias", 
                ferias.getId(), 
                null,
                "Solicitação de férias de " + dataInicioStr + " a " + dataFimStr
            );
            
            // =============================================================
            // NOTIFICAR SOLICITAÇÃO DE FÉRIAS
            // =============================================================
            try {
                Funcionario func = funcionarioService.buscarPorId(usuario.getIdFuncionario());
                if (func != null) {
                    String periodo = dataInicioStr + " a " + dataFimStr;
                    sistemaNotificacaoService.notificarSolicitacaoFerias(
                        usuario.getIdFuncionario(),
                        func.getNome(),
                        periodo,
                        "PENDENTE"
                    );
                }
            } catch (Exception e) {
                System.err.println("⚠️ Erro ao notificar solicitação de férias: " + e.getMessage());
            }
            
            request.getSession().setAttribute(Constants.MSG_SUCESSO, 
                "Solicitação de férias enviada com sucesso! Aguarde aprovação.");
            response.sendRedirect(request.getContextPath() + "/funcionario/minhas-ferias");
            
        } catch (BusinessException e) {
            request.getSession().setAttribute(Constants.MSG_ERRO, e.getMessage());
            response.sendRedirect(request.getContextPath() + "/ferias/solicitar");
        } catch (Exception e) {
            e.printStackTrace();
            request.getSession().setAttribute(Constants.MSG_ERRO, "Erro ao solicitar férias: " + e.getMessage());
            response.sendRedirect(request.getContextPath() + "/ferias/solicitar");
        }
    }
    
    // ============================================================
    // APROVAR (RH/GESTOR) - COM NOTIFICAÇÃO
    // ============================================================
    private void aprovar(HttpServletRequest request, HttpServletResponse response, Usuario usuario) 
            throws IOException {
        
        response.setContentType("application/json");
        PrintWriter out = response.getWriter();
        
        if (!(usuario.isAdmin() || usuario.isRH() || usuario.isGestor())) {
            response.setStatus(HttpServletResponse.SC_FORBIDDEN);
            out.print("{\"success\":false,\"message\":\"Acesso negado\"}");
            out.flush();
            return;
        }
        
        try {
            Integer id = Integer.parseInt(request.getParameter("id"));
            
            Ferias ferias = feriasDAO.buscarPorId(id);
            if (ferias == null) {
                out.print("{\"success\":false,\"message\":\"Férias não encontradas\"}");
                out.flush();
                return;
            }
            
            if (!"SOLICITADA".equals(ferias.getStatus())) {
                out.print("{\"success\":false,\"message\":\"Apenas solicitações pendentes podem ser aprovadas\"}");
                out.flush();
                return;
            }
            
            ferias.setStatus("APROVADA");
            ferias.setAprovadoPor(usuario.getId());
            ferias.setDataAprovacao(new Timestamp(System.currentTimeMillis()));
            feriasDAO.atualizar(ferias);
            
            auditoriaService.registrar(
                usuario, 
                "UPDATE", 
                "ferias", 
                id, 
                "Status: SOLICITADA",
                "Status: APROVADA por " + usuario.getNome()
            );
            
            // =============================================================
            // NOTIFICAR APROVAÇÃO DE FÉRIAS
            // =============================================================
            try {
                Funcionario func = funcionarioService.buscarPorId(ferias.getIdFuncionario());
                if (func != null) {
                    String periodo = ferias.getDataInicio() + " a " + ferias.getDataFim();
                    sistemaNotificacaoService.notificarAprovacaoFerias(
                        ferias.getIdFuncionario(),
                        func.getNome(),
                        periodo,
                        true
                    );
                }
            } catch (Exception e) {
                System.err.println("⚠️ Erro ao notificar aprovação de férias: " + e.getMessage());
            }
            
            out.print("{\"success\":true,\"message\":\"Férias aprovadas com sucesso!\"}");
            
        } catch (BusinessException e) {
            out.print("{\"success\":false,\"message\":\"" + e.getMessage() + "\"}");
        } catch (Exception e) {
            e.printStackTrace();
            out.print("{\"success\":false,\"message\":\"Erro ao aprovar férias\"}");
        }
        
        out.flush();
    }
    
    // ============================================================
    // REJEITAR (RH/GESTOR) - COM NOTIFICAÇÃO
    // ============================================================
    private void rejeitar(HttpServletRequest request, HttpServletResponse response, Usuario usuario) 
            throws IOException {
        
        response.setContentType("application/json");
        PrintWriter out = response.getWriter();
        
        if (!(usuario.isAdmin() || usuario.isRH() || usuario.isGestor())) {
            response.setStatus(HttpServletResponse.SC_FORBIDDEN);
            out.print("{\"success\":false,\"message\":\"Acesso negado\"}");
            out.flush();
            return;
        }
        
        try {
            Integer id = Integer.parseInt(request.getParameter("id"));
            String motivo = request.getParameter("motivo");
            
            if (motivo == null || motivo.trim().isEmpty()) {
                out.print("{\"success\":false,\"message\":\"Motivo da rejeição é obrigatório\"}");
                out.flush();
                return;
            }
            
            Ferias ferias = feriasDAO.buscarPorId(id);
            if (ferias == null) {
                out.print("{\"success\":false,\"message\":\"Férias não encontradas\"}");
                out.flush();
                return;
            }
            
            if (!"SOLICITADA".equals(ferias.getStatus())) {
                out.print("{\"success\":false,\"message\":\"Apenas solicitações pendentes podem ser rejeitadas\"}");
                out.flush();
                return;
            }
            
            ferias.setStatus("REJEITADA");
            ferias.setMotivoRejeicao(motivo);
            feriasDAO.atualizar(ferias);
            
            auditoriaService.registrar(
                usuario, 
                "UPDATE", 
                "ferias", 
                id, 
                "Status: SOLICITADA",
                "Status: REJEITADA por " + usuario.getNome() + ". Motivo: " + motivo
            );
            
            // =============================================================
            // NOTIFICAR REJEIÇÃO DE FÉRIAS
            // =============================================================
            try {
                Funcionario func = funcionarioService.buscarPorId(ferias.getIdFuncionario());
                if (func != null) {
                    String periodo = ferias.getDataInicio() + " a " + ferias.getDataFim();
                    sistemaNotificacaoService.notificarAprovacaoFerias(
                        ferias.getIdFuncionario(),
                        func.getNome(),
                        periodo,
                        false
                    );
                }
            } catch (Exception e) {
                System.err.println("⚠️ Erro ao notificar rejeição de férias: " + e.getMessage());
            }
            
            out.print("{\"success\":true,\"message\":\"Férias rejeitadas\"}");
            
        } catch (BusinessException e) {
            out.print("{\"success\":false,\"message\":\"" + e.getMessage() + "\"}");
        } catch (Exception e) {
            e.printStackTrace();
            out.print("{\"success\":false,\"message\":\"Erro ao rejeitar férias\"}");
        }
        
        out.flush();
    }
    
    // ============================================================
    // CHECKOUT (INICIAR FÉRIAS - FUNCIONÁRIO)
    // ============================================================
    private void checkout(HttpServletRequest request, HttpServletResponse response, Usuario usuario) 
            throws IOException {
        
        response.setContentType("application/json");
        PrintWriter out = response.getWriter();
        
        try {
            Integer id = Integer.parseInt(request.getParameter("id"));
            
            Ferias ferias = feriasDAO.buscarPorId(id);
            if (ferias == null) {
                out.print("{\"success\":false,\"message\":\"Férias não encontradas\"}");
                out.flush();
                return;
            }
            
            if (!usuario.isAdmin() && !usuario.isRH() && 
                (usuario.getIdFuncionario() == null || 
                 !usuario.getIdFuncionario().equals(ferias.getIdFuncionario()))) {
                out.print("{\"success\":false,\"message\":\"Acesso negado\"}");
                out.flush();
                return;
            }
            
            if (!"APROVADA".equals(ferias.getStatus())) {
                out.print("{\"success\":false,\"message\":\"Apenas férias aprovadas podem ser iniciadas\"}");
                out.flush();
                return;
            }
            
            // Verificar se a data de início já chegou
            Date hoje = new Date(System.currentTimeMillis());
            if (ferias.getDataInicio().after(hoje)) {
                out.print("{\"success\":false,\"message\":\"A data de início das férias ainda não chegou\"}");
                out.flush();
                return;
            }
            
            ferias.setStatus("EM_ANDAMENTO");
            ferias.setDataCheckout(new Timestamp(System.currentTimeMillis()));
            feriasDAO.atualizar(ferias);
            
            auditoriaService.registrar(
                usuario, 
                "UPDATE", 
                "ferias", 
                id, 
                "Status: APROVADA",
                "Status: EM_ANDAMENTO (Checkout)"
            );
            
            out.print("{\"success\":true,\"message\":\"Checkout realizado com sucesso!\"}");
            
        } catch (BusinessException e) {
            out.print("{\"success\":false,\"message\":\"" + e.getMessage() + "\"}");
        } catch (Exception e) {
            e.printStackTrace();
            out.print("{\"success\":false,\"message\":\"Erro ao fazer checkout\"}");
        }
        
        out.flush();
    }
    
    // ============================================================
    // CHECKIN (FINALIZAR FÉRIAS - FUNCIONÁRIO)
    // ============================================================
    private void checkin(HttpServletRequest request, HttpServletResponse response, Usuario usuario) 
            throws IOException {
        
        response.setContentType("application/json");
        PrintWriter out = response.getWriter();
        
        try {
            Integer id = Integer.parseInt(request.getParameter("id"));
            
            Ferias ferias = feriasDAO.buscarPorId(id);
            if (ferias == null) {
                out.print("{\"success\":false,\"message\":\"Férias não encontradas\"}");
                out.flush();
                return;
            }
            
            if (!usuario.isAdmin() && !usuario.isRH() && 
                (usuario.getIdFuncionario() == null || 
                 !usuario.getIdFuncionario().equals(ferias.getIdFuncionario()))) {
                out.print("{\"success\":false,\"message\":\"Acesso negado\"}");
                out.flush();
                return;
            }
            
            if (!"EM_ANDAMENTO".equals(ferias.getStatus())) {
                out.print("{\"success\":false,\"message\":\"Apenas férias em andamento podem ser finalizadas\"}");
                out.flush();
                return;
            }
            
            ferias.setStatus("CONCLUIDA");
            ferias.setDataCheckin(new Timestamp(System.currentTimeMillis()));
            feriasDAO.atualizar(ferias);
            
            auditoriaService.registrar(
                usuario, 
                "UPDATE", 
                "ferias", 
                id, 
                "Status: EM_ANDAMENTO",
                "Status: CONCLUIDA (Checkin)"
            );
            
            out.print("{\"success\":true,\"message\":\"Checkin realizado com sucesso!\"}");
            
        } catch (BusinessException e) {
            out.print("{\"success\":false,\"message\":\"" + e.getMessage() + "\"}");
        } catch (Exception e) {
            e.printStackTrace();
            out.print("{\"success\":false,\"message\":\"Erro ao fazer checkin\"}");
        }
        
        out.flush();
    }
    
    // ============================================================
    // CANCELAR SOLICITAÇÃO (FUNCIONÁRIO)
    // ============================================================
    private void cancelar(HttpServletRequest request, HttpServletResponse response, Usuario usuario) 
            throws ServletException, IOException {
        
        // GET - mostrar página de cancelamento (redirecionar para minhas férias)
        response.sendRedirect(request.getContextPath() + "/funcionario/minhas-ferias");
    }
    
    private void cancelarPost(HttpServletRequest request, HttpServletResponse response, Usuario usuario) 
            throws IOException {
        
        response.setContentType("application/json");
        PrintWriter out = response.getWriter();
        
        try {
            Integer id = Integer.parseInt(request.getParameter("id"));
            
            Ferias ferias = feriasDAO.buscarPorId(id);
            if (ferias == null) {
                out.print("{\"success\":false,\"message\":\"Férias não encontradas\"}");
                out.flush();
                return;
            }
            
            if (!usuario.isAdmin() && !usuario.isRH() && 
                (usuario.getIdFuncionario() == null || 
                 !usuario.getIdFuncionario().equals(ferias.getIdFuncionario()))) {
                out.print("{\"success\":false,\"message\":\"Acesso negado\"}");
                out.flush();
                return;
            }
            
            if (!"SOLICITADA".equals(ferias.getStatus())) {
                out.print("{\"success\":false,\"message\":\"Apenas solicitações pendentes podem ser canceladas\"}");
                out.flush();
                return;
            }
            
            ferias.setStatus("CANCELADA");
            feriasDAO.atualizar(ferias);
            
            auditoriaService.registrar(
                usuario, 
                "UPDATE", 
                "ferias", 
                id, 
                "Status: SOLICITADA",
                "Status: CANCELADA por " + usuario.getNome()
            );
            
            out.print("{\"success\":true,\"message\":\"Solicitação cancelada com sucesso!\"}");
            
        } catch (BusinessException e) {
            out.print("{\"success\":false,\"message\":\"" + e.getMessage() + "\"}");
        } catch (Exception e) {
            e.printStackTrace();
            out.print("{\"success\":false,\"message\":\"Erro ao cancelar solicitação\"}");
        }
        
        out.flush();
    }
    
    // ============================================================
    // INTERROMPER FÉRIAS (RH/GESTOR/ADMIN)
    // ============================================================
    private void mostrarInterromper(HttpServletRequest request, HttpServletResponse response, Usuario usuario) 
            throws ServletException, IOException {
        
        // GET - redirecionar para página de interrupção (modal via AJAX)
        response.sendError(HttpServletResponse.SC_METHOD_NOT_ALLOWED);
    }
    
    private void interromper(HttpServletRequest request, HttpServletResponse response, Usuario usuario) 
            throws IOException {
        
        response.setContentType("application/json");
        PrintWriter out = response.getWriter();
        
        if (!(usuario.isAdmin() || usuario.isRH() || usuario.isGestor())) {
            response.setStatus(HttpServletResponse.SC_FORBIDDEN);
            out.print("{\"success\":false,\"message\":\"Acesso negado\"}");
            out.flush();
            return;
        }
        
        try {
            Integer id = Integer.parseInt(request.getParameter("id"));
            String motivo = request.getParameter("motivo");
            String dataInicioStr = request.getParameter("dataInicio");
            String dataFimStr = request.getParameter("dataFim");
            
            if (motivo == null || motivo.trim().isEmpty()) {
                out.print("{\"success\":false,\"message\":\"Motivo da interrupção é obrigatório\"}");
                out.flush();
                return;
            }
            
            if (dataInicioStr == null || dataInicioStr.isEmpty() || 
                dataFimStr == null || dataFimStr.isEmpty()) {
                out.print("{\"success\":false,\"message\":\"Datas de início e fim da interrupção são obrigatórias\"}");
                out.flush();
                return;
            }
            
            Ferias ferias = feriasDAO.buscarPorId(id);
            if (ferias == null) {
                out.print("{\"success\":false,\"message\":\"Férias não encontradas\"}");
                out.flush();
                return;
            }
            
            if (!"EM_ANDAMENTO".equals(ferias.getStatus()) && !"APROVADA".equals(ferias.getStatus())) {
                out.print("{\"success\":false,\"message\":\"Apenas férias aprovadas ou em andamento podem ser interrompidas\"}");
                out.flush();
                return;
            }
            
            Date dataInicioInterrupcao = Date.valueOf(dataInicioStr);
            Date dataFimInterrupcao = Date.valueOf(dataFimStr);
            
            if (dataFimInterrupcao.before(dataInicioInterrupcao)) {
                out.print("{\"success\":false,\"message\":\"Data fim da interrupção não pode ser anterior à data início\"}");
                out.flush();
                return;
            }
            
            int diasInterrompidos = calcularDiasUteis(dataInicioInterrupcao, dataFimInterrupcao);
            
            ferias.setStatus("INTERROMPIDA");
            ferias.setMotivoInterrupcao(motivo);
            ferias.setDiasInterrompidos(diasInterrompidos);
            // Opcional: calcular dias compensados se necessário
            // ferias.setDiasCompensados(...);
            
            feriasDAO.atualizar(ferias);
            
            auditoriaService.registrar(
                usuario, 
                "UPDATE", 
                "ferias", 
                id, 
                "Status anterior",
                "Status: INTERROMPIDA por " + usuario.getNome() + ". Motivo: " + motivo + 
                ". Período: " + dataInicioStr + " a " + dataFimStr + " (" + diasInterrompidos + " dias)"
            );
            
            out.print("{\"success\":true,\"message\":\"Férias interrompidas com sucesso!\"}");
            
        } catch (BusinessException e) {
            out.print("{\"success\":false,\"message\":\"" + e.getMessage() + "\"}");
        } catch (Exception e) {
            e.printStackTrace();
            out.print("{\"success\":false,\"message\":\"Erro ao interromper férias: " + e.getMessage() + "\"}");
        }
        
        out.flush();
    }
    
    // ============================================================
    // UTILITÁRIO - CALCULAR DIAS ÚTEIS
    // ============================================================
    /**
     * Calcula o número de dias úteis (segunda a sexta) entre duas datas (inclusivo).
     */
    private int calcularDiasUteis(Date dataInicio, Date dataFim) {
        if (dataInicio == null || dataFim == null || dataFim.before(dataInicio)) {
            return 0;
        }
        
        Calendar cal = Calendar.getInstance();
        cal.setTime(dataInicio);
        
        int diasUteis = 0;
        
        while (!cal.getTime().after(dataFim)) {
            int diaSemana = cal.get(Calendar.DAY_OF_WEEK);
            // Segunda = 2 ... Sexta = 6
            if (diaSemana >= Calendar.MONDAY && diaSemana <= Calendar.FRIDAY) {
                diasUteis++;
            }
            cal.add(Calendar.DAY_OF_MONTH, 1);
        }
        
        return diasUteis;
    }
}
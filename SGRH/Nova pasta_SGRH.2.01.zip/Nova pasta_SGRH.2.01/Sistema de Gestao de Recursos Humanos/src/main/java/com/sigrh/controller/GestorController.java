package com.sigrh.controller;

import com.sigrh.exception.BusinessException;
import com.sigrh.model.Usuario;
import com.sigrh.service.FuncionarioService;
import com.sigrh.service.FeriasService;
import com.sigrh.util.Constants;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.List;

@WebServlet(urlPatterns = "/gestor/*")
public class GestorController extends HttpServlet {
    
    private static final long serialVersionUID = 1L;
    private final FuncionarioService funcionarioService;
    private final FeriasService feriasService;
    
    public GestorController() {
        this.funcionarioService = new FuncionarioService();
        this.feriasService = new FeriasService();
    }
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String path = request.getPathInfo();
        
        if (path == null || path.equals("/")) {
            response.sendRedirect(request.getContextPath() + "/dashboard");
            return;
        } else if (path.equals("/funcionarios")) {
            listarFuncionarios(request, response);
        } else if (path.equals("/ferias-pendentes")) {
            feriasPendentes(request, response);
        } else {
            response.sendError(HttpServletResponse.SC_NOT_FOUND);
        }
    }
    
    private void listarFuncionarios(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        Usuario usuario = (Usuario) request.getSession().getAttribute(Constants.SESSION_USER);
        if (usuario == null || !usuario.isGestor()) {
            request.getSession().setAttribute(Constants.MSG_ERRO, "Acesso negado");
            response.sendRedirect(request.getContextPath() + "/dashboard");
            return;
        }
        
        try {
            // Buscar funcionários do setor do gestor
            // Para simplificar, vamos listar todos
            var funcionarios = funcionarioService.listarTodos();
            request.setAttribute("funcionarios", funcionarios);
            request.setAttribute("total", funcionarios.size());
            
            request.getSession().removeAttribute(Constants.MSG_ERRO);
            request.getSession().removeAttribute(Constants.MSG_SUCESSO);
            request.getSession().removeAttribute(Constants.MSG_INFO);
            
            request.getRequestDispatcher("/WEB-INF/views/gestor/funcionarios.jsp").forward(request, response);
            
        } catch (BusinessException e) {
            request.getSession().setAttribute(Constants.MSG_ERRO, e.getMessage());
            response.sendRedirect(request.getContextPath() + "/dashboard");
        }
    }
    
    private void feriasPendentes(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        Usuario usuario = (Usuario) request.getSession().getAttribute(Constants.SESSION_USER);
        if (usuario == null || !usuario.isGestor()) {
            request.getSession().setAttribute(Constants.MSG_ERRO, "Acesso negado");
            response.sendRedirect(request.getContextPath() + "/dashboard");
            return;
        }
        
        try {
            var pendentes = feriasService.buscarPendentes();
            request.setAttribute("ferias", pendentes);
            request.setAttribute("total", pendentes.size());
            
            request.getSession().removeAttribute(Constants.MSG_ERRO);
            request.getSession().removeAttribute(Constants.MSG_SUCESSO);
            request.getSession().removeAttribute(Constants.MSG_INFO);
            
            request.getRequestDispatcher("/WEB-INF/views/gestor/ferias-pendentes.jsp").forward(request, response);
            
        } catch (BusinessException e) {
            request.getSession().setAttribute(Constants.MSG_ERRO, e.getMessage());
            response.sendRedirect(request.getContextPath() + "/dashboard");
        }
    }
}
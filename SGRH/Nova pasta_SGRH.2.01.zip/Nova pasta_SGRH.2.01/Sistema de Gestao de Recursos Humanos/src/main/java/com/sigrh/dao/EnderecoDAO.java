package com.sigrh.dao;

import com.sigrh.exception.DatabaseException;
import com.sigrh.model.Endereco;
import com.sigrh.util.DatabaseUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class EnderecoDAO extends GenericDAO<Endereco> {
    
    @Override
    protected String getTableName() {
        return "endereco";
    }
    
    @Override
    protected Endereco mapResultSetToEntity(ResultSet rs) throws SQLException {
        Endereco endereco = new Endereco();
        endereco.setId(rs.getInt("id"));
        endereco.setIdFuncionario(rs.getInt("id_funcionario"));
        endereco.setLogradouro(rs.getString("logradouro"));
        endereco.setNumero(rs.getString("numero"));
        endereco.setBairro(rs.getString("bairro"));
        endereco.setCidade(rs.getString("cidade"));
        endereco.setProvincia(rs.getString("provincia"));
        endereco.setCep(rs.getString("cep"));
        endereco.setComplemento(rs.getString("complemento"));
        endereco.setTipo(rs.getString("tipo"));
        endereco.setPrincipal(rs.getBoolean("principal"));
        endereco.setDataCadastro(rs.getTimestamp("data_cadastro"));
        return endereco;
    }
    
    @Override
    protected void setInsertParameters(PreparedStatement ps, Endereco entity) throws SQLException {
        ps.setInt(1, entity.getIdFuncionario());
        ps.setString(2, entity.getLogradouro());
        ps.setString(3, entity.getNumero());
        ps.setString(4, entity.getBairro());
        ps.setString(5, entity.getCidade());
        ps.setString(6, entity.getProvincia());
        ps.setString(7, entity.getCep());
        ps.setString(8, entity.getComplemento());
        ps.setString(9, entity.getTipo().name());
        ps.setBoolean(10, entity.getPrincipal());
    }
    
    @Override
    protected void setUpdateParameters(PreparedStatement ps, Endereco entity) throws SQLException {
        ps.setInt(1, entity.getIdFuncionario());
        ps.setString(2, entity.getLogradouro());
        ps.setString(3, entity.getNumero());
        ps.setString(4, entity.getBairro());
        ps.setString(5, entity.getCidade());
        ps.setString(6, entity.getProvincia());
        ps.setString(7, entity.getCep());
        ps.setString(8, entity.getComplemento());
        ps.setString(9, entity.getTipo().name());
        ps.setBoolean(10, entity.getPrincipal());
    }
    
    @Override
    protected String getInsertColumns() {
        return "id_funcionario, logradouro, numero, bairro, cidade, provincia, cep, complemento, tipo, principal";
    }
    
    @Override
    protected String getInsertPlaceholders() {
        return "?, ?, ?, ?, ?, ?, ?, ?, ?, ?";
    }
    
    @Override
    protected String getUpdateColumns() {
        return "id_funcionario = ?, logradouro = ?, numero = ?, bairro = ?, cidade = ?, " +
               "provincia = ?, cep = ?, complemento = ?, tipo = ?, principal = ?";
    }
    
    @Override
    protected int getUpdateParameterCount() {
        return 10;
    }
    
    @Override
    protected Integer getId(Endereco entity) {
        return entity.getId();
    }
    
    @Override
    protected void setId(Endereco entity, Integer id) {
        entity.setId(id);
    }
    
    /**
     * Busca endereços de um funcionário
     */
    public List<Endereco> findByFuncionario(Integer idFuncionario) throws DatabaseException {
        List<Endereco> list = new ArrayList<>();
        String sql = "SELECT * FROM " + getTableName() + " WHERE id_funcionario = ? ORDER BY principal DESC";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setInt(1, idFuncionario);
            
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(mapResultSetToEntity(rs));
                }
            }
            return list;
            
        } catch (SQLException e) {
            logger.error("Erro ao buscar endereços do funcionário ID {}", idFuncionario, e);
            throw new DatabaseException("Erro ao buscar endereços: " + e.getMessage(), e);
        }
    }
    
    /**
     * Busca endereço principal de um funcionário
     */
    public Endereco findPrincipalByFuncionario(Integer idFuncionario) throws DatabaseException {
        String sql = "SELECT * FROM " + getTableName() + 
                    " WHERE id_funcionario = ? AND principal = TRUE LIMIT 1";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setInt(1, idFuncionario);
            
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToEntity(rs);
                }
            }
            return null;
            
        } catch (SQLException e) {
            logger.error("Erro ao buscar endereço principal do funcionário ID {}", idFuncionario, e);
            throw new DatabaseException("Erro ao buscar endereço: " + e.getMessage(), e);
        }
    }
}
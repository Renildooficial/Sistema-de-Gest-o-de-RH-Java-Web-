package com.sigrh.model;

import java.sql.Date;
import java.time.LocalDate;
import java.time.Period;

public class AgregadoFamiliar extends BaseModel {
    
    private static final long serialVersionUID = 1L;
    
    public enum GrauParentesco {
        CONJUGE, FILHO, FILHA, PAI, MAE, IRMAO, IRMA, AVO, TIO, PRIMO, SOBRINHO, OUTRO
    }
    
    private Integer idFuncionario;
    private String nome;
    private GrauParentesco grauParentesco;
    private Date dataNascimento;
    private String tipoDocumento;  // ← NOVO: BI, PASSAPORTE, RG, CERTIDAO, OUTRO
    private String documento;
    private String observacao;
    private boolean ativo;
    
    private Funcionario funcionario;
    
    public AgregadoFamiliar() {
        super();
        this.ativo = true;
    }
    
    // ==================== GETTERS E SETTERS ====================
    public Integer getIdFuncionario() { return idFuncionario; }
    public void setIdFuncionario(Integer idFuncionario) { this.idFuncionario = idFuncionario; }
    
    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }
    
    public GrauParentesco getGrauParentesco() { return grauParentesco; }
    public void setGrauParentesco(GrauParentesco grauParentesco) { this.grauParentesco = grauParentesco; }
    public void setGrauParentesco(String grauParentesco) { 
        this.grauParentesco = GrauParentesco.valueOf(grauParentesco); 
    }
    
    public Date getDataNascimento() { return dataNascimento; }
    public void setDataNascimento(Date dataNascimento) { this.dataNascimento = dataNascimento; }
    
    public String getTipoDocumento() { return tipoDocumento; }
    public void setTipoDocumento(String tipoDocumento) { this.tipoDocumento = tipoDocumento; }
    
    public String getDocumento() { return documento; }
    public void setDocumento(String documento) { this.documento = documento; }
    
    public String getObservacao() { return observacao; }
    public void setObservacao(String observacao) { this.observacao = observacao; }
    
    public boolean isAtivo() { return ativo; }
    public void setAtivo(boolean ativo) { this.ativo = ativo; }
    
    public Funcionario getFuncionario() { return funcionario; }
    public void setFuncionario(Funcionario funcionario) { 
        this.funcionario = funcionario; 
        if (funcionario != null) {
            this.idFuncionario = funcionario.getId();
        }
    }
    
    // ==================== MÉTODOS DE CONVENIÊNCIA ====================
    public int getIdade() {
        if (dataNascimento == null) return 0;
        LocalDate nascimento = dataNascimento.toLocalDate();
        LocalDate hoje = LocalDate.now();
        return Period.between(nascimento, hoje).getYears();
    }
    
    public String getTipoDocumentoFormatado() {
        if (tipoDocumento == null) return "-";
        return switch (tipoDocumento) {
            case "BI" -> "Bilhete de Identidade";
            case "PASSAPORTE" -> "Passaporte";
            case "RG" -> "Registro Geral";
            case "CERTIDAO" -> "Certidão de Nascimento";
            default -> tipoDocumento;
        };
    }
    
    @Override
    public String toString() {
        return String.format("AgregadoFamiliar{id=%d, nome='%s', parentesco=%s}", 
                id, nome, grauParentesco);
    }
}
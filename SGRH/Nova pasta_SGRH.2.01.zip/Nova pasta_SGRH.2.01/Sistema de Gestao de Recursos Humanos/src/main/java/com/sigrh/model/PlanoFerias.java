package com.sigrh.model;

import java.sql.Timestamp;
import java.util.Date;

public class PlanoFerias extends BaseModel {
    
    private Integer id;
    private Integer idFuncionario;
    private Funcionario funcionario;
    private Integer mesPlanejado;
    private Integer ano;
    private Integer prioridade;
    private String status;
    private String observacao;
    private Timestamp dataCadastro;
    
    // Campo auxiliar para exibição do nome do mês
    private String nomeMes;
    
    // ============================================================
    // CONSTRUTORES
    // ============================================================
    public PlanoFerias() {}
    
    public PlanoFerias(Integer id, Integer idFuncionario, Integer mesPlanejado, 
                       Integer ano, Integer prioridade, String status, String observacao) {
        this.id = id;
        this.idFuncionario = idFuncionario;
        this.mesPlanejado = mesPlanejado;
        this.ano = ano;
        this.prioridade = prioridade;
        this.status = status;
        this.observacao = observacao;
    }
    
    // ============================================================
    // GETTERS E SETTERS
    // ============================================================
    public Integer getId() {
        return id;
    }
    
    public void setId(Integer id) {
        this.id = id;
    }
    
    public Integer getIdFuncionario() {
        return idFuncionario;
    }
    
    public void setIdFuncionario(Integer idFuncionario) {
        this.idFuncionario = idFuncionario;
    }
    
    public Funcionario getFuncionario() {
        return funcionario;
    }
    
    public void setFuncionario(Funcionario funcionario) {
        this.funcionario = funcionario;
    }
    
    public Integer getMesPlanejado() {
        return mesPlanejado;
    }
    
    public void setMesPlanejado(Integer mesPlanejado) {
        this.mesPlanejado = mesPlanejado;
    }
    
    public Integer getAno() {
        return ano;
    }
    
    public void setAno(Integer ano) {
        this.ano = ano;
    }
    
    public Integer getPrioridade() {
        return prioridade;
    }
    
    public void setPrioridade(Integer prioridade) {
        this.prioridade = prioridade;
    }
    
    public String getStatus() {
        return status;
    }
    
    public void setStatus(String status) {
        this.status = status;
    }
    
    public String getObservacao() {
        return observacao;
    }
    
    public void setObservacao(String observacao) {
        this.observacao = observacao;
    }
    
    @Override
    public Timestamp getDataCadastro() {
        return dataCadastro;
    }
    
    public void setDataCadastro(Timestamp dataCadastro) {
        this.dataCadastro = dataCadastro;
    }
    
    // ============================================================
    // GETTERS E SETTERS - AUXILIARES
    // ============================================================
    public String getNomeMes() {
        return nomeMes;
    }
    
    public void setNomeMes(String nomeMes) {
        this.nomeMes = nomeMes;
    }
    
    // ============================================================
    // MÉTODOS AUXILIARES
    // ============================================================
    public boolean isPendente() {
        return "PENDENTE".equals(this.status);
    }
    
    public boolean isAprovado() {
        return "APROVADO".equals(this.status);
    }
    
    public boolean isConcluido() {
        return "CONCLUIDO".equals(this.status);
    }
    
    public boolean isCancelado() {
        return "CANCELADO".equals(this.status);
    }
    
    public boolean isEmExecucao() {
        return "EM_EXECUCAO".equals(this.status);
    }
}
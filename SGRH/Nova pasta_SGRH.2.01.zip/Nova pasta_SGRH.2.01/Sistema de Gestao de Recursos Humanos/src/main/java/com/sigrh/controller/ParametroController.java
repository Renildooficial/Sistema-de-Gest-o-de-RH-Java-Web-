package com.sigrh.controller;

import com.sigrh.exception.BusinessException;
import com.sigrh.model.ParametroSistema;
import com.sigrh.model.Usuario;
import com.sigrh.service.ParametroService;
import com.sigrh.util.Constants;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import java.util.Map;

@WebServlet(urlPatterns = "/parametros/*")
public class ParametroController extends HttpServlet {
    
    private static final long serialVersionUID = 1L;
    private final ParametroService parametroService;
    
    public ParametroController() {
        this.parametroService = new ParametroService();
    }
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String path = request.getPathInfo();
        
        Usuario usuario = (Usuario) request.getSession().getAttribute(Constants.SESSION_USER);
        if (usuario == null || !usuario.isAdmin()) {
            request.getSession().setAttribute(Constants.MSG_ERRO, "Acesso negado");
            response.sendRedirect(request.getContextPath() + "/dashboard");
            return;
        }
        
        if (path == null || path.equals("/")) {
            listar(request, response);
        } else if (path.equals("/api")) {
            apiListar(request, response);
        } else if (path.startsWith("/buscar/")) {
            buscarPorChave(request, response);
        } else {
            response.sendError(HttpServletResponse.SC_NOT_FOUND);
        }
    }
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String path = request.getPathInfo();
        
        Usuario usuario = (Usuario) request.getSession().getAttribute(Constants.SESSION_USER);
        if (usuario == null || !usuario.isAdmin()) {
            request.getSession().setAttribute(Constants.MSG_ERRO, "Acesso negado");
            response.sendRedirect(request.getContextPath() + "/dashboard");
            return;
        }
        
        if (path == null || path.equals("/")) {
            salvar(request, response);
        } else if (path.equals("/excluir")) {
            excluir(request, response);
        } else {
            response.sendError(HttpServletResponse.SC_NOT_FOUND);
        }
    }
    
    private void listar(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        try {
            List<ParametroSistema> parametros = parametroService.listarTodos();
            
            // Agrupar por categoria
            Map<String, List<ParametroSistema>> categorias = new java.util.LinkedHashMap<>();
            for (ParametroSistema p : parametros) {
                String cat = p.getCategoria() != null ? p.getCategoria() : "Geral";
                categorias.computeIfAbsent(cat, k -> new java.util.ArrayList<>()).add(p);
            }
            
            request.setAttribute("categorias", categorias);
            request.setAttribute("parametros", parametros);
            request.setAttribute("total", parametros.size());
            
            request.getSession().removeAttribute(Constants.MSG_ERRO);
            request.getSession().removeAttribute(Constants.MSG_SUCESSO);
            request.getSession().removeAttribute(Constants.MSG_INFO);
            
            request.getRequestDispatcher("/WEB-INF/views/admin/parametros.jsp").forward(request, response);
            
        } catch (BusinessException e) {
            request.getSession().setAttribute(Constants.MSG_ERRO, e.getMessage());
            response.sendRedirect(request.getContextPath() + "/dashboard");
        }
    }
    
    private void salvar(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        try {
            String chave = request.getParameter("chave");
            String valor = request.getParameter("valor");
            String descricao = request.getParameter("descricao");
            String categoria = request.getParameter("categoria");
            
            if (chave == null || chave.trim().isEmpty()) {
                throw new BusinessException("Chave é obrigatória");
            }
            if (valor == null || valor.trim().isEmpty()) {
                throw new BusinessException("Valor é obrigatório");
            }
            
            ParametroSistema parametro = new ParametroSistema();
            parametro.setChave(chave);
            parametro.setValor(valor);
            parametro.setDescricao(descricao);
            parametro.setCategoria(categoria != null ? categoria : "Geral");
            
            parametroService.salvar(parametro);
            
            request.getSession().setAttribute(Constants.MSG_SUCESSO, 
                "Parâmetro '" + chave + "' salvo com sucesso!");
            
        } catch (BusinessException e) {
            request.getSession().setAttribute(Constants.MSG_ERRO, e.getMessage());
        }
        
        response.sendRedirect(request.getContextPath() + "/parametros");
    }
    
    private void excluir(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        
        response.setContentType("application/json");
        PrintWriter out = response.getWriter();
        
        try {
            String chave = request.getParameter("chave");
            parametroService.excluir(chave);
            
            out.print("{\"success\":true,\"message\":\"Parâmetro excluído com sucesso!\"}");
            
        } catch (BusinessException e) {
            out.print("{\"success\":false,\"message\":\"" + e.getMessage() + "\"}");
        }
        
        out.flush();
    }
    
    private void buscarPorChave(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        
        response.setContentType("application/json");
        PrintWriter out = response.getWriter();
        
        try {
            String chave = request.getPathInfo().substring("/buscar/".length());
            ParametroSistema parametro = parametroService.buscarPorChave(chave);
            
            if (parametro != null) {
                out.print("{");
                out.print("\"success\":true,");
                out.print("\"chave\":\"" + parametro.getChave() + "\",");
                out.print("\"valor\":\"" + parametro.getValor() + "\",");
                out.print("\"descricao\":\"" + parametro.getDescricao() + "\",");
                out.print("\"categoria\":\"" + parametro.getCategoria() + "\"");
                out.print("}");
            } else {
                out.print("{\"success\":false,\"message\":\"Parâmetro não encontrado\"}");
            }
            
        } catch (BusinessException e) {
            out.print("{\"success\":false,\"message\":\"" + e.getMessage() + "\"}");
        }
        
        out.flush();
    }
    
    private void apiListar(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        
        response.setContentType("application/json");
        PrintWriter out = response.getWriter();
        
        try {
            List<ParametroSistema> parametros = parametroService.listarTodos();
            
            StringBuilder json = new StringBuilder("[");
            for (int i = 0; i < parametros.size(); i++) {
                ParametroSistema p = parametros.get(i);
                json.append("{");
                json.append("\"id\":").append(p.getId()).append(",");
                json.append("\"chave\":\"").append(p.getChave()).append("\",");
                json.append("\"valor\":\"").append(p.getValor()).append("\",");
                json.append("\"descricao\":\"").append(p.getDescricao()).append("\",");
                json.append("\"categoria\":\"").append(p.getCategoria()).append("\"");
                json.append("}");
                if (i < parametros.size() - 1) json.append(",");
            }
            json.append("]");
            
            out.print(json.toString());
            
        } catch (BusinessException e) {
            out.print("[]");
        }
        
        out.flush();
    }
}
package com.sigrh.controller;

import com.sigrh.dao.NomeacaoDAO;
import com.sigrh.dao.FuncionarioDAO;
import com.sigrh.dao.UsuarioDAO;
import com.sigrh.model.Nomeacao;
import com.sigrh.model.Usuario;
import com.sigrh.model.Funcionario;
import com.sigrh.service.AuditoriaService;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.List;

@WebServlet(name = "NomeacaoController", urlPatterns = {"/nomeacoes", "/nomeacoes/*", "/nomeacao", "/nomeacao/*"})
public class NomeacaoController extends HttpServlet {
    
    private NomeacaoDAO nomeacaoDAO = new NomeacaoDAO();
    private FuncionarioDAO funcionarioDAO = new FuncionarioDAO();
    private UsuarioDAO usuarioDAO = new UsuarioDAO();
    private AuditoriaService auditoriaService = new AuditoriaService();
    
    private static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd");
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String pathInfo = request.getPathInfo();
        System.out.println("🔍 NomeacaoController.doGet - Path: " + pathInfo);
        
        try {
            if (pathInfo == null || pathInfo.equals("/") || pathInfo.equals("")) {
                listar(request, response);
            } else if (pathInfo.equals("/novo")) {
                novo(request, response);
            } else if (pathInfo.startsWith("/editar/")) {
                editar(request, response);
            } else if (pathInfo.equals("/ativas")) {
                listarAtivas(request, response);
            } else {
                response.sendError(HttpServletResponse.SC_NOT_FOUND);
            }
        } catch (Exception e) {
            e.printStackTrace();
            addMensagem(request, "error", "Erro ao processar requisição: " + e.getMessage());
            response.sendRedirect(request.getContextPath() + "/nomeacao");
        }
    }
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String pathInfo = request.getPathInfo();
        System.out.println("🔍 NomeacaoController.doPost - Path: " + pathInfo);
        System.out.println("🔥🔥🔥 MÉTODO DO POST CHAMADO! 🔥🔥🔥");
        
        try {
            if (pathInfo == null || pathInfo.equals("/") || pathInfo.equals("")) {
                salvar(request, response);
            } else if (pathInfo.equals("/excluir")) {
                excluir(request, response);
            } else if (pathInfo.equals("/encerrar")) {
                encerrar(request, response);
            } else {
                response.sendError(HttpServletResponse.SC_NOT_FOUND);
            }
        } catch (Exception e) {
            e.printStackTrace();
            response.setContentType("application/json");
            response.getWriter().write("{\"success\": false, \"message\": \"" + e.getMessage() + "\"}");
        }
    }
    
    // ============================================================
    // LISTAR
    // ============================================================
    private void listar(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        List<Nomeacao> nomeacoes = nomeacaoDAO.listarTodos();
        int total = nomeacaoDAO.contar();
        
        for (Nomeacao n : nomeacoes) {
            if (n.getIdFuncionario() != null) {
                try {
                    Funcionario f = funcionarioDAO.buscarPorId(n.getIdFuncionario());
                    n.setFuncionario(f);
                } catch (Exception e) {
                    System.err.println("Erro ao carregar funcionário: " + e.getMessage());
                }
            }
        }
        
        request.setAttribute("nomeacoes", nomeacoes);
        request.setAttribute("total", total);
        request.setAttribute("ativas", false);
        
        request.getRequestDispatcher("/WEB-INF/views/rh/nomeacoes.jsp").forward(request, response);
    }
    
    private void listarAtivas(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        List<Nomeacao> nomeacoes = nomeacaoDAO.listarAtivas();
        int total = nomeacaoDAO.contarAtivas();
        
        for (Nomeacao n : nomeacoes) {
            if (n.getIdFuncionario() != null) {
                try {
                    Funcionario f = funcionarioDAO.buscarPorId(n.getIdFuncionario());
                    n.setFuncionario(f);
                } catch (Exception e) {
                    System.err.println("Erro ao carregar funcionário: " + e.getMessage());
                }
            }
        }
        
        request.setAttribute("nomeacoes", nomeacoes);
        request.setAttribute("total", total);
        request.setAttribute("ativas", true);
        
        request.getRequestDispatcher("/WEB-INF/views/rh/nomeacoes.jsp").forward(request, response);
    }
    
    // ============================================================
    // NOVO
    // ============================================================
    private void novo(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        List<Funcionario> funcionarios = funcionarioDAO.listarTodos();
        request.setAttribute("funcionarios", funcionarios);
        request.setAttribute("acao", "cadastrar");
        request.setAttribute("nomeacao", new Nomeacao());
        
        request.getRequestDispatcher("/WEB-INF/views/rh/nomeacao-form.jsp").forward(request, response);
    }
    
    // ============================================================
    // EDITAR
    // ============================================================
    private void editar(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String pathInfo = request.getPathInfo();
        String[] parts = pathInfo.split("/");
        
        if (parts.length < 3) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST);
            return;
        }
        
        try {
            Integer id = Integer.parseInt(parts[2]);
            System.out.println("🔍 Editando nomeação ID: " + id);
            
            Nomeacao nomeacao = nomeacaoDAO.buscarPorId(id);
            
            if (nomeacao == null) {
                System.out.println("❌ Nomeação não encontrada!");
                response.sendError(HttpServletResponse.SC_NOT_FOUND);
                return;
            }
            
            if (nomeacao.getIdFuncionario() != null) {
                try {
                    Funcionario f = funcionarioDAO.buscarPorId(nomeacao.getIdFuncionario());
                    nomeacao.setFuncionario(f);
                } catch (Exception e) {
                    System.err.println("Erro ao carregar funcionário: " + e.getMessage());
                }
            }
            
            List<Funcionario> funcionarios = funcionarioDAO.listarTodos();
            request.setAttribute("funcionarios", funcionarios);
            request.setAttribute("nomeacao", nomeacao);
            request.setAttribute("acao", "editar");
            
            request.getRequestDispatcher("/WEB-INF/views/rh/nomeacao-form.jsp").forward(request, response);
            
        } catch (NumberFormatException e) {
            System.err.println("❌ ID inválido: " + e.getMessage());
            response.sendError(HttpServletResponse.SC_BAD_REQUEST);
        } catch (Exception e) {
            e.printStackTrace();
            addMensagem(request, "error", "Erro ao carregar nomeação: " + e.getMessage());
            response.sendRedirect(request.getContextPath() + "/nomeacao");
        }
    }
    
    // ============================================================
    // SALVAR
    // ============================================================
    private void salvar(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        System.out.println("🔥🔥🔥 MÉTODO SALVAR CHAMADO! 🔥🔥🔥");
        
        try {
            String idStr = request.getParameter("id");
            Integer id = idStr != null && !idStr.isEmpty() ? Integer.parseInt(idStr) : null;
            
            String idFuncionarioStr = request.getParameter("idFuncionario");
            String despacho = request.getParameter("despacho");
            String local = request.getParameter("local");
            String dataNomeacaoStr = request.getParameter("dataNomeacao");
            String dataInicioStr = request.getParameter("dataInicio");
            String dataFimStr = request.getParameter("dataFim");
            String status = request.getParameter("status");
            String observacao = request.getParameter("observacao");
            
            String[] funcoesArray = request.getParameterValues("funcoes");
            String funcoes = null;
            if (funcoesArray != null && funcoesArray.length > 0) {
                funcoes = String.join(",", funcoesArray);
            }
            
            String cargo = request.getParameter("cargo");
            
            System.out.println("📝 ID: " + id);
            System.out.println("📝 Funcionário: " + idFuncionarioStr);
            System.out.println("📝 Despacho: " + despacho);
            System.out.println("📝 Status: " + status);
            System.out.println("📝 Funções: " + funcoes);
            System.out.println("📝 Cargo: " + cargo);
            
            // VALIDAÇÕES
            if (idFuncionarioStr == null || idFuncionarioStr.isEmpty()) {
                addMensagem(request, "error", "Funcionário é obrigatório");
                request.getRequestDispatcher("/WEB-INF/views/rh/nomeacao-form.jsp").forward(request, response);
                return;
            }
            
            if (despacho == null || despacho.trim().isEmpty()) {
                addMensagem(request, "error", "Despacho é obrigatório");
                request.getRequestDispatcher("/WEB-INF/views/rh/nomeacao-form.jsp").forward(request, response);
                return;
            }
            
            if (funcoes == null || funcoes.isEmpty()) {
                addMensagem(request, "error", "Pelo menos uma função é obrigatória");
                request.getRequestDispatcher("/WEB-INF/views/rh/nomeacao-form.jsp").forward(request, response);
                return;
            }
            
            if (cargo == null || cargo.isEmpty()) {
                addMensagem(request, "error", "Cargo é obrigatório");
                request.getRequestDispatcher("/WEB-INF/views/rh/nomeacao-form.jsp").forward(request, response);
                return;
            }
            
            // Criar objeto Nomeacao
            Nomeacao nomeacao = new Nomeacao();
            if (id != null) {
                nomeacao.setId(id);
            }
            nomeacao.setIdFuncionario(Integer.parseInt(idFuncionarioStr));
            nomeacao.setFuncao(funcoes);
            nomeacao.setFuncoes(funcoes);
            nomeacao.setCargo(cargo);
            nomeacao.setDespacho(despacho);
            nomeacao.setLocal(local);
            
            if (dataNomeacaoStr != null && !dataNomeacaoStr.isEmpty()) {
                nomeacao.setDataNomeacao(DATE_FORMAT.parse(dataNomeacaoStr));
            }
            if (dataInicioStr != null && !dataInicioStr.isEmpty()) {
                nomeacao.setDataInicio(DATE_FORMAT.parse(dataInicioStr));
            }
            if (dataFimStr != null && !dataFimStr.isEmpty()) {
                nomeacao.setDataFim(DATE_FORMAT.parse(dataFimStr));
            }
            
            nomeacao.setStatus(status != null ? status : "ATIVA");
            nomeacao.setObservacao(observacao);
            
            // SALVAR
            if (id == null) {
                System.out.println("📝 Inserindo nova nomeação...");
                nomeacaoDAO.salvar(nomeacao);
                addMensagem(request, "success", "Nomeação cadastrada com sucesso!");
            } else {
                System.out.println("📝 Atualizando nomeação ID: " + id);
                nomeacaoDAO.atualizar(nomeacao);
                addMensagem(request, "success", "Nomeação atualizada com sucesso!");
            }
            
            // AUDITORIA
            HttpSession session = request.getSession();
            String nomeUsuario = (String) session.getAttribute("usuarioLogado");
            
            if (nomeUsuario != null && !nomeUsuario.isEmpty()) {
                try {
                    Usuario usuarioLogado = usuarioDAO.findByUsuario(nomeUsuario);
                    
                    if (usuarioLogado != null) {
                        auditoriaService.registrar(
                            usuarioLogado,
                            id == null ? "CREATE" : "UPDATE",
                            "nomeacao",
                            nomeacao.getId(),
                            null,
                            "ID: " + nomeacao.getId() + ", Funções: " + funcoes + ", Cargo: " + cargo,
                            request
                        );
                    }
                } catch (Exception e) {
                    System.err.println("Erro ao registrar auditoria: " + e.getMessage());
                }
            }
            
            response.sendRedirect(request.getContextPath() + "/nomeacao");
            
        } catch (Exception e) {
            e.printStackTrace();
            addMensagem(request, "error", "Erro ao salvar nomeação: " + e.getMessage());
            request.getRequestDispatcher("/WEB-INF/views/rh/nomeacao-form.jsp").forward(request, response);
        }
    }
    
    // ============================================================
    // EXCLUIR
    // ============================================================
    private void excluir(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        response.setContentType("application/json");
        response.getWriter().write("{\"success\": false, \"message\": \"Exclusão de nomeações não é permitida\"}");
    }
    
    // ============================================================
    // ENCERRAR
    // ============================================================
    private void encerrar(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String idStr = request.getParameter("id");
        if (idStr == null || idStr.isEmpty()) {
            response.setContentType("application/json");
            response.getWriter().write("{\"success\": false, \"message\": \"ID não informado\"}");
            return;
        }
        
        try {
            Integer id = Integer.parseInt(idStr);
            System.out.println("🔍 Encerrando nomeação ID: " + id);
            nomeacaoDAO.encerrar(id);
            
            response.setContentType("application/json");
            response.getWriter().write("{\"success\": true, \"message\": \"Nomeação encerrada com sucesso!\"}");
            
        } catch (Exception e) {
            System.err.println("❌ Erro ao encerrar: " + e.getMessage());
            response.setContentType("application/json");
            response.getWriter().write("{\"success\": false, \"message\": \"" + e.getMessage() + "\"}");
        }
    }
    
    // ============================================================
    // MÉTODOS AUXILIARES
    // ============================================================
    private void addMensagem(HttpServletRequest request, String tipo, String mensagem) {
        HttpSession session = request.getSession();
        session.setAttribute("mensagem_tipo", tipo);
        session.setAttribute("mensagem", mensagem);
    }
}
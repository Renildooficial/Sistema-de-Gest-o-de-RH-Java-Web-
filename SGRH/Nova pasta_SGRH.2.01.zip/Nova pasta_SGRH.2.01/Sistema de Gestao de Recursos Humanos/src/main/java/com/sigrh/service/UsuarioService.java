package com.sigrh.service;

import com.sigrh.dao.UsuarioDAO;
import com.sigrh.model.Usuario;
import com.sigrh.model.Usuario.Perfil;
import com.sigrh.exception.DatabaseException;
import com.sigrh.util.PasswordUtil;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class UsuarioService {
    
    private final UsuarioDAO usuarioDAO;
    
    public UsuarioService() {
        this.usuarioDAO = new UsuarioDAO();
    }
    
    // ============================================================
    // MÉTODOS CRUD
    // ============================================================
    
    public List<Usuario> listarTodos() {
        try {
            return usuarioDAO.listarTodos();
        } catch (DatabaseException e) {
            e.printStackTrace();
            return new ArrayList<>();
        }
    }
    
    public Usuario buscarPorId(Integer id) {
        try {
            return usuarioDAO.buscarPorId(id);
        } catch (DatabaseException e) {
            e.printStackTrace();
            return null;
        }
    }
    
    public Usuario buscarPorUsuario(String username) {
        try {
            return usuarioDAO.findByUsuario(username);
        } catch (DatabaseException e) {
            e.printStackTrace();
            return null;
        }
    }
    
    public Usuario buscarPorEmail(String email) {
        try {
            return usuarioDAO.findByEmail(email);
        } catch (DatabaseException e) {
            e.printStackTrace();
            return null;
        }
    }
    
    public void salvar(Usuario usuario) throws Exception {
        try {
            usuarioDAO.salvar(usuario);
        } catch (DatabaseException e) {
            throw new Exception("Erro ao salvar usuário: " + e.getMessage());
        }
    }
    
    public void atualizar(Usuario usuario) throws Exception {
        try {
            usuarioDAO.atualizar(usuario);
        } catch (DatabaseException e) {
            throw new Exception("Erro ao atualizar usuário: " + e.getMessage());
        }
    }
    
    public void excluir(Integer id) throws Exception {
        try {
            usuarioDAO.excluir(id);
        } catch (DatabaseException e) {
            throw new Exception("Erro ao excluir usuário: " + e.getMessage());
        }
    }
    
    public int contar() {
        try {
            return usuarioDAO.contar();
        } catch (DatabaseException e) {
            e.printStackTrace();
            return 0;
        }
    }
    
    public int contarAtivos() {
        try {
            return usuarioDAO.contarAtivos();
        } catch (DatabaseException e) {
            e.printStackTrace();
            return 0;
        }
    }
    
    // ============================================================
    // MÉTODOS DE BUSCA ESPECÍFICOS
    // ============================================================
    
    public List<Usuario> buscarPorPerfil(Perfil perfil) {
        try {
            return usuarioDAO.buscarPorPerfil(perfil);
        } catch (SQLException e) {
            e.printStackTrace();
            return new ArrayList<>();
        }
    }
    
    public Usuario buscarPorFuncionario(Integer idFuncionario) {
        try {
            return usuarioDAO.buscarPorFuncionario(idFuncionario);
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }
    
    public List<Usuario> buscarPorPerfil(String perfil) {
        try {
            return usuarioDAO.findByPerfil(perfil);
        } catch (DatabaseException e) {
            e.printStackTrace();
            return new ArrayList<>();
        }
    }
    
    public List<Usuario> buscarPorStatus(String status) {
        try {
            return usuarioDAO.findByStatus(status);
        } catch (DatabaseException e) {
            e.printStackTrace();
            return new ArrayList<>();
        }
    }
    
    // ============================================================
    // MÉTODOS DE AUTENTICAÇÃO - CORRIGIDOS
    // ============================================================
    
    public Usuario autenticar(String username, String senha) {
        try {
            Usuario usuario = usuarioDAO.findByUsuario(username);
            if (usuario == null) {
                System.out.println("⚠️ Usuário não encontrado: " + username);
                return null;
            }
            
            // Verificar se o usuário está ativo
            if (usuario.getStatus() != Usuario.Status.ATIVO) {
                System.out.println("⚠️ Usuário inativo: " + username);
                return null;
            }
            
            // Verificar senha - usando PasswordUtil.verifyPassword
            if (!PasswordUtil.verifyPassword(senha, usuario.getSenha())) {
                System.out.println("⚠️ Senha inválida para: " + username);
                return null;
            }
            
            // Atualizar último login
            usuarioDAO.atualizarUltimoLogin(usuario.getId());
            System.out.println("✅ Usuário autenticado: " + username);
            
            return usuario;
            
        } catch (DatabaseException e) {
            e.printStackTrace();
            return null;
        }
    }
    
    public boolean autenticarComToken(String token) {
        try {
            Usuario usuario = usuarioDAO.findByTokenRecuperacao(token);
            return usuario != null;
        } catch (DatabaseException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    // ============================================================
    // MÉTODOS DE SENHA - CORRIGIDOS
    // ============================================================
    
    public void alterarSenha(Integer id, String novaSenha) throws Exception {
        try {
            String senhaHash = PasswordUtil.hashPassword(novaSenha);
            if (senhaHash == null) {
                throw new Exception("Erro ao gerar hash da senha");
            }
            usuarioDAO.updateSenha(id, senhaHash);
        } catch (DatabaseException e) {
            throw new Exception("Erro ao alterar senha: " + e.getMessage());
        }
    }
    
    public void resetarSenha(String email) throws Exception {
        try {
            Usuario usuario = usuarioDAO.findByEmail(email);
            if (usuario == null) {
                throw new Exception("Usuário não encontrado");
            }
            
            String token = PasswordUtil.generateToken();
            String senhaTemporaria = PasswordUtil.generateCodigoVerificacao();
            String senhaHash = PasswordUtil.hashPassword(senhaTemporaria);
            
            if (senhaHash == null) {
                throw new Exception("Erro ao gerar hash da senha temporária");
            }
            
            // Atualizar senha e token
            usuario.setSenha(senhaHash);
            usuario.setTokenRecuperacao(token);
            usuarioDAO.atualizar(usuario);
            
            System.out.println("🔑 Senha temporária gerada para: " + email + " → " + senhaTemporaria);
            // TODO: Enviar email com a senha temporária
            // EmailService.enviarSenhaTemporaria(usuario.getEmail(), senhaTemporaria);
            
        } catch (DatabaseException e) {
            throw new Exception("Erro ao resetar senha: " + e.getMessage());
        }
    }
    
    public boolean isSenhaForte(String senha) {
        if (senha == null || senha.length() < 8) {
            return false;
        }
        
        boolean hasUpper = false;
        boolean hasLower = false;
        boolean hasDigit = false;
        boolean hasSpecial = false;
        
        for (char c : senha.toCharArray()) {
            if (Character.isUpperCase(c)) hasUpper = true;
            else if (Character.isLowerCase(c)) hasLower = true;
            else if (Character.isDigit(c)) hasDigit = true;
            else hasSpecial = true;
        }
        
        return hasUpper && hasLower && hasDigit && hasSpecial;
    }
    
    // ============================================================
    // MÉTODOS DE VALIDAÇÃO
    // ============================================================
    
    public boolean usuarioExiste(String username) {
        try {
            return usuarioDAO.findByUsuario(username) != null;
        } catch (DatabaseException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    public boolean emailExiste(String email) {
        try {
            return usuarioDAO.findByEmail(email) != null;
        } catch (DatabaseException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    public boolean isAdmin(Usuario usuario) {
        return usuario != null && usuario.getPerfil() == Perfil.ADMIN;
    }
    
    public boolean isRH(Usuario usuario) {
        return usuario != null && usuario.getPerfil() == Perfil.RH;
    }
    
    public boolean isFinanceiro(Usuario usuario) {
        return usuario != null && usuario.getPerfil() == Perfil.FINANCEIRO;
    }
    
    public boolean isGestor(Usuario usuario) {
        return usuario != null && usuario.getPerfil() == Perfil.GESTOR;
    }
    
    public boolean isFuncionario(Usuario usuario) {
        return usuario != null && usuario.getPerfil() == Perfil.FUNCIONARIO;
    }
    
    // ============================================================
    // MÉTODOS DE PERMISSÃO
    // ============================================================
    
    public boolean temPermissao(Usuario usuario, String... perfisPermitidos) {
        if (usuario == null) return false;
        if (usuario.getPerfil() == Perfil.ADMIN) return true;
        
        for (String perfil : perfisPermitidos) {
            if (usuario.getPerfil().name().equals(perfil)) {
                return true;
            }
        }
        return false;
    }
}
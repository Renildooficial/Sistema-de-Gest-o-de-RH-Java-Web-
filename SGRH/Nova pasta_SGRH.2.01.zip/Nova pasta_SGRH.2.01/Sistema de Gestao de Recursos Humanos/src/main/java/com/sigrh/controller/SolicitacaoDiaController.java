package com.sigrh.controller;

import com.sigrh.model.SolicitacaoDia;
import com.sigrh.model.Usuario;
import com.sigrh.service.SolicitacaoDiaService;
import com.sigrh.service.FeriasService;
import com.sigrh.util.Constants;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Date;

@WebServlet(urlPatterns = {"/solicitacao-dias", "/solicitacao-dias/*"})
public class SolicitacaoDiaController extends HttpServlet {
    
    private final SolicitacaoDiaService solicitacaoDiaService;
    private final FeriasService feriasService;
    
    public SolicitacaoDiaController() {
        this.solicitacaoDiaService = new SolicitacaoDiaService();
        this.feriasService = new FeriasService();
    }
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String path = request.getPathInfo();
        Usuario usuario = (Usuario) request.getSession().getAttribute(Constants.SESSION_USER);
        
        if (usuario == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }
        
        if (path == null || path.equals("/")) {
            // Listar solicitações
            listar(request, response, usuario);
        } else if (path.equals("/nova")) {
            // Mostrar formulário
            novaSolicitacao(request, response, usuario);
        } else {
            response.sendError(HttpServletResponse.SC_NOT_FOUND);
        }
    }
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String path = request.getPathInfo();
        Usuario usuario = (Usuario) request.getSession().getAttribute(Constants.SESSION_USER);
        
        if (usuario == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }
        
        try {
            if (path == null || path.equals("/")) {
                salvar(request, response, usuario);
            } else if (path.equals("/aprovar")) {
                aprovar(request, response, usuario);
            } else if (path.equals("/rejeitar")) {
                rejeitar(request, response, usuario);
            } else if (path.equals("/cancelar")) {
                cancelar(request, response, usuario);
            } else {
                response.sendError(HttpServletResponse.SC_NOT_FOUND);
            }
        } catch (Exception e) {
            e.printStackTrace();
            request.getSession().setAttribute(Constants.MSG_ERRO, "Erro: " + e.getMessage());
            response.sendRedirect(request.getContextPath() + "/solicitacao-dias");
        }
    }
    
    private void salvar(HttpServletRequest request, HttpServletResponse response, Usuario usuario) 
            throws ServletException, IOException {
        
        try {
            String dataStr = request.getParameter("data");
            String tipo = request.getParameter("tipo");
            String periodo = request.getParameter("periodo");
            String justificativa = request.getParameter("justificativa");
            
            if (dataStr == null || dataStr.isEmpty()) {
                throw new Exception("Data é obrigatória");
            }
            
            Date data = Date.valueOf(dataStr);
            
            SolicitacaoDia solicitacao = solicitacaoDiaService.solicitar(
                usuario.getIdFuncionario(),
                data,
                tipo,
                periodo,
                justificativa,
                usuario
            );
            
            request.getSession().setAttribute(Constants.MSG_SUCESSO, 
                "Solicitação de dia enviada com sucesso!");
            
        } catch (Exception e) {
            request.getSession().setAttribute(Constants.MSG_ERRO, e.getMessage());
        }
        
        response.sendRedirect(request.getContextPath() + "/solicitacao-dias");
    }
    
    private void aprovar(HttpServletRequest request, HttpServletResponse response, Usuario usuario) 
            throws IOException {
        
        try {
            Integer id = Integer.parseInt(request.getParameter("id"));
            solicitacaoDiaService.aprovar(id, usuario);
            
            response.setContentType("application/json");
            response.getWriter().write("{\"success\":true,\"message\":\"Solicitação aprovada!\"}");
            
        } catch (Exception e) {
            response.setContentType("application/json");
            response.getWriter().write("{\"success\":false,\"message\":\"" + e.getMessage() + "\"}");
        }
    }
    
    private void rejeitar(HttpServletRequest request, HttpServletResponse response, Usuario usuario) 
            throws IOException {
        
        try {
            Integer id = Integer.parseInt(request.getParameter("id"));
            String motivo = request.getParameter("motivo");
            solicitacaoDiaService.rejeitar(id, motivo, usuario);
            
            response.setContentType("application/json");
            response.getWriter().write("{\"success\":true,\"message\":\"Solicitação rejeitada!\"}");
            
        } catch (Exception e) {
            response.setContentType("application/json");
            response.getWriter().write("{\"success\":false,\"message\":\"" + e.getMessage() + "\"}");
        }
    }
    
    private void cancelar(HttpServletRequest request, HttpServletResponse response, Usuario usuario) 
            throws IOException {
        
        try {
            Integer id = Integer.parseInt(request.getParameter("id"));
            solicitacaoDiaService.cancelar(id, usuario);
            
            response.setContentType("application/json");
            response.getWriter().write("{\"success\":true,\"message\":\"Solicitação cancelada!\"}");
            
        } catch (Exception e) {
            response.setContentType("application/json");
            response.getWriter().write("{\"success\":false,\"message\":\"" + e.getMessage() + "\"}");
        }
    }
    
    private void listar(HttpServletRequest request, HttpServletResponse response, Usuario usuario) 
            throws ServletException, IOException {
        
        // Listar solicitações do funcionário
        request.getRequestDispatcher("/WEB-INF/views/funcionario/solicitacao-dias.jsp")
               .forward(request, response);
    }
    
    private void novaSolicitacao(HttpServletRequest request, HttpServletResponse response, Usuario usuario) 
            throws ServletException, IOException {
        
        request.getRequestDispatcher("/WEB-INF/views/funcionario/solicitar-dia.jsp")
               .forward(request, response);
    }
}
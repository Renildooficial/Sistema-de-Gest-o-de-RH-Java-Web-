package com.sigrh.service;

import com.sigrh.dao.FeriasDAO;
import com.sigrh.exception.BusinessException;
import com.sigrh.exception.DatabaseException;
import com.sigrh.model.Ferias;
import com.sigrh.model.Funcionario;

import java.sql.Date;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.*;

public class FeriasService {

    private final FeriasDAO feriasDAO;
    private final FuncionarioService funcionarioService;

    public FeriasService() {
        this.feriasDAO = new FeriasDAO();
        this.funcionarioService = new FuncionarioService();
    }

    // ============================================================
    // MÉTODOS DA VERSÃO 1 (NOVA) - PARA SOLICITACAODIASERVICE
    // ============================================================
    
    /**
     * Busca férias de um funcionário que se sobrepõem a um período específico.
     * Utilizado pelo SolicitacaoDiaService para verificar conflitos.
     */
    public List<Ferias> buscarPorFuncionarioPeriodo(Integer idFuncionario, Date inicio, Date fim) 
            throws BusinessException {
        
        if (idFuncionario == null) {
            throw new BusinessException("Funcionário não identificado");
        }
        
        try {
            // Buscar todas as férias do funcionário
            List<Ferias> todasFerias = feriasDAO.findByFuncionario(idFuncionario);
            List<Ferias> conflitantes = new ArrayList<>();
            
            for (Ferias f : todasFerias) {
                // Considera apenas férias com status que realmente ocupam tempo
                String status = f.getStatus();
                if ("APROVADA".equals(status) || "EM_ANDAMENTO".equals(status) || "CONCLUIDA".equals(status)) {
                    
                    // Verifica sobreposição
                    boolean sobrepoe = !(f.getDataFim().before(inicio) || f.getDataInicio().after(fim));
                    
                    if (sobrepoe) {
                        conflitantes.add(f);
                    }
                }
            }
            
            return conflitantes;
            
        } catch (DatabaseException e) {
            throw new BusinessException("Erro ao buscar férias por período: " + e.getMessage());
        }
    }
    
    
    /**
     * Verifica se existe conflito de férias para o período
     */
    public boolean existeConflito(Integer idFuncionario, Date inicio, Date fim) throws BusinessException {
        List<Ferias> conflitantes = buscarPorFuncionarioPeriodo(idFuncionario, inicio, fim);
        return !conflitantes.isEmpty();
    }

    // ============================================================
    // MÉTODOS DA VERSÃO 2 (EXISTENTE) - PARA FERIASCONTROLLER
    // ============================================================
    
    public List<Ferias> listarTodasFerias() throws BusinessException {
        try {
            return feriasDAO.listarTodasFerias();
        } catch (DatabaseException e) {
            throw new BusinessException("Erro ao listar todas as férias: " + e.getMessage());
        }
    }
    
    public List<Ferias> buscarPorFuncionario(Integer idFuncionario) throws BusinessException {
        try {
            return feriasDAO.findByFuncionario(idFuncionario);
        } catch (DatabaseException e) {
            throw new BusinessException("Erro ao buscar férias do funcionário: " + e.getMessage());
        }
    }
    
    public List<Ferias> buscarPorStatus(String status) throws BusinessException {
        try {
            return feriasDAO.findByStatus(status);
        } catch (DatabaseException e) {
            throw new BusinessException("Erro ao buscar férias por status: " + e.getMessage());
        }
    }
    
 
 // Em FeriasService.java
    public List<Ferias> buscarPendentes() throws BusinessException {
        try {
            return feriasDAO.findByStatus("SOLICITADA");
        } catch (Exception e) {
            throw new BusinessException("Erro ao buscar férias pendentes: " + e.getMessage());
        }
    }

    public List<Ferias> buscarTodas() throws BusinessException {
        try {
            return feriasDAO.listarTodos();
        } catch (Exception e) {
            throw new BusinessException("Erro ao buscar todas as férias: " + e.getMessage());
        }
    }
    public int calcularSaldoFerias(Integer idFuncionario) throws BusinessException {
        try {
            int diasUtilizados = feriasDAO.somarDiasAprovados(idFuncionario);
            int diasPendentes = feriasDAO.somarDiasPendentes(idFuncionario);
            int saldoTotal = 30; // Ajuste conforme regra de negócio
            return saldoTotal - diasUtilizados - diasPendentes;
        } catch (DatabaseException e) {
            throw new BusinessException("Erro ao calcular saldo de férias: " + e.getMessage());
        }
    }
    
    public int calcularDiasUtilizados(int idFuncionario) throws BusinessException {
        try {
            return feriasDAO.somarDiasAprovados(idFuncionario);
        } catch (DatabaseException e) {
            throw new BusinessException("Erro ao calcular dias utilizados: " + e.getMessage());
        }
    }
    
    public int contarPorStatus(int idFuncionario, String status) throws BusinessException {
        try {
            return feriasDAO.contarPorStatus(idFuncionario, status);
        } catch (DatabaseException e) {
            throw new BusinessException("Erro ao contar férias por status: " + e.getMessage());
        }
    }
    
    public Ferias buscarProximasFerias(int idFuncionario) throws BusinessException {
        try {
            java.sql.Date dataReferencia = new java.sql.Date(System.currentTimeMillis());
            List<Ferias> ferias = feriasDAO.listarPorFuncionario(
                idFuncionario, "APROVADA", dataReferencia
            );
            if (!ferias.isEmpty()) {
                return ferias.get(0);
            }
            return null;
        } catch (DatabaseException e) {
            throw new BusinessException("Erro ao buscar próximas férias: " + e.getMessage());
        }
    }
    
    /**
     * Busca férias de um funcionário para um mês específico (para calendário)
     */
    public List<Ferias> buscarPorMes(Integer idFuncionario, int mes, int ano) throws BusinessException {
        try {
            if (idFuncionario != null) {
                return feriasDAO.listarPorMes(idFuncionario, mes, ano);
            } else {
                // Busca todas as férias do mês
                return feriasDAO.findByPeriodo(
                    Date.valueOf(ano + "-" + String.format("%02d", mes) + "-01"),
                    Date.valueOf(ano + "-" + String.format("%02d", mes) + "-" + diasDoMes(mes, ano))
                );
            }
        } catch (DatabaseException e) {
            throw new BusinessException("Erro ao buscar férias por mês: " + e.getMessage());
        }
    }
    
    public Map<String, Object> buscarEventosMes(int idFuncionario, int mes, int ano) throws BusinessException {
        Map<String, Object> resultado = new HashMap<>();
        List<Map<String, Object>> dias = new ArrayList<>();
        
        try {
            List<Ferias> ferias = feriasDAO.listarPorMes(idFuncionario, mes, ano);
            
            // Carregar funcionários para cada férias
            for (Ferias f : ferias) {
                if (f.getIdFuncionario() != null) {
                    try {
                        Funcionario func = funcionarioService.buscarPorId(f.getIdFuncionario());
                        f.setFuncionario(func);
                    } catch (Exception e) {
                        // Ignorar
                    }
                }
            }
            
            // Criar estrutura de dias do mês
            Calendar cal = Calendar.getInstance();
            cal.set(ano, mes - 1, 1);
            int primeiroDiaSemana = cal.get(Calendar.DAY_OF_WEEK);
            int ultimoDia = cal.getActualMaximum(Calendar.DAY_OF_MONTH);
            
            // Adicionar dias do mês anterior
            Calendar calAnterior = (Calendar) cal.clone();
            calAnterior.add(Calendar.MONTH, -1);
            int ultimoDiaAnterior = calAnterior.getActualMaximum(Calendar.DAY_OF_MONTH);
            
            for (int i = primeiroDiaSemana - 1; i > 0; i--) {
                Map<String, Object> dia = new HashMap<>();
                dia.put("numero", ultimoDiaAnterior - i + 1);
                dia.put("classe", "other-month");
                dia.put("data", "");
                dia.put("eventos", new ArrayList<>());
                dias.add(dia);
            }
            
            // Adicionar dias do mês atual
            for (int i = 1; i <= ultimoDia; i++) {
                Map<String, Object> dia = new HashMap<>();
                dia.put("numero", i);
                
                cal.set(ano, mes - 1, i);
                int diaSemana = cal.get(Calendar.DAY_OF_WEEK);
                boolean isWeekend = diaSemana == Calendar.SATURDAY || diaSemana == Calendar.SUNDAY;
                dia.put("classe", isWeekend ? "weekend" : "");
                
                Calendar hoje = Calendar.getInstance();
                if (ano == hoje.get(Calendar.YEAR) && mes == hoje.get(Calendar.MONTH) + 1 &&
                    i == hoje.get(Calendar.DAY_OF_MONTH)) {
                    dia.put("classe", (dia.get("classe") != null ? dia.get("classe") + " " : "") + "today");
                }
                
                String dataStr = String.format("%04d-%02d-%02d", ano, mes, i);
                dia.put("data", dataStr);
                
                // Buscar eventos do dia
                List<Map<String, Object>> eventosDia = new ArrayList<>();
                Date diaAtual = new Date(cal.getTimeInMillis());
                for (Ferias f : ferias) {
                    Date inicio = f.getDataInicio();
                    Date fim = f.getDataFim();
                    if (inicio != null && fim != null) {
                        if (!diaAtual.before(inicio) && !diaAtual.after(fim)) {
                            Map<String, Object> evento = new HashMap<>();
                            evento.put("id", f.getId());
                            evento.put("nome", f.getFuncionario() != null ? 
                                f.getFuncionario().getNome().substring(0, Math.min(8, f.getFuncionario().getNome().length())) : "Férias");
                            evento.put("tipo", getTipoEvento(f.getStatus()));
                            evento.put("titulo", "Férias - " + (f.getFuncionario() != null ? f.getFuncionario().getNome() : ""));
                            evento.put("periodo", formatDate(inicio) + " → " + formatDate(fim));
                            evento.put("status", f.getStatus());
                            evento.put("dias", f.getDiasUteis());
                            evento.put("observacao", f.getObservacao());
                            evento.put("motivoRejeicao", f.getMotivoRejeicao());
                            evento.put("motivoInterrupcao", f.getMotivoInterrupcao());
                            evento.put("diasInterrompidos", f.getDiasInterrompidos() != null ? f.getDiasInterrompidos() : 0);
                            evento.put("diasCompensados", f.getDiasCompensados() != null ? f.getDiasCompensados() : 0);
                            eventosDia.add(evento);
                        }
                    }
                }
                
                dia.put("eventos", eventosDia);
                dias.add(dia);
            }
            
            resultado.put("dias", dias);
            
        } catch (DatabaseException e) {
            throw new BusinessException("Erro ao buscar eventos do mês: " + e.getMessage());
        }
        
        return resultado;
    }
    
    // ============================================================
    // INTERROMPER FÉRIAS
    // ============================================================
    
    public int interromperFerias(int idFerias, String dataInicioInterrupcao, 
                                 String dataFimInterrupcao, String motivo, 
                                 int idUsuario) throws Exception {
        
        Ferias ferias = feriasDAO.buscarPorId(idFerias);
        if (ferias == null) {
            throw new Exception("Férias não encontradas");
        }
        
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Date inicio = new Date(sdf.parse(dataInicioInterrupcao).getTime());
        Date fim = new Date(sdf.parse(dataFimInterrupcao).getTime());
        
        if (inicio.before(ferias.getDataInicio()) || fim.after(ferias.getDataFim())) {
            throw new Exception("A interrupção deve estar dentro do período das férias");
        }
        
        int diasInterrompidos = calcularDiasUteis(inicio, fim);
        
        ferias.setStatus("INTERROMPIDA");
        ferias.setDiasInterrompidos(diasInterrompidos);
        ferias.setMotivoInterrupcao(motivo);
        ferias.setDataInterrupcao(new Timestamp(System.currentTimeMillis()));
        
        feriasDAO.atualizar(ferias);
        
        return diasInterrompidos;
    }
    
    // ============================================================
    // MÉTODOS AUXILIARES
    // ============================================================
    
    private boolean datasSobrepoem(Date inicio1, Date fim1, Date inicio2, Date fim2) {
        return !(fim1.before(inicio2) || inicio1.after(fim2));
    }
    
    private String getTipoEvento(String status) {
        if (status == null) return "ferias";
        switch (status) {
            case "APROVADA": return "ferias";
            case "SOLICITADA": return "pendente";
            case "REJEITADA": return "rejeitada";
            case "INTERROMPIDA": return "interrompida";
            case "COMPENSADA": return "compensacao";
            case "AUSENCIA": return "ausencia";
            default: return "ferias";
        }
    }
    
    private String formatDate(Date date) {
        if (date == null) return "";
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        return sdf.format(date);
    }
    
    private int calcularDiasUteis(Date inicio, Date fim) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(inicio);
        int dias = 0;
        while (!cal.getTime().after(fim)) {
            int diaSemana = cal.get(Calendar.DAY_OF_WEEK);
            if (diaSemana != Calendar.SATURDAY && diaSemana != Calendar.SUNDAY) {
                dias++;
            }
            cal.add(Calendar.DAY_OF_MONTH, 1);
        }
        return dias;
    }
 // Em FeriasService.java
    public Ferias buscarPorId(Integer id) throws BusinessException {
        if (id == null || id <= 0) {
            throw new BusinessException("ID inválido");
        }
        try {
            Ferias ferias = feriasDAO.buscarPorId(id);
            if (ferias == null) {
                throw new BusinessException("Férias não encontradas");
            }
            return ferias;
        } catch (Exception e) {
            throw new BusinessException("Erro ao buscar férias: " + e.getMessage());
        }
    }
    
    private int diasDoMes(int mes, int ano) {
        switch (mes) {
            case 2:
                return (ano % 4 == 0 && (ano % 100 != 0 || ano % 400 == 0)) ? 29 : 28;
            case 4: case 6: case 9: case 11:
                return 30;
            default:
                return 31;
        }
    }
}
package com.sigrh.service;

import com.sigrh.model.Ferias;
import com.sigrh.model.FolhaPagamento;
import com.sigrh.model.Formacao;
import com.sigrh.model.Funcionario;
import com.sigrh.model.Nomeacao;
import com.sigrh.model.Usuario;
import com.sigrh.model.Usuario.Perfil;
import com.sigrh.util.ConfiguracaoUtil;

import java.math.BigDecimal;
import java.util.List;

public class SistemaNotificacaoService {
    
    private final NotificacaoService notificacaoService;
    private final UsuarioService usuarioService;
    private final ConfiguracaoUtil configuracaoUtil;
    
    public SistemaNotificacaoService() {
        this.notificacaoService = new NotificacaoService();
        this.usuarioService = new UsuarioService();
        this.configuracaoUtil = new ConfiguracaoUtil();
    }
    
    // ============================================================
    // MÉTODO PARA ENVIAR NOTIFICAÇÃO DIRETA (PARA USUÁRIO CONTROLLER)
    // ============================================================
    
    /**
     * Envia uma notificação para um usuário específico
     */
    public void enviarNotificacao(Integer idUsuario, String titulo, String mensagem, String tipo) {
        try {
            notificacaoService.enviarNotificacao(idUsuario, titulo, mensagem, tipo);
        } catch (Exception e) {
            System.err.println("❌ Erro ao enviar notificação: " + e.getMessage());
        }
    }
    
    /**
     * Envia uma notificação para um usuário específico (com Usuario object)
     */
    public void enviarNotificacao(Usuario usuario, String titulo, String mensagem, String tipo) {
        try {
            notificacaoService.enviarNotificacao(usuario.getId(), titulo, mensagem, tipo);
        } catch (Exception e) {
            System.err.println("❌ Erro ao enviar notificação: " + e.getMessage());
        }
    }
    
    // ============================================================
    // EVENTOS DE LOGIN
    // ============================================================
    
    /**
     * Notificar sobre novo login
     */
    public void notificarLogin(Usuario usuario, String ip, String navegador) {
        try {
            String titulo = "🔐 Novo Login";
            String mensagem = String.format(
                "Login realizado em %s às %s",
                new java.text.SimpleDateFormat("dd/MM/yyyy").format(new java.util.Date()),
                new java.text.SimpleDateFormat("HH:mm:ss").format(new java.util.Date())
            );
            
            notificacaoService.enviarNotificacao(
                usuario.getId(),
                titulo,
                mensagem,
                "INFO"
            );
            
            // Para ADMIN, enviar notificação com mais detalhes
            if (usuario.getPerfil() == Perfil.ADMIN || usuario.getPerfil() == Perfil.FINANCEIRO) {
                String tituloAdmin = "🔐 Login de " + usuario.getPerfil().name();
                String mensagemAdmin = String.format(
                    "Usuário: %s (%s)\nIP: %s\nData: %s",
                    usuario.getNome(),
                    usuario.getPerfil().name(),
                    ip != null ? ip : "N/A",
                    new java.text.SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(new java.util.Date())
                );
                
                notificacaoService.enviarParaPerfil(
                    Perfil.ADMIN,
                    tituloAdmin,
                    mensagemAdmin,
                    "INFO"
                );
            }
            
        } catch (Exception e) {
            System.err.println("❌ Erro ao notificar login: " + e.getMessage());
        }
    }
    
    /**
     * Notificar sobre último login
     */
    public void notificarUltimoLogin(Usuario usuario, java.util.Date ultimoLogin) {
        try {
            if (ultimoLogin == null) {
                String titulo = "👋 Primeiro Login!";
                String mensagem = String.format(
                    "Olá %s! Bem-vindo ao SIGRH.",
                    usuario.getNome()
                );
                notificacaoService.enviarNotificacao(usuario.getId(), titulo, mensagem, "SUCESSO");
            } else {
                String titulo = "🔄 Bem-vindo de volta!";
                String mensagem = String.format(
                    "Olá %s! Último acesso: %s",
                    usuario.getNome(),
                    new java.text.SimpleDateFormat("dd/MM/yyyy HH:mm").format(ultimoLogin)
                );
                notificacaoService.enviarNotificacao(usuario.getId(), titulo, mensagem, "SUCESSO");
            }
        } catch (Exception e) {
            System.err.println("❌ Erro ao notificar último login: " + e.getMessage());
        }
    }
    
    /**
     * Notificar sobre tentativa de login falha
     */
    public void notificarTentativaFalha(String usuario, String ip) {
        try {
            String titulo = "⚠️ Tentativa de Login Falha";
            String mensagem = String.format(
                "Houve uma tentativa de login falha no sistema.\n" +
                "Usuário: %s\n" +
                "IP: %s\n" +
                "Data: %s",
                usuario,
                ip != null ? ip : "Não disponível",
                new java.text.SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(new java.util.Date())
            );
            
            notificacaoService.enviarParaPerfil(Perfil.ADMIN, titulo, mensagem, "AVISO");
            
            Usuario user = usuarioService.buscarPorUsuario(usuario);
            if (user != null) {
                String tituloUser = "🔐 Tentativa de Acesso à Sua Conta";
                String mensagemUser = String.format(
                    "Houve uma tentativa de acesso à sua conta.\n" +
                    "IP: %s\n" +
                    "Data: %s\n\n" +
                    "Se não foi você, entre em contato com o suporte imediatamente!",
                    ip != null ? ip : "Não disponível",
                    new java.text.SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(new java.util.Date())
                );
                
                notificacaoService.enviarNotificacao(
                    user.getId(),
                    tituloUser,
                    mensagemUser,
                    "ERRO"
                );
            }
            
        } catch (Exception e) {
            System.err.println("❌ Erro ao notificar tentativa falha: " + e.getMessage());
        }
    }
    
    /**
     * Notificar sobre alteração de senha
     */
    public void notificarAlteracaoSenha(Integer idUsuario, String nome) {
        try {
            String titulo = "🔑 Senha Alterada com Sucesso";
            String mensagem = String.format(
                "Olá %s!\n\n" +
                "Sua senha foi alterada com sucesso em:\n" +
                "%s\n\n" +
                "Se você não realizou esta alteração, entre em contato com o suporte imediatamente.",
                nome,
                new java.text.SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(new java.util.Date())
            );
            
            notificacaoService.enviarNotificacao(
                idUsuario,
                titulo,
                mensagem,
                "SUCESSO"
            );
            
        } catch (Exception e) {
            System.err.println("❌ Erro ao notificar alteração de senha: " + e.getMessage());
        }
    }
    
    // ============================================================
    // EVENTOS DE FOLHA DE PAGAMENTO
    // ============================================================
    
    /**
     * Notificar quando uma folha é processada
     */
    public void notificarFolhaProcessada(Integer mes, Integer ano, Integer totalFuncionarios, BigDecimal totalLiquido) {
        try {
            String titulo = "📊 Folha de Pagamento Processada";
            String mensagem = String.format(
                "A folha de pagamento de %s/%d foi processada com sucesso!\n" +
                "Total de funcionários: %d\n" +
                "Valor total líquido: %s",
                getNomeMes(mes),
                ano,
                totalFuncionarios != null ? totalFuncionarios : 0,
                ConfiguracaoUtil.formatarMoeda(totalLiquido)
            );
            
            notificacaoService.enviarParaPerfil(Perfil.ADMIN, titulo, mensagem, "SUCESSO");
            notificacaoService.enviarParaPerfil(Perfil.FINANCEIRO, titulo, mensagem, "SUCESSO");
            
            notificarFolhaIndividual(mes, ano);
            
        } catch (Exception e) {
            System.err.println("❌ Erro ao notificar folha processada: " + e.getMessage());
        }
    }
    
    /**
     * Notificar cada funcionário sobre sua folha
     */
    private void notificarFolhaIndividual(Integer mes, Integer ano) {
        try {
            List<Usuario> usuarios = usuarioService.buscarPorPerfil(Perfil.FUNCIONARIO);
            if (usuarios != null) {
                for (Usuario u : usuarios) {
                    String titulo = "📄 Sua Folha de Pagamento";
                    String mensagem = String.format(
                        "Sua folha de pagamento referente a %s/%d está disponível.\n" +
                        "Acesse o sistema para visualizar os detalhes.",
                        getNomeMes(mes),
                        ano
                    );
                    
                    notificacaoService.enviarNotificacao(
                        u.getId(),
                        titulo,
                        mensagem,
                        "INFO"
                    );
                }
            }
        } catch (Exception e) {
            System.err.println("❌ Erro ao notificar folha individual: " + e.getMessage());
        }
    }
    
    /**
     * Notificar quando uma folha é paga
     */
    public void notificarFolhaPaga(Integer idFuncionario, String nome, BigDecimal valor) {
        try {
            Usuario usuario = usuarioService.buscarPorFuncionario(idFuncionario);
            if (usuario != null) {
                String titulo = "💰 Pagamento Confirmado";
                String mensagem = String.format(
                    "Olá %s!\n\n" +
                    "Seu pagamento foi confirmado no sistema.\n" +
                    "Valor líquido: %s\n" +
                    "Data: %s",
                    nome,
                    ConfiguracaoUtil.formatarMoeda(valor),
                    new java.text.SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(new java.util.Date())
                );
                
                notificacaoService.enviarNotificacao(
                    usuario.getId(),
                    titulo,
                    mensagem,
                    "SUCESSO"
                );
            }
            
            String tituloFinanceiro = "💵 Pagamento Realizado";
            String mensagemFinanceiro = String.format(
                "Pagamento confirmado para o funcionário: %s\n" +
                "Valor: %s",
                nome,
                ConfiguracaoUtil.formatarMoeda(valor)
            );
            
            notificacaoService.enviarParaPerfil(Perfil.FINANCEIRO, tituloFinanceiro, mensagemFinanceiro, "SUCESSO");
            
        } catch (Exception e) {
            System.err.println("❌ Erro ao notificar folha paga: " + e.getMessage());
        }
    }
    
    // ============================================================
    // EVENTOS DE FÉRIAS
    // ============================================================
    
    /**
     * Notificar sobre nova solicitação de férias
     */
    public void notificarSolicitacaoFerias(Integer idFuncionario, String nome, String periodo, String status) {
        try {
            String titulo = "🏖️ Nova Solicitação de Férias";
            String mensagem = String.format(
                "O funcionário %s solicitou férias.\n" +
                "Período: %s\n" +
                "Status: %s",
                nome,
                periodo,
                status
            );
            
            notificacaoService.enviarParaPerfil(Perfil.ADMIN, titulo, mensagem, "AVISO");
            notificacaoService.enviarParaPerfil(Perfil.RH, titulo, mensagem, "AVISO");
            
            Usuario usuario = usuarioService.buscarPorFuncionario(idFuncionario);
            if (usuario != null) {
                String tituloUser = "📋 Sua Solicitação de Férias";
                String mensagemUser = String.format(
                    "Sua solicitação de férias foi enviada com sucesso!\n" +
                    "Período: %s\n" +
                    "Status: %s\n\n" +
                    "Aguarde a aprovação.",
                    periodo,
                    status
                );
                
                notificacaoService.enviarNotificacao(
                    usuario.getId(),
                    tituloUser,
                    mensagemUser,
                    "INFO"
                );
            }
            
        } catch (Exception e) {
            System.err.println("❌ Erro ao notificar solicitação de férias: " + e.getMessage());
        }
    }
    
    /**
     * Notificar sobre aprovação/rejeição de férias
     */
    public void notificarAprovacaoFerias(Integer idFuncionario, String nome, String periodo, boolean aprovada) {
        try {
            Usuario usuario = usuarioService.buscarPorFuncionario(idFuncionario);
            if (usuario != null) {
                String titulo = aprovada ? "✅ Férias Aprovadas!" : "❌ Férias Rejeitadas";
                String mensagem = String.format(
                    "Sua solicitação de férias foi %s.\n" +
                    "Período: %s",
                    aprovada ? "APROVADA" : "REJEITADA",
                    periodo
                );
                
                String tipo = aprovada ? "SUCESSO" : "ERRO";
                notificacaoService.enviarNotificacao(
                    usuario.getId(),
                    titulo,
                    mensagem,
                    tipo
                );
            }
            
            String tituloAdmin = aprovada ? "✅ Férias Aprovadas" : "❌ Férias Rejeitadas";
            String mensagemAdmin = String.format(
                "%s para o funcionário %s.\n" +
                "Período: %s",
                tituloAdmin,
                nome,
                periodo
            );
            
            notificacaoService.enviarParaPerfil(Perfil.ADMIN, tituloAdmin, mensagemAdmin, aprovada ? "SUCESSO" : "AVISO");
            notificacaoService.enviarParaPerfil(Perfil.RH, tituloAdmin, mensagemAdmin, aprovada ? "SUCESSO" : "AVISO");
            
        } catch (Exception e) {
            System.err.println("❌ Erro ao notificar aprovação de férias: " + e.getMessage());
        }
    }
    
    // ============================================================
    // EVENTOS DE FUNCIONÁRIOS
    // ============================================================
    
    /**
     * Notificar sobre novo funcionário cadastrado
     */
    public void notificarNovoFuncionario(Funcionario funcionario) {
        try {
            String titulo = "🆕 Novo Funcionário Cadastrado";
            String mensagem = String.format(
                "O funcionário %s foi cadastrado no sistema.\n" +
                "ID: %d\n" +
                "Data: %s",
                funcionario.getNome(),
                funcionario.getId(),
                new java.text.SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(new java.util.Date())
            );
            // REMOVIDO: funcionario.getCargo() - não existe na classe Funcionario
            
            notificacaoService.enviarParaPerfil(Perfil.ADMIN, titulo, mensagem, "SUCESSO");
            notificacaoService.enviarParaPerfil(Perfil.RH, titulo, mensagem, "SUCESSO");
            
            Usuario usuario = usuarioService.buscarPorFuncionario(funcionario.getId());
            if (usuario != null) {
                String tituloUser = "👋 Bem-vindo(a) ao SIGRH!";
                String mensagemUser = String.format(
                    "Olá %s!\n\n" +
                    "Seu cadastro foi realizado com sucesso no Sistema Integrado de Gestão de Recursos Humanos.\n\n" +
                    "Bem-vindo(a) à equipe! 🎉",
                    funcionario.getNome()
                );
                
                notificacaoService.enviarNotificacao(
                    usuario.getId(),
                    tituloUser,
                    mensagemUser,
                    "SUCESSO"
                );
            }
            
        } catch (Exception e) {
            System.err.println("❌ Erro ao notificar novo funcionário: " + e.getMessage());
        }
    }
    
    // ============================================================
    // EVENTOS DE FORMAÇÕES
    // ============================================================
    
    /**
     * Notificar sobre nova formação adicionada
     */
    public void notificarNovaFormacao(Integer idFuncionario, String nome, String curso, String instituicao) {
        try {
            Usuario usuario = usuarioService.buscarPorFuncionario(idFuncionario);
            if (usuario != null) {
                String titulo = "🎓 Nova Formação Adicionada";
                String mensagem = String.format(
                    "Uma nova formação foi adicionada ao seu perfil:\n\n" +
                    "Curso: %s\n" +
                    "Instituição: %s",
                    curso,
                    instituicao
                );
                
                notificacaoService.enviarNotificacao(
                    usuario.getId(),
                    titulo,
                    mensagem,
                    "INFO"
                );
            }
            
            String tituloRH = "📚 Nova Formação Registrada";
            String mensagemRH = String.format(
                "Nova formação registrada para %s.\n" +
                "Curso: %s\n" +
                "Instituição: %s",
                nome,
                curso,
                instituicao
            );
            
            notificacaoService.enviarParaPerfil(Perfil.RH, tituloRH, mensagemRH, "INFO");
            
        } catch (Exception e) {
            System.err.println("❌ Erro ao notificar nova formação: " + e.getMessage());
        }
    }
    
    // ============================================================
    // MÉTODOS AUXILIARES
    // ============================================================
    
    private String getNomeMes(int mes) {
        String[] meses = {"Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho",
                          "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"};
        return meses[mes - 1];
    }
}
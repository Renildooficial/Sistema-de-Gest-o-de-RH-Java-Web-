package com.sigrh.controller;

import com.sigrh.exception.BusinessException;
import com.sigrh.model.Ferias;
import com.sigrh.model.Formacao;
import com.sigrh.model.Funcionario;
import com.sigrh.model.Nomeacao;
import com.sigrh.model.PlanoFerias;
import com.sigrh.model.Setor;
import com.sigrh.model.Usuario;
import com.sigrh.service.*;
import com.sigrh.util.Constants;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.Part;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;
import java.util.List;

@WebServlet(urlPatterns = {"/funcionarios/*", "/funcionario/*"})
@MultipartConfig(
    maxFileSize = 2 * 1024 * 1024,      // 2MB
    maxRequestSize = 4 * 1024 * 1024,   // 4MB
    fileSizeThreshold = 1024 * 1024     // 1MB
)
public class FuncionarioController extends HttpServlet {
    
    private static final long serialVersionUID = 1L;
    private final FuncionarioService funcionarioService;
    private final SetorService setorService;
    private final FeriasService feriasService;
    private final AuthService authService;
    private final AuditoriaService auditoriaService;
    private final FormacaoService formacaoService;
    private final NomeacaoService nomeacaoService;
    private final PlanoFeriasService planoFeriasService;
    private final SistemaNotificacaoService sistemaNotificacaoService;

    
    public FuncionarioController() {
        this.funcionarioService = new FuncionarioService();
        this.setorService = new SetorService();
        this.feriasService = new FeriasService();
        this.authService = new AuthService();
        this.auditoriaService = new AuditoriaService();
        this.formacaoService = new FormacaoService();  // ADICIONE
        this.nomeacaoService = new NomeacaoService();  // ADICIONE
        this.planoFeriasService = new PlanoFeriasService();  // <-- ADICIONE ESTA LINHA
        this.sistemaNotificacaoService = new SistemaNotificacaoService();

    }
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String path = request.getPathInfo();
        System.out.println("🔍 FuncionarioController.doGet - Path: " + path);
        
        if (request.getRequestURI().contains("/funcionario/")) {
            handleFuncionarioGet(request, response, path);
            return;
        }
        
        if (path == null || path.equals("/")) {
            listar(request, response);
        } else if (path.equals("/alterar-status")) {
            alterarStatus(request, response);
        
        } else if (path.equals("/novo")) {
            novo(request, response);
        } else if (path.startsWith("/editar/")) {
            editar(request, response);
        } else if (path.startsWith("/visualizar/")) {
            visualizar(request, response);
        } else if (path.equals("/buscar")) {
        	
            buscar(request, response);
        } else {
            response.sendError(HttpServletResponse.SC_NOT_FOUND);
        }
    }
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String path = request.getPathInfo();
        System.out.println("🔍 FuncionarioController.doPost - Path: " + path);
        
        if (request.getRequestURI().contains("/funcionario/")) {
            handleFuncionarioPost(request, response, path);
            return;
        }
        
        if (path == null || path.equals("/")) {
            salvar(request, response);
        } else if (path.equals("/excluir")) {
            excluir(request, response);
        } else {
            response.sendError(HttpServletResponse.SC_NOT_FOUND);
        }
    }
    
    // ============================================================
    // ROTAS PARA FUNCIONÁRIO (perfil)
    // ============================================================
    
    private void handleFuncionarioGet(HttpServletRequest request, HttpServletResponse response, String path) 
            throws ServletException, IOException {
        
        Usuario usuario = (Usuario) request.getSession().getAttribute(Constants.SESSION_USER);
        if (usuario == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }
        
        if (path == null || path.equals("/meus-dados")) {
            meusDados(request, response, usuario);
        } else if (path.equals("/minhas-ferias")) {
            minhasFerias(request, response, usuario);
        } else if (path.equals("/minhas-formacoes")) {
            minhasFormacoes(request, response, usuario);
        } else if (path.equals("/minhas-nomeacoes")) {
            minhasNomeacoes(request, response, usuario);
        } else if (path.equals("/alterar-senha")) {
            mostrarAlterarSenha(request, response);
        } else {
            response.sendError(HttpServletResponse.SC_NOT_FOUND);
        }
    }
    
    private void handleFuncionarioPost(HttpServletRequest request, HttpServletResponse response, String path) 
            throws ServletException, IOException {
        
        Usuario usuario = (Usuario) request.getSession().getAttribute(Constants.SESSION_USER);
        if (usuario == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }
        
        if (path.equals("/alterar-senha")) {
            alterarSenha(request, response, usuario);
        } else {
            response.sendError(HttpServletResponse.SC_NOT_FOUND);
        }
    }
    
    // ============================================================
    // MÉTODOS DO FUNCIONÁRIO
    // ============================================================
    
    private void meusDados(HttpServletRequest request, HttpServletResponse response, Usuario usuario) 
            throws ServletException, IOException {
        
        if (usuario.getIdFuncionario() == null) {
            request.getSession().setAttribute(Constants.MSG_ERRO, "Usuário não tem funcionário associado");
            response.sendRedirect(request.getContextPath() + "/dashboard");
            return;
        }
        
        try {
            Funcionario funcionario = funcionarioService.buscarCompleto(usuario.getIdFuncionario());
            request.setAttribute("funcionario", funcionario);
            request.getRequestDispatcher("/WEB-INF/views/funcionario/meus-dados.jsp").forward(request, response);
        } catch (BusinessException e) {
            request.getSession().setAttribute(Constants.MSG_ERRO, e.getMessage());
            response.sendRedirect(request.getContextPath() + "/dashboard");
        }
    }
    
    private void minhasFerias(HttpServletRequest request, HttpServletResponse response, Usuario usuario) 
            throws ServletException, IOException {
        
        if (usuario.getIdFuncionario() == null) {
            request.getSession().setAttribute(Constants.MSG_ERRO, "Usuário não tem funcionário associado");
            response.sendRedirect(request.getContextPath() + "/dashboard");
            return;
        }
        
        try {
            Integer idFuncionario = usuario.getIdFuncionario();
            
            // ============================================================
            // 1. ESTATÍSTICAS DE FÉRIAS
            // ============================================================
            List<Ferias> todas = feriasService.buscarPorFuncionario(idFuncionario);
            int saldo = feriasService.calcularSaldoFerias(idFuncionario);
            
            long pendentes = todas.stream().filter(f -> "SOLICITADA".equals(f.getStatus())).count();
            long aprovadas = todas.stream().filter(f -> "APROVADA".equals(f.getStatus())).count();
            long emAndamento = todas.stream().filter(f -> "EM_ANDAMENTO".equals(f.getStatus())).count();
            
            request.setAttribute("saldoFerias", saldo);
            request.setAttribute("pendentes", pendentes);
            request.setAttribute("aprovadas", aprovadas);
            request.setAttribute("emAndamento", emAndamento);
            request.setAttribute("total", todas.size());
            request.setAttribute("listaFerias", todas);
            
            // ============================================================
            // 2. PLANO DE FÉRIAS (definido pelo RH)
            // ============================================================
            // Você precisa ter um serviço para PlanoFerias.
            // Se ainda não tiver, crie um (veja observação abaixo).
            List<PlanoFerias> planos = planoFeriasService.buscarPorFuncionario(idFuncionario);
            request.setAttribute("planos", planos);
            request.setAttribute("totalPlanos", planos != null ? planos.size() : 0);
            
            // ============================================================
            // 3. ENCAMINHAR PARA A JSP
            // ============================================================
            request.getRequestDispatcher("/WEB-INF/views/funcionario/minhas-ferias.jsp").forward(request, response);
            
        } catch (BusinessException e) {
            request.getSession().setAttribute(Constants.MSG_ERRO, e.getMessage());
            response.sendRedirect(request.getContextPath() + "/dashboard");
        }
    }
    
    private void minhasFormacoes(HttpServletRequest request, HttpServletResponse response, Usuario usuario) 
            throws ServletException, IOException {
        
        if (usuario.getIdFuncionario() == null) {
            request.getSession().setAttribute(Constants.MSG_ERRO, "Usuário não tem funcionário associado");
            response.sendRedirect(request.getContextPath() + "/dashboard");
            return;
        }
        
        try {
            List<com.sigrh.model.Formacao> formacoes = new com.sigrh.dao.FormacaoDAO()
                    .findByFuncionario(usuario.getIdFuncionario());
            
            int total = formacoes.size();
            int concluidas = 0;
            int cursando = 0;
            for (com.sigrh.model.Formacao f : formacoes) {
                if ("CONCLUIDO".equals(f.getStatus())) concluidas++;
                else if ("CURSANDO".equals(f.getStatus())) cursando++;
            }
            
            request.setAttribute("formacoes", formacoes);
            request.setAttribute("total", total);
            request.setAttribute("concluidas", concluidas);
            request.setAttribute("cursando", cursando);
            request.getRequestDispatcher("/WEB-INF/views/funcionario/minhas-formacoes.jsp").forward(request, response);
        } catch (Exception e) {
            request.getSession().setAttribute(Constants.MSG_ERRO, "Erro ao carregar formações: " + e.getMessage());
            response.sendRedirect(request.getContextPath() + "/dashboard");
        }
    }
    
    private void minhasNomeacoes(HttpServletRequest request, HttpServletResponse response, Usuario usuario) 
            throws ServletException, IOException {
        
        if (usuario.getIdFuncionario() == null) {
            request.getSession().setAttribute(Constants.MSG_ERRO, "Usuário não tem funcionário associado");
            response.sendRedirect(request.getContextPath() + "/dashboard");
            return;
        }
        
        try {
            List<com.sigrh.model.Nomeacao> nomeacoes = new com.sigrh.dao.NomeacaoDAO()
                    .findByFuncionario(usuario.getIdFuncionario());
            
            int total = nomeacoes.size();
            int ativas = 0;
            for (com.sigrh.model.Nomeacao n : nomeacoes) {
                if ("ATIVA".equals(n.getStatus())) ativas++;
            }
            
            request.setAttribute("nomeacoes", nomeacoes);
            request.setAttribute("total", total);
            request.setAttribute("ativas", ativas);
            request.getRequestDispatcher("/WEB-INF/views/funcionario/minhas-nomeacoes.jsp").forward(request, response);
        } catch (Exception e) {
            request.getSession().setAttribute(Constants.MSG_ERRO, "Erro ao carregar nomeações: " + e.getMessage());
            response.sendRedirect(request.getContextPath() + "/dashboard");
        }
    }
    
    private void mostrarAlterarSenha(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        request.getRequestDispatcher("/WEB-INF/views/funcionario/alterar-senha.jsp").forward(request, response);
    }
    
    private void alterarSenha(HttpServletRequest request, HttpServletResponse response, Usuario usuario) 
            throws ServletException, IOException {
        
        try {
            String senhaAtual = request.getParameter("senhaAtual");
            String novaSenha = request.getParameter("novaSenha");
            String confirmarSenha = request.getParameter("confirmarSenha");
            
            if (senhaAtual == null || senhaAtual.trim().isEmpty()) {
                throw new BusinessException("Senha atual é obrigatória");
            }
            if (novaSenha == null || novaSenha.trim().isEmpty()) {
                throw new BusinessException("Nova senha é obrigatória");
            }
            if (!novaSenha.equals(confirmarSenha)) {
                throw new BusinessException("As senhas não coincidem");
            }
            
            authService.alterarSenha(usuario.getId(), senhaAtual, novaSenha);
            request.getSession().setAttribute(Constants.MSG_SUCESSO, "Senha alterada com sucesso!");
            response.sendRedirect(request.getContextPath() + "/dashboard");
        } catch (BusinessException e) {
            request.getSession().setAttribute(Constants.MSG_ERRO, e.getMessage());
            request.getRequestDispatcher("/WEB-INF/views/funcionario/alterar-senha.jsp").forward(request, response);
        }
    }
    
    // ============================================================
    // MÉTODOS ADMIN/RH
    // ============================================================
    
    private void listar(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
    	   Usuario usuario = (Usuario) request.getSession().getAttribute(Constants.SESSION_USER);
    	    if (usuario == null || !(usuario.isAdmin() || usuario.isRH() || usuario.isGestor())) {
    	        request.getSession().setAttribute(Constants.MSG_ERRO, "Acesso negado");
    	        response.sendRedirect(request.getContextPath() + "/dashboard");
    	        return;
    	    }
        
        try {
            String search = request.getParameter("search");
            String status = request.getParameter("status");
            
            List<Funcionario> funcionarios;
            if (search != null && !search.trim().isEmpty()) {
                funcionarios = funcionarioService.pesquisarPorNome(search);
            } else if (status != null && !status.isEmpty()) {
                funcionarios = funcionarioService.listarPorStatus(status);
            } else {
                funcionarios = funcionarioService.listarTodos();
            }
            
            // =============================================================
            // CARREGAR SETOR PARA CADA FUNCIONÁRIO
            // =============================================================
            for (Funcionario f : funcionarios) {
                if (f.getIdSetor() != null && f.getIdSetor() > 0) {
                    try {
                        Setor setor = setorService.buscarPorId(f.getIdSetor());
                        f.setSetor(setor);
                    } catch (BusinessException e) {
                        // Ignorar
                    }
                }
            }
            
            List<Setor> setores = setorService.listarAtivos();
            
            request.setAttribute("funcionarios", funcionarios);
            request.setAttribute("setores", setores);
            request.setAttribute("total", funcionarios != null ? funcionarios.size() : 0);
            
            request.getSession().removeAttribute(Constants.MSG_ERRO);
            request.getSession().removeAttribute(Constants.MSG_SUCESSO);
            request.getSession().removeAttribute(Constants.MSG_INFO);
            
            request.getRequestDispatcher("/WEB-INF/views/rh/funcionarios.jsp").forward(request, response);
            
        } catch (BusinessException e) {
            request.getSession().setAttribute(Constants.MSG_ERRO, e.getMessage());
            response.sendRedirect(request.getContextPath() + "/dashboard");
        }
    }
    
    private void novo(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        Usuario usuario = (Usuario) request.getSession().getAttribute(Constants.SESSION_USER);
        if (usuario == null || !(usuario.isAdmin() || usuario.isRH())) {
            request.getSession().setAttribute(Constants.MSG_ERRO, "Acesso negado");
            response.sendRedirect(request.getContextPath() + "/dashboard");
            return;
        }
        
        try {
            List<Setor> setores = setorService.listarAtivos();
            request.setAttribute("setores", setores);
            request.setAttribute("funcionario", new Funcionario());
            request.setAttribute("acao", "cadastrar");
            
            request.getSession().removeAttribute(Constants.MSG_ERRO);
            request.getSession().removeAttribute(Constants.MSG_SUCESSO);
            request.getSession().removeAttribute(Constants.MSG_INFO);
            
            request.getRequestDispatcher("/WEB-INF/views/rh/funcionario-form.jsp").forward(request, response);
            
        } catch (BusinessException e) {
            request.getSession().setAttribute(Constants.MSG_ERRO, e.getMessage());
            response.sendRedirect(request.getContextPath() + "/funcionarios");
        }
    }
    
    private void editar(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        Usuario usuario = (Usuario) request.getSession().getAttribute(Constants.SESSION_USER);
        if (usuario == null || !(usuario.isAdmin() || usuario.isRH())) {
            request.getSession().setAttribute(Constants.MSG_ERRO, "Acesso negado");
            response.sendRedirect(request.getContextPath() + "/dashboard");
            return;
        }
        
        try {
            String idStr = request.getPathInfo().substring("/editar/".length());
            Integer id = Integer.parseInt(idStr);
            
            Funcionario funcionario = funcionarioService.buscarCompleto(id);
            List<Setor> setores = setorService.listarAtivos();
            
            request.setAttribute("funcionario", funcionario);
            request.setAttribute("setores", setores);
            request.setAttribute("acao", "editar");
            
            request.getSession().removeAttribute(Constants.MSG_ERRO);
            request.getSession().removeAttribute(Constants.MSG_SUCESSO);
            request.getSession().removeAttribute(Constants.MSG_INFO);
            
            request.getRequestDispatcher("/WEB-INF/views/rh/funcionario-form.jsp").forward(request, response);
            
        } catch (NumberFormatException e) {
            request.getSession().setAttribute(Constants.MSG_ERRO, "ID inválido");
            response.sendRedirect(request.getContextPath() + "/funcionarios");
        } catch (BusinessException e) {
            request.getSession().setAttribute(Constants.MSG_ERRO, e.getMessage());
            response.sendRedirect(request.getContextPath() + "/funcionarios");
        }
    }
    
    private void visualizar(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        try {
            String idStr = request.getPathInfo().substring("/visualizar/".length());
            Integer id = Integer.parseInt(idStr);
            
            Funcionario funcionario = funcionarioService.buscarCompleto(id);
            
            // Se for requisição AJAX (modal)
            String accept = request.getHeader("Accept");
            if (accept != null && accept.contains("application/json")) {
                response.setContentType("application/json");
                response.setCharacterEncoding("UTF-8");
                
                String fotoBase64 = funcionario.getFotoBase64();
                
                // Buscar setor se existir
                String setorNome = "-";
                if (funcionario.getIdSetor() != null && funcionario.getIdSetor() > 0) {
                    try {
                        Setor setor = setorService.buscarPorId(funcionario.getIdSetor());
                        setorNome = setor.getNome();
                    } catch (BusinessException e) {
                        // Ignorar
                    }
                }
                
                String json = String.format(
                    "{" +
                    "\"id\": %d," +
                    "\"nome\": \"%s\"," +
                    "\"email\": \"%s\"," +
                    "\"provincia\": \"%s\"," +
                    "\"distrito\": \"%s\"," +
                    "\"setor\": \"%s\"," +
                    "\"status\": \"%s\"," +
                    "\"bi\": \"%s\"," +
                    "\"telefone\": \"%s\"," +
                    "\"nuit\": \"%s\"," +
                    "\"banco\": \"%s\"," +
                    "\"numeroConta\": \"%s\"," +
                    "\"dataNascimento\": \"%s\"," +
                    "\"dataAdmissao\": \"%s\"," +
                    "\"estadoCivil\": \"%s\"," +
                    "\"foto\": \"%s\"" +
                    "}",
                    funcionario.getId(),
                    funcionario.getNome() != null ? funcionario.getNome() : "",
                    funcionario.getEmailEmpresa() != null ? funcionario.getEmailEmpresa() : "",
                    funcionario.getProvincia() != null ? funcionario.getProvincia() : "",
                    funcionario.getDistrito() != null ? funcionario.getDistrito() : "",
                    setorNome,
                    funcionario.getStatus() != null ? funcionario.getStatus().name() : "",
                    funcionario.getBi() != null ? funcionario.getBi() : "",
                    funcionario.getTelefone() != null ? funcionario.getTelefone() : "",
                    funcionario.getNuit() != null ? funcionario.getNuit() : "",
                    funcionario.getBanco() != null ? funcionario.getBanco() : "",
                    funcionario.getNumeroConta() != null ? funcionario.getNumeroConta() : "",
                    funcionario.getDataNascimento() != null ? funcionario.getDataNascimento().toString() : "",
                    funcionario.getDataAdmissao() != null ? funcionario.getDataAdmissao().toString() : "",
                    funcionario.getEstadoCivil() != null ? funcionario.getEstadoCivil().name() : "",
                    fotoBase64 != null ? fotoBase64 : ""
                );
                
                response.getWriter().print(json);
                return;
            }
            
            // Página de detalhes completa
            request.setAttribute("funcionario", funcionario);
            request.getRequestDispatcher("/WEB-INF/views/rh/funcionario-detalhes.jsp").forward(request, response);
            
        } catch (BusinessException e) {
            request.getSession().setAttribute(Constants.MSG_ERRO, e.getMessage());
            response.sendRedirect(request.getContextPath() + "/funcionarios");
        }
    }
    
    // ============================================================
    // SALVAR - COM SUPORTE A MULTIPART
    // ============================================================
    
 // No método salvar() - substitua a parte de cadastro por esta:
    private void salvar(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        Usuario usuarioLogado = (Usuario) request.getSession().getAttribute(Constants.SESSION_USER);
        if (usuarioLogado == null || !(usuarioLogado.isAdmin() || usuarioLogado.isRH())) {
            request.getSession().setAttribute(Constants.MSG_ERRO, "Acesso negado");
            response.sendRedirect(request.getContextPath() + "/dashboard");
            return;
        }
        
        try {
            Funcionario funcionario = extrairFuncionarioDoRequest(request);
            
            // Processar foto
            try {
                Part fotoPart = request.getPart("foto");
                if (fotoPart != null && fotoPart.getSize() > 0) {
                    byte[] fotoBytes = fotoPart.getInputStream().readAllBytes();
                    funcionario.setFoto(fotoBytes);
                    System.out.println("📸 Foto recebida: " + fotoBytes.length + " bytes");
                } else {
                    if (funcionario.getId() != null) {
                        Funcionario existente = funcionarioService.buscarPorId(funcionario.getId());
                        if (existente != null) {
                            funcionario.setFoto(existente.getFoto());
                        }
                    }
                }
            } catch (Exception e) {
                System.out.println("⚠️ Erro ao processar foto: " + e.getMessage());
            }
            
            String dadosAntigos = null;
            
            if (funcionario.getId() != null) {
                // ATUALIZAR
                Funcionario antigo = funcionarioService.buscarCompleto(funcionario.getId());
                dadosAntigos = "ID: " + antigo.getId() + 
                              ", Nome: " + antigo.getNome() + 
                              ", Telefone: " + antigo.getTelefone() +
                              ", Setor: " + (antigo.getSetor() != null ? antigo.getSetor().getNome() : "N/A") +
                              ", Status: " + antigo.getStatus();
                
                funcionarioService.atualizar(funcionario);
                request.getSession().setAttribute(Constants.MSG_SUCESSO, "Funcionário atualizado com sucesso!");
                
                String dadosNovos = "ID: " + funcionario.getId() + 
                                   ", Nome: " + funcionario.getNome() + 
                                   ", Telefone: " + funcionario.getTelefone() +
                                   ", Setor ID: " + (funcionario.getIdSetor() != null ? funcionario.getIdSetor() : "N/A") +
                                   ", Status: " + funcionario.getStatus();
                
                auditoriaService.registrar(usuarioLogado, "UPDATE", "funcionario", funcionario.getId(), 
                                          dadosAntigos, dadosNovos, request);
                
            } else {
                // CADASTRAR
                funcionarioService.cadastrar(funcionario);
                
                // =============================================================
                // NOTIFICAR NOVO FUNCIONÁRIO
                // =============================================================
                try {
                    sistemaNotificacaoService.notificarNovoFuncionario(funcionario);
                } catch (Exception e) {
                    System.err.println("⚠️ Erro ao notificar novo funcionário: " + e.getMessage());
                }
                
                request.getSession().setAttribute(Constants.MSG_SUCESSO, "Funcionário cadastrado com sucesso!");
                
                String dadosNovos = "ID: " + funcionario.getId() + 
                                   ", Nome: " + funcionario.getNome() + 
                                   ", Telefone: " + funcionario.getTelefone() +
                                   ", Setor ID: " + (funcionario.getIdSetor() != null ? funcionario.getIdSetor() : "N/A") +
                                   ", Status: " + funcionario.getStatus();
                
                auditoriaService.registrar(usuarioLogado, "CREATE", "funcionario", funcionario.getId(), 
                                          null, dadosNovos, request);
            }
            
            response.sendRedirect(request.getContextPath() + "/funcionarios");
            
        } catch (BusinessException e) {
            request.getSession().setAttribute(Constants.MSG_ERRO, e.getMessage());
            e.printStackTrace();
            
            try {
                List<Setor> setores = setorService.listarAtivos();
                request.setAttribute("setores", setores);
                request.setAttribute("funcionario", extrairFuncionarioDoRequest(request));
                request.getRequestDispatcher("/WEB-INF/views/rh/funcionario-form.jsp").forward(request, response);
            } catch (Exception ex) {
                response.sendRedirect(request.getContextPath() + "/funcionarios");
            }
        } catch (Exception e) {
            request.getSession().setAttribute(Constants.MSG_ERRO, "Erro ao salvar funcionário: " + e.getMessage());
            e.printStackTrace();
            response.sendRedirect(request.getContextPath() + "/funcionarios");
        }
    }
    
    private void excluir(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        
        response.setContentType("application/json");
        PrintWriter out = response.getWriter();
        
        Usuario usuarioLogado = (Usuario) request.getSession().getAttribute(Constants.SESSION_USER);
        if (usuarioLogado == null || !(usuarioLogado.isAdmin() || usuarioLogado.isRH())) {
            response.setStatus(HttpServletResponse.SC_FORBIDDEN);
            out.print("{\"success\":false,\"message\":\"Acesso negado\"}");
            out.flush();
            return;
        }
        
        try {
            String idStr = request.getParameter("id");
            Integer id = Integer.parseInt(idStr);
            
            Funcionario funcionario = funcionarioService.buscarCompleto(id);
            String dadosAntigos = "ID: " + funcionario.getId() + 
                                 ", Nome: " + funcionario.getNome() + 
                                 ", Telefone: " + funcionario.getTelefone() +
                                 ", Status: " + funcionario.getStatus();
            
            funcionarioService.excluir(id);
            
            auditoriaService.registrar(usuarioLogado, "DELETE", "funcionario", id, 
                                      dadosAntigos, null, request);
            
            out.print("{\"success\":true,\"message\":\"Funcionário excluído com sucesso!\"}");
            
        } catch (BusinessException e) {
            out.print("{\"success\":false,\"message\":\"" + e.getMessage() + "\"}");
        } catch (Exception e) {
            e.printStackTrace();
            out.print("{\"success\":false,\"message\":\"Erro ao excluir funcionário\"}");
        }
        
        out.flush();
    }
    
    private void buscar(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        
        response.setContentType("application/json");
        PrintWriter out = response.getWriter();
        
        try {
            String termo = request.getParameter("term");
            List<Funcionario> funcionarios = funcionarioService.pesquisarPorNome(termo);
            
            StringBuilder json = new StringBuilder("[");
            for (int i = 0; i < funcionarios.size(); i++) {
                Funcionario f = funcionarios.get(i);
                json.append("{");
                json.append("\"id\":").append(f.getId()).append(",");
                json.append("\"nome\":\"").append(f.getNome()).append("\",");
                json.append("\"email\":\"").append(f.getEmailEmpresa() != null ? f.getEmailEmpresa() : "").append("\"");
                json.append("}");
                if (i < funcionarios.size() - 1) json.append(",");
            }
            json.append("]");
            
            out.print(json.toString());
            
        } catch (BusinessException e) {
            out.print("[]");
        }
        
        out.flush();
    }
    
    // ============================================================
    // EXTRAIR FUNCIONÁRIO DO REQUEST
    // ============================================================
    
    private Funcionario extrairFuncionarioDoRequest(HttpServletRequest request) {
        Funcionario func = new Funcionario();
        
        try {
            // ID
            String id = request.getParameter("id");
            if (id != null && !id.isEmpty()) {
                func.setId(Integer.parseInt(id));
            }
            
            // Nome
            String nome = request.getParameter("nome");
            if (nome != null && !nome.trim().isEmpty()) {
                func.setNome(nome.trim());
            }
            
            // Data Nascimento
            String dataNasc = request.getParameter("dataNascimento");
            if (dataNasc != null && !dataNasc.isEmpty()) {
                try {
                    func.setDataNascimento(Date.valueOf(dataNasc));
                } catch (IllegalArgumentException e) {
                    System.out.println("⚠️ Data de nascimento inválida: " + dataNasc);
                }
            }
            
            // Província
            func.setProvincia(request.getParameter("provincia"));
            
            // Distrito
            func.setDistrito(request.getParameter("distrito"));
            
            // Estado Civil
            String estadoCivil = request.getParameter("estadoCivil");
            if (estadoCivil != null && !estadoCivil.isEmpty()) {
                try {
                    func.setEstadoCivil(estadoCivil);
                } catch (IllegalArgumentException e) {
                    System.out.println("⚠️ Estado civil inválido: " + estadoCivil + " - Usando SOLTEIRO");
                    func.setEstadoCivil(Funcionario.EstadoCivil.SOLTEIRO);
                }
            } else {
                func.setEstadoCivil(Funcionario.EstadoCivil.SOLTEIRO);
            }
            
            // Nome do Cônjuge
            func.setNomeConjuge(request.getParameter("nomeConjuge"));
            
            // Data Admissão
            String dataAdmissao = request.getParameter("dataAdmissao");
            if (dataAdmissao != null && !dataAdmissao.isEmpty()) {
                try {
                    func.setDataAdmissao(Date.valueOf(dataAdmissao));
                } catch (IllegalArgumentException e) {
                    System.out.println("⚠️ Data de admissão inválida: " + dataAdmissao);
                }
            }
            
            // Telefone
            func.setTelefone(request.getParameter("telefone"));
            
            // NUIT
            func.setNuit(request.getParameter("nuit"));
            
            // Número da Conta
            func.setNumeroConta(request.getParameter("numeroConta"));
            
            // Banco
            func.setBanco(request.getParameter("banco"));
            
            // Status
            String status = request.getParameter("status");
            if (status != null && !status.isEmpty()) {
                try {
                    func.setStatus(status);
                } catch (IllegalArgumentException e) {
                    System.out.println("⚠️ Status inválido: " + status + " - Usando ATIVO");
                    func.setStatus(Funcionario.StatusFuncionario.ATIVO);
                }
            } else {
                func.setStatus(Funcionario.StatusFuncionario.ATIVO);
            }
            
            // Email Empresa
            func.setEmailEmpresa(request.getParameter("emailEmpresa"));
            
            // RG
            func.setRg(request.getParameter("rg"));
            
            // BI
            func.setBi(request.getParameter("bi"));
            
            // Setor
            String idSetor = request.getParameter("idSetor");
            if (idSetor != null && !idSetor.isEmpty()) {
                try {
                    func.setIdSetor(Integer.parseInt(idSetor));
                } catch (NumberFormatException e) {
                    System.out.println("⚠️ ID do setor inválido: " + idSetor);
                }
            }
            
        } catch (Exception e) {
            System.err.println("❌ Erro ao extrair funcionário do request: " + e.getMessage());
            e.printStackTrace();
        }
        
        return func;
    }
    private void alterarStatus(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        
        response.setContentType("application/json");
        PrintWriter out = response.getWriter();
        
        Usuario usuarioLogado = (Usuario) request.getSession().getAttribute(Constants.SESSION_USER);
        if (usuarioLogado == null || !(usuarioLogado.isAdmin() || usuarioLogado.isRH())) {
            response.setStatus(HttpServletResponse.SC_FORBIDDEN);
            out.print("{\"success\":false,\"message\":\"Acesso negado\"}");
            out.flush();
            return;
        }
        
        try {
            Integer id = Integer.parseInt(request.getParameter("id"));
            
            Funcionario funcionario = funcionarioService.buscarPorId(id);
            if (funcionario == null) {
                throw new BusinessException("Funcionário não encontrado");
            }
            
            // Alternar status
            if (funcionario.getStatus() == Funcionario.StatusFuncionario.ATIVO) {
                funcionario.setStatus(Funcionario.StatusFuncionario.INATIVO);
            } else {
                funcionario.setStatus(Funcionario.StatusFuncionario.ATIVO);
            }
            
            funcionarioService.atualizar(funcionario);
            
            // Registrar auditoria
            auditoriaService.registrar(usuarioLogado, "UPDATE_STATUS", "funcionario", id,
                "Status alterado para: " + funcionario.getStatus(), null, request);
            
            out.print("{\"success\":true,\"message\":\"Status alterado com sucesso!\"}");
            
        } catch (BusinessException e) {
            out.print("{\"success\":false,\"message\":\"" + e.getMessage() + "\"}");
        } catch (Exception e) {
            e.printStackTrace();
            out.print("{\"success\":false,\"message\":\"Erro ao alterar status\"}");
        }
        
        out.flush();
    }
    private void doDashboard(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        Usuario usuario = (Usuario) request.getSession().getAttribute(Constants.SESSION_USER);
        
        if (usuario == null || usuario.getIdFuncionario() == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }
        
        try {
            int idFuncionario = usuario.getIdFuncionario();
            
            // 1. Buscar saldo de férias
            int saldoFerias = feriasService.calcularSaldoFerias(idFuncionario);
            request.setAttribute("saldoFerias", saldoFerias);
            
            // 2. Buscar férias do funcionário
            List<Ferias> minhasFerias = feriasService.buscarPorFuncionario(idFuncionario);
            request.setAttribute("minhasFerias", minhasFerias);
            
            // 3. Buscar formações do funcionário - CORRIGIDO
            List<Formacao> formacoes = formacaoService.buscarPorFuncionario(idFuncionario);
            request.setAttribute("formacoes", formacoes);
            request.setAttribute("totalFormacoes", formacoes != null ? formacoes.size() : 0);
            
            // 4. Buscar nomeações do funcionário - CORRIGIDO
            List<Nomeacao> nomeacoes = nomeacaoService.buscarPorFuncionario(idFuncionario);
            request.setAttribute("nomeacoes", nomeacoes);
            request.setAttribute("totalNomeacoes", nomeacoes != null ? nomeacoes.size() : 0);
            
            request.getRequestDispatcher("/WEB-INF/views/funcionario/dashboard.jsp").forward(request, response);
            
        } catch (Exception e) {
            e.printStackTrace();
            request.getSession().setAttribute(Constants.MSG_ERRO, "Erro ao carregar dashboard: " + e.getMessage());
            response.sendRedirect(request.getContextPath() + "/dashboard");
        }
    }
   
}

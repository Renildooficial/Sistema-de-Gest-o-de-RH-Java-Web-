package com.sigrh.util;

import org.mindrot.jbcrypt.BCrypt;

public class PasswordUtil {
    
    public static String hashPassword(String password) {
        if (password == null || password.isEmpty()) {
            return null;
        }
        try {
            String hash = BCrypt.hashpw(password, BCrypt.gensalt(10));
            System.out.println("🔑 Hash gerado para senha: " + password + " → " + hash);
            return hash;
        } catch (Exception e) {
            System.err.println("❌ Erro ao gerar hash: " + e.getMessage());
            return null;
        }
    }
    
    public static boolean verifyPassword(String password, String hashed) {
        if (password == null || hashed == null || hashed.isEmpty()) {
            System.out.println("⚠️ PasswordUtil.verifyPassword - Dados inválidos");
            return false;
        }
        try {
            boolean result = BCrypt.checkpw(password, hashed);
            System.out.println("🔍 Verificando senha: '" + password + "' → " + (result ? "✅ OK" : "❌ FALHOU"));
            return result;
        } catch (Exception e) {
            System.err.println("❌ Erro ao verificar senha: " + e.getMessage());
            return false;
        }
    }
    
    public static String generateToken() {
        return java.util.UUID.randomUUID().toString().replace("-", "");
    }
    
    public static String generateCodigoVerificacao() {
        java.util.Random random = new java.util.Random();
        int codigo = 100000 + random.nextInt(900000);
        return String.valueOf(codigo);
    }
}
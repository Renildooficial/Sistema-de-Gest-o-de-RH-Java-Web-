<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%
    // Redireciona para o controller de login
    response.sendRedirect(request.getContextPath() + "/login");
%>
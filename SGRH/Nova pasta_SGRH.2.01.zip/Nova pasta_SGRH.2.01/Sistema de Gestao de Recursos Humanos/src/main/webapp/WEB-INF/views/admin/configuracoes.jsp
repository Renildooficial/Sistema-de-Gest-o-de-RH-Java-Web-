<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="com.sigrh.util.ConfiguracaoUtil" %>
<%@ taglib prefix="c" uri="jakarta.tags.core"%>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt"%>

<jsp:include page="/WEB-INF/views/layout/header.jsp">
    <jsp:param name="pageTitle" value="Configurações do Sistema" />
    <jsp:param name="activeMenu" value="configuracoes" />
</jsp:include>

<style>
    .required { color: var(--danger); font-weight: 700; }
    .form-group label { font-weight: 600; font-size: 13px; color: var(--dark); margin-bottom: 4px; }
    .form-control, .form-select { border-radius: 10px; border: 1px solid var(--gray-border); padding: 8px 12px; font-size: 13px; transition: var(--transition); }
    .form-control:focus, .form-select:focus { border-color: var(--primary); box-shadow: 0 0 0 3px rgba(79,70,229,0.1); }
    .form-container { background: #fff; border-radius: var(--border-radius); padding: 28px; box-shadow: var(--shadow-sm); border: 1px solid var(--gray-border); margin-bottom: 24px; }
    .form-title { font-size: 20px; font-weight: 700; color: var(--dark); margin-bottom: 24px; display: flex; align-items: center; gap: 12px; }
    .form-title i { color: var(--primary); }
    .form-actions { margin-top: 24px; padding-top: 20px; border-top: 1px solid var(--gray-border); display: flex; gap: 12px; flex-wrap: wrap; }
    .helper-text { font-size: 11px; color: var(--gray); margin-top: 4px; }
    .helper-text i { color: var(--info); }
    .form-check-input:checked { background-color: var(--primary); border-color: var(--primary); }
    .form-check-label { font-size: 13px; color: var(--dark); cursor: pointer; }
    
    .section-title {
        font-size: 14px;
        font-weight: 700;
        color: var(--primary);
        border-bottom: 2px solid var(--gray-border);
        padding-bottom: 10px;
        margin-bottom: 16px;
        display: flex;
        align-items: center;
        gap: 10px;
    }
    .section-title i {
        font-size: 16px;
    }
    
    .config-card {
        background: var(--gray-light);
        border-radius: 10px;
        padding: 16px 20px;
        margin-bottom: 12px;
        border-left: 3px solid var(--primary);
        transition: var(--transition);
    }
    .config-card:hover {
        background: #fff;
        box-shadow: var(--shadow-sm);
    }
    .config-card .config-label {
        font-size: 12px;
        color: var(--gray);
        font-weight: 500;
        text-transform: uppercase;
        letter-spacing: 0.5px;
    }
    .config-card .config-value {
        font-size: 14px;
        font-weight: 600;
        color: var(--dark);
        margin-top: 2px;
    }
    
    .backup-item {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 8px 12px;
        background: #fff;
        border-radius: 8px;
        border: 1px solid var(--gray-border);
        margin-bottom: 6px;
        transition: var(--transition);
    }
    .backup-item:hover {
        border-color: var(--primary);
        box-shadow: var(--shadow-sm);
    }
    .backup-item .backup-info {
        display: flex;
        align-items: center;
        gap: 12px;
        font-size: 13px;
    }
    .backup-item .backup-info i {
        color: var(--primary-light);
    }
    .backup-item .backup-info .nome {
        font-weight: 500;
        color: var(--dark);
    }
    .backup-item .backup-info .tamanho {
        color: var(--gray);
        font-size: 12px;
    }
    .backup-item .backup-info .data {
        color: var(--gray);
        font-size: 12px;
    }
    .backup-item .backup-actions {
        display: flex;
        gap: 6px;
    }
    .backup-item .backup-actions .btn-sm {
        padding: 4px 10px;
        font-size: 12px;
        border-radius: 6px;
        border: none;
        cursor: pointer;
        transition: var(--transition);
        text-decoration: none;
        display: inline-flex;
        align-items: center;
        gap: 4px;
    }
    .backup-item .backup-actions .btn-download {
        background: var(--success-bg);
        color: var(--success);
    }
    .backup-item .backup-actions .btn-download:hover {
        background: var(--success);
        color: #fff;
    }
    .backup-item .backup-actions .btn-delete {
        background: var(--danger-bg);
        color: var(--danger);
    }
    .backup-item .backup-actions .btn-delete:hover {
        background: var(--danger);
        color: #fff;
    }
    
    .backup-empty {
        text-align: center;
        padding: 20px;
        color: var(--gray);
        font-size: 13px;
    }
    .backup-empty i {
        font-size: 28px;
        display: block;
        margin-bottom: 8px;
        color: var(--gray-border);
    }
    
    .ver-todos-btn {
        margin-top: 8px;
        text-align: center;
    }

    @media (max-width: 768px) {
        .form-container { padding: 20px; }
        .form-title { font-size: 18px; }
        .form-actions { flex-direction: column; }
        .form-actions .btn-primary-custom, .form-actions .btn-outline-custom { width: 100%; justify-content: center; }
        .config-card { padding: 12px 16px; }
        .backup-item { flex-wrap: wrap; gap: 8px; }
        .backup-item .backup-info { flex-wrap: wrap; }
    }
    @media (max-width: 576px) {
        .form-container { padding: 16px; }
        .form-title { font-size: 16px; }
    }
</style>

<div class="form-container animate-in">
    <div class="form-title">
        <i class="fas fa-cog"></i>
        Configurações do Sistema
        <span style="font-size: 12px; font-weight: 400; color: var(--gray); margin-left: auto;">
            <i class="fas fa-clock"></i> Última atualização: <fmt:formatDate value="${ultimaAtualizacao}" pattern="dd/MM/yyyy HH:mm" />
        </span>
    </div>

    <!-- Resumo das Configurações -->
    <div class="row g-3 mb-4">
        <div class="col-md-3 col-6">
            <div class="config-card">
                <div class="config-label"><i class="fas fa-building"></i> Empresa</div>
                <div class="config-value">${empresaNome != null ? empresaNome : 'SIGRH'}</div>
            </div>
        </div>
        <div class="col-md-3 col-6">
            <div class="config-card" style="border-left-color: var(--success);">
                <div class="config-label"><i class="fas fa-umbrella-beach"></i> Dias de Férias</div>
                <div class="config-value">${diasFerias != null ? diasFerias : '30'} dias</div>
            </div>
        </div>
        <div class="col-md-3 col-6">
            <div class="config-card" style="border-left-color: var(--warning);">
                <div class="config-label"><i class="fas fa-percent"></i> IRS</div>
                <div class="config-value">${taxaIrs != null ? taxaIrs : '15'}%</div>
            </div>
        </div>
        <div class="col-md-3 col-6">
            <div class="config-card" style="border-left-color: var(--info);">
                <div class="config-label"><i class="fas fa-shield-alt"></i> Expiração Senha</div>
                <div class="config-value">${expiraSenha != null ? expiraSenha : '90'} dias</div>
            </div>
        </div>
    </div>

    <form action="${pageContext.request.contextPath}/configuracoes" method="post" id="configForm" novalidate enctype="multipart/form-data">
        <div class="row g-3">
            <!-- DADOS DA EMPRESA -->
            <div class="col-12">
                <div class="section-title">
                    <i class="fas fa-building"></i> Dados da Empresa
                </div>
            </div>
            
            <div class="col-md-6">
                <div class="form-group">
                    <label for="empresaNome">Nome da Empresa <span class="required">*</span></label>
                    <input type="text" class="form-control" name="empresaNome" id="empresaNome"
                           value="${empresaNome != null ? empresaNome : 'SIGRH - Sistema Integrado de Gestão de Recursos Humanos'}"
                           required maxlength="100">
                    <div class="helper-text">
                        <i class="fas fa-info-circle"></i> Nome da instituição/empresa
                    </div>
                </div>
            </div>
            
            <div class="col-md-6">
                <div class="form-group">
                    <label for="empresaLogo">Logo do Sistema</label>
                    <input type="file" class="form-control" name="empresaLogo" id="empresaLogo" accept="image/*">
                    <div class="helper-text">
                        <i class="fas fa-info-circle"></i> Formatos: PNG, JPG, SVG (máx. 2MB)
                    </div>
                    <c:if test="${not empty empresaLogo}">
                        <div style="margin-top: 8px;">
                            <img src="${pageContext.request.contextPath}/uploads/${empresaLogo}" 
                                 alt="Logo" style="max-height: 50px; border-radius: 8px; border: 1px solid var(--gray-border);">
                            <span style="font-size: 12px; color: var(--gray); margin-left: 8px;">Logo atual</span>
                        </div>
                    </c:if>
                </div>
            </div>

            <div class="col-md-6">
                <div class="form-group">
                    <label for="empresaEmail">E-mail da Empresa</label>
                    <input type="email" class="form-control" name="empresaEmail" id="empresaEmail"
                           value="${empresaEmail != null ? empresaEmail : 'contato@sigrh.com'}" maxlength="100">
                    <div class="helper-text">
                        <i class="fas fa-info-circle"></i> E-mail para notificações e contato
                    </div>
                </div>
            </div>

            <div class="col-md-6">
                <div class="form-group">
                    <label for="empresaTelefone">Telefone da Empresa</label>
                    <input type="text" class="form-control" name="empresaTelefone" id="empresaTelefone"
                           value="${empresaTelefone != null ? empresaTelefone : '+258 84 123 4567'}" maxlength="20">
                    <div class="helper-text">
                        <i class="fas fa-info-circle"></i> Telefone para contato
                    </div>
                </div>
            </div>

            <!-- PARÂMETROS FINANCEIROS -->
            <div class="col-12" style="margin-top: 8px;">
                <div class="section-title">
                    <i class="fas fa-calculator"></i> Parâmetros Financeiros
                </div>
            </div>
            
            <div class="col-md-4">
                <div class="form-group">
                    <label for="moedaSimbolo">Símbolo da Moeda <span class="required">*</span></label>
                    <input type="text" class="form-control" name="moedaSimbolo" id="moedaSimbolo"
                           value="${moedaSimbolo != null ? moedaSimbolo : 'MT'}" 
                           required maxlength="5" placeholder="Ex: MT, $, €">
                    <div class="helper-text">
                        <i class="fas fa-info-circle"></i> Símbolo da moeda (ex: MT, $, €, R$)
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="form-group">
                    <label for="moedaCodigo">Código da Moeda</label>
                    <select class="form-select" name="moedaCodigo" id="moedaCodigo">
                        <option value="MZN" ${moedaCodigo == 'MZN' ? 'selected' : ''}>Metical (MZN)</option>
                        <option value="USD" ${moedaCodigo == 'USD' ? 'selected' : ''}>Dólar (USD)</option>
                        <option value="EUR" ${moedaCodigo == 'EUR' ? 'selected' : ''}>Euro (EUR)</option>
                        <option value="BRL" ${moedaCodigo == 'BRL' ? 'selected' : ''}>Real (BRL)</option>
                        <option value="GBP" ${moedaCodigo == 'GBP' ? 'selected' : ''}>Libra (GBP)</option>
                    </select>
                    <div class="helper-text">
                        <i class="fas fa-info-circle"></i> Código internacional da moeda
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="form-group">
                    <label>Moeda Atual</label>
                    <div style="padding: 8px 0; font-size: 18px; font-weight: 700; color: var(--primary);">
                        ${moedaSimbolo != null ? moedaSimbolo : 'MT'} 
                        <span style="font-size: 13px; font-weight: 400; color: var(--gray);">
                            (${moedaCodigo != null ? moedaCodigo : 'MZN'})
                        </span>
                    </div>
                </div>
            </div>

            <div class="col-md-4">
                <div class="form-group">
                    <label for="diasFerias">Dias Padrão de Férias <span class="required">*</span></label>
                    <input type="number" class="form-control" name="diasFerias" id="diasFerias"
                           value="${diasFerias != null ? diasFerias : '30'}" 
                           required min="0" max="365">
                    <div class="helper-text">
                        <i class="fas fa-info-circle"></i> Dias padrão de férias por ano
                    </div>
                </div>
            </div>
            
            <div class="col-md-4">
                <div class="form-group">
                    <label for="taxaIrs">Taxa de IRS (%) <span class="required">*</span></label>
                    <input type="number" class="form-control" name="taxaIrs" id="taxaIrs"
                           value="${taxaIrs != null ? taxaIrs : '15'}" 
                           required step="0.5" min="0" max="100">
                    <div class="helper-text">
                        <i class="fas fa-info-circle"></i> Taxa padrão de IRS
                    </div>
                </div>
            </div>
            
            <div class="col-md-4">
                <div class="form-group">
                    <label for="taxaInss">Taxa de INSS (%) <span class="required">*</span></label>
                    <input type="number" class="form-control" name="taxaInss" id="taxaInss"
                           value="${taxaInss != null ? taxaInss : '11'}" 
                           required step="0.5" min="0" max="100">
                    <div class="helper-text">
                        <i class="fas fa-info-circle"></i> Taxa padrão de INSS
                    </div>
                </div>
            </div>

            <!-- NOTIFICAÇÕES -->
            <div class="col-12" style="margin-top: 8px;">
                <div class="section-title">
                    <i class="fas fa-bell"></i> Notificações
                </div>
            </div>
            
            <div class="col-12">
                <div class="form-group">
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" name="notifNovosFuncionarios" id="notifNovosFuncionarios" 
                               ${notifNovosFuncionarios != null && notifNovosFuncionarios ? 'checked' : ''}>
                        <label class="form-check-label" for="notifNovosFuncionarios">
                            <i class="fas fa-user-plus text-success"></i>
                            Notificar novos cadastros de funcionários
                        </label>
                    </div>
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" name="notifSolicitacoesFerias" id="notifSolicitacoesFerias"
                               ${notifSolicitacoesFerias != null && notifSolicitacoesFerias ? 'checked' : ''}>
                        <label class="form-check-label" for="notifSolicitacoesFerias">
                            <i class="fas fa-umbrella-beach text-warning"></i>
                            Notificar solicitações de férias
                        </label>
                    </div>
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" name="notifAlteracoesDados" id="notifAlteracoesDados"
                               ${notifAlteracoesDados != null && notifAlteracoesDados ? 'checked' : ''}>
                        <label class="form-check-label" for="notifAlteracoesDados">
                            <i class="fas fa-edit text-info"></i>
                            Notificar alterações de dados importantes
                        </label>
                    </div>
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" name="notifVencimentoSenha" id="notifVencimentoSenha"
                               ${notifVencimentoSenha != null && notifVencimentoSenha ? 'checked' : ''}>
                        <label class="form-check-label" for="notifVencimentoSenha">
                            <i class="fas fa-key text-danger"></i>
                            Notificar vencimento de senha (90 dias)
                        </label>
                    </div>
                </div>
            </div>

            <!-- SEGURANÇA -->
            <div class="col-12" style="margin-top: 8px;">
                <div class="section-title">
                    <i class="fas fa-shield-alt"></i> Segurança
                </div>
            </div>
            
            <div class="col-md-6">
                <div class="form-group">
                    <label for="expiraSenha">Expiração de Senha (dias) <span class="required">*</span></label>
                    <input type="number" class="form-control" name="expiraSenha" id="expiraSenha"
                           value="${expiraSenha != null ? expiraSenha : '90'}" 
                           required min="0" max="365">
                    <div class="helper-text">
                        <i class="fas fa-info-circle"></i> 0 = nunca expira
                    </div>
                </div>
            </div>
            
            <div class="col-md-6">
                <div class="form-group">
                    <label for="tentativasLogin">Tentativas de Login Permitidas <span class="required">*</span></label>
                    <input type="number" class="form-control" name="tentativasLogin" id="tentativasLogin"
                           value="${tentativasLogin != null ? tentativasLogin : '5'}" 
                           required min="1" max="20">
                    <div class="helper-text">
                        <i class="fas fa-info-circle"></i> Número de tentativas antes de bloquear o usuário
                    </div>
                </div>
            </div>

            <div class="col-md-6">
                <div class="form-group">
                    <label for="minCaracteresSenha">Mínimo de Caracteres na Senha <span class="required">*</span></label>
                    <input type="number" class="form-control" name="minCaracteresSenha" id="minCaracteresSenha"
                           value="${minCaracteresSenha != null ? minCaracteresSenha : '8'}" 
                           required min="4" max="20">
                    <div class="helper-text">
                        <i class="fas fa-info-circle"></i> Mínimo de caracteres para senha
                    </div>
                </div>
            </div>

            <div class="col-md-6">
                <div class="form-group">
                    <label for="sessaoTimeout">Timeout da Sessão (minutos) <span class="required">*</span></label>
                    <input type="number" class="form-control" name="sessaoTimeout" id="sessaoTimeout"
                           value="${sessaoTimeout != null ? sessaoTimeout : '30'}" 
                           required min="5" max="480">
                    <div class="helper-text">
                        <i class="fas fa-info-circle"></i> Tempo de inatividade antes de encerrar a sessão
                    </div>
                </div>
            </div>

            <!-- ============================================================
            BACKUP - COM LISTA DE BACKUPS
            ============================================================ -->
            <div class="col-12" style="margin-top: 8px;">
                <div class="section-title">
                    <i class="fas fa-database"></i> Backup
                    <span style="font-size: 12px; font-weight: 400; color: var(--gray); margin-left: auto;">
                        <a href="${pageContext.request.contextPath}/configuracoes/backups" class="btn-outline-custom" style="padding: 4px 12px; font-size: 12px;">
                            <i class="fas fa-external-link-alt"></i> Gerenciar Backups
                        </a>
                    </span>
                </div>
            </div>
            
            <div class="col-md-6">
                <div class="form-group">
                    <label for="backupFrequencia">Frequência de Backup</label>
                    <select class="form-select" name="backupFrequencia" id="backupFrequencia">
                        <option value="DIARIO" ${backupFrequencia == 'DIARIO' ? 'selected' : ''}>Diário</option>
                        <option value="SEMANAL" ${backupFrequencia == 'SEMANAL' ? 'selected' : ''}>Semanal</option>
                        <option value="MENSAL" ${backupFrequencia == 'MENSAL' ? 'selected' : ''}>Mensal</option>
                        <option value="NENHUM" ${backupFrequencia == 'NENHUM' ? 'selected' : ''}>Nenhum</option>
                    </select>
                    <div class="helper-text">
                        <i class="fas fa-info-circle"></i> Frequência de backup automático do sistema
                    </div>
                </div>
            </div>
            
            <div class="col-md-6">
                <div class="form-group">
                    <label>Último Backup</label>
                    <div style="padding: 8px 0;">
                        <span class="badge" style="background: var(--success-bg); color: var(--success); padding: 4px 12px; border-radius: 12px;">
                            <i class="fas fa-check-circle"></i> ${ultimoBackup != null ? ultimoBackup : 'Nunca realizado'}
                        </span>
                    </div>
                    <button type="button" class="btn-primary-custom" style="margin-top: 4px;" onclick="realizarBackup()">
                        <i class="fas fa-download"></i> Realizar Backup Agora
                    </button>
                </div>
            </div>

            <!-- ============================================================
            LISTA DE BACKUPS - EMBUTIDA
            ============================================================ -->
            <div class="col-12">
                <div style="margin-top: 8px;">
                    <h6 style="font-weight: 600; color: var(--dark); margin-bottom: 12px;">
                        <i class="fas fa-list"></i> Últimos Backups
                    </h6>
                    
                    <c:choose>
                        <c:when test="${not empty backups}">
                            <c:forEach items="${backups}" var="b" varStatus="i">
                                <c:if test="${i.index < 5}">
                                    <div class="backup-item">
                                        <div class="backup-info">
                                            <i class="fas fa-file-archive"></i>
                                            <span class="nome">${b.nome}</span>
                                            <span class="tamanho">(${b.tamanho})</span>
                                            <span class="data">${b.data}</span>
                                        </div>
                                        <div class="backup-actions">
                                            <a href="${pageContext.request.contextPath}/configuracoes/download-backup?arquivo=${b.nome}" 
                                               class="btn-sm btn-download" title="Baixar">
                                                <i class="fas fa-download"></i>
                                            </a>
                                            <button class="btn-sm btn-delete" onclick="excluirBackup('${b.nome}')" title="Excluir">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </div>
                                    </div>
                                </c:if>
                            </c:forEach>
                            
                            <c:if test="${totalBackups > 5}">
                                <div class="ver-todos-btn">
                                    <a href="${pageContext.request.contextPath}/configuracoes/backups" class="btn-outline-custom" style="font-size: 12px;">
                                        <i class="fas fa-eye"></i> Ver todos (${totalBackups} backups)
                                    </a>
                                </div>
                            </c:if>
                        </c:when>
                        <c:otherwise>
                            <div class="backup-empty">
                                <i class="fas fa-database"></i>
                                Nenhum backup encontrado. Clique em "Realizar Backup Agora" para criar o primeiro.
                            </div>
                        </c:otherwise>
                    </c:choose>
                </div>
            </div>

            <!-- ============================================================
            BOTÕES
            ============================================================ -->
            <div class="form-actions">
                <button type="submit" class="btn-primary-custom" id="btnSalvar">
                    <i class="fas fa-save"></i> Salvar Configurações
                </button>
                <button type="reset" class="btn-outline-custom" onclick="resetarPadroes()">
                    <i class="fas fa-undo"></i> Restaurar Padrões
                </button>
                <a href="${pageContext.request.contextPath}/dashboard" class="btn-outline-custom">
                    <i class="fas fa-times"></i> Cancelar
                </a>
            </div>
        </div>
    </form>
</div>

<script>
// ============================================================
// RESETAR PARA VALORES PADRÃO
// ============================================================
function resetarPadroes() {
    if (confirm('Deseja restaurar todas as configurações para os valores padrão?')) {
        document.getElementById('empresaNome').value = 'SIGRH - Sistema Integrado de Gestão de Recursos Humanos';
        document.getElementById('diasFerias').value = '30';
        document.getElementById('taxaIrs').value = '15';
        document.getElementById('taxaInss').value = '11';
        document.getElementById('expiraSenha').value = '90';
        document.getElementById('tentativasLogin').value = '5';
        document.getElementById('minCaracteresSenha').value = '8';
        document.getElementById('sessaoTimeout').value = '30';
        document.getElementById('backupFrequencia').value = 'SEMANAL';
        
        showNotification('info', 'Restaurado', 'Valores padrão restaurados com sucesso!');
    }
}

// ============================================================
// REALIZAR BACKUP
// ============================================================
function realizarBackup() {
    if (confirm('Deseja realizar um backup do sistema agora?')) {
        const btn = event.target;
        btn.disabled = true;
        btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Processando...';
        
        fetch('${pageContext.request.contextPath}/configuracoes/backup', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                showNotification('success', 'Backup', data.message);
                setTimeout(() => location.reload(), 2000);
            } else {
                showNotification('error', 'Erro', data.message);
                btn.disabled = false;
                btn.innerHTML = '<i class="fas fa-download"></i> Realizar Backup Agora';
            }
        })
        .catch(error => {
            showNotification('error', 'Erro', 'Erro ao realizar backup');
            btn.disabled = false;
            btn.innerHTML = '<i class="fas fa-download"></i> Realizar Backup Agora';
        });
    }
}

// ============================================================
// EXCLUIR BACKUP
// ============================================================
function excluirBackup(nome) {
    if (confirm('Tem certeza que deseja excluir o backup "' + nome + '"?')) {
        fetch('${pageContext.request.contextPath}/configuracoes/excluir-backup', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: 'arquivo=' + encodeURIComponent(nome)
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                showNotification('success', 'Excluído', data.message);
                setTimeout(() => location.reload(), 1000);
            } else {
                showNotification('error', 'Erro', data.message);
            }
        })
        .catch(error => {
            showNotification('error', 'Erro', 'Erro ao excluir backup');
        });
    }
}

// ============================================================
// VALIDAÇÃO DO FORMULÁRIO
// ============================================================
document.getElementById('configForm').addEventListener('submit', function(e) {
    let isValid = true;
    let errorMessages = [];

    const empresaNome = document.getElementById('empresaNome');
    if (empresaNome.value.trim().length < 2) {
        errorMessages.push('Nome da empresa deve ter no mínimo 2 caracteres');
        isValid = false;
    }

    const diasFerias = document.getElementById('diasFerias');
    if (parseInt(diasFerias.value) < 0 || parseInt(diasFerias.value) > 365) {
        errorMessages.push('Dias de férias deve estar entre 0 e 365');
        isValid = false;
    }

    const taxaIrs = document.getElementById('taxaIrs');
    if (parseFloat(taxaIrs.value) < 0 || parseFloat(taxaIrs.value) > 100) {
        errorMessages.push('Taxa de IRS deve estar entre 0 e 100');
        isValid = false;
    }

    const taxaInss = document.getElementById('taxaInss');
    if (parseFloat(taxaInss.value) < 0 || parseFloat(taxaInss.value) > 100) {
        errorMessages.push('Taxa de INSS deve estar entre 0 e 100');
        isValid = false;
    }

    const expiraSenha = document.getElementById('expiraSenha');
    if (parseInt(expiraSenha.value) < 0 || parseInt(expiraSenha.value) > 365) {
        errorMessages.push('Expiração de senha deve estar entre 0 e 365');
        isValid = false;
    }

    const tentativasLogin = document.getElementById('tentativasLogin');
    if (parseInt(tentativasLogin.value) < 1 || parseInt(tentativasLogin.value) > 20) {
        errorMessages.push('Tentativas de login deve estar entre 1 e 20');
        isValid = false;
    }

    const minCaracteresSenha = document.getElementById('minCaracteresSenha');
    if (parseInt(minCaracteresSenha.value) < 4 || parseInt(minCaracteresSenha.value) > 20) {
        errorMessages.push('Mínimo de caracteres deve estar entre 4 e 20');
        isValid = false;
    }

    const sessaoTimeout = document.getElementById('sessaoTimeout');
    if (parseInt(sessaoTimeout.value) < 5 || parseInt(sessaoTimeout.value) > 480) {
        errorMessages.push('Timeout da sessão deve estar entre 5 e 480');
        isValid = false;
    }

    if (!isValid) {
        e.preventDefault();
        alert('Erro de Validação:\n' + errorMessages.join('\n'));
        return false;
    }

    return true;
});

// ============================================================
// FALLBACK - SHOW NOTIFICATION
// ============================================================
if (typeof showNotification === 'undefined') {
    window.showNotification = function(type, title, message) {
        alert(title + ': ' + message);
    };
}

// ============================================================
// CARREGAR VALORES DA SESSÃO
// ============================================================
document.addEventListener('DOMContentLoaded', function() {
    <c:if test="${not empty sessionScope.sucesso}">
        showNotification('success', 'Sucesso', '${sessionScope.sucesso}');
        <c:remove var="sucesso" scope="session" />
    </c:if>
    <c:if test="${not empty sessionScope.erro}">
        showNotification('error', 'Erro', '${sessionScope.erro}');
        <c:remove var="erro" scope="session" />
    </c:if>
});
</script>

<jsp:include page="/WEB-INF/views/layout/footer.jsp" />
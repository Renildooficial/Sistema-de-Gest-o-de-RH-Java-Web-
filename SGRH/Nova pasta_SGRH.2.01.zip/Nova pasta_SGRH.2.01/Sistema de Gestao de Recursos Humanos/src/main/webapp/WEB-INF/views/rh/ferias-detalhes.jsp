<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core"%>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt"%>

<jsp:include page="/WEB-INF/views/layout/header.jsp">
    <jsp:param name="pageTitle" value="Detalhes da Solicitação" />
    <jsp:param name="activeMenu" value="ferias" />
</jsp:include>

<style>
    /* ============================================================
    ESTILOS - DETALHES FÉRIAS
    ============================================================ */
    .detail-container {
        max-width: 800px;
        margin: 0 auto;
        padding: 20px;
    }
    
    .detail-card {
        background: #fff;
        border-radius: var(--border-radius);
        border: 1px solid var(--gray-border);
        box-shadow: var(--shadow-sm);
        overflow: hidden;
    }
    
    .detail-header {
        padding: 20px 24px;
        background: var(--gray-light);
        border-bottom: 1px solid var(--gray-border);
        display: flex;
        justify-content: space-between;
        align-items: center;
        flex-wrap: wrap;
        gap: 12px;
    }
    
    .detail-header h4 {
        font-size: 18px;
        font-weight: 700;
        color: var(--dark);
        margin: 0;
        display: flex;
        align-items: center;
        gap: 10px;
    }
    
    .detail-header h4 i {
        color: var(--primary);
    }
    
    .detail-body {
        padding: 24px;
    }
    
    .detail-grid {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 20px;
    }
    
    .detail-item {
        display: flex;
        flex-direction: column;
        gap: 4px;
    }
    
    .detail-item.full {
        grid-column: 1 / -1;
    }
    
    .detail-item .label {
        font-size: 11px;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        color: var(--gray);
    }
    
    .detail-item .value {
        font-size: 15px;
        font-weight: 500;
        color: var(--dark);
        padding: 8px 12px;
        background: var(--gray-light);
        border-radius: 8px;
    }
    
    .detail-item .value.highlight {
        background: rgba(79, 70, 229, 0.08);
        color: var(--primary);
        font-weight: 600;
    }
    
    .detail-item .value.success {
        background: rgba(16, 185, 129, 0.08);
        color: var(--success);
    }
    
    .detail-item .value.warning {
        background: rgba(245, 158, 11, 0.08);
        color: #d97706;
    }
    
    .detail-item .value.danger {
        background: rgba(239, 68, 68, 0.08);
        color: var(--danger);
    }
    
    .detail-item .value .badge-status {
        display: inline-block;
        padding: 4px 14px;
        border-radius: 20px;
        font-size: 12px;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.3px;
    }
    
    .badge-status.solicitada {
        background: rgba(245, 158, 11, 0.12);
        color: #d97706;
        border: 1px solid rgba(245, 158, 11, 0.2);
    }
    .badge-status.aprovada {
        background: rgba(16, 185, 129, 0.12);
        color: var(--success);
        border: 1px solid rgba(16, 185, 129, 0.2);
    }
    .badge-status.concluida {
        background: rgba(59, 130, 246, 0.12);
        color: #2563eb;
        border: 1px solid rgba(59, 130, 246, 0.2);
    }
    .badge-status.rejeitada {
        background: rgba(239, 68, 68, 0.12);
        color: var(--danger);
        border: 1px solid rgba(239, 68, 68, 0.2);
    }
    .badge-status.em_andamento {
        background: rgba(139, 92, 246, 0.12);
        color: #7c3aed;
        border: 1px solid rgba(139, 92, 246, 0.2);
    }
    .badge-status.cancelada {
        background: rgba(107, 114, 128, 0.12);
        color: var(--gray);
        border: 1px solid rgba(107, 114, 128, 0.2);
    }
    
    .detail-footer {
        padding: 16px 24px;
        border-top: 1px solid var(--gray-border);
        display: flex;
        gap: 12px;
        flex-wrap: wrap;
    }
    
    .btn-primary-custom {
        background: var(--primary);
        color: #fff;
        padding: 10px 24px;
        border: none;
        border-radius: 8px;
        font-size: 14px;
        font-weight: 600;
        display: inline-flex;
        align-items: center;
        gap: 8px;
        text-decoration: none;
        cursor: pointer;
        transition: all 0.2s ease;
    }
    
    .btn-primary-custom:hover {
        background: var(--primary-hover);
        color: #fff;
        transform: translateY(-2px);
        box-shadow: 0 4px 12px rgba(79, 70, 229, 0.3);
    }
    
    .btn-outline-custom {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        padding: 10px 20px;
        border: 1.5px solid var(--gray-border);
        border-radius: 8px;
        background: transparent;
        color: var(--gray);
        font-size: 14px;
        font-weight: 600;
        text-decoration: none;
        transition: all 0.2s ease;
        cursor: pointer;
    }
    
    .btn-outline-custom:hover {
        background: var(--gray-light);
        color: var(--dark);
        border-color: #cbd5e1;
    }
    
    .btn-success-custom {
        background: var(--success);
        color: #fff;
        padding: 10px 24px;
        border: none;
        border-radius: 8px;
        font-size: 14px;
        font-weight: 600;
        display: inline-flex;
        align-items: center;
        gap: 8px;
        text-decoration: none;
        cursor: pointer;
        transition: all 0.2s ease;
    }
    
    .btn-success-custom:hover {
        background: #16a34a;
        color: #fff;
        transform: translateY(-2px);
        box-shadow: 0 4px 12px rgba(16, 185, 129, 0.3);
    }
    
    .btn-danger-custom {
        background: var(--danger);
        color: #fff;
        padding: 10px 24px;
        border: none;
        border-radius: 8px;
        font-size: 14px;
        font-weight: 600;
        display: inline-flex;
        align-items: center;
        gap: 8px;
        text-decoration: none;
        cursor: pointer;
        transition: all 0.2s ease;
    }
    
    .btn-danger-custom:hover {
        background: #dc2626;
        color: #fff;
        transform: translateY(-2px);
        box-shadow: 0 4px 12px rgba(239, 68, 68, 0.3);
    }
    
    .btn-warning-custom {
        background: var(--warning);
        color: #fff;
        padding: 10px 24px;
        border: none;
        border-radius: 8px;
        font-size: 14px;
        font-weight: 600;
        display: inline-flex;
        align-items: center;
        gap: 8px;
        text-decoration: none;
        cursor: pointer;
        transition: all 0.2s ease;
    }
    
    .btn-warning-custom:hover {
        background: #d97706;
        color: #fff;
        transform: translateY(-2px);
        box-shadow: 0 4px 12px rgba(245, 158, 11, 0.3);
    }
    
    .avatar-large {
        width: 64px;
        height: 64px;
        border-radius: 50%;
        background: linear-gradient(135deg, var(--primary), #7c3aed);
        display: flex;
        align-items: center;
        justify-content: center;
        color: #fff;
        font-weight: 700;
        font-size: 24px;
        flex-shrink: 0;
    }
    
    .funcionario-info {
        display: flex;
        align-items: center;
        gap: 16px;
        padding: 12px 16px;
        background: var(--gray-light);
        border-radius: 12px;
        margin-bottom: 16px;
    }
    
    .funcionario-info .nome {
        font-size: 18px;
        font-weight: 700;
        color: var(--dark);
    }
    
    .funcionario-info .id {
        font-size: 13px;
        color: var(--gray);
    }
    
    .funcionario-info .setor {
        font-size: 13px;
        color: var(--gray);
        display: flex;
        align-items: center;
        gap: 4px;
    }
    
    .timeline {
        position: relative;
        padding-left: 20px;
        border-left: 2px solid var(--gray-border);
        margin-top: 8px;
    }
    
    .timeline-item {
        position: relative;
        padding: 8px 0 8px 16px;
    }
    
    .timeline-item::before {
        content: '';
        position: absolute;
        left: -6px;
        top: 14px;
        width: 10px;
        height: 10px;
        border-radius: 50%;
        background: var(--gray-border);
        border: 2px solid #fff;
    }
    
    .timeline-item.active::before {
        background: var(--success);
    }
    
    .timeline-item .time {
        font-size: 11px;
        color: var(--gray);
    }
    
    .timeline-item .desc {
        font-size: 13px;
        color: var(--dark);
    }
    
    .timeline-item .desc strong {
        font-weight: 600;
    }
    
    /* ============================================================
    RESPONSIVO
    ============================================================ */
    @media (max-width: 768px) {
        .detail-container {
            padding: 12px;
        }
        .detail-grid {
            grid-template-columns: 1fr;
            gap: 12px;
        }
        .detail-header {
            padding: 16px;
        }
        .detail-header h4 {
            font-size: 16px;
        }
        .detail-body {
            padding: 16px;
        }
        .detail-footer {
            padding: 12px 16px;
            flex-direction: column;
        }
        .detail-footer .btn {
            width: 100%;
            justify-content: center;
        }
        .funcionario-info {
            flex-direction: column;
            text-align: center;
        }
        .avatar-large {
            width: 48px;
            height: 48px;
            font-size: 18px;
        }
        .funcionario-info .nome {
            font-size: 16px;
        }
    }
    
    @media (max-width: 480px) {
        .detail-container {
            padding: 8px;
        }
        .detail-header h4 {
            font-size: 14px;
        }
        .detail-item .value {
            font-size: 13px;
            padding: 6px 10px;
        }
        .detail-footer .btn {
            font-size: 12px;
            padding: 8px 16px;
        }
    }

    /* ============================================================
    ANIMAÇÕES
    ============================================================ */
    @keyframes fadeInUp {
        from {
            opacity: 0;
            transform: translateY(20px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }

    .animate-in {
        opacity: 0;
        animation: fadeInUp 0.5s ease forwards;
    }
</style>

<div class="detail-container animate-in">
    <div class="detail-card">
        <!-- Header -->
        <div class="detail-header">
            <h4>
                <i class="fas fa-umbrella-beach"></i>
                Detalhes da Solicitação
                <span style="font-size: 14px; font-weight: 400; color: var(--gray);">#${ferias.id}</span>
            </h4>
            <div>
                <span class="badge-status ${ferias.status.toLowerCase()}">
                    <i class="fas 
                        ${ferias.status == 'SOLICITADA' ? 'fa-clock' : 
                          ferias.status == 'APROVADA' ? 'fa-check-circle' : 
                          ferias.status == 'CONCLUIDA' ? 'fa-flag-checkered' : 
                          ferias.status == 'REJEITADA' ? 'fa-times-circle' : 
                          ferias.status == 'EM_ANDAMENTO' ? 'fa-play-circle' : 
                          ferias.status == 'CANCELADA' ? 'fa-ban' : 'fa-circle'} 
                        me-1"></i>
                    ${ferias.status}
                </span>
            </div>
        </div>

        <!-- Body -->
        <div class="detail-body">
            <!-- Funcionário -->
            <div class="funcionario-info">
                <div class="avatar-large">
                    ${ferias.funcionario != null ? ferias.funcionario.nome.charAt(0) : '?'}
                </div>
                <div>
                    <div class="nome">${ferias.funcionario != null ? ferias.funcionario.nome : 'Funcionário não encontrado'}</div>
                    <div class="id">ID: #${ferias.idFuncionario}</div>
                    <c:if test="${not empty ferias.funcionario.setor}">
                        <div class="setor">
                            <i class="fas fa-building"></i> ${ferias.funcionario.setor.nome}
                        </div>
                    </c:if>
                </div>
            </div>

            <!-- Detalhes -->
            <div class="detail-grid">
                <div class="detail-item">
                    <span class="label"><i class="fas fa-calendar-alt me-1"></i> Data de Início</span>
                    <span class="value highlight">
                        <fmt:formatDate value="${ferias.dataInicio}" pattern="dd/MM/yyyy" />
                    </span>
                </div>
                <div class="detail-item">
                    <span class="label"><i class="fas fa-calendar-check me-1"></i> Data de Fim</span>
                    <span class="value highlight">
                        <fmt:formatDate value="${ferias.dataFim}" pattern="dd/MM/yyyy" />
                    </span>
                </div>
                <div class="detail-item">
                    <span class="label"><i class="fas fa-sun me-1"></i> Dias Úteis</span>
                    <span class="value success">${ferias.diasUteis} dias</span>
                </div>
                <div class="detail-item">
                    <span class="label"><i class="fas fa-calendar-day me-1"></i> Dias Corridos</span>
                    <span class="value">${ferias.diasCalendario} dias</span>
                </div>
                <c:if test="${not empty ferias.anoReferencia}">
                    <div class="detail-item">
                        <span class="label"><i class="fas fa-calendar me-1"></i> Ano de Referência</span>
                        <span class="value">${ferias.anoReferencia}</span>
                    </div>
                </c:if>
                <div class="detail-item">
                    <span class="label"><i class="fas fa-clock me-1"></i> Data de Solicitação</span>
                    <span class="value">
                        <fmt:formatDate value="${ferias.dataSolicitacao}" pattern="dd/MM/yyyy HH:mm" />
                    </span>
                </div>
                <c:if test="${not empty ferias.motivoRejeicao}">
                    <div class="detail-item full">
                        <span class="label"><i class="fas fa-info-circle me-1"></i> Motivo da Rejeição</span>
                        <span class="value danger">${ferias.motivoRejeicao}</span>
                    </div>
                </c:if>
                <c:if test="${not empty ferias.observacao}">
                    <div class="detail-item full">
                        <span class="label"><i class="fas fa-comment me-1"></i> Observação</span>
                        <span class="value">${ferias.observacao}</span>
                    </div>
                </c:if>
            </div>

            <!-- Timeline -->
            <div style="margin-top: 20px; border-top: 1px solid var(--gray-border); padding-top: 16px;">
                <h6 style="font-weight: 600; color: var(--dark); margin-bottom: 12px;">
                    <i class="fas fa-history me-2"></i> Histórico
                </h6>
                <div class="timeline">
                    <div class="timeline-item ${ferias.status == 'SOLICITADA' ? 'active' : ''}">
                        <div class="time">
                            <fmt:formatDate value="${ferias.dataSolicitacao}" pattern="dd/MM/yyyy HH:mm" />
                        </div>
                        <div class="desc">
                            <strong>Solicitação criada</strong> por ${ferias.funcionario != null ? ferias.funcionario.nome : 'Funcionário'}
                        </div>
                    </div>
                    
                    <c:if test="${ferias.status == 'APROVADA' || ferias.status == 'EM_ANDAMENTO' || ferias.status == 'CONCLUIDA'}">
                        <div class="timeline-item active">
                            <div class="time">
                                ${not empty ferias.dataAprovacao ? '<fmt:formatDate value="' += ferias.dataAprovacao += '" pattern="dd/MM/yyyy HH:mm" />' : '-'}
                            </div>
                            <div class="desc">
                                <strong>Solicitação aprovada</strong> por RH
                            </div>
                        </div>
                    </c:if>
                    
                    <c:if test="${ferias.status == 'EM_ANDAMENTO' || ferias.status == 'CONCLUIDA'}">
                        <div class="timeline-item active">
                            <div class="time">
                                ${not empty ferias.dataInicio ? '<fmt:formatDate value="' += ferias.dataInicio += '" pattern="dd/MM/yyyy HH:mm" />' : '-'}
                            </div>
                            <div class="desc">
                                <strong>Férias iniciadas</strong> (Checkout)
                            </div>
                        </div>
                    </c:if>
                    
                    <c:if test="${ferias.status == 'CONCLUIDA'}">
                        <div class="timeline-item active">
                            <div class="time">
                                ${not empty ferias.dataFim ? '<fmt:formatDate value="' += ferias.dataFim += '" pattern="dd/MM/yyyy HH:mm" />' : '-'}
                            </div>
                            <div class="desc">
                                <strong>Férias finalizadas</strong> (Checkin)
                            </div>
                        </div>
                    </c:if>
                    
                    <c:if test="${ferias.status == 'REJEITADA'}">
                        <div class="timeline-item">
                            <div class="time">
                                ${not empty ferias.dataAprovacao ? '<fmt:formatDate value="' += ferias.dataAprovacao += '" pattern="dd/MM/yyyy HH:mm" />' : '-'}
                            </div>
                            <div class="desc">
                                <strong>Solicitação rejeitada</strong>
                                <c:if test="${not empty ferias.motivoRejeicao}">
                                    - Motivo: ${ferias.motivoRejeicao}
                                </c:if>
                            </div>
                        </div>
                    </c:if>
                    
                    <c:if test="${ferias.status == 'CANCELADA'}">
                        <div class="timeline-item">
                            <div class="time">-</div>
                            <div class="desc">
                                <strong>Solicitação cancelada</strong>
                            </div>
                        </div>
                    </c:if>
                </div>
            </div>
        </div>

        <!-- Footer -->
        <div class="detail-footer">
            <a href="${pageContext.request.contextPath}/ferias" class="btn-outline-custom">
                <i class="fas fa-arrow-left"></i> Voltar
            </a>
            
            <!-- Ações baseadas no status -->
            <c:if test="${ferias.status == 'SOLICITADA'}">
                <button class="btn-success-custom" onclick="aprovarFerias(${ferias.id})">
                    <i class="fas fa-check"></i> Aprovar
                </button>
                <button class="btn-danger-custom" onclick="rejeitarFerias(${ferias.id})">
                    <i class="fas fa-times"></i> Rejeitar
                </button>
            </c:if>
            
            <c:if test="${ferias.status == 'APROVADA'}">
                <button class="btn-warning-custom" onclick="checkoutFerias(${ferias.id})">
                    <i class="fas fa-sign-out-alt"></i> Iniciar Férias
                </button>
            </c:if>
            
            <c:if test="${ferias.status == 'EM_ANDAMENTO'}">
                <button class="btn-success-custom" onclick="checkinFerias(${ferias.id})">
                    <i class="fas fa-sign-in-alt"></i> Finalizar Férias
                </button>
            </c:if>
        </div>
    </div>
</div>

<script>
// ============================================================
// APROVAR FÉRIAS
// ============================================================
function aprovarFerias(id) {
    if (confirm('✅ Deseja aprovar esta solicitação de férias?')) {
        fetch('${pageContext.request.contextPath}/ferias/aprovar', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: 'id=' + id
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                showNotification('success', '✅ Aprovado', data.message);
                setTimeout(() => location.reload(), 1200);
            } else {
                showNotification('error', '❌ Erro', data.message);
            }
        })
        .catch(error => {
            showNotification('error', '❌ Erro', 'Falha na comunicação com o servidor');
        });
    }
}

// ============================================================
// REJEITAR FÉRIAS
// ============================================================
function rejeitarFerias(id) {
    const motivo = prompt('Digite o motivo da rejeição:');
    if (motivo !== null && motivo.trim() !== '') {
        fetch('${pageContext.request.contextPath}/ferias/rejeitar', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: 'id=' + id + '&motivo=' + encodeURIComponent(motivo)
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                showNotification('warning', '⚠️ Rejeitado', data.message);
                setTimeout(() => location.reload(), 1200);
            } else {
                showNotification('error', '❌ Erro', data.message);
            }
        })
        .catch(error => {
            showNotification('error', '❌ Erro', 'Falha na comunicação com o servidor');
        });
    } else if (motivo !== null) {
        showNotification('warning', '⚠️ Atenção', 'Motivo da rejeição é obrigatório');
    }
}

// ============================================================
// CHECKOUT (INICIAR FÉRIAS)
// ============================================================
function checkoutFerias(id) {
    if (confirm('🏖️ Confirmar início das férias (Checkout)?')) {
        fetch('${pageContext.request.contextPath}/ferias/checkout', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: 'id=' + id
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                showNotification('success', '✅ Checkout', data.message);
                setTimeout(() => location.reload(), 1200);
            } else {
                showNotification('error', '❌ Erro', data.message);
            }
        })
        .catch(error => {
            showNotification('error', '❌ Erro', 'Falha na comunicação com o servidor');
        });
    }
}

// ============================================================
// CHECKIN (FINALIZAR FÉRIAS)
// ============================================================
function checkinFerias(id) {
    if (confirm('✅ Confirmar retorno das férias (Checkin)?')) {
        fetch('${pageContext.request.contextPath}/ferias/checkin', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: 'id=' + id
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                showNotification('success', '✅ Checkin', data.message);
                setTimeout(() => location.reload(), 1200);
            } else {
                showNotification('error', '❌ Erro', data.message);
            }
        })
        .catch(error => {
            showNotification('error', '❌ Erro', 'Falha na comunicação com o servidor');
        });
    }
}

// ============================================================
// NOTIFICATIONS
// ============================================================
function showNotification(type, title, message) {
    if (typeof window.showNotification === 'function') {
        window.showNotification(type, title, message);
    } else {
        alert(title + '\n\n' + message);
    }
}
</script>

<jsp:include page="/WEB-INF/views/layout/footer.jsp" />
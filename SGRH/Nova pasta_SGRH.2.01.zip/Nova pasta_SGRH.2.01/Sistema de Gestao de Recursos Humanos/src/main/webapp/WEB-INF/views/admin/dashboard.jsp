<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" isELIgnored="false"%>
<%@ taglib prefix="c" uri="jakarta.tags.core"%>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt"%>

<jsp:include page="/WEB-INF/views/layout/header.jsp">
    <jsp:param name="pageTitle" value="Dashboard" />
    <jsp:param name="activeMenu" value="dashboard" />
</jsp:include>

<!-- ========================================
STATS CARDS
======================================== -->
<div class="stats-grid">
    <div class="stat-card animate-in animate-in-d1">
        <div class="stat-icon blue">
            <i class="fas fa-users"></i>
        </div>
        <div class="stat-value">${totalFuncionarios != null ? totalFuncionarios : '0'}</div>
        <div class="stat-label">Total de Funcionários</div>
        <a href="${pageContext.request.contextPath}/funcionarios" class="stat-link">
            Ver todos <i class="fas fa-arrow-right ms-1"></i>
        </a>
    </div>
    <div class="stat-card animate-in animate-in-d2">
        <div class="stat-icon green">
            <i class="fas fa-user-check"></i>
        </div>
        <div class="stat-value">${ativos != null ? ativos : '0'}</div>
        <div class="stat-label">Funcionários Ativos</div>
        <a href="${pageContext.request.contextPath}/funcionarios?status=ATIVO" class="stat-link">
            Ver ativos <i class="fas fa-arrow-right ms-1"></i>
        </a>
    </div>
    <div class="stat-card animate-in animate-in-d3">
        <div class="stat-icon yellow">
            <i class="fas fa-umbrella-beach"></i>
        </div>
        <div class="stat-value">${ferias != null ? ferias : '0'}</div>
        <div class="stat-label">Em Férias</div>
        <a href="${pageContext.request.contextPath}/ferias?status=FERIAS" class="stat-link">
            Ver detalhes <i class="fas fa-arrow-right ms-1"></i>
        </a>
    </div>
    <div class="stat-card animate-in animate-in-d4">
        <div class="stat-icon red">
            <i class="fas fa-user-slash"></i>
        </div>
        <div class="stat-value">${inativos != null ? inativos : '0'}</div>
        <div class="stat-label">Funcionários Inativos</div>
    </div>
    <div class="stat-card animate-in animate-in-d5">
        <div class="stat-icon purple">
            <i class="fas fa-building"></i>
        </div>
        <div class="stat-value">${totalSetores != null ? totalSetores : '0'}</div>
        <div class="stat-label">Setores</div>
        <a href="${pageContext.request.contextPath}/setores" class="stat-link">
            Gerenciar <i class="fas fa-arrow-right ms-1"></i>
        </a>
    </div>
</div>

<!-- ========================================
QUICK ACCESS
======================================== -->
<div class="quick-access-grid">
    <a href="${pageContext.request.contextPath}/funcionarios/novo" class="quick-card">
        <div class="quick-icon" style="color: var(--primary);"><i class="fas fa-user-plus"></i></div>
        <div class="quick-label">Novo Funcionário</div>
    </a>
    <a href="${pageContext.request.contextPath}/agregados/novo" class="quick-card">
        <div class="quick-icon" style="color: var(--success);"><i class="fas fa-user-friends"></i></div>
        <div class="quick-label">Novo Agregado</div>
    </a>
    <a href="${pageContext.request.contextPath}/formacoes/novo" class="quick-card">
        <div class="quick-icon" style="color: var(--warning);"><i class="fas fa-graduation-cap"></i></div>
        <div class="quick-label">Nova Formação</div>
    </a>
    <a href="${pageContext.request.contextPath}/nomeacoes/novo" class="quick-card">
        <div class="quick-icon" style="color: var(--secondary);"><i class="fas fa-briefcase"></i></div>
        <div class="quick-label">Nova Nomeação</div>
    </a>
    <a href="${pageContext.request.contextPath}/ferias/nova" class="quick-card">
        <div class="quick-icon" style="color: var(--info);"><i class="fas fa-umbrella-beach"></i></div>
        <div class="quick-label">Solicitar Férias</div>
    </a>
    <a href="${pageContext.request.contextPath}/plano-ferias/novo" class="quick-card">
        <div class="quick-icon" style="color: var(--success);"><i class="fas fa-calendar-plus"></i></div>
        <div class="quick-label">Plano de Férias</div>
    </a>
    <a href="${pageContext.request.contextPath}/setores/novo" class="quick-card">
        <div class="quick-icon" style="color: var(--primary);"><i class="fas fa-building"></i></div>
        <div class="quick-label">Novo Setor</div>
    </a>
    <a href="${pageContext.request.contextPath}/usuarios/novo" class="quick-card">
        <div class="quick-icon" style="color: var(--danger);"><i class="fas fa-user-plus"></i></div>
        <div class="quick-label">Novo Usuário</div>
    </a>
</div>

<!-- ========================================
CHARTS
======================================== -->
<div class="charts-grid">
    <div class="chart-card animate-in animate-in-d2">
        <div class="card-header">
            <div>
                <div class="card-title">Funcionários por Setor</div>
                <div class="card-subtitle">Distribuição atual dos colaboradores</div>
            </div>
            <a href="${pageContext.request.contextPath}/relatorios" style="font-size: 12px; color: var(--primary); text-decoration: none; font-weight: 600;">
                Ver relatório <i class="fas fa-arrow-right"></i>
            </a>
        </div>
        <div class="chart-container">
            <canvas id="setorChart"></canvas>
        </div>
    </div>
    <div class="chart-card animate-in animate-in-d3">
        <div class="card-header">
            <div>
                <div class="card-title">Status dos Funcionários</div>
                <div class="card-subtitle">Visão geral da força de trabalho</div>
            </div>
        </div>
        <div class="chart-container">
            <canvas id="statusChart"></canvas>
        </div>
    </div>
</div>

<!-- ========================================
ÚLTIMOS FUNCIONÁRIOS
======================================== -->
<div class="table-section animate-in animate-in-d4">
    <div class="table-header">
        <div class="title">
            <i class="fas fa-users me-2"></i>
            &Uacute;ltimos Funcion&aacute;rios Cadastrados
        </div>
        <div class="actions">
            <a href="${pageContext.request.contextPath}/funcionarios" class="btn-outline-custom">
                Ver todos <i class="fas fa-arrow-right ms-1"></i>
            </a>
            <a href="${pageContext.request.contextPath}/funcionarios/novo" class="btn-primary-custom">
                <i class="fas fa-plus"></i> Novo Funcion&aacute;rio
            </a>
        </div>
    </div>
    <div class="table-responsive-custom">
        <table class="table-custom">
            <thead>
                <tr>
                    <th>Funcion&aacute;rio</th>
                    <th>Setor</th>
                    <th>Status</th>
                    <th>Admiss&atilde;o</th>
                    <th>A&ccedil;&otilde;es</th>
                </tr>
            </thead>
            <tbody>
                <c:forEach items="${ultimosFuncionarios}" var="f">
                    <tr>
                        <td>
                            <div class="d-flex align-items-center gap-3">
                                <div class="avatar-table" data-nome="${f.nome}">
                                    <!-- preenchido via JS -->
                                </div>
                                <div>
                                    <div style="font-weight: 600;">${f.nome}</div>
                                    <div style="font-size: 12px; color: var(--gray);">
                                        ${f.emailEmpresa != null ? f.emailEmpresa : '-'}
                                    </div>
                                </div>
                            </div>
                        </td>
                        <td>${f.setor != null ? f.setor.nome : '-'}</td>
                        <td>
                            <span class="status-badge 
                                ${f.status == 'ATIVO' ? 'ativo' : 
                                  f.status == 'FERIAS' ? 'ferias' : 
                                  f.status == 'LICENCA' ? 'licenca' : 
                                  f.status == 'AFASTADO' ? 'pendente' : 'inativo'}">
                                ${f.status}
                            </span>
                        </td>
                        <td><fmt:formatDate value="${f.dataAdmissao}" pattern="dd/MM/yyyy" /></td>
                        <td>
                            <div class="action-btns">
                                <a href="${pageContext.request.contextPath}/funcionarios/visualizar/${f.id}" 
                                   class="btn-icon view" title="Visualizar">
                                    <i class="fas fa-eye"></i>
                                </a>
                                <a href="${pageContext.request.contextPath}/funcionarios/editar/${f.id}" 
                                   class="btn-icon edit" title="Editar">
                                    <i class="fas fa-edit"></i>
                                </a>
                            </div>
                        </td>
                    </tr>
                </c:forEach>
                <c:if test="${empty ultimosFuncionarios}">
                    <tr>
                        <td colspan="5" style="text-align: center; padding: 40px; color: var(--gray);">
                            <i class="fas fa-inbox fa-2x d-block mb-2" style="opacity: 0.4;"></i>
                            Nenhum funcion&aacute;rio cadastrado
                        </td>
                    </tr>
                </c:if>
            </tbody>
        </table>
    </div>
</div>

<!-- ========================================
SCRIPTS
======================================== -->
<script>
// Gráfico de Setores - Dados REAIS
const ctx1 = document.getElementById('setorChart').getContext('2d');
const setorLabels = [
    <c:forEach items="${funcionariosPorSetor}" var="entry" varStatus="status">
        '${entry.key}'${!status.last ? ',' : ''}
    </c:forEach>
];
const setorData = [
    <c:forEach items="${funcionariosPorSetor}" var="entry" varStatus="status">
        ${entry.value}${!status.last ? ',' : ''}
    </c:forEach>
];

new Chart(ctx1, {
    type: 'bar',
    data: {
        labels: setorLabels.length > 0 ? setorLabels : ['Nenhum dado'],
        datasets: [{
            label: 'Funcionários',
            data: setorData.length > 0 ? setorData : [0],
            backgroundColor: [
                'rgba(79,70,229,0.8)',
                'rgba(59,130,246,0.8)',
                'rgba(16,185,129,0.8)',
                'rgba(245,158,11,0.8)',
                'rgba(124,58,237,0.8)',
                'rgba(239,68,68,0.8)',
                'rgba(14,165,233,0.8)'
            ],
            borderColor: [
                'rgba(79,70,229,1)',
                'rgba(59,130,246,1)',
                'rgba(16,185,129,1)',
                'rgba(245,158,11,1)',
                'rgba(124,58,237,1)',
                'rgba(239,68,68,1)',
                'rgba(14,165,233,1)'
            ],
            borderWidth: 2,
            borderRadius: 8,
            maxBarThickness: 40,
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: { legend: { display: false } },
        scales: {
            y: { beginAtZero: true, grid: { color: 'rgba(0,0,0,0.05)' }, ticks: { stepSize: 1, font: { size: 11 } } },
            x: { grid: { display: false }, ticks: { font: { size: 11 } } }
        }
    }
});

// Gráfico de Status - Dados REAIS
const ctx2 = document.getElementById('statusChart').getContext('2d');
new Chart(ctx2, {
    type: 'doughnut',
    data: {
        labels: ['Ativos', 'Em Férias', 'Inativos', 'Licença', 'Afastados'],
        datasets: [{
            data: [
                ${ativos != null ? ativos : 0},
                ${ferias != null ? ferias : 0},
                ${inativos != null ? inativos : 0},
                ${licenca != null ? licenca : 0},
                ${afastados != null ? afastados : 0}
            ],
            backgroundColor: [
                'rgba(16,185,129,0.9)',
                'rgba(245,158,11,0.9)',
                'rgba(239,68,68,0.9)',
                'rgba(59,130,246,0.9)',
                'rgba(124,58,237,0.9)'
            ],
            borderColor: '#fff',
            borderWidth: 3,
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            legend: {
                position: 'bottom',
                labels: { padding: 16, usePointStyle: true, pointStyle: 'circle', font: { size: 12, weight: '500' } }
            }
        },
        cutout: '70%'
    }
});

// Preenche as iniciais dos avatares de forma segura
document.querySelectorAll('.avatar-table[data-nome]').forEach(el => {
    const nome = el.getAttribute('data-nome') || '';
    let iniciais = 'U';
    if (nome.trim()) {
        const parts = nome.trim().split(/\s+/);
        iniciais = parts[0].charAt(0).toUpperCase();
        if (parts.length > 1) {
            iniciais += parts[parts.length - 1].charAt(0).toUpperCase();
        }
    }
    el.textContent = iniciais;
});
</script>

<jsp:include page="/WEB-INF/views/layout/footer.jsp" />
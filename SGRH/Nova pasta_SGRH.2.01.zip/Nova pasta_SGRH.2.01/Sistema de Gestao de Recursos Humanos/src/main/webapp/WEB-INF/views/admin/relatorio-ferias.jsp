<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core"%>

<jsp:include page="/WEB-INF/views/layout/header.jsp">
    <jsp:param name="pageTitle" value="${titulo}" />
    <jsp:param name="activeMenu" value="relatorios" />
</jsp:include>

<div class="form-container animate-in" style="max-width: 100%;">
    <div class="form-title">
        <i class="fas fa-umbrella-beach" style="color: var(--warning);"></i>
        ${titulo}
    </div>

    <div class="row g-4">
        <div class="col-md-6">
            <div class="chart-card">
                <div class="card-header">
                    <div>
                        <div class="card-title">Férias por Status</div>
                        <div class="card-subtitle">Distribuição das solicitações</div>
                    </div>
                </div>
                <div class="chart-container" style="height: 300px;">
                    <canvas id="feriasChart"></canvas>
                </div>
            </div>
        </div>

        <div class="col-md-6">
            <div class="stat-card">
                <h6 style="font-weight: 700; color: var(--dark); margin-bottom: 16px;">
                    <i class="fas fa-list me-2"></i> Resumo
                </h6>
                <table class="table-custom">
                    <thead>
                        <tr>
                            <th>Status</th>
                            <th>Quantidade</th>
                        </tr>
                    </thead>
                    <tbody>
                        <c:forEach items="${feriasPorStatus}" var="entry">
                            <tr>
                                <td>
                                    <span class="status-badge 
                                        ${entry.key == 'APROVADA' ? 'aprovado' : 
                                          entry.key == 'SOLICITADA' ? 'pendente' : 
                                          entry.key == 'CONCLUIDA' ? 'ativo' : 
                                          entry.key == 'REJEITADA' ? 'inativo' : 
                                          entry.key == 'EM_ANDAMENTO' ? 'ferias' : 'inativo'}">
                                        ${entry.key}
                                    </span>
                                </td>
                                <td><strong>${entry.value}</strong></td>
                            </tr>
                        </c:forEach>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <div class="form-actions">
        <button class="btn-primary-custom" onclick="window.print()">
            <i class="fas fa-print"></i> Imprimir
        </button>
        <button class="btn-outline-custom" onclick="window.location.href='${pageContext.request.contextPath}/relatorios'">
            <i class="fas fa-arrow-left"></i> Voltar
        </button>
    </div>
</div>

<script>
// Gráfico de Férias
const ctx = document.getElementById('feriasChart').getContext('2d');
const labels = [
    <c:forEach items="${feriasPorStatus}" var="entry" varStatus="status">
        '${entry.key}'${!status.last ? ',' : ''}
    </c:forEach>
];
const data = [
    <c:forEach items="${feriasPorStatus}" var="entry" varStatus="status">
        ${entry.value}${!status.last ? ',' : ''}
    </c:forEach>
];

new Chart(ctx, {
    type: 'doughnut',
    data: {
        labels: labels.length > 0 ? labels : ['Nenhum dado'],
        datasets: [{
            data: data.length > 0 ? data : [0],
            backgroundColor: [
                'rgba(16,185,129,0.9)',
                'rgba(245,158,11,0.9)',
                'rgba(239,68,68,0.9)',
                'rgba(59,130,246,0.9)',
                'rgba(124,58,237,0.9)',
                'rgba(14,165,233,0.9)'
            ],
            borderColor: '#fff',
            borderWidth: 3,
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            legend: {
                position: 'bottom',
                labels: { padding: 16, usePointStyle: true, pointStyle: 'circle', font: { size: 12, weight: '500' } }
            }
        },
        cutout: '70%'
    }
});
</script>

<jsp:include page="/WEB-INF/views/layout/footer.jsp" />
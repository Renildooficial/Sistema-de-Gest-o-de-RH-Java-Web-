<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" isELIgnored="false"%>
<%@ taglib prefix="c" uri="jakarta.tags.core"%>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt"%>

<jsp:include page="/WEB-INF/views/layout/header.jsp">
    <jsp:param name="pageTitle" value="Usuários do Sistema" />
    <jsp:param name="activeMenu" value="usuarios" />
</jsp:include>

<style>
    .badge-perfil {
        display: inline-block;
        padding: 2px 10px;
        border-radius: 12px;
        font-size: 11px;
        font-weight: 600;
        border: 1px solid transparent;
    }
    .badge-perfil-ADMIN {
        background: rgba(239,68,68,0.1);
        color: #dc2626;
        border-color: rgba(239,68,68,0.15);
    }
    .badge-perfil-RH {
        background: rgba(79,70,229,0.1);
        color: #4f46e5;
        border-color: rgba(79,70,229,0.15);
    }
    .badge-perfil-FINANCEIRO {
        background: rgba(16,185,129,0.1);
        color: #059669;
        border-color: rgba(16,185,129,0.15);
    }
    .badge-perfil-GESTOR {
        background: rgba(245,158,11,0.1);
        color: #d97706;
        border-color: rgba(245,158,11,0.15);
    }
    .badge-perfil-FUNCIONARIO {
        background: rgba(59,130,246,0.1);
        color: #2563eb;
        border-color: rgba(59,130,246,0.15);
    }

    .badge-status-user {
        display: inline-block;
        padding: 2px 10px;
        border-radius: 12px;
        font-size: 11px;
        font-weight: 600;
        border: 1px solid transparent;
    }
    .badge-status-user-ATIVO {
        background: rgba(16,185,129,0.1);
        color: #059669;
        border-color: rgba(16,185,129,0.15);
    }
    .badge-status-user-INATIVO {
        background: rgba(239,68,68,0.1);
        color: #dc2626;
        border-color: rgba(239,68,68,0.15);
    }
    .badge-status-user-BLOQUEADO {
        background: rgba(245,158,11,0.1);
        color: #d97706;
        border-color: rgba(245,158,11,0.15);
    }

    .action-btns {
        display: flex;
        gap: 4px;
        flex-wrap: wrap;
        align-items: center;
    }
    .action-btns .btn-icon {
        width: 34px;
        height: 34px;
        border: none;
        border-radius: 8px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        transition: var(--transition);
        text-decoration: none;
        font-size: 13px;
        position: relative;
    }
    .action-btns .btn-icon:hover {
        transform: scale(1.1);
    }
    .action-btns .btn-icon .tooltip {
        display: none;
        position: absolute;
        bottom: -28px;
        left: 50%;
        transform: translateX(-50%);
        background: var(--dark);
        color: #fff;
        padding: 2px 10px;
        border-radius: 6px;
        font-size: 10px;
        font-weight: 500;
        white-space: nowrap;
        z-index: 10;
    }
    .action-btns .btn-icon:hover .tooltip {
        display: block;
    }
    .btn-icon.edit {
        background: rgba(79,70,229,0.1);
        color: var(--primary);
    }
    .btn-icon.edit:hover {
        background: var(--primary);
        color: #fff;
    }
    .btn-icon.view {
        background: rgba(245,158,11,0.1);
        color: var(--warning);
    }
    .btn-icon.view:hover {
        background: var(--warning);
        color: #fff;
    }
    .btn-icon.delete {
        background: rgba(239,68,68,0.1);
        color: var(--danger);
    }
    .btn-icon.delete:hover {
        background: var(--danger);
        color: #fff;
    }

    .empty-state {
        text-align: center;
        padding: 60px 20px;
        color: var(--gray);
    }
    .empty-state i {
        font-size: 48px;
        margin-bottom: 16px;
        color: var(--primary-light);
    }
    .empty-state h5 {
        font-size: 18px;
        font-weight: 600;
        margin-bottom: 8px;
        color: var(--dark);
    }
    .empty-state p {
        font-size: 14px;
    }

    @media (max-width: 768px) {
        .table-custom thead { display: none; }
        .table-custom tbody tr {
            display: block;
            margin-bottom: 16px;
            border: 1px solid var(--gray-border);
            border-radius: var(--border-radius);
            padding: 16px;
            background: #fff;
        }
        .table-custom tbody tr td {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 8px 4px;
            border: none;
            border-bottom: 1px solid var(--gray-light);
            font-size: 13px;
        }
        .table-custom tbody tr td:last-child { border-bottom: none; }
        .table-custom tbody tr td::before {
            content: attr(data-label);
            font-weight: 600;
            color: var(--dark);
            font-size: 12px;
            margin-right: 12px;
            min-width: 80px;
        }
        .table-header {
            flex-direction: column;
            gap: 12px;
            align-items: flex-start;
        }
        .table-header .actions {
            width: 100%;
            flex-wrap: wrap;
        }
        .table-header .actions .btn-primary-custom {
            width: 100%;
            justify-content: center;
        }
        .empty-state { padding: 30px 16px; }
        .empty-state i { font-size: 32px; }
        .empty-state h5 { font-size: 16px; }
    }
    @media (max-width: 480px) {
        .table-custom tbody tr { padding: 12px; }
        .table-custom tbody tr td {
            font-size: 12px;
            padding: 6px 2px;
            flex-wrap: wrap;
        }
        .table-custom tbody tr td::before {
            font-size: 11px;
            min-width: 60px;
        }
        .action-btns .btn-icon {
            width: 28px;
            height: 28px;
            font-size: 11px;
        }
    }
</style>

<div class="table-section animate-in">
    <div class="table-header">
        <div class="title">
            <i class="fas fa-user-cog me-2"></i>
            Usuários do Sistema
            <span style="font-size: 12px; font-weight: 400; color: var(--gray); margin-left: 8px;">
                ${total != null ? total : '0'} registros
            </span>
            <c:if test="${ativos > 0}">
                <span class="badge" style="background: var(--success); color: #fff; margin-left: 8px; padding: 2px 10px; border-radius: 12px; font-size: 11px;">
                    <i class="fas fa-check-circle"></i> ${ativos} ativos
                </span>
            </c:if>
        </div>
        <div class="actions">
            <a href="${pageContext.request.contextPath}/usuarios/novo" class="btn-primary-custom">
                <i class="fas fa-plus-circle"></i> Novo Usuário
            </a>
        </div>
    </div>

    <div class="table-responsive-custom">
        <table class="table-custom" id="usuariosTable">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Nome</th>
                    <th>Usuário</th>
                    <th>E-mail</th>
                    <th>Perfil</th>
                    <th>Status</th>
                    <th>Funcionário</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <c:forEach items="${usuarios}" var="user">
                    <tr>
                        <td data-label="#">${user.id}</td>
                        <td data-label="Nome"><strong>${user.nome}</strong></td>
                        <td data-label="Usuário">${user.usuario}</td>
                        <td data-label="E-mail">${user.email}</td>
                        <td data-label="Perfil">
                            <span class="badge-perfil badge-perfil-${user.perfil.name()}">
                                <i class="fas 
                                    ${user.perfil.name() == 'ADMIN' ? 'fa-crown' : 
                                      user.perfil.name() == 'RH' ? 'fa-users' : 
                                      user.perfil.name() == 'FINANCEIRO' ? 'fa-coins' : 
                                      user.perfil.name() == 'GESTOR' ? 'fa-user-tie' : 'fa-user'}"></i>
                                ${user.perfil.name()}
                            </span>
                        </td>
                        <td data-label="Status">
                            <span class="badge-status-user badge-status-user-${user.status.name()}">
                                <i class="fas ${user.status.name() == 'ATIVO' ? 'fa-check-circle' : 'fa-times-circle'}"></i>
                                ${user.status.name()}
                            </span>
                        </td>
                        <td data-label="Funcionário">
                            <c:choose>
                                <%-- Usa mapa nomesFuncionarios (evita conflito EL com isFuncionario() Boolean) --%>
                                <c:when test="${not empty nomesFuncionarios[user.id]}">
                                    <span style="font-weight: 500; font-size: 12px; color: var(--primary);">
                                        <i class="fas fa-user"></i> ${nomesFuncionarios[user.id]}
                                    </span>
                                </c:when>
                                <c:when test="${user.idFuncionario != null && user.idFuncionario > 0}">
                                    <span style="font-weight: 500; font-size: 12px; color: var(--primary);">
                                        <i class="fas fa-user"></i> ID: ${user.idFuncionario}
                                    </span>
                                </c:when>
                                <c:otherwise>
                                    <span style="color: var(--gray); font-size: 12px;">-</span>
                                </c:otherwise>
                            </c:choose>
                        </td>
                        <td data-label="Ações">
                            <div class="action-btns">
                                <a href="${pageContext.request.contextPath}/usuarios/editar/${user.id}" 
                                   class="btn-icon edit" title="Editar">
                                    <i class="fas fa-pen"></i>
                                    <span class="tooltip">Editar</span>
                                </a>

                                <c:if test="${user.id != sessionScope.usuario.id}">
                                    <button class="btn-icon view" 
                                            onclick="alterarStatus(${user.id})" 
                                            title="Alterar Status">
                                        <i class="fas fa-exchange-alt"></i>
                                        <span class="tooltip">Alterar Status</span>
                                    </button>
                                    
                                    <button class="btn-icon delete" 
                                            onclick="excluirUsuario(${user.id}, '${user.nome}')" 
                                            title="Excluir">
                                        <i class="fas fa-trash"></i>
                                        <span class="tooltip">Excluir</span>
                                    </button>
                                </c:if>
                                
                                <c:if test="${user.id == sessionScope.usuario.id}">
                                    <span style="font-size: 11px; color: var(--gray); padding: 4px 8px; background: var(--gray-light); border-radius: 6px;">
                                        <i class="fas fa-lock"></i> Atual
                                    </span>
                                </c:if>
                            </div>
                        </td>
                    </tr>
                </c:forEach>

                <c:if test="${empty usuarios}">
                    <tr>
                        <td colspan="8">
                            <div class="empty-state">
                                <i class="fas fa-users"></i>
                                <h5>Nenhum usuário cadastrado</h5>
                                <p>Clique em "Novo Usuário" para começar</p>
                            </div>
                        </td>
                    </tr>
                </c:if>
            </tbody>
        </table>
    </div>
</div>

<script>
function excluirUsuario(id, nome) {
    if (confirm('Tem certeza que deseja excluir o usuário "' + nome + '"?')) {
        fetch('${pageContext.request.contextPath}/usuarios/excluir', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: 'id=' + id
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                showNotification('success', 'Excluído', data.message);
                setTimeout(() => location.reload(), 1000);
            } else {
                showNotification('error', 'Erro', data.message);
            }
        })
        .catch(function(err) {
            showNotification('error', 'Erro', 'Falha na comunicação com o servidor');
        });
    }
}

function alterarStatus(id) {
    if (confirm('Deseja alterar o status deste usuário?')) {
        fetch('${pageContext.request.contextPath}/usuarios/alterar-status', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: 'id=' + id
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                showNotification('success', 'Status Alterado', data.message);
                setTimeout(() => location.reload(), 1000);
            } else {
                showNotification('error', 'Erro', data.message);
            }
        })
        .catch(function(err) {
            showNotification('error', 'Erro', 'Falha na comunicação com o servidor');
        });
    }
}

if (typeof showNotification === 'undefined') {
    window.showNotification = function(type, title, message) {
        alert(title + ': ' + message);
    };
}
</script>

<jsp:include page="/WEB-INF/views/layout/footer.jsp" />
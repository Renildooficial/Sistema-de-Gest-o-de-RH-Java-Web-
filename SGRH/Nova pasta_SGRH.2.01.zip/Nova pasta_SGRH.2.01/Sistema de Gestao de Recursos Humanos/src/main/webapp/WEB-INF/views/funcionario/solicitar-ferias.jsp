<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core"%>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt"%>

<jsp:include page="/WEB-INF/views/layout/header.jsp">
    <jsp:param name="pageTitle" value="Solicitar Férias" />
    <jsp:param name="activeMenu" value="minhas-ferias" />
</jsp:include>

<style>
    .container { max-width: 550px; margin: 40px auto; padding: 30px; background: #fff; border-radius: 12px; border: 1px solid #e2e8f0; }
    .container h2 { font-size: 22px; margin-bottom: 20px; }
    .form-group { margin-bottom: 18px; }
    .form-group label { display: block; font-weight: 600; margin-bottom: 6px; color: #0f172a; }
    .form-group input, .form-group textarea { width: 100%; padding: 10px 14px; border: 1.5px solid #e2e8f0; border-radius: 8px; font-size: 14px; box-sizing: border-box; }
    .form-group input:focus, .form-group textarea:focus { border-color: #4f46e5; outline: none; }
    .btn-submit { width: 100%; padding: 12px; background: #4f46e5; color: #fff; border: none; border-radius: 8px; font-size: 16px; font-weight: 600; cursor: pointer; transition: background 0.2s; }
    .btn-submit:hover { background: #4338ca; }
    .btn-submit:disabled { opacity: 0.6; cursor: not-allowed; }
    .saldo-info { background: #f0fdf4; border: 1px solid #bbf7d0; padding: 12px 16px; border-radius: 8px; margin-bottom: 20px; display: flex; justify-content: space-between; align-items: center; }
    .saldo-info .value { font-size: 24px; font-weight: 700; color: #16a34a; }
    .alert { padding: 12px 16px; border-radius: 8px; margin-bottom: 16px; }
    .alert-danger { background: #fef2f2; border: 1px solid #fecaca; color: #dc2626; }
    .alert-success { background: #f0fdf4; border: 1px solid #bbf7d0; color: #16a34a; }
    .help-text { font-size: 12px; color: #64748b; margin-top: 4px; }
    .dias-calc { font-size: 13px; color: #64748b; margin-top: 8px; padding: 8px 12px; background: #f1f5f9; border-radius: 6px; display: none; }
    .dias-calc.show { display: block; }
    .back-link { display: block; text-align: center; margin-top: 20px; color: #64748b; text-decoration: none; }
    .back-link:hover { text-decoration: underline; }
</style>

<div class="container animate-in">
    <h2><i class="fas fa-plus-circle" style="color: #4f46e5;"></i> Solicitar Férias</h2>

    <!-- Saldo -->
    <div class="saldo-info">
        <span>🌴 Saldo disponível</span>
        <span class="value">${saldo != null ? saldo : 0} dias</span>
    </div>

    <!-- Mensagens -->
    <c:if test="${not empty error}">
        <div class="alert alert-danger">${error}</div>
    </c:if>
    <c:if test="${not empty success}">
        <div class="alert alert-success">${success}</div>
    </c:if>

    <!-- ⚠️ IMPORTANTE: method="POST" e action="/ferias" -->
    <form action="${pageContext.request.contextPath}/ferias" method="POST" id="formFerias">
        <div class="form-group">
            <label for="dataInicio">📅 Data de início</label>
            <input type="date" id="dataInicio" name="dataInicio" required
                   min="<fmt:formatDate value='<%= new java.util.Date() %>' pattern='yyyy-MM-dd'/>"
                   onchange="calcularDias()">
            <div class="help-text">A data deve ser igual ou posterior a hoje</div>
        </div>

        <div class="form-group">
            <label for="dataFim">📅 Data de fim</label>
            <input type="date" id="dataFim" name="dataFim" required
                   min="<fmt:formatDate value='<%= new java.util.Date() %>' pattern='yyyy-MM-dd'/>"
                   onchange="calcularDias()">
            <div class="help-text">Máximo de 15 dias úteis por solicitação</div>
        </div>

        <div class="dias-calc" id="diasCalc">
            <i class="fas fa-calculator"></i>
            Dias úteis: <strong id="diasUteis">0</strong>
            | Dias corridos: <strong id="diasCorridos">0</strong>
        </div>

        <div class="form-group">
            <label for="observacao">📝 Observação (opcional)</label>
            <textarea id="observacao" name="observacao" rows="3" 
                      placeholder="Adicione uma observação..."></textarea>
        </div>

        <!-- ⚠️ type="submit" é obrigatório -->
        <button type="submit" class="btn-submit" id="btnSubmit">
            <i class="fas fa-paper-plane"></i> Enviar Solicitação
        </button>
    </form>

    <a href="${pageContext.request.contextPath}/funcionario/minhas-ferias" class="back-link">
        ← Voltar para Minhas Férias
    </a>
</div>

<script>
// Debug: Verificar configuração do formulário
document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('formFerias');
    console.log('✅ Formulário carregado:');
    console.log('   Method:', form.method);
    console.log('   Action:', form.action);
    
    form.addEventListener('submit', function(e) {
        console.log('🚀 FORMULÁRIO SUBMETIDO!');
        console.log('   Method:', this.method);
        console.log('   Action:', this.action);
    });
});

function calcularDias() {
    const inicio = document.getElementById('dataInicio').value;
    const fim = document.getElementById('dataFim').value;
    const div = document.getElementById('diasCalc');
    const diasUteisSpan = document.getElementById('diasUteis');
    const diasCorridosSpan = document.getElementById('diasCorridos');
    const btn = document.getElementById('btnSubmit');

    if (inicio && fim) {
        const dataInicio = new Date(inicio);
        const dataFim = new Date(fim);
        
        if (dataFim < dataInicio) {
            diasUteisSpan.textContent = 'Data inválida';
            diasCorridosSpan.textContent = 'Data inválida';
            btn.disabled = true;
            div.classList.add('show');
            return;
        }

        // Dias corridos
        const diffTime = Math.abs(dataFim - dataInicio);
        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)) + 1;
        diasCorridosSpan.textContent = diffDays;

        // Dias úteis
        let diasUteis = 0;
        const current = new Date(dataInicio);
        while (current <= dataFim) {
            const diaSemana = current.getDay();
            if (diaSemana >= 1 && diaSemana <= 5) {
                diasUteis++;
            }
            current.setDate(current.getDate() + 1);
        }
        diasUteisSpan.textContent = diasUteis;

        // Validações
        const saldo = ${saldo != null ? saldo : 0};
        let error = null;
        
        if (diasUteis > 15) {
            error = '⚠️ Máximo de 15 dias úteis por solicitação.';
        } else if (diasUteis > saldo) {
            error = '⚠️ Saldo insuficiente. Você tem ' + saldo + ' dias disponíveis.';
        }
        
        if (error) {
            const alertDiv = document.querySelector('.alert-danger');
            if (alertDiv) {
                alertDiv.textContent = error;
            } else {
                const newAlert = document.createElement('div');
                newAlert.className = 'alert alert-danger';
                newAlert.textContent = error;
                document.getElementById('formFerias').prepend(newAlert);
            }
            btn.disabled = true;
        } else {
            document.querySelector('.alert-danger')?.remove();
            btn.disabled = false;
        }

        div.classList.add('show');
    } else {
        div.classList.remove('show');
        btn.disabled = false;
    }
}
</script>

<jsp:include page="/WEB-INF/views/layout/footer.jsp" />
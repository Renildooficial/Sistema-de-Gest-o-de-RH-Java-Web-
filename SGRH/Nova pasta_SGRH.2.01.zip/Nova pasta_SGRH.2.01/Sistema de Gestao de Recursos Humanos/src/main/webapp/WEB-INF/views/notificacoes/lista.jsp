<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core"%>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt"%>

<jsp:include page="/WEB-INF/views/layout/header.jsp">
    <jsp:param name="pageTitle" value="Minhas Notificações" />
    <jsp:param name="activeMenu" value="notificacoes" />
</jsp:include>

<style>
    .notificacoes-container {
        max-width: 900px;
        margin: 0 auto;
    }

    .notificacoes-header {
        background: #fff;
        border-radius: var(--border-radius);
        padding: 24px 28px;
        border: 1px solid var(--gray-border);
        box-shadow: var(--shadow-sm);
        margin-bottom: 24px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        flex-wrap: wrap;
        gap: 16px;
    }

    .notificacoes-header .header-left {
        display: flex;
        align-items: center;
        gap: 16px;
    }

    .notificacoes-header .header-left .icon-box {
        width: 52px;
        height: 52px;
        border-radius: 14px;
        background: linear-gradient(135deg, var(--primary), var(--secondary));
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 24px;
        color: #fff;
        box-shadow: 0 4px 15px rgba(79,70,229,0.3);
    }

    .notificacoes-header .header-left .title {
        font-size: 20px;
        font-weight: 800;
        color: var(--dark);
    }

    .notificacoes-header .header-left .subtitle {
        font-size: 13px;
        color: var(--gray);
        margin-top: 2px;
    }

    .notificacoes-header .header-left .subtitle strong {
        color: var(--danger);
    }

    .notificacoes-header .header-actions {
        display: flex;
        gap: 10px;
        flex-wrap: wrap;
    }

    .notificacao-item {
        background: #fff;
        border-radius: var(--border-radius);
        border: 1px solid var(--gray-border);
        box-shadow: var(--shadow-sm);
        padding: 18px 22px;
        margin-bottom: 12px;
        transition: var(--transition);
        display: flex;
        align-items: flex-start;
        gap: 18px;
        cursor: pointer;
        position: relative;
        overflow: hidden;
    }

    .notificacao-item::before {
        content: '';
        position: absolute;
        left: 0;
        top: 0;
        bottom: 0;
        width: 4px;
        border-radius: 0 4px 4px 0;
    }

    .notificacao-item.nao-lida::before {
        background: var(--primary);
    }

    .notificacao-item.nao-lida {
        background: rgba(79, 70, 229, 0.02);
        border-color: rgba(79, 70, 229, 0.15);
    }

    .notificacao-item:hover {
        transform: translateY(-2px);
        box-shadow: var(--shadow-md);
    }

    .notificacao-item .icone-wrapper {
        width: 48px;
        height: 48px;
        border-radius: 12px;
        display: flex;
        align-items: center;
        justify-content: center;
        flex-shrink: 0;
        font-size: 20px;
    }

    .notificacao-item .icone-wrapper.sucesso {
        background: var(--success-bg);
        color: var(--success);
    }

    .notificacao-item .icone-wrapper.aviso {
        background: var(--warning-bg);
        color: var(--warning);
    }

    .notificacao-item .icone-wrapper.erro {
        background: var(--danger-bg);
        color: var(--danger);
    }

    .notificacao-item .icone-wrapper.info {
        background: var(--info-bg);
        color: var(--info);
    }

    .notificacao-item .conteudo {
        flex: 1;
        min-width: 0;
    }

    .notificacao-item .conteudo .titulo {
        font-weight: 600;
        font-size: 15px;
        color: var(--dark);
        display: flex;
        align-items: center;
        gap: 8px;
        flex-wrap: wrap;
    }

    .notificacao-item .conteudo .titulo .badge-nova {
        background: var(--info);
        color: #fff;
        font-size: 9px;
        font-weight: 700;
        padding: 2px 10px;
        border-radius: 20px;
        text-transform: uppercase;
        letter-spacing: 0.5px;
    }

    .notificacao-item .conteudo .mensagem {
        color: var(--gray);
        font-size: 14px;
        margin-top: 4px;
        line-height: 1.6;
    }

    .notificacao-item .conteudo .link-acao {
        font-size: 13px;
        color: var(--primary);
        text-decoration: none;
        display: inline-flex;
        align-items: center;
        gap: 6px;
        margin-top: 6px;
        font-weight: 600;
        transition: var(--transition);
    }

    .notificacao-item .conteudo .link-acao:hover {
        color: var(--primary-dark);
        gap: 10px;
    }

    .notificacao-item .meta {
        display: flex;
        align-items: center;
        gap: 12px;
        flex-shrink: 0;
        margin-top: 4px;
    }

    .notificacao-item .meta .data {
        font-size: 12px;
        color: var(--gray);
        white-space: nowrap;
        display: flex;
        align-items: center;
        gap: 4px;
    }

    .notificacao-item .meta .data i {
        font-size: 12px;
        color: var(--gray-light);
    }

    .notificacao-item .meta .btn-marcar-lida {
        width: 32px;
        height: 32px;
        border: none;
        border-radius: 8px;
        background: rgba(16, 185, 129, 0.1);
        color: var(--success);
        cursor: pointer;
        transition: var(--transition);
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 14px;
    }

    .notificacao-item .meta .btn-marcar-lida:hover {
        background: var(--success);
        color: #fff;
        transform: scale(1.1);
    }

    .notificacao-item .meta .btn-marcar-lida i {
        font-size: 14px;
    }

    .empty-state {
        text-align: center;
        padding: 80px 20px;
        background: #fff;
        border-radius: var(--border-radius);
        border: 1px solid var(--gray-border);
        box-shadow: var(--shadow-sm);
    }

    .empty-state .empty-icon {
        font-size: 72px;
        color: var(--gray-border);
        margin-bottom: 20px;
    }

    .empty-state .empty-icon i {
        color: #e2e8f0;
    }

    .empty-state h5 {
        font-weight: 700;
        color: var(--dark);
        margin-bottom: 8px;
    }

    .empty-state p {
        color: var(--gray);
        font-size: 14px;
    }

    .btn-primary-custom {
        background: linear-gradient(135deg, var(--primary), var(--secondary));
        border: none;
        color: #fff;
        padding: 8px 20px;
        border-radius: 10px;
        font-weight: 600;
        font-size: 13px;
        transition: var(--transition);
        font-family: 'Inter', sans-serif;
        display: inline-flex;
        align-items: center;
        gap: 8px;
        text-decoration: none;
        box-shadow: 0 2px 10px rgba(79,70,229,0.2);
        cursor: pointer;
    }

    .btn-primary-custom:hover {
        transform: translateY(-2px);
        box-shadow: 0 8px 25px rgba(79,70,229,0.4);
        color: #fff;
    }

    .btn-outline-custom {
        background: var(--gray-light);
        border: 1px solid var(--gray-border);
        color: var(--dark);
        padding: 8px 18px;
        border-radius: 10px;
        font-weight: 600;
        font-size: 13px;
        transition: var(--transition);
        font-family: 'Inter', sans-serif;
        display: inline-flex;
        align-items: center;
        gap: 6px;
        text-decoration: none;
        cursor: pointer;
    }

    .btn-outline-custom:hover {
        background: var(--gray-border);
        color: var(--dark);
    }

    @media (max-width: 768px) {
        .notificacoes-header {
            flex-direction: column;
            align-items: stretch;
            padding: 18px 20px;
        }

        .notificacoes-header .header-left .icon-box {
            width: 44px;
            height: 44px;
            font-size: 20px;
        }

        .notificacoes-header .header-left .title {
            font-size: 17px;
        }

        .notificacao-item {
            flex-direction: column;
            padding: 16px 18px;
        }

        .notificacao-item .icone-wrapper {
            width: 40px;
            height: 40px;
            font-size: 16px;
        }

        .notificacao-item .meta {
            width: 100%;
            justify-content: space-between;
            margin-top: 8px;
        }

        .notificacao-item .conteudo .titulo {
            font-size: 14px;
        }

        .notificacao-item .conteudo .mensagem {
            font-size: 13px;
        }

        .notificacoes-header .header-actions {
            width: 100%;
        }

        .notificacoes-header .header-actions .btn {
            flex: 1;
            justify-content: center;
        }
    }

    @media (max-width: 480px) {
        .notificacao-item {
            padding: 14px 16px;
            gap: 12px;
        }

        .notificacao-item .icone-wrapper {
            width: 36px;
            height: 36px;
            font-size: 14px;
        }

        .notificacao-item .conteudo .titulo {
            font-size: 13px;
        }

        .notificacao-item .conteudo .mensagem {
            font-size: 12px;
        }

        .notificacao-item .meta .data {
            font-size: 10px;
        }

        .notificacoes-header .header-left .title {
            font-size: 15px;
        }

        .btn-primary-custom, .btn-outline-custom {
            font-size: 11px;
            padding: 6px 14px;
        }
    }

    @keyframes slideIn {
        from {
            opacity: 0;
            transform: translateY(20px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }

    .notificacao-item {
        animation: slideIn 0.4s ease forwards;
        opacity: 0;
    }

    .notificacao-item:nth-child(1) { animation-delay: 0.05s; }
    .notificacao-item:nth-child(2) { animation-delay: 0.10s; }
    .notificacao-item:nth-child(3) { animation-delay: 0.15s; }
    .notificacao-item:nth-child(4) { animation-delay: 0.20s; }
    .notificacao-item:nth-child(5) { animation-delay: 0.25s; }
    .notificacao-item:nth-child(6) { animation-delay: 0.30s; }
    .notificacao-item:nth-child(7) { animation-delay: 0.35s; }
    .notificacao-item:nth-child(8) { animation-delay: 0.40s; }
    .notificacao-item:nth-child(9) { animation-delay: 0.45s; }
    .notificacao-item:nth-child(10) { animation-delay: 0.50s; }
</style>

<div class="notificacoes-container animate-in">
    <!-- Header -->
    <div class="notificacoes-header">
        <div class="header-left">
            <div class="icon-box">
                <i class="fas fa-bell"></i>
            </div>
            <div>
                <div class="title">Minhas Notificações</div>
                <div class="subtitle">
                    <c:choose>
                        <c:when test="${naoLidas > 0}">
                            <i class="fas fa-circle" style="color: var(--danger); font-size: 8px; margin-right: 4px;"></i>
                            Você tem <strong>${naoLidas}</strong> notificação(ões) não lida(s)
                        </c:when>
                        <c:otherwise>
                            <i class="fas fa-check-circle" style="color: var(--success);"></i>
                            Todas as notificações foram lidas
                        </c:otherwise>
                    </c:choose>
                </div>
            </div>
        </div>
        <div class="header-actions">
            <c:if test="${naoLidas > 0}">
                <button class="btn-primary-custom" onclick="marcarTodas()">
                    <i class="fas fa-check-double"></i> Marcar todas como lidas
                </button>
            </c:if>
            <button class="btn-outline-custom" onclick="window.location.reload()">
                <i class="fas fa-sync"></i> Atualizar
            </button>
        </div>
    </div>

    <!-- Lista de Notificações -->
    <c:if test="${empty notificacoes}">
        <div class="empty-state">
            <div class="empty-icon">
                <i class="fas fa-bell-slash"></i>
            </div>
            <h5>Nenhuma notificação</h5>
            <p>Você não tem notificações no momento.</p>
            <p style="font-size: 12px; color: var(--gray-light); margin-top: 8px;">
                <i class="fas fa-arrow-left"></i> Volte ao <a href="${pageContext.request.contextPath}/dashboard" style="color: var(--primary); text-decoration: none; font-weight: 600;">Dashboard</a>
            </p>
        </div>
    </c:if>

    <c:if test="${not empty notificacoes}">
        <c:forEach items="${notificacoes}" var="n">
            <div class="notificacao-item ${n.status == 'NAO_LIDA' ? 'nao-lida' : ''}" onclick="marcarLidaClick(${n.id})">
                <!-- Ícone -->
                <div class="icone-wrapper 
                    ${n.tipo == 'SUCESSO' ? 'sucesso' : 
                      n.tipo == 'AVISO' ? 'aviso' : 
                      n.tipo == 'ERRO' ? 'erro' : 'info'}">
                    <i class="fas ${n.icone}"></i>
                </div>

                <!-- Conteúdo -->
                <div class="conteudo">
                    <div class="titulo">
                        ${n.titulo}
                        <c:if test="${n.status == 'NAO_LIDA'}">
                            <span class="badge-nova"><i class="fas fa-circle" style="font-size: 6px; margin-right: 4px;"></i> Nova</span>
                        </c:if>
                    </div>
                    <div class="mensagem">${n.mensagem}</div>
                    <c:if test="${not empty n.link}">
                        <a href="${pageContext.request.contextPath}${n.link}" class="link-acao" onclick="event.stopPropagation();">
                            <i class="fas fa-arrow-right"></i> Ver detalhes
                        </a>
                    </c:if>
                </div>

                <!-- Meta -->
                <div class="meta">
                    <span class="data">
                        <i class="far fa-clock"></i>
                        <fmt:formatDate value="${n.dataCriacao}" pattern="dd/MM/yyyy HH:mm" />
                    </span>
                    <c:if test="${n.status == 'NAO_LIDA'}">
                        <button class="btn-marcar-lida" onclick="event.stopPropagation(); marcarLida(${n.id})" title="Marcar como lida">
                            <i class="fas fa-check"></i>
                        </button>
                    </c:if>
                </div>
            </div>
        </c:forEach>

        <!-- Rodapé com contagem -->
        <div style="text-align: center; padding: 16px 0 4px 0; color: var(--gray); font-size: 12px;">
            <i class="fas fa-info-circle"></i>
            Mostrando <strong>${notificacoes.size()}</strong> notificação(ões)
            <c:if test="${naoLidas > 0}">
                · <strong style="color: var(--danger);">${naoLidas}</strong> não lida(s)
            </c:if>
        </div>
    </c:if>
</div>

<script>
function marcarLida(id) {
    fetch('${pageContext.request.contextPath}/notificacoes/marcar-lida', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: 'id=' + id
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            showNotification('success', 'Atualizado', 'Notificação marcada como lida');
            setTimeout(() => location.reload(), 800);
        } else {
            showNotification('error', 'Erro', data.message);
        }
    })
    .catch(error => {
        showNotification('error', 'Erro', 'Falha ao marcar como lida');
    });
}

function marcarLidaClick(id) {
    if (event.target.closest('.btn-marcar-lida')) return;
    if (event.target.closest('.link-acao')) return;
    marcarLida(id);
}

function marcarTodas() {
    if (confirm('Marcar todas as notificações como lidas?')) {
        fetch('${pageContext.request.contextPath}/notificacoes/marcar-todas', {
            method: 'POST'
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                showNotification('success', 'Atualizado', data.message);
                setTimeout(() => location.reload(), 800);
            } else {
                showNotification('error', 'Erro', data.message);
            }
        })
        .catch(error => {
            showNotification('error', 'Erro', 'Falha ao marcar todas como lidas');
        });
    }
}

function showNotification(type, title, message) {
    if (typeof window.showNotification === 'function') {
        window.showNotification(type, title, message);
    } else {
        alert(title + '\n\n' + message);
    }
}

// Carregar contagem de notificações ao entrar na página
document.addEventListener('DOMContentLoaded', function() {
    if (typeof carregarContagemNotificacoes === 'function') {
        carregarContagemNotificacoes();
    }
});
</script>

<jsp:include page="/WEB-INF/views/layout/footer.jsp" />
<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core"%>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt"%>

<jsp:include page="/WEB-INF/views/layout/header.jsp">
    <jsp:param name="pageTitle" value="Funcionários - Consulta" />
    <jsp:param name="activeMenu" value="funcionarios" />
</jsp:include>

<div class="table-section animate-in">
    <div class="table-header">
        <div class="title">
            <i class="fas fa-users me-2"></i>
            Funcionários do Setor
            <span style="font-size: 12px; font-weight: 400; color: var(--gray);">${total != null ? total : '0'} registros</span>
        </div>
        <div class="actions">
            <div class="search-box" style="position: relative;">
                <i class="fas fa-search" style="position: absolute; left: 12px; top: 50%; transform: translateY(-50%); color: var(--gray);"></i>
                <input type="text" id="searchFuncionario" placeholder="Pesquisar..." 
                       style="padding: 8px 12px 8px 36px; border: 1px solid var(--gray-border); border-radius: 10px; font-size: 13px; font-family: 'Inter', sans-serif; background: var(--gray-light);"
                       onkeyup="filterTable()">
            </div>
        </div>
    </div>

    <div class="table-responsive-custom">
        <table class="table-custom" id="funcionariosTable">
            <thead>
                <tr>
                    <th>Funcionário</th>
                    <th>Setor</th>
                    <th>Cargo</th>
                    <th>Status</th>
                    <th>Admissão</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <c:forEach items="${funcionarios}" var="f">
                    <tr>
                        <td>
                            <div class="d-flex align-items-center gap-3">
                                <div class="avatar-table">${f.nome.charAt(0)}${f.nome.split(' ')[1].charAt(0)}</div>
                                <div>
                                    <div style="font-weight: 600;">${f.nome}</div>
                                    <div style="font-size: 12px; color: var(--gray);">${f.emailEmpresa != null ? f.emailEmpresa : '-'}</div>
                                </div>
                            </div>
                        </td>
                        <td>${f.setor != null ? f.setor.nome : '-'}</td>
                        <td>${f.cargo != null ? f.cargo : '-'}</td>
                        <td>
                            <span class="status-badge 
                                ${f.status == 'ATIVO' ? 'ativo' : 
                                  f.status == 'FERIAS' ? 'ferias' : 
                                  f.status == 'LICENCA' ? 'licenca' : 
                                  f.status == 'AFASTADO' ? 'pendente' : 'inativo'}">
                                ${f.status}
                            </span>
                        </td>
                        <td><fmt:formatDate value="${f.dataAdmissao}" pattern="dd/MM/yyyy" /></td>
                        <td>
                            <div class="action-btns">
                                <a href="${pageContext.request.contextPath}/funcionarios/visualizar/${f.id}" class="btn-icon view">
                                    <i class="fas fa-eye"></i>
                                </a>
                            </div>
                        </td>
                    </tr>
                </c:forEach>
                <c:if test="${empty funcionarios}">
                    <tr>
                        <td colspan="6" style="text-align: center; padding: 30px; color: var(--gray);">
                            <i class="fas fa-inbox fa-2x d-block mb-2"></i>
                            Nenhum funcionário encontrado
                        </td>
                    </tr>
                </c:if>
            </tbody>
        </table>
    </div>
</div>

<script>
function filterTable() {
    const input = document.getElementById('searchFuncionario');
    const filter = input.value.toLowerCase();
    const rows = document.querySelectorAll('#funcionariosTable tbody tr');
    
    rows.forEach(row => {
        const text = row.textContent.toLowerCase();
        row.style.display = text.includes(filter) ? '' : 'none';
    });
}
</script>

<jsp:include page="/WEB-INF/views/layout/footer.jsp" />
<%@ taglib prefix="c" uri="jakarta.tags.core"%>
           <!-- FOOTER PROFISSIONAL - UTF-8 SAFE - MENUS POR PERFIL -->
<footer class="sigrh-footer">
    <div class="footer-container">
        
        <!-- Grid Superior -->
        <div class="footer-grid">
            <!-- Sobre (sempre visível) -->
            <div class="footer-col footer-about">
                <div class="footer-brand">
                    <c:choose>
                        <c:when test="${not empty empresaLogo}">
                            <img src="${pageContext.request.contextPath}/uploads/${empresaLogo}"
                                 alt="Logo" style="height: 40px; width: 40px; border-radius: 10px; object-fit: cover; flex-shrink: 0;">
                        </c:when>
                        <c:otherwise>
                            <div class="footer-logo">S</div>
                        </c:otherwise>
                    </c:choose>
                    <div>
                        <h2>${not empty empresaNome ? empresaNome : 'SIGRH'}</h2>
                        <span>Sistema Integrado de RH</span>
                    </div>
                </div>
                <p>
                    Gerencie todos os processos de Recursos Humanos em um &uacute;nico lugar, 
                    com seguran&ccedil;a, transpar&ecirc;ncia e efici&ecirc;ncia.
                </p>
                <div class="footer-badges">
                    <span class="badge-stable"><i class="fas fa-check-circle"></i> Est&aacute;vel</span>
                    <span class="badge-version"><i class="fas fa-code-branch"></i> v1.0.0</span>
                    <span class="badge-secure"><i class="fas fa-shield-alt"></i> Seguro</span>
                </div>
            </div>

            <!-- Links Rápidos - condicionados por perfil -->
            <div class="footer-col">
                <h4><i class="fas fa-link"></i> Links R&aacute;pidos</h4>
                <ul>
                    <li><a href="${pageContext.request.contextPath}/dashboard"><i class="fas fa-chevron-right"></i> Dashboard</a></li>

                    <!-- ADMIN = ADMIN + RH -->
                    <c:if test="${sessionScope.usuario.perfil == 'ADMIN'}">
                        <li><a href="${pageContext.request.contextPath}/funcionarios"><i class="fas fa-chevron-right"></i> Funcion&aacute;rios</a></li>
                        <li><a href="${pageContext.request.contextPath}/ferias"><i class="fas fa-chevron-right"></i> F&eacute;rias</a></li>
                        <li><a href="${pageContext.request.contextPath}/usuarios"><i class="fas fa-chevron-right"></i> Utilizadores</a></li>
                        <li><a href="${pageContext.request.contextPath}/relatorios"><i class="fas fa-chevron-right"></i> Relat&oacute;rios</a></li>
                    </c:if>

                    <!-- RH -->
                    <c:if test="${sessionScope.usuario.perfil == 'RH'}">
                        <li><a href="${pageContext.request.contextPath}/funcionarios"><i class="fas fa-chevron-right"></i> Funcion&aacute;rios</a></li>
                        <li><a href="${pageContext.request.contextPath}/ferias"><i class="fas fa-chevron-right"></i> F&eacute;rias</a></li>
                        <li><a href="${pageContext.request.contextPath}/relatorios"><i class="fas fa-chevron-right"></i> Relat&oacute;rios</a></li>
                    </c:if>

                    <!-- GESTOR -->
                    <c:if test="${sessionScope.usuario.perfil == 'GESTOR'}">
                        <li><a href="${pageContext.request.contextPath}/funcionarios"><i class="fas fa-chevron-right"></i> Funcion&aacute;rios</a></li>
                        <li><a href="${pageContext.request.contextPath}/ferias/pendentes"><i class="fas fa-chevron-right"></i> F&eacute;rias Pendentes</a></li>
                        <li><a href="${pageContext.request.contextPath}/relatorios"><i class="fas fa-chevron-right"></i> Relat&oacute;rios</a></li>
                    </c:if>

                    <!-- FINANCEIRO -->
                    <c:if test="${sessionScope.usuario.perfil == 'FINANCEIRO'}">
                        <li><a href="${pageContext.request.contextPath}/financeiro/folha-pagamento"><i class="fas fa-chevron-right"></i> Folha de Pagamento</a></li>
                        <li><a href="${pageContext.request.contextPath}/financeiro/salarios"><i class="fas fa-chevron-right"></i> Sal&aacute;rios</a></li>
                        <li><a href="${pageContext.request.contextPath}/relatorios"><i class="fas fa-chevron-right"></i> Relat&oacute;rios</a></li>
                    </c:if>

                    <!-- FUNCIONARIO -->
                    <c:if test="${sessionScope.usuario.perfil == 'FUNCIONARIO'}">
                        <li><a href="${pageContext.request.contextPath}/funcionario/meus-dados"><i class="fas fa-chevron-right"></i> Meus Dados</a></li>
                        <li><a href="${pageContext.request.contextPath}/funcionario/minhas-ferias"><i class="fas fa-chevron-right"></i> Minhas F&eacute;rias</a></li>
                        <li><a href="${pageContext.request.contextPath}/notificacoes"><i class="fas fa-chevron-right"></i> Notifica&ccedil;&otilde;es</a></li>
                    </c:if>
                </ul>
            </div>

            <!-- Módulos - condicionados por perfil -->
            <div class="footer-col">
                <h4><i class="fas fa-cubes"></i> M&oacute;dulos</h4>
                <ul>
                    <!-- ADMIN = ADMIN + RH -->
                    <c:if test="${sessionScope.usuario.perfil == 'ADMIN'}">
                        <li><a href="${pageContext.request.contextPath}/agregados"><i class="fas fa-chevron-right"></i> Agregados</a></li>
                        <li><a href="${pageContext.request.contextPath}/formacoes"><i class="fas fa-chevron-right"></i> Forma&ccedil;&otilde;es</a></li>
                        <li><a href="${pageContext.request.contextPath}/nomeacoes"><i class="fas fa-chevron-right"></i> Nomea&ccedil;&otilde;es</a></li>
                        <li><a href="${pageContext.request.contextPath}/plano-ferias"><i class="fas fa-chevron-right"></i> Plano de F&eacute;rias</a></li>
                        <li><a href="${pageContext.request.contextPath}/parametros"><i class="fas fa-chevron-right"></i> Par&acirc;metros</a></li>
                        <li><a href="${pageContext.request.contextPath}/auditoria"><i class="fas fa-chevron-right"></i> Auditoria</a></li>
                    </c:if>

                    <!-- RH -->
                    <c:if test="${sessionScope.usuario.perfil == 'RH'}">
                        <li><a href="${pageContext.request.contextPath}/agregados"><i class="fas fa-chevron-right"></i> Agregados</a></li>
                        <li><a href="${pageContext.request.contextPath}/formacoes"><i class="fas fa-chevron-right"></i> Forma&ccedil;&otilde;es</a></li>
                        <li><a href="${pageContext.request.contextPath}/nomeacoes"><i class="fas fa-chevron-right"></i> Nomea&ccedil;&otilde;es</a></li>
                        <li><a href="${pageContext.request.contextPath}/plano-ferias"><i class="fas fa-chevron-right"></i> Plano de F&eacute;rias</a></li>
                    </c:if>

                    <!-- GESTOR -->
                    <c:if test="${sessionScope.usuario.perfil == 'GESTOR'}">
                        <li><a href="${pageContext.request.contextPath}/ferias"><i class="fas fa-chevron-right"></i> F&eacute;rias</a></li>
                        <li><a href="${pageContext.request.contextPath}/plano-ferias"><i class="fas fa-chevron-right"></i> Plano de F&eacute;rias</a></li>
                    </c:if>

                    <!-- FINANCEIRO -->
                    <c:if test="${sessionScope.usuario.perfil == 'FINANCEIRO'}">
                        <li><a href="${pageContext.request.contextPath}/financeiro/dashboard"><i class="fas fa-chevron-right"></i> Dashboard Financeiro</a></li>
                        <li><a href="${pageContext.request.contextPath}/financeiro/folha-pagamento"><i class="fas fa-chevron-right"></i> Folha de Pagamento</a></li>
                        <li><a href="${pageContext.request.contextPath}/financeiro/salarios"><i class="fas fa-chevron-right"></i> Sal&aacute;rios</a></li>
                    </c:if>

                    <!-- FUNCIONARIO -->
                    <c:if test="${sessionScope.usuario.perfil == 'FUNCIONARIO'}">
                        <li><a href="${pageContext.request.contextPath}/funcionario/minhas-formacoes"><i class="fas fa-chevron-right"></i> Minhas Forma&ccedil;&otilde;es</a></li>
                        <li><a href="${pageContext.request.contextPath}/funcionario/minhas-nomeacoes"><i class="fas fa-chevron-right"></i> Minhas Nomea&ccedil;&otilde;es</a></li>
                        <li><a href="${pageContext.request.contextPath}/funcionario/alterar-senha"><i class="fas fa-chevron-right"></i> Alterar Senha</a></li>
                    </c:if>
                </ul>
            </div>

            <!-- Administração / Área específica -->
            <div class="footer-col">
                <h4><i class="fas fa-cog"></i> 
                    <c:choose>
                        <c:when test="${sessionScope.usuario.perfil == 'ADMIN'}">Administra&ccedil;&atilde;o</c:when>
                        <c:when test="${sessionScope.usuario.perfil == 'RH'}">RH</c:when>
                        <c:when test="${sessionScope.usuario.perfil == 'GESTOR'}">Gest&atilde;o</c:when>
                        <c:when test="${sessionScope.usuario.perfil == 'FINANCEIRO'}">Financeiro</c:when>
                        <c:when test="${sessionScope.usuario.perfil == 'FUNCIONARIO'}">Minha &Aacute;rea</c:when>
                        <c:otherwise>Sistema</c:otherwise>
                    </c:choose>
                </h4>
                <ul>
                    <!-- ADMIN = ADMIN + RH -->
                    <c:if test="${sessionScope.usuario.perfil == 'ADMIN'}">
                        <li><a href="${pageContext.request.contextPath}/usuarios"><i class="fas fa-chevron-right"></i> Utilizadores</a></li>
                        <li><a href="${pageContext.request.contextPath}/setores"><i class="fas fa-chevron-right"></i> Setores</a></li>
                        <li><a href="${pageContext.request.contextPath}/auditoria"><i class="fas fa-chevron-right"></i> Auditoria</a></li>
                        <li><a href="${pageContext.request.contextPath}/configuracoes"><i class="fas fa-chevron-right"></i> Configura&ccedil;&otilde;es</a></li>
                        <li><a href="${pageContext.request.contextPath}/ferias/pendentes"><i class="fas fa-chevron-right"></i> F&eacute;rias Pendentes</a></li>
                        <li><a href="${pageContext.request.contextPath}/plano-ferias"><i class="fas fa-chevron-right"></i> Plano de F&eacute;rias</a></li>
                    </c:if>

                    <c:if test="${sessionScope.usuario.perfil == 'RH'}">
                        <li><a href="${pageContext.request.contextPath}/funcionarios"><i class="fas fa-chevron-right"></i> Funcion&aacute;rios</a></li>
                        <li><a href="${pageContext.request.contextPath}/ferias/pendentes"><i class="fas fa-chevron-right"></i> F&eacute;rias Pendentes</a></li>
                        <li><a href="${pageContext.request.contextPath}/plano-ferias"><i class="fas fa-chevron-right"></i> Plano de F&eacute;rias</a></li>
                    </c:if>

                    <c:if test="${sessionScope.usuario.perfil == 'GESTOR'}">
                        <li><a href="${pageContext.request.contextPath}/funcionarios"><i class="fas fa-chevron-right"></i> Funcion&aacute;rios</a></li>
                        <li><a href="${pageContext.request.contextPath}/ferias/pendentes"><i class="fas fa-chevron-right"></i> F&eacute;rias Pendentes</a></li>
                    </c:if>

                    <c:if test="${sessionScope.usuario.perfil == 'FINANCEIRO'}">
                        <li><a href="${pageContext.request.contextPath}/financeiro/dashboard"><i class="fas fa-chevron-right"></i> Dashboard Financeiro</a></li>
                        <li><a href="${pageContext.request.contextPath}/financeiro/folha-pagamento"><i class="fas fa-chevron-right"></i> Folha</a></li>
                    </c:if>

                    <c:if test="${sessionScope.usuario.perfil == 'FUNCIONARIO'}">
                        <li><a href="${pageContext.request.contextPath}/funcionario/meus-dados"><i class="fas fa-chevron-right"></i> Meus Dados</a></li>
                        <li><a href="${pageContext.request.contextPath}/funcionario/minhas-ferias"><i class="fas fa-chevron-right"></i> Minhas F&eacute;rias</a></li>
                        <li><a href="${pageContext.request.contextPath}/notificacoes"><i class="fas fa-chevron-right"></i> Notifica&ccedil;&otilde;es</a></li>
                    </c:if>
                </ul>
            </div>
        </div>

        <!-- Linha Inferior -->
        <div class="footer-bottom">
            <div class="footer-tech">
                <span><i class="fas fa-database"></i> <strong>MySQL</strong></span>
                <span><i class="fas fa-server"></i> <strong>Tomcat 10.1</strong></span>
                <span><i class="fas fa-java"></i> <strong>Java 17</strong></span>
                <span><i class="fas fa-clock"></i> <span id="footerDateTime"></span></span>
                <span><i class="fas fa-user"></i> <strong>${sessionScope.usuario.nome}</strong></span>
            </div>

            <div class="footer-copyright">
                <p>
                    <i class="fas fa-copyright"></i> 2026 
                    <strong>${not empty empresaNome ? empresaNome : 'SIGRH'}</strong> &mdash; Sistema Integrado de Gest&atilde;o de Recursos Humanos.
                    <span class="separator">|</span>
                    Desenvolvido com <i class="fas fa-heart heart"></i> por <strong>SIGRH Team</strong>
                </p>
                
                <div class="footer-links">
                    <a href="#"><i class="fas fa-question-circle"></i> Ajuda</a>
                    <a href="#"><i class="fas fa-envelope"></i> Suporte</a>
                    <a href="#"><i class="fas fa-shield-alt"></i> Privacidade</a>
                    
                    <div class="social">
                        <a href="#" title="GitHub"><i class="fab fa-github"></i></a>
                        <a href="#" title="LinkedIn"><i class="fab fa-linkedin-in"></i></a>
                        <a href="#" title="YouTube"><i class="fab fa-youtube"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>
        </div> <!-- fecha page-content -->
    </div> <!-- fecha main-content -->

    <!-- Toast Container -->
    <div class="toast-container-custom" id="toastContainer"></div>

    <!-- Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
        // ========================================
        // INICIAIS SEGURAS DO USUÁRIO
        // ========================================
        (function() {
            const nome = "${sessionScope.usuario.nome}";
            let iniciais = "";
            if (nome && nome.trim().length > 0) {
                const parts = nome.trim().split(/\s+/);
                iniciais = parts[0].charAt(0).toUpperCase();
                if (parts.length > 1) {
                    iniciais += parts[parts.length - 1].charAt(0).toUpperCase();
                }
            } else {
                iniciais = "U";
            }
            
            const avatar = document.getElementById('userInitials');
            const headerAvatar = document.getElementById('headerInitials');
            if (avatar) avatar.textContent = iniciais;
            if (headerAvatar) headerAvatar.textContent = iniciais;
        })();

        // ========================================
        // ACORDEÃO
        // ========================================
        function toggleAccordion(id) {
            const body = document.getElementById(id);
            if (!body) return;
            
            const header = body.closest('.accordion-item-custom').querySelector('.accordion-header-custom');
            
            if (body.classList.contains('open')) {
                body.classList.remove('open');
                if (header) {
                    header.classList.remove('active');
                    header.setAttribute('aria-expanded', 'false');
                }
            } else {
                document.querySelectorAll('.accordion-body-custom.open').forEach(el => {
                    if (el.id !== id) {
                        el.classList.remove('open');
                        const h = el.closest('.accordion-item-custom').querySelector('.accordion-header-custom');
                        if (h) {
                            h.classList.remove('active');
                            h.setAttribute('aria-expanded', 'false');
                        }
                    }
                });
                body.classList.add('open');
                if (header) {
                    header.classList.add('active');
                    header.setAttribute('aria-expanded', 'true');
                }
            }
        }

        // ========================================
        // SIDEBAR MOBILE
        // ========================================
        document.getElementById('toggleSidebar').addEventListener('click', function() {
            document.getElementById('sidebar').classList.toggle('open');
            document.getElementById('sidebarOverlay').classList.toggle('show');
        });

        document.getElementById('sidebarOverlay').addEventListener('click', function() {
            document.getElementById('sidebar').classList.remove('open');
            document.getElementById('sidebarOverlay').classList.remove('show');
        });

        window.addEventListener('resize', function() {
            if (window.innerWidth > 992) {
                document.getElementById('sidebar').classList.remove('open');
                document.getElementById('sidebarOverlay').classList.remove('show');
            }
        });

        // ========================================
        // SEARCH
        // ========================================
        function searchTable() {
            const input = document.getElementById('globalSearch');
            if (!input) return;
            
            const filter = input.value.toLowerCase();
            document.querySelectorAll('.table-custom').forEach(table => {
                table.querySelectorAll('tbody tr').forEach(row => {
                    row.style.display = row.textContent.toLowerCase().includes(filter) ? '' : 'none';
                });
            });
        }

        // ========================================
        // TOAST
        // ========================================
        function showNotification(type, title, message) {
            const container = document.getElementById('toastContainer');
            if (!container) return;

            const iconMap = {
                success: 'fa-check-circle',
                error: 'fa-times-circle',
                warning: 'fa-exclamation-triangle',
                info: 'fa-info-circle'
            };

            const toast = document.createElement('div');
            toast.className = 'toast-custom ' + type;
            toast.innerHTML = `
                <div class="toast-icon ${type}">
                    <i class="fas ${iconMap[type] || 'fa-info-circle'}"></i>
                </div>
                <div class="toast-content">
                    <div class="title">${title}</div>
                    <div class="message">${message}</div>
                </div>
                <button class="toast-close" onclick="this.parentElement.remove()" aria-label="Fechar">
                    <i class="fas fa-times"></i>
                </button>
            `;

            container.appendChild(toast);

            setTimeout(() => {
                toast.style.animation = 'slideOutRight 0.4s ease forwards';
                setTimeout(() => toast.remove(), 400);
            }, 4000);
        }

        // ========================================
        // CONFIRM DELETE
        // ========================================
        function confirmDelete(message) {
            return confirm(message || 'Tem certeza que deseja excluir este registro?');
        }

        // ========================================
        // DATA/HORA DO FOOTER
        // ========================================
        function updateDateTime() {
            const el = document.getElementById('footerDateTime');
            if (el) {
                el.textContent = new Date().toLocaleString('pt-BR', {
                    day: '2-digit', month: '2-digit', year: 'numeric',
                    hour: '2-digit', minute: '2-digit', second: '2-digit'
                });
            }
        }
        updateDateTime();
        setInterval(updateDateTime, 1000);

        console.log('✅ SIGRH carregado com sucesso');
        console.log('👤 Usuário: ${sessionScope.usuario.nome} (${sessionScope.usuario.perfil})');
    </script>

    <style>
        /* ========== FOOTER STYLES ========== */
        .sigrh-footer {
            margin-top: 17%;
            background: linear-gradient(135deg, #0F172A 0%, #1E293B 100%);
            color: #fff;
            padding: 36px 32px 24px;
            border-radius: 16px 16px 0 0;
            border-top: 1px solid rgba(255,255,255,0.06);
            box-shadow: 0 -8px 30px rgba(0,0,0,0.08);
        }

        .footer-container {
            max-width: 1400px;
            margin: 0 auto;
        }

        .footer-grid {
            display: grid;
            grid-template-columns: 2fr 1fr 1fr 1fr;
            gap: 32px;
            padding-bottom: 24px;
            border-bottom: 1px solid rgba(255,255,255,0.06);
        }

        .footer-brand {
            display: flex;
            align-items: center;
            gap: 12px;
            margin-bottom: 12px;
        }

        .footer-logo {
            width: 40px;
            height: 40px;
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
            font-weight: 800;
            color: #fff;
            flex-shrink: 0;
        }

        .footer-brand h2 {
            font-size: 18px;
            font-weight: 800;
            margin: 0;
            line-height: 1.2;
        }

        .footer-brand span {
            display: block;
            font-size: 9px;
            font-weight: 400;
            color: rgba(255,255,255,0.4);
            letter-spacing: 0.8px;
            text-transform: uppercase;
        }

        .footer-about p {
            color: #94A3B8;
            font-size: 13px;
            line-height: 1.6;
            max-width: 300px;
            margin-bottom: 14px;
        }

        .footer-badges {
            display: flex;
            gap: 8px;
            flex-wrap: wrap;
        }

        .footer-badges span {
            padding: 3px 12px;
            border-radius: 20px;
            font-size: 10px;
            font-weight: 600;
            border: 1px solid transparent;
        }

        .badge-stable {
            background: rgba(16,185,129,0.15);
            color: #10B981;
            border-color: rgba(16,185,129,0.2);
        }

        .badge-version {
            background: rgba(255,255,255,0.06);
            color: #94A3B8;
            border-color: rgba(255,255,255,0.08);
        }

        .badge-secure {
            background: rgba(59,130,246,0.15);
            color: #3B82F6;
            border-color: rgba(59,130,246,0.2);
        }

        .footer-col h4 {
            font-size: 11px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            color: rgba(255,255,255,0.55);
            margin-bottom: 14px;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .footer-col h4 i {
            color: var(--primary-light);
            font-size: 12px;
        }

        .footer-col ul {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .footer-col li {
            margin-bottom: 8px;
        }

        .footer-col a {
            color: #94A3B8;
            text-decoration: none;
            font-size: 13px;
            display: flex;
            align-items: center;
            gap: 8px;
            transition: all 0.25s ease;
        }

        .footer-col a i {
            font-size: 8px;
            color: var(--primary-light);
            transition: transform 0.25s ease;
        }

        .footer-col a:hover {
            color: #fff;
            transform: translateX(4px);
        }

        .footer-col a:hover i {
            transform: translateX(2px);
        }

        /* Bottom */
        .footer-bottom {
            padding-top: 20px;
        }

        .footer-tech {
            display: flex;
            flex-wrap: wrap;
            gap: 18px;
            font-size: 12px;
            color: #64748B;
            margin-bottom: 16px;
            padding: 10px 16px;
            background: rgba(255,255,255,0.03);
            border-radius: 10px;
            border: 1px solid rgba(255,255,255,0.04);
        }

        .footer-tech i {
            color: var(--primary-light);
            margin-right: 4px;
        }

        .footer-tech strong {
            color: #94A3B8;
        }

        .footer-copyright {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 16px;
        }

        .footer-copyright p {
            color: #64748B;
            font-size: 12px;
            margin: 0;
        }

        .footer-copyright strong {
            color: #94A3B8;
        }

        .footer-copyright .separator {
            color: #475569;
            margin: 0 6px;
        }

        .footer-copyright .heart {
            color: var(--danger);
            animation: pulse-heart 1.5s infinite;
        }

        @keyframes pulse-heart {
            0%, 100% { transform: scale(1); }
            50% { transform: scale(1.25); }
        }

        .footer-links {
            display: flex;
            align-items: center;
            gap: 18px;
            flex-wrap: wrap;
        }

        .footer-links > a {
            color: #64748B;
            text-decoration: none;
            font-size: 12px;
            transition: color 0.25s ease;
        }

        .footer-links > a:hover {
            color: #fff;
        }

        .footer-links > a i {
            color: var(--primary-light);
            margin-right: 4px;
        }

        .social {
            display: flex;
            gap: 8px;
        }

        .social a {
            width: 32px;
            height: 32px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            background: rgba(255,255,255,0.04);
            color: #64748B;
            font-size: 14px;
            transition: all 0.25s ease;
            text-decoration: none;
        }

        .social a:hover {
            background: rgba(79,70,229,0.25);
            color: #fff;
            transform: translateY(-2px);
        }

        /* Responsive Footer */
        @media (max-width: 992px) {
            .footer-grid {
                grid-template-columns: 1fr 1fr;
                gap: 28px;
            }
        }

        @media (max-width: 576px) {
            .sigrh-footer {
                padding: 28px 20px 20px;
            }
            .footer-grid {
                grid-template-columns: 1fr;
                gap: 24px;
            }
            .footer-copyright {
                flex-direction: column;
                text-align: center;
            }
            .footer-links {
                justify-content: center;
            }
            .footer-tech {
                justify-content: center;
                text-align: center;
            }
        }
    </style>
</body>
</html>
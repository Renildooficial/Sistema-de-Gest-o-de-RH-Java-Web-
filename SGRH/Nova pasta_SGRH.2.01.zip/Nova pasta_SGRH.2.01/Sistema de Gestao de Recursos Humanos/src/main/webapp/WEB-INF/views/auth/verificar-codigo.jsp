<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core"%>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SIGRH - Verificar Código</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Inter', sans-serif;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            background: linear-gradient(135deg, #0F172A 0%, #1E293B 100%);
            padding: 20px;
        }
        .container {
            background: #fff;
            border-radius: 24px;
            padding: 48px 40px;
            max-width: 440px;
            width: 100%;
            box-shadow: 0 24px 80px rgba(0,0,0,0.3);
            animation: fadeInUp 0.6s ease;
        }
        @keyframes fadeInUp {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        .logo { text-align: center; margin-bottom: 32px; }
        .logo .brand-icon {
            width: 64px;
            height: 64px;
            background: linear-gradient(135deg, #4F46E5, #7C3AED);
            border-radius: 16px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            font-size: 32px;
            font-weight: 800;
            color: #fff;
            margin-bottom: 12px;
        }
        .logo h1 { font-size: 24px; font-weight: 800; color: #1E293B; }
        .logo p { color: #64748B; font-size: 14px; margin-top: 4px; }
        .form-group { margin-bottom: 20px; }
        .form-group label { font-weight: 600; font-size: 13px; color: #1E293B; margin-bottom: 6px; display: block; }
        .form-group .input-group { position: relative; }
        .form-group .input-group i {
            position: absolute;
            left: 14px;
            top: 50%;
            transform: translateY(-50%);
            color: #94A3B8;
            font-size: 16px;
        }
        .form-group .form-control {
            border: 1px solid #E2E8F0;
            border-radius: 12px;
            padding: 12px 16px 12px 44px;
            font-size: 14px;
            font-family: 'Inter', sans-serif;
            background: #F8FAFC;
            width: 100%;
            text-align: center;
            font-size: 24px;
            letter-spacing: 8px;
            font-weight: 700;
        }
        .form-group .form-control:focus {
            border-color: #4F46E5;
            box-shadow: 0 0 0 3px rgba(79,70,229,0.1);
            background: #fff;
            outline: none;
        }
        .btn-primary-custom {
            width: 100%;
            padding: 12px;
            background: linear-gradient(135deg, #4F46E5, #7C3AED);
            border: none;
            border-radius: 12px;
            color: #fff;
            font-weight: 700;
            font-size: 15px;
            font-family: 'Inter', sans-serif;
            transition: all 0.3s ease;
            cursor: pointer;
        }
        .btn-primary-custom:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 24px rgba(79,70,229,0.3);
        }
        .btn-primary-custom:disabled {
            opacity: 0.7;
            cursor: not-allowed;
            transform: none;
        }
        .btn-secondary-custom {
            width: 100%;
            padding: 12px;
            background: transparent;
            border: 1px solid #E2E8F0;
            border-radius: 12px;
            color: #1E293B;
            font-weight: 600;
            font-size: 14px;
            font-family: 'Inter', sans-serif;
            transition: all 0.3s ease;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
            text-align: center;
        }
        .btn-secondary-custom:hover { background: #F8FAFC; }
        .alert-custom {
            border-radius: 12px;
            padding: 12px 16px;
            margin-bottom: 16px;
            font-size: 14px;
        }
        .alert-custom.alert-danger {
            background: rgba(239,68,68,0.1);
            color: #EF4444;
            border-left: 4px solid #EF4444;
        }
        .alert-custom.alert-success {
            background: rgba(16,185,129,0.1);
            color: #10B981;
            border-left: 4px solid #10B981;
        }
        .alert-custom.alert-info {
            background: rgba(59,130,246,0.1);
            color: #3B82F6;
            border-left: 4px solid #3B82F6;
        }
        .footer-text { text-align: center; margin-top: 20px; font-size: 12px; color: #94A3B8; }
        .info-text {
            font-size: 13px;
            color: #64748B;
            margin-bottom: 20px;
            text-align: center;
            line-height: 1.6;
        }
        .codigo-hint {
            font-size: 12px;
            color: #94A3B8;
            text-align: center;
            margin-top: 8px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="logo">
            <div class="brand-icon">S</div>
            <h1>SIGRH</h1>
            <p>Verificar Código</p>
        </div>

        <div class="info-text">
            <i class="fas fa-key me-2" style="color: #4F46E5;"></i>
            Digite o código de 6 dígitos enviado para seu e-mail.
        </div>

        <c:if test="${not empty sessionScope.erro}">
            <div class="alert-custom alert-danger">
                <i class="fas fa-exclamation-circle me-2"></i> ${sessionScope.erro}
            </div>
            <c:remove var="erro" scope="session" />
        </c:if>
        <c:if test="${not empty sessionScope.sucesso}">
            <div class="alert-custom alert-success">
                <i class="fas fa-check-circle me-2"></i> ${sessionScope.sucesso}
            </div>
            <c:remove var="sucesso" scope="session" />
        </c:if>

        <form action="${pageContext.request.contextPath}/auth/verificar-codigo" method="post">
            <input type="hidden" name="email" value="${email}">
            <div class="form-group">
                <label for="codigo">Código de Verificação</label>
                <div class="input-group">
                    <i class="fas fa-shield-alt"></i>
                    <input type="text" class="form-control" id="codigo" name="codigo" 
                           placeholder="000000" required maxlength="6" pattern="[0-9]{6}"
                           autofocus>
                </div>
                <div class="codigo-hint">
                    <i class="fas fa-info-circle"></i> Digite os 6 dígitos recebidos por e-mail
                </div>
            </div>
            <button type="submit" class="btn-primary-custom">
                <i class="fas fa-check-circle me-2"></i> Verificar Código
            </button>
        </form>

        <div style="margin-top: 16px;">
            <a href="${pageContext.request.contextPath}/auth/recuperar-senha" class="btn-secondary-custom">
                <i class="fas fa-redo me-2"></i> Reenviar Código
            </a>
        </div>

        <div class="footer-text">
            <i class="fas fa-shield-alt me-1"></i> Ambiente seguro
        </div>
    </div>

    <script>
        // Auto-focus e limitar a 6 dígitos
        document.getElementById('codigo').addEventListener('input', function(e) {
            this.value = this.value.replace(/\D/g, '').slice(0, 6);
        });
    </script>
</body>
</html>
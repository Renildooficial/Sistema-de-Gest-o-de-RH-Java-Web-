<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core"%>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt"%>

<jsp:include page="/WEB-INF/views/layout/header.jsp">
    <jsp:param name="pageTitle" value="Backups do Sistema" />
    <jsp:param name="activeMenu" value="configuracoes" />
</jsp:include>

<style>
    .badge-backup {
        background: rgba(16,185,129,0.1);
        color: #059669;
        padding: 2px 10px;
        border-radius: 12px;
        font-size: 11px;
        font-weight: 600;
        border: 1px solid rgba(16,185,129,0.15);
    }
    .empty-state {
        text-align: center;
        padding: 60px 20px;
        color: var(--gray);
    }
    .empty-state i {
        font-size: 48px;
        margin-bottom: 16px;
        color: var(--primary-light);
    }
    
    .backup-item-full {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 12px 16px;
        background: #fff;
        border-radius: 8px;
        border: 1px solid var(--gray-border);
        margin-bottom: 8px;
        transition: var(--transition);
    }
    .backup-item-full:hover {
        border-color: var(--primary);
        box-shadow: var(--shadow-sm);
    }
    .backup-item-full .backup-info {
        display: flex;
        align-items: center;
        gap: 16px;
        font-size: 13px;
        flex-wrap: wrap;
    }
    .backup-item-full .backup-info i {
        color: var(--primary-light);
        font-size: 20px;
    }
    .backup-item-full .backup-info .nome {
        font-weight: 600;
        color: var(--dark);
    }
    .backup-item-full .backup-info .tamanho {
        color: var(--gray);
        font-size: 12px;
        background: var(--gray-light);
        padding: 2px 10px;
        border-radius: 12px;
    }
    .backup-item-full .backup-info .data {
        color: var(--gray);
        font-size: 12px;
    }
    .backup-item-full .backup-actions {
        display: flex;
        gap: 8px;
    }
    .backup-item-full .backup-actions .btn-sm {
        padding: 6px 14px;
        font-size: 12px;
        border-radius: 6px;
        border: none;
        cursor: pointer;
        transition: var(--transition);
        text-decoration: none;
        display: inline-flex;
        align-items: center;
        gap: 6px;
        font-weight: 500;
    }
    .backup-item-full .backup-actions .btn-download {
        background: var(--success-bg);
        color: var(--success);
    }
    .backup-item-full .backup-actions .btn-download:hover {
        background: var(--success);
        color: #fff;
    }
    .backup-item-full .backup-actions .btn-delete {
        background: var(--danger-bg);
        color: var(--danger);
    }
    .backup-item-full .backup-actions .btn-delete:hover {
        background: var(--danger);
        color: #fff;
    }

    @media (max-width: 768px) {
        .backup-item-full {
            flex-wrap: wrap;
            gap: 10px;
        }
        .backup-item-full .backup-info {
            width: 100%;
        }
        .backup-item-full .backup-actions {
            width: 100%;
            justify-content: flex-end;
        }
    }
</style>

<div class="table-section animate-in">
    <div class="table-header">
        <div class="title">
            <i class="fas fa-database me-2"></i>
            Backups do Sistema
            <span style="font-size: 12px; font-weight: 400; color: var(--gray);">${totalBackups != null ? totalBackups : '0'} arquivos</span>
        </div>
        <div class="actions">
            <a href="${pageContext.request.contextPath}/configuracoes" class="btn-outline-custom">
                <i class="fas fa-arrow-left"></i> Voltar
            </a>
            <button onclick="window.location.reload()" class="btn-outline-custom">
                <i class="fas fa-sync"></i> Atualizar
            </button>
            <button onclick="realizarBackup()" class="btn-primary-custom">
                <i class="fas fa-download"></i> Novo Backup
            </button>
        </div>
    </div>

    <!-- Resumo -->
    <div class="row g-3 mb-4">
        <div class="col-md-3 col-6">
            <div class="stat-card" style="padding: 12px 16px;">
                <div class="stat-label" style="font-size: 11px;">
                    <i class="fas fa-file-archive"></i> Total de Backups
                </div>
                <div class="stat-value" style="font-size: 20px;">${totalBackups != null ? totalBackups : 0}</div>
            </div>
        </div>
        <div class="col-md-3 col-6">
            <div class="stat-card" style="padding: 12px 16px; border-left: 4px solid var(--success);">
                <div class="stat-label" style="font-size: 11px;">
                    <i class="fas fa-clock"></i> Último Backup
                </div>
                <div class="stat-value" style="font-size: 14px; color: var(--success);">
                    ${not empty backups ? backups[0].data : 'Nunca'}
                </div>
            </div>
        </div>
        <div class="col-md-3 col-6">
            <div class="stat-card" style="padding: 12px 16px; border-left: 4px solid var(--info);">
                <div class="stat-label" style="font-size: 11px;">
                    <i class="fas fa-weight"></i> Espaço Total
                </div>
                <div class="stat-value" style="font-size: 14px; color: var(--info);">
                    ${espacoTotal != null ? espacoTotal : '0 MB'}
                </div>
            </div>
        </div>
        <div class="col-md-3 col-6">
            <div class="stat-card" style="padding: 12px 16px; border-left: 4px solid var(--warning);">
                <div class="stat-label" style="font-size: 11px;">
                    <i class="fas fa-folder"></i> Pasta
                </div>
                <div class="stat-value" style="font-size: 12px; color: var(--gray); word-break: break-all;">
                    ${pastaBackup != null ? pastaBackup : '-'}
                </div>
            </div>
        </div>
    </div>

    <div class="table-responsive-custom">
        <c:choose>
            <c:when test="${not empty backups}">
                <c:forEach items="${backups}" var="b" varStatus="i">
                    <div class="backup-item-full">
                        <div class="backup-info">
                            <i class="fas fa-file-archive"></i>
                            <span class="nome">#${i.index + 1} ${b.nome}</span>
                            <span class="tamanho">${b.tamanho}</span>
                            <span class="data"><i class="far fa-calendar-alt"></i> ${b.data}</span>
                        </div>
                        <div class="backup-actions">
                            <a href="${pageContext.request.contextPath}/configuracoes/download-backup?arquivo=${b.nome}" 
                               class="btn-sm btn-download" title="Baixar Backup">
                                <i class="fas fa-download"></i> Baixar
                            </a>
                            <button class="btn-sm btn-delete" onclick="excluirBackup('${b.nome}')" title="Excluir Backup">
                                <i class="fas fa-trash"></i> Excluir
                            </button>
                        </div>
                    </div>
                </c:forEach>
            </c:when>
            <c:otherwise>
                <div class="empty-state">
                    <i class="fas fa-database"></i>
                    <h5>Nenhum backup encontrado</h5>
                    <p>Clique em "Novo Backup" para criar o primeiro backup do sistema.</p>
                </div>
            </c:otherwise>
        </c:choose>
    </div>
</div>

<script>
function realizarBackup() {
    if (confirm('Deseja realizar um backup completo do sistema?')) {
        const btn = document.querySelector('button[onclick="realizarBackup()"]');
        btn.disabled = true;
        btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Processando...';
        
        fetch('${pageContext.request.contextPath}/configuracoes/backup', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                showNotification('success', 'Backup Concluído', data.message);
                setTimeout(() => location.reload(), 2000);
            } else {
                showNotification('error', 'Erro', data.message);
                btn.disabled = false;
                btn.innerHTML = '<i class="fas fa-download"></i> Novo Backup';
            }
        })
        .catch(error => {
            showNotification('error', 'Erro', 'Erro ao realizar backup');
            btn.disabled = false;
            btn.innerHTML = '<i class="fas fa-download"></i> Novo Backup';
        });
    }
}

function excluirBackup(nome) {
    if (confirm('Tem certeza que deseja excluir o backup "' + nome + '"?')) {
        fetch('${pageContext.request.contextPath}/configuracoes/excluir-backup', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: 'arquivo=' + encodeURIComponent(nome)
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                showNotification('success', 'Excluído', data.message);
                setTimeout(() => location.reload(), 1000);
            } else {
                showNotification('error', 'Erro', data.message);
            }
        })
        .catch(error => {
            showNotification('error', 'Erro', 'Erro ao excluir backup');
        });
    }
}

if (typeof showNotification === 'undefined') {
    window.showNotification = function(type, title, message) {
        alert(title + ': ' + message);
    };
}
</script>

<jsp:include page="/WEB-INF/views/layout/footer.jsp" />
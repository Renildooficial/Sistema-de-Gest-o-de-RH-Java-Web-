<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" isELIgnored="false"%>
<%@ taglib prefix="c" uri="jakarta.tags.core"%>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt"%>

<jsp:include page="/WEB-INF/views/layout/header.jsp">
    <jsp:param name="pageTitle" value="Dashboard - Financeiro" />
    <jsp:param name="activeMenu" value="dashboard" />
</jsp:include>

<style>
    /* ============================================================
    RESPONSIVIDADE - DASHBOARD FINANCEIRO
    ============================================================ */
    
    /* STATS CARDS - RESPONSIVO */
    .stats-grid {
        display: grid;
        grid-template-columns: repeat(4, 1fr);
        gap: 20px;
        margin-bottom: 24px;
    }
    
    .stat-card {
        background: #fff;
        border-radius: var(--border-radius);
        padding: 20px 24px;
        border: 1px solid var(--gray-border);
        box-shadow: var(--shadow-sm);
        transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        position: relative;
        overflow: hidden;
    }
    
    .stat-card::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        height: 3px;
    }
    
    .stat-card:hover {
        transform: translateY(-4px);
        box-shadow: var(--shadow-md);
    }
    
    .stat-card .stat-icon {
        width: 48px;
        height: 48px;
        border-radius: 12px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 20px;
        margin-bottom: 12px;
    }
    
    .stat-card .stat-icon.blue {
        background: rgba(79, 70, 229, 0.1);
        color: var(--primary);
    }
    .stat-card .stat-icon.blue::before { background: var(--primary); }
    
    .stat-card .stat-icon.green {
        background: rgba(16, 185, 129, 0.1);
        color: var(--success);
    }
    .stat-card .stat-icon.green::before { background: var(--success); }
    
    .stat-card .stat-icon.yellow {
        background: rgba(245, 158, 11, 0.1);
        color: var(--warning);
    }
    .stat-card .stat-icon.yellow::before { background: var(--warning); }
    
    .stat-card .stat-icon.purple {
        background: rgba(124, 58, 237, 0.1);
        color: #7C3AED;
    }
    .stat-card .stat-icon.purple::before { background: #7C3AED; }
    
    .stat-card .stat-value {
        font-size: 24px;
        font-weight: 700;
        color: var(--dark);
        line-height: 1.2;
    }
    
    .stat-card .stat-label {
        font-size: 13px;
        color: var(--gray);
        margin-top: 4px;
        font-weight: 500;
    }
    
    /* CHARTS GRID - RESPONSIVO */
    .charts-grid {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 20px;
        margin-bottom: 24px;
    }
    
    .chart-card {
        background: #fff;
        border-radius: var(--border-radius);
        padding: 20px;
        border: 1px solid var(--gray-border);
        box-shadow: var(--shadow-sm);
    }
    
    .chart-card .card-header {
        display: flex;
        justify-content: space-between;
        align-items: flex-start;
        margin-bottom: 16px;
        flex-wrap: wrap;
        gap: 8px;
    }
    
    .chart-card .card-title {
        font-size: 15px;
        font-weight: 700;
        color: var(--dark);
    }
    
    .chart-card .card-subtitle {
        font-size: 12px;
        color: var(--gray);
        font-weight: 400;
    }
    
    .chart-container {
        position: relative;
        height: 280px;
        width: 100%;
    }
    
    /* TABLE SECTION - RESPONSIVO */
    .table-section {
        background: #fff;
        border-radius: var(--border-radius);
        padding: 20px;
        border: 1px solid var(--gray-border);
        box-shadow: var(--shadow-sm);
        overflow: hidden;
    }
    
    .table-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 16px;
        flex-wrap: wrap;
        gap: 12px;
    }
    
    .table-header .title {
        font-size: 16px;
        font-weight: 700;
        color: var(--dark);
        display: flex;
        align-items: center;
        gap: 8px;
        flex-wrap: wrap;
    }
    
    .table-header .title i {
        color: var(--primary);
    }
    
    .table-header .title .badge-count {
        font-size: 12px;
        font-weight: 400;
        color: var(--gray);
    }
    
    .table-header .actions {
        display: flex;
        gap: 8px;
        flex-wrap: wrap;
    }
    
    .table-responsive-custom {
        overflow-x: auto;
        -webkit-overflow-scrolling: touch;
        margin: 0 -4px;
        padding: 0 4px;
    }
    
    .table-custom {
        width: 100%;
        border-collapse: collapse;
        font-size: 13px;
        min-width: 650px;
    }
    
    .table-custom thead th {
        background: var(--gray-light);
        padding: 10px 14px;
        text-align: left;
        font-size: 11px;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        font-weight: 700;
        color: var(--gray);
        border-bottom: 2px solid var(--gray-border);
        white-space: nowrap;
    }
    
    .table-custom tbody td {
        padding: 10px 14px;
        border-bottom: 1px solid var(--gray-border);
        vertical-align: middle;
    }
    
    .table-custom tbody tr {
        transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    }
    
    .table-custom tbody tr:hover {
        background: var(--gray-light);
    }
    
    /* STATUS BADGES */
    .status-badge {
        padding: 4px 14px;
        border-radius: 20px;
        font-size: 11px;
        font-weight: 600;
        display: inline-block;
        text-transform: uppercase;
        letter-spacing: 0.3px;
        white-space: nowrap;
    }
    
    .status-badge.ativo {
        background: rgba(16, 185, 129, 0.12);
        color: var(--success);
        border: 1px solid rgba(16, 185, 129, 0.2);
    }
    .status-badge.inativo {
        background: rgba(239, 68, 68, 0.12);
        color: var(--danger);
        border: 1px solid rgba(239, 68, 68, 0.2);
    }
    .status-badge.licenca {
        background: rgba(59, 130, 246, 0.12);
        color: var(--info);
        border: 1px solid rgba(59, 130, 246, 0.2);
    }
    .status-badge.ferias {
        background: rgba(245, 158, 11, 0.12);
        color: var(--warning);
        border: 1px solid rgba(245, 158, 11, 0.2);
    }
    .status-badge.pendente {
        background: rgba(245, 158, 11, 0.12);
        color: #D97706;
        border: 1px solid rgba(245, 158, 11, 0.2);
    }
    .status-badge.pago {
        background: rgba(16, 185, 129, 0.12);
        color: var(--success);
        border: 1px solid rgba(16, 185, 129, 0.2);
    }
    .status-badge.processado {
        background: rgba(59, 130, 246, 0.12);
        color: var(--info);
        border: 1px solid rgba(59, 130, 246, 0.2);
    }
    
    /* ACTION BUTTONS */
    .action-btns {
        display: flex;
        gap: 4px;
        flex-wrap: wrap;
    }
    
    .action-btns .btn-icon {
        width: 34px;
        height: 34px;
        border: none;
        border-radius: 8px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        background: transparent;
        color: var(--gray);
        font-size: 14px;
        text-decoration: none;
        position: relative;
    }
    
    .action-btns .btn-icon:hover {
        transform: translateY(-2px);
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
    }
    
    .action-btns .btn-icon.view {
        background: rgba(79, 70, 229, 0.1);
        color: var(--primary);
    }
    .action-btns .btn-icon.view:hover {
        background: rgba(79, 70, 229, 0.2);
        box-shadow: 0 4px 12px rgba(79, 70, 229, 0.3);
    }
    
    .action-btns .btn-icon.edit {
        background: rgba(16, 185, 129, 0.1);
        color: var(--success);
    }
    .action-btns .btn-icon.edit:hover {
        background: rgba(16, 185, 129, 0.2);
        box-shadow: 0 4px 12px rgba(16, 185, 129, 0.3);
    }
    
    .action-btns .btn-icon.delete {
        background: rgba(239, 68, 68, 0.1);
        color: var(--danger);
    }
    .action-btns .btn-icon.delete:hover {
        background: rgba(239, 68, 68, 0.2);
        box-shadow: 0 4px 12px rgba(239, 68, 68, 0.3);
    }
    
    .action-btns .btn-icon .tooltip {
        display: none;
        position: absolute;
        bottom: -28px;
        left: 50%;
        transform: translateX(-50%);
        background: var(--dark);
        color: #fff;
        padding: 2px 10px;
        border-radius: 4px;
        font-size: 9px;
        font-weight: 500;
        white-space: nowrap;
        z-index: 100;
    }
    
    .action-btns .btn-icon:hover .tooltip {
        display: block;
    }
    
    /* AVATAR */
    .avatar-mini {
        width: 36px;
        height: 36px;
        border-radius: 50%;
        background: linear-gradient(135deg, var(--primary), var(--secondary));
        display: flex;
        align-items: center;
        justify-content: center;
        color: #fff;
        font-weight: 700;
        font-size: 14px;
        flex-shrink: 0;
    }
    
    .funcionario-nome {
        font-weight: 500;
        font-size: 13px;
        color: var(--dark);
    }
    
    .funcionario-id {
        font-size: 10px;
        color: var(--gray);
    }

    /* ============================================================
    RESPONSIVIDADE - BREAKPOINTS
    ============================================================ */
    
    /* Tablets e telas médias */
    @media (max-width: 1200px) {
        .stats-grid {
            grid-template-columns: repeat(2, 1fr);
            gap: 16px;
        }
        .charts-grid {
            grid-template-columns: 1fr 1fr;
            gap: 16px;
        }
    }
    
    @media (max-width: 992px) {
        .stat-card .stat-value {
            font-size: 20px;
        }
        .stat-card .stat-icon {
            width: 40px;
            height: 40px;
            font-size: 16px;
        }
        .chart-container {
            height: 240px;
        }
        .table-section {
            padding: 16px;
        }
        .table-custom {
            font-size: 12px;
            min-width: 600px;
        }
        .table-custom thead th {
            padding: 8px 10px;
            font-size: 10px;
        }
        .table-custom tbody td {
            padding: 8px 10px;
        }
    }
    
    @media (max-width: 768px) {
        .stats-grid {
            grid-template-columns: repeat(2, 1fr);
            gap: 12px;
        }
        .charts-grid {
            grid-template-columns: 1fr;
            gap: 16px;
        }
        .chart-container {
            height: 220px;
        }
        .stat-card {
            padding: 16px 18px;
        }
        .stat-card .stat-value {
            font-size: 18px;
        }
        .stat-card .stat-label {
            font-size: 11px;
        }
        .stat-card .stat-icon {
            width: 36px;
            height: 36px;
            font-size: 14px;
            margin-bottom: 8px;
        }
        .table-section {
            padding: 12px;
        }
        .table-header {
            flex-direction: column;
            align-items: stretch;
        }
        .table-header .actions {
            justify-content: flex-start;
        }
        .table-custom {
            font-size: 11px;
            min-width: 500px;
        }
        .table-custom thead th {
            padding: 6px 8px;
            font-size: 9px;
        }
        .table-custom tbody td {
            padding: 6px 8px;
        }
        .action-btns .btn-icon {
            width: 30px;
            height: 30px;
            font-size: 12px;
        }
        .status-badge {
            font-size: 9px;
            padding: 2px 10px;
        }
        .avatar-mini {
            width: 30px;
            height: 30px;
            font-size: 12px;
        }
        .funcionario-nome {
            font-size: 12px;
        }
        .table-header .title {
            font-size: 14px;
        }
        .btn-primary-custom {
            font-size: 11px;
            padding: 6px 12px;
        }
        .chart-card .card-title {
            font-size: 13px;
        }
        .chart-card .card-subtitle {
            font-size: 11px;
        }
    }
    
    @media (max-width: 576px) {
        .stats-grid {
            grid-template-columns: 1fr 1fr;
            gap: 10px;
        }
        .stat-card {
            padding: 12px 14px;
        }
        .stat-card .stat-value {
            font-size: 16px;
        }
        .stat-card .stat-label {
            font-size: 10px;
        }
        .stat-card .stat-icon {
            width: 32px;
            height: 32px;
            font-size: 12px;
            border-radius: 8px;
            margin-bottom: 6px;
        }
        .charts-grid {
            gap: 12px;
        }
        .chart-card {
            padding: 12px;
        }
        .chart-container {
            height: 200px;
        }
        .table-section {
            padding: 10px;
        }
        .table-custom {
            font-size: 10px;
            min-width: 400px;
        }
        .table-custom thead th {
            padding: 4px 6px;
            font-size: 8px;
        }
        .table-custom tbody td {
            padding: 4px 6px;
        }
        .action-btns .btn-icon {
            width: 26px;
            height: 26px;
            font-size: 11px;
            border-radius: 6px;
        }
        .avatar-mini {
            width: 26px;
            height: 26px;
            font-size: 10px;
        }
        .status-badge {
            font-size: 8px;
            padding: 2px 8px;
        }
        .funcionario-nome {
            font-size: 11px;
        }
        .funcionario-id {
            font-size: 9px;
        }
        .table-header .title {
            font-size: 13px;
        }
        .table-header .title .badge-count {
            font-size: 10px;
        }
        .btn-primary-custom {
            font-size: 10px;
            padding: 4px 10px;
        }
        .btn-primary-custom i {
            font-size: 10px;
        }
        .chart-card .card-title {
            font-size: 12px;
        }
        .chart-card .card-subtitle {
            font-size: 10px;
        }
        .stat-card::before {
            height: 2px;
        }
    }
    
    @media (max-width: 480px) {
        .stats-grid {
            grid-template-columns: 1fr 1fr;
            gap: 8px;
        }
        .stat-card {
            padding: 10px 12px;
        }
        .stat-card .stat-value {
            font-size: 14px;
        }
        .stat-card .stat-label {
            font-size: 9px;
        }
        .stat-card .stat-icon {
            width: 28px;
            height: 28px;
            font-size: 11px;
            border-radius: 6px;
            margin-bottom: 4px;
        }
        .chart-container {
            height: 180px;
        }
        .table-custom {
            font-size: 9px;
            min-width: 350px;
        }
        .table-custom thead th {
            padding: 3px 4px;
            font-size: 7px;
        }
        .table-custom tbody td {
            padding: 3px 4px;
        }
        .action-btns {
            gap: 2px;
        }
        .action-btns .btn-icon {
            width: 22px;
            height: 22px;
            font-size: 10px;
            border-radius: 4px;
        }
        .avatar-mini {
            width: 22px;
            height: 22px;
            font-size: 9px;
        }
        .status-badge {
            font-size: 7px;
            padding: 1px 6px;
        }
        .funcionario-nome {
            font-size: 10px;
        }
        .funcionario-id {
            font-size: 8px;
        }
        .table-header .title {
            font-size: 12px;
        }
        .btn-primary-custom {
            font-size: 9px;
            padding: 3px 8px;
        }
        .btn-primary-custom i {
            font-size: 9px;
        }
        .chart-card .card-title {
            font-size: 11px;
        }
        .chart-card .card-subtitle {
            font-size: 9px;
        }
    }
</style>

<!-- Stats Cards -->
<div class="stats-grid">
    <div class="stat-card animate-in animate-in-d1">
        <div class="stat-icon blue">
            <i class="fas fa-users"></i>
        </div>
        <div class="stat-value">${totalFuncionarios != null ? totalFuncionarios : '0'}</div>
        <div class="stat-label">Total de Funcionários</div>
    </div>
    <div class="stat-card animate-in animate-in-d2">
        <div class="stat-icon green">
            <i class="fas fa-coins"></i>
        </div>
        <div class="stat-value">
            <fmt:formatNumber value="${totalFolha != null ? totalFolha : 0}" type="currency" currencySymbol="MZN " />
        </div>
        <div class="stat-label">Total da Folha (Mês)</div>
    </div>
    <div class="stat-card animate-in animate-in-d3">
        <div class="stat-icon yellow">
            <i class="fas fa-file-invoice"></i>
        </div>
        <div class="stat-value">${processados != null ? processados : '0'}</div>
        <div class="stat-label">Folhas Processadas</div>
    </div>
    <div class="stat-card animate-in animate-in-d4">
        <div class="stat-icon purple">
            <i class="fas fa-chart-line"></i>
        </div>
        <div class="stat-value">
            <fmt:formatNumber value="${mediaSalarial != null ? mediaSalarial : 0}" type="currency" currencySymbol="MZN " />
        </div>
        <div class="stat-label">Média Salarial</div>
    </div>
</div>

<!-- Charts -->
<div class="charts-grid">
    <div class="chart-card animate-in animate-in-d2">
        <div class="card-header">
            <div>
                <div class="card-title"><i class="fas fa-chart-bar" style="color: var(--primary); margin-right: 8px;"></i>Custo por Setor</div>
                <div class="card-subtitle">Distribuição dos custos mensais</div>
            </div>
            <a href="${pageContext.request.contextPath}/relatorios/financeiro" style="font-size: 12px; color: var(--primary); text-decoration: none; font-weight: 600;">
                Ver detalhes <i class="fas fa-arrow-right"></i>
            </a>
        </div>
        <div class="chart-container">
            <canvas id="custoSetorChart"></canvas>
        </div>
    </div>
    <div class="chart-card animate-in animate-in-d3">
        <div class="card-header">
            <div>
                <div class="card-title"><i class="fas fa-chart-line" style="color: var(--success); margin-right: 8px;"></i>Evolução da Folha</div>
                <div class="card-subtitle">Últimos 6 meses</div>
            </div>
        </div>
        <div class="chart-container">
            <canvas id="evolucaoChart"></canvas>
        </div>
    </div>
</div>

<!-- Últimas Folhas -->
<div class="table-section animate-in animate-in-d4">
    <div class="table-header">
        <div class="title">
            <i class="fas fa-file-invoice-dollar"></i>
            Últimas Folhas Processadas
            <span class="badge-count">
                <i class="fas fa-archive"></i> ${ultimasFolhas != null ? ultimasFolhas.size() : '0'} registros
            </span>
        </div>
        <div class="actions">
            <a href="${pageContext.request.contextPath}/financeiro/folha-pagamento" class="btn-primary-custom">
                <i class="fas fa-plus"></i> Nova Folha
            </a>
        </div>
    </div>
    <div class="table-responsive-custom">
        <table class="table-custom" id="folhasTable">
            <thead>
                <tr>
                    <th style="min-width: 130px;"><i class="fas fa-user me-1"></i>Funcionário</th>
                    <th style="min-width: 80px;"><i class="fas fa-calendar me-1"></i>Mês/Ano</th>
                    <th style="min-width: 100px;"><i class="fas fa-money-bill-wave me-1"></i>Salário Base</th>
                    <th style="min-width: 100px;"><i class="fas fa-hand-holding-usd me-1"></i>Líquido</th>
                    <th style="min-width: 90px;"><i class="fas fa-circle me-1"></i>Status</th>
                    <th style="min-width: 90px;"><i class="fas fa-cogs me-1"></i>Ações</th>
                </tr>
            </thead>
            <tbody>
                <c:forEach items="${ultimasFolhas}" var="f">
                    <tr>
                        <td>
                            <c:choose>
                                <c:when test="${not empty f.funcionario}">
                                    <div style="display: flex; align-items: center; gap: 10px;">
                                        <div class="avatar-mini">
                                            ${f.funcionario.nome.charAt(0)}${f.funcionario.nome.split(' ')[1].charAt(0)}
                                        </div>
                                        <div>
                                            <div class="funcionario-nome">${f.funcionario.nome}</div>
                                            <div class="funcionario-id">ID: #${f.funcionario.id}</div>
                                        </div>
                                    </div>
                                </c:when>
                                <c:otherwise>
                                    <span style="color: var(--gray);">-</span>
                                </c:otherwise>
                            </c:choose>
                        </td>
                        <td>
                            <span style="font-weight: 600;">
                                ${f.mesReferencia}/${f.anoReferencia}
                            </span>
                        </td>
                        <td>
                            <fmt:formatNumber value="${f.salarioBase}" type="currency" currencySymbol="MZN " />
                        </td>
                        <td>
                            <fmt:formatNumber value="${f.totalLiquido}" type="currency" currencySymbol="MZN " />
                        </td>
                        <td>
                            <span class="status-badge 
                                ${f.status == 'PAGO' ? 'pago' : 
                                  f.status == 'PROCESSADO' ? 'processado' : 
                                  f.status == 'PENDENTE' ? 'pendente' : 'inativo'}">
                                <i class="fas 
                                    ${f.status == 'PAGO' ? 'fa-check-circle' : 
                                      f.status == 'PROCESSADO' ? 'fa-sync' : 
                                      f.status == 'PENDENTE' ? 'fa-clock' : 'fa-times-circle'} 
                                    me-1"></i>
                                ${f.status}
                            </span>
                        </td>
                        <td>
                            <div class="action-btns">
                                <button class="btn-icon view" onclick="visualizarFolha(${f.id})" title="Visualizar">
                                    <i class="fas fa-eye"></i>
                                    <span class="tooltip">Visualizar</span>
                                </button>
                                <c:if test="${f.status == 'PENDENTE'}">
                                    <button class="btn-icon edit" onclick="processarFolha(${f.id})" title="Processar">
                                        <i class="fas fa-cogs"></i>
                                        <span class="tooltip">Processar</span>
                                    </button>
                                </c:if>
                            </div>
                        </td>
                    </tr>
                </c:forEach>
                <c:if test="${empty ultimasFolhas}">
                    <tr>
                        <td colspan="6" style="text-align: center; padding: 50px 20px; color: var(--gray);">
                            <i class="fas fa-inbox fa-3x d-block mb-3" style="opacity: 0.3;"></i>
                            <h5 style="font-weight: 600; color: var(--dark);">Nenhuma folha processada</h5>
                            <p style="font-size: 14px; color: var(--gray);">Clique em "Nova Folha" para começar</p>
                            <a href="${pageContext.request.contextPath}/financeiro/folha-pagamento" class="btn-primary-custom" style="margin-top: 10px;">
                                <i class="fas fa-plus"></i> Criar Folha
                            </a>
                        </td>
                    </tr>
                </c:if>
            </tbody>
        </table>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
// ============================================================
// GRÁFICO DE CUSTO POR SETOR - DADOS REAIS
// ============================================================
const ctx1 = document.getElementById('custoSetorChart').getContext('2d');

// Dados reais do backend
const custoPorSetorData = {
    labels: [
        <c:forEach items="${custoPorSetor}" var="entry" varStatus="status">
            '${entry.key}'${!status.last ? ',' : ''}
        </c:forEach>
    ],
    values: [
        <c:forEach items="${custoPorSetor}" var="entry" varStatus="status">
            ${entry.value}${!status.last ? ',' : ''}
        </c:forEach>
    ]
};

// Cores dinâmicas para os setores
const cores = [
    'rgba(79,70,229,0.8)',
    'rgba(59,130,246,0.8)',
    'rgba(16,185,129,0.8)',
    'rgba(245,158,11,0.8)',
    'rgba(124,58,237,0.8)',
    'rgba(239,68,68,0.8)',
    'rgba(14,165,233,0.8)',
    'rgba(236,72,153,0.8)',
    'rgba(168,85,247,0.8)',
    'rgba(251,146,60,0.8)'
];

const coresBorda = cores.map(c => c.replace('0.8', '1'));

new Chart(ctx1, {
    type: 'bar',
    data: {
        labels: custoPorSetorData.labels.length > 0 ? custoPorSetorData.labels : ['Sem dados'],
        datasets: [{
            label: 'Custo (MZN)',
            data: custoPorSetorData.values.length > 0 ? custoPorSetorData.values : [0],
            backgroundColor: custoPorSetorData.labels.length > 0 ? cores.slice(0, custoPorSetorData.labels.length) : ['rgba(200,200,200,0.8)'],
            borderColor: custoPorSetorData.labels.length > 0 ? coresBorda.slice(0, custoPorSetorData.labels.length) : ['rgba(200,200,200,1)'],
            borderWidth: 2,
            borderRadius: 8,
            maxBarThickness: 40,
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: { 
            legend: { display: false },
            tooltip: {
                callbacks: {
                    label: function(context) {
                        return 'MZN ' + context.parsed.y.toLocaleString('pt-MZ', {minimumFractionDigits: 2, maximumFractionDigits: 2});
                    }
                }
            }
        },
        scales: {
            y: { 
                beginAtZero: true, 
                grid: { color: 'rgba(0,0,0,0.05)' }, 
                ticks: { 
                    font: { size: 11 },
                    callback: function(value) {
                        return 'MZN ' + value.toLocaleString('pt-MZ');
                    },
                    maxTicksLimit: 8
                } 
            },
            x: { 
                grid: { display: false }, 
                ticks: { 
                    font: { size: 11 },
                    maxRotation: 45,
                    minRotation: 0
                } 
            }
        }
    }
});

// ============================================================
// GRÁFICO DE EVOLUÇÃO - DADOS REAIS
// ============================================================
const ctx2 = document.getElementById('evolucaoChart').getContext('2d');

// Dados reais do backend
const evolucaoData = {
    labels: [
        <c:forEach items="${evolucaoFolha}" var="entry" varStatus="status">
            '${entry.key}'${!status.last ? ',' : ''}
        </c:forEach>
    ],
    values: [
        <c:forEach items="${evolucaoFolha}" var="entry" varStatus="status">
            ${entry.value}${!status.last ? ',' : ''}
        </c:forEach>
    ]
};

new Chart(ctx2, {
    type: 'line',
    data: {
        labels: evolucaoData.labels.length > 0 ? evolucaoData.labels : ['Sem dados'],
        datasets: [{
            label: 'Total da Folha',
            data: evolucaoData.values.length > 0 ? evolucaoData.values : [0],
            borderColor: 'rgba(79,70,229,1)',
            backgroundColor: 'rgba(79,70,229,0.1)',
            fill: true,
            tension: 0.4,
            pointBackgroundColor: 'rgba(79,70,229,1)',
            pointRadius: 4,
            pointHoverRadius: 6,
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: { 
            legend: { display: false },
            tooltip: {
                callbacks: {
                    label: function(context) {
                        return 'MZN ' + context.parsed.y.toLocaleString('pt-MZ', {minimumFractionDigits: 2, maximumFractionDigits: 2});
                    }
                }
            }
        },
        scales: {
            y: { 
                beginAtZero: true, 
                grid: { color: 'rgba(0,0,0,0.05)' }, 
                ticks: { 
                    font: { size: 11 },
                    callback: function(value) {
                        return 'MZN ' + value.toLocaleString('pt-MZ');
                    },
                    maxTicksLimit: 8
                } 
            },
            x: { 
                grid: { display: false }, 
                ticks: { 
                    font: { size: 11 },
                    maxRotation: 45,
                    minRotation: 0
                } 
            }
        }
    }
});

// ============================================================
// FUNÇÕES AUXILIARES
// ============================================================
function visualizarFolha(id) {
    // Usar o mesmo padrão da página folha-pagamento.jsp
    window.location.href = '${pageContext.request.contextPath}/financeiro/folha-detalhes/' + id;
}

function processarFolha(id) {
    if (confirm('⚠️ Processar esta folha de pagamento?')) {
        fetch('${pageContext.request.contextPath}/financeiro/processar-folha', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: 'id=' + id
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                showNotification('success', '✅ Processado', data.message);
                setTimeout(() => location.reload(), 1000);
            } else {
                showNotification('error', '❌ Erro', data.message);
            }
        })
        .catch(error => {
            showNotification('error', '❌ Erro', 'Erro ao processar folha: ' + error.message);
        });
    }
}

// ============================================================
// FILTRO DE PESQUISA NA TABELA
// ============================================================
document.addEventListener('DOMContentLoaded', function() {
    var searchInput = document.getElementById('globalSearch');
    if (searchInput) {
        searchInput.addEventListener('keyup', function() {
            var filter = this.value.toLowerCase();
            var rows = document.querySelectorAll('#folhasTable tbody tr');
            
            rows.forEach(function(row) {
                var text = row.textContent.toLowerCase();
                row.style.display = text.includes(filter) ? '' : 'none';
            });
        });
    }
});

// ============================================================
// REDIMENSIONAR GRÁFICOS AO REDIMENSIONAR A JANELA
// ============================================================
let resizeTimeout;
window.addEventListener('resize', function() {
    clearTimeout(resizeTimeout);
    resizeTimeout = setTimeout(function() {
        // Os gráficos do Chart.js redimensionam automaticamente
        // Mas forçamos uma atualização suave
        document.querySelectorAll('.chart-container canvas').forEach(function(canvas) {
            if (canvas.chart) {
                canvas.chart.resize();
            }
        });
    }, 200);
});
</script>

<jsp:include page="/WEB-INF/views/layout/footer.jsp" />
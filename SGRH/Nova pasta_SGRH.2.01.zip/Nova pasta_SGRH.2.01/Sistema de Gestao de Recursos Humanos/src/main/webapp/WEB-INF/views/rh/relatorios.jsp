<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core"%>

<jsp:include page="/WEB-INF/views/layout/header.jsp">
    <jsp:param name="pageTitle" value="Relatórios" />
    <jsp:param name="activeMenu" value="relatorios" />
</jsp:include>

<div class="row g-4 animate-in">
    <div class="col-12">
        <h5 style="font-weight: 700; color: var(--dark);">
            <i class="fas fa-chart-bar me-2" style="color: var(--primary);"></i>
            Relatórios do Sistema
        </h5>
        <p style="color: var(--gray); font-size: 14px;">Selecione um relatório para visualizar ou exportar dados.</p>
    </div>

    <!-- Relatório de Funcionários -->
    <div class="col-md-4">
        <div class="stat-card" style="cursor: pointer; transition: all 0.3s ease;" 
             onclick="window.location.href='${pageContext.request.contextPath}/relatorios/funcionarios'">
            <div class="d-flex align-items-center gap-3">
                <div class="stat-icon blue" style="width: 48px; height: 48px; margin-bottom: 0;">
                    <i class="fas fa-users fa-lg"></i>
                </div>
                <div>
                    <div style="font-weight: 700; font-size: 16px;">Funcionários</div>
                    <div style="font-size: 13px; color: var(--gray);">Análise completa do quadro</div>
                </div>
            </div>
            <div style="margin-top: 12px;">
                <span class="badge" style="background: var(--primary-light); color: #fff; padding: 4px 12px;">
                    <i class="fas fa-arrow-right me-1"></i> Visualizar
                </span>
            </div>
        </div>
    </div>

    <!-- Relatório de Férias -->
    <div class="col-md-4">
        <div class="stat-card" style="cursor: pointer; transition: all 0.3s ease;"
             onclick="window.location.href='${pageContext.request.contextPath}/relatorios/ferias'">
            <div class="d-flex align-items-center gap-3">
                <div class="stat-icon yellow" style="width: 48px; height: 48px; margin-bottom: 0;">
                    <i class="fas fa-umbrella-beach fa-lg"></i>
                </div>
                <div>
                    <div style="font-weight: 700; font-size: 16px;">Férias</div>
                    <div style="font-size: 13px; color: var(--gray);">Status e planejamento</div>
                </div>
            </div>
            <div style="margin-top: 12px;">
                <span class="badge" style="background: var(--primary-light); color: #fff; padding: 4px 12px;">
                    <i class="fas fa-arrow-right me-1"></i> Visualizar
                </span>
            </div>
        </div>
    </div>

    <!-- Relatório Financeiro -->
    <div class="col-md-4">
        <div class="stat-card" style="cursor: pointer; transition: all 0.3s ease;"
             onclick="window.location.href='${pageContext.request.contextPath}/relatorios/financeiro'">
            <div class="d-flex align-items-center gap-3">
                <div class="stat-icon green" style="width: 48px; height: 48px; margin-bottom: 0;">
                    <i class="fas fa-coins fa-lg"></i>
                </div>
                <div>
                    <div style="font-weight: 700; font-size: 16px;">Financeiro</div>
                    <div style="font-size: 13px; color: var(--gray);">Folha e custos</div>
                </div>
            </div>
            <div style="margin-top: 12px;">
                <span class="badge" style="background: var(--primary-light); color: #fff; padding: 4px 12px;">
                    <i class="fas fa-arrow-right me-1"></i> Visualizar
                </span>
            </div>
        </div>
    </div>
</div>

<jsp:include page="/WEB-INF/views/layout/footer.jsp" />
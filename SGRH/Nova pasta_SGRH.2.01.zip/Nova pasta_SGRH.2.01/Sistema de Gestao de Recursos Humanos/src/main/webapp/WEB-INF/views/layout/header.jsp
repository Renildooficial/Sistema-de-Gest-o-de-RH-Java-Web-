<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" isELIgnored="false"%>
<%@ page import="com.sigrh.service.FuncionarioService" %>
<%@ page import="com.sigrh.exception.BusinessException" %>
<%@ page import="com.sigrh.util.ConfiguracaoUtil" %>
<%@ taglib prefix="c" uri="jakarta.tags.core"%>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt"%>

<%
    // =============================================================
    // CARREGAR TOTAL DE FUNCIONÁRIOS PARA O MENU (quando necessário)
    // =============================================================
    Integer totalFuncionarios = (Integer) session.getAttribute("totalFuncionariosMenu");
    
    if (totalFuncionarios == null) {
        try {
            FuncionarioService funcionarioService = new FuncionarioService();
            totalFuncionarios = funcionarioService.listarTodos().size();
            session.setAttribute("totalFuncionariosMenu", totalFuncionarios);
        } catch (BusinessException e) {
            totalFuncionarios = 0;
        } catch (Exception e) {
            totalFuncionarios = 0;
        }
    }
    
    request.setAttribute("totalFuncionarios", totalFuncionarios);
    
    // =============================================================
    // CONFIGURAÇÕES DA EMPRESA (nome + logo)
    // =============================================================
    String empresaNome = "SIGRH";
    String empresaLogo = null;
    try {
        empresaNome = ConfiguracaoUtil.getEmpresaNome();
        if (empresaNome == null || empresaNome.trim().isEmpty()) {
            empresaNome = "SIGRH";
        }
        empresaLogo = ConfiguracaoUtil.getEmpresaLogo();
        if (empresaLogo != null && empresaLogo.trim().isEmpty()) {
            empresaLogo = null;
        }
    } catch (Exception e) {
        empresaNome = "SIGRH";
        empresaLogo = null;
    }
    request.setAttribute("empresaNome", empresaNome);
    request.setAttribute("empresaLogo", empresaLogo);
%>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>SIGRH - ${param.pageTitle}</title>
    
    <!-- Bootstrap 5 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome 6 -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <!-- Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    
    <style>
        /* ============================================================
        CSS PRINCIPAL - COMPLETO
        ============================================================ */
        :root {
            --primary: #4F46E5;
            --primary-dark: #4338CA;
            --primary-light: #818CF8;
            --secondary: #7C3AED;
            --success: #10B981;
            --success-bg: rgba(16, 185, 129, 0.08);
            --warning: #F59E0B;
            --warning-bg: rgba(245, 158, 11, 0.08);
            --danger: #EF4444;
            --danger-bg: rgba(239, 68, 68, 0.08);
            --info: #3B82F6;
            --info-bg: rgba(59, 130, 246, 0.08);
            --dark: #1E293B;
            --gray: #64748B;
            --gray-light: #F1F5F9;
            --gray-border: #E2E8F0;
            --sidebar-width: 280px;
            --header-height: 68px;
            --border-radius: 16px;
            --transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            --shadow-sm: 0 1px 3px rgba(0,0,0,0.04);
            --shadow-md: 0 4px 20px rgba(0,0,0,0.06);
            --shadow-lg: 0 12px 40px rgba(0,0,0,0.08);
        }

        * { margin: 0; padding: 0; box-sizing: border-box; }

        html, body {
            height: 100%;
            margin: 0;
        }

        body {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
            background: #F8FAFC;
            color: var(--dark);
            overflow-x: hidden;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }

        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            height: 100vh;
            width: var(--sidebar-width);
            background: linear-gradient(180deg, #0F172A 0%, #1E293B 50%, #0F172A 100%);
            color: #fff;
            z-index: 1050;
            transition: var(--transition);
            box-shadow: 4px 0 30px rgba(0,0,0,0.2);
            overflow-y: auto;
            overflow-x: hidden;
            display: flex;
            flex-direction: column;
            scrollbar-width: none;
        }

        .sidebar::-webkit-scrollbar { display: none; }

        .sidebar::before {
            content: '';
            position: absolute;
            inset: 0;
            background: radial-gradient(circle at 0% 0%, rgba(79, 70, 229, 0.12), transparent 70%);
            pointer-events: none;
        }

        .sidebar-brand {
            padding: 20px 24px;
            border-bottom: 1px solid rgba(255,255,255,0.06);
            display: flex;
            align-items: center;
            gap: 14px;
            flex-shrink: 0;
            position: relative;
        }

        .sidebar-brand .brand-icon {
            width: 44px;
            height: 44px;
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 22px;
            font-weight: 800;
            color: #fff;
            flex-shrink: 0;
            box-shadow: 0 4px 15px rgba(79,70,229,0.4);
        }

        .sidebar-brand .brand-text {
            font-size: 18px;
            font-weight: 800;
            letter-spacing: -0.5px;
            line-height: 1.2;
            background: linear-gradient(135deg, #fff 60%, var(--primary-light));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        .sidebar-brand .brand-text small {
            display: block;
            font-size: 9px;
            font-weight: 400;
            opacity: 0.5;
            letter-spacing: 0.8px;
            text-transform: uppercase;
            -webkit-text-fill-color: rgba(255,255,255,0.5);
        }

        .sidebar-user {
            padding: 16px 20px;
            border-bottom: 1px solid rgba(255,255,255,0.06);
            display: flex;
            align-items: center;
            gap: 12px;
            flex-shrink: 0;
            background: rgba(255,255,255,0.03);
        }

        .sidebar-user .avatar {
            width: 42px;
            height: 42px;
            border-radius: 50%;
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 700;
            font-size: 16px;
            color: #fff;
            flex-shrink: 0;
            box-shadow: 0 2px 10px rgba(79,70,229,0.3);
        }

        .sidebar-user .user-info .name {
            font-size: 14px;
            font-weight: 600;
            color: #fff;
        }

        .sidebar-user .user-info .role {
            font-size: 11px;
            color: rgba(255,255,255,0.5);
            font-weight: 500;
        }

        .sidebar-user .role-badge {
            padding: 2px 10px;
            border-radius: 20px;
            font-size: 9px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            background: rgba(79,70,229,0.3);
            color: var(--primary-light);
            border: 1px solid rgba(79,70,229,0.2);
            flex-shrink: 0;
        }

        .sidebar-menu {
            padding: 8px 12px;
            flex: 1;
            overflow-y: auto;
            position: relative;
            z-index: 1;
            scrollbar-width: none;
        }

        .sidebar-menu::-webkit-scrollbar { display: none; }

        .sidebar-menu .menu-label {
            font-size: 9px;
            text-transform: uppercase;
            letter-spacing: 1px;
            color: rgba(255,255,255,0.25);
            padding: 12px 16px 6px;
            font-weight: 700;
        }

        .nav-link-top {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 10px 16px;
            border-radius: 10px;
            color: rgba(255,255,255,0.6);
            font-size: 13px;
            font-weight: 500;
            text-decoration: none;
            transition: var(--transition);
            margin-bottom: 4px;
        }

        .nav-link-top:hover {
            color: #fff;
            background: rgba(255,255,255,0.06);
        }

        .nav-link-top.active {
            color: #fff;
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            box-shadow: 0 4px 20px rgba(79,70,229,0.3);
        }

        .nav-link-top i {
            width: 20px;
            text-align: center;
            font-size: 15px;
        }

        .nav-link-top .badge-menu {
            margin-left: auto;
            background: rgba(255,255,255,0.12);
            color: #fff;
            padding: 1px 10px;
            border-radius: 20px;
            font-size: 10px;
            font-weight: 600;
        }

        .accordion-header-custom {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 10px 16px;
            border-radius: 10px;
            color: rgba(255,255,255,0.6);
            font-size: 13px;
            font-weight: 500;
            cursor: pointer;
            transition: var(--transition);
            width: 100%;
            background: transparent;
            border: none;
            font-family: 'Inter', sans-serif;
        }

        .accordion-header-custom:hover {
            color: #fff;
            background: rgba(255,255,255,0.06);
        }

        .accordion-header-custom .accordion-icon {
            width: 20px;
            text-align: center;
            font-size: 15px;
            flex-shrink: 0;
        }

        .accordion-header-custom .accordion-arrow {
            margin-left: auto;
            transition: transform 0.3s ease;
            font-size: 12px;
            color: rgba(255,255,255,0.3);
        }

        .accordion-header-custom.active .accordion-arrow {
            transform: rotate(180deg);
        }

        .accordion-header-custom .badge-menu {
            background: rgba(255,255,255,0.12);
            color: #fff;
            padding: 1px 10px;
            border-radius: 20px;
            font-size: 10px;
            font-weight: 600;
        }

        .accordion-body-custom {
            max-height: 0;
            overflow: hidden;
            transition: max-height 0.3s ease;
            padding-left: 8px;
        }

        .accordion-body-custom.open {
            max-height: 500px;
        }

        .accordion-body-custom .nav-item {
            margin-bottom: 2px;
        }

        .accordion-body-custom .nav-link {
            color: rgba(255,255,255,0.5);
            border-radius: 10px;
            padding: 8px 16px 8px 44px;
            display: flex;
            align-items: center;
            gap: 12px;
            text-decoration: none;
            transition: var(--transition);
            font-size: 13px;
            font-weight: 400;
            width: 100%;
            text-align: left;
            border: none;
            background: transparent;
            position: relative;
        }

        .accordion-body-custom .nav-link:hover {
            color: #fff;
            background: rgba(255,255,255,0.06);
        }

        .accordion-body-custom .nav-link.active {
            color: #fff;
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            box-shadow: 0 4px 20px rgba(79,70,229,0.3);
        }

        .accordion-body-custom .nav-link.active::before {
            content: '';
            position: absolute;
            left: 0;
            top: 50%;
            transform: translateY(-50%);
            width: 3px;
            height: 16px;
            background: #fff;
            border-radius: 0 4px 4px 0;
        }

        .accordion-body-custom .nav-link i {
            width: 18px;
            text-align: center;
            font-size: 13px;
            flex-shrink: 0;
        }

        .accordion-body-custom .nav-link .badge-menu {
            margin-left: auto;
            background: rgba(255,255,255,0.1);
            color: #fff;
            padding: 1px 8px;
            border-radius: 20px;
            font-size: 9px;
            font-weight: 600;
        }

        .sidebar-footer {
            padding: 16px 20px;
            border-top: 1px solid rgba(255,255,255,0.06);
            flex-shrink: 0;
            position: relative;
            z-index: 1;
        }

        .sidebar-footer .btn-logout {
            width: 100%;
            padding: 10px;
            border: none;
            border-radius: 10px;
            background: rgba(239,68,68,0.15);
            color: #EF4444;
            font-weight: 600;
            font-size: 13px;
            transition: var(--transition);
            font-family: 'Inter', sans-serif;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            cursor: pointer;
        }

        .sidebar-footer .btn-logout:hover {
            background: rgba(239,68,68,0.25);
            transform: scale(1.02);
        }

        .main-content {
            flex: 1;
            display: flex;
            flex-direction: column;
            margin-left: var(--sidebar-width);
            min-height: 100vh;
            transition: var(--transition);
        }

        .header {
            position: sticky;
            top: 0;
            background: rgba(255,255,255,0.85);
            backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);
            border-bottom: 1px solid rgba(0,0,0,0.04);
            padding: 0 32px;
            height: var(--header-height);
            display: flex;
            align-items: center;
            justify-content: space-between;
            z-index: 1040;
            transition: var(--transition);
            flex-shrink: 0;
        }

        .header::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            right: 0;
            height: 2px;
            background: linear-gradient(90deg, var(--primary), var(--secondary), var(--primary-light));
            opacity: 0.3;
        }

        .header-left {
            display: flex;
            align-items: center;
            gap: 16px;
        }

        .header-left .toggle-sidebar {
            display: none;
            background: none;
            border: none;
            font-size: 20px;
            color: var(--dark);
            cursor: pointer;
            padding: 8px;
            border-radius: 10px;
            transition: var(--transition);
        }

        .header-left .toggle-sidebar:hover {
            background: var(--gray-light);
        }

        .header-left .page-title {
            font-size: 20px;
            font-weight: 800;
            color: var(--dark);
            letter-spacing: -0.5px;
        }

        .header-left .page-title small {
            font-size: 13px;
            font-weight: 400;
            color: var(--gray);
            margin-left: 8px;
        }

        .header-right {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .header-right .search-box {
            position: relative;
        }

        .header-right .search-box input {
            width: 220px;
            padding: 8px 16px 8px 38px;
            border: 1px solid var(--gray-border);
            border-radius: 10px;
            font-size: 13px;
            background: var(--gray-light);
            transition: var(--transition);
            font-family: 'Inter', sans-serif;
        }

        .header-right .search-box input:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(79,70,229,0.1);
            background: #fff;
        }

        .header-right .search-box i {
            position: absolute;
            left: 13px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--gray);
            font-size: 14px;
        }

        .header-right .header-btn {
            width: 40px;
            height: 40px;
            border: none;
            border-radius: 10px;
            background: var(--gray-light);
            color: var(--dark);
            font-size: 17px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: var(--transition);
            position: relative;
        }

        .header-right .header-btn:hover {
            background: var(--gray-border);
            transform: translateY(-2px);
        }

        .header-right .header-btn .notification-dot {
            position: absolute;
            top: 8px;
            right: 8px;
            width: 8px;
            height: 8px;
            background: var(--danger);
            border-radius: 50%;
            border: 2px solid #fff;
            animation: pulse-dot 2s infinite;
        }

        @keyframes pulse-dot {
            0%, 100% { transform: scale(1); }
            50% { transform: scale(1.3); }
        }

        .header-right .user-avatar-header {
            width: 38px;
            height: 38px;
            border-radius: 50%;
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            display: flex;
            align-items: center;
            justify-content: center;
            color: #fff;
            font-weight: 700;
            font-size: 14px;
            cursor: pointer;
            transition: var(--transition);
            border: 2px solid transparent;
            box-shadow: 0 2px 10px rgba(79,70,229,0.2);
        }

        .header-right .user-avatar-header:hover {
            border-color: var(--primary);
            transform: scale(1.05);
            box-shadow: 0 4px 20px rgba(79,70,229,0.3);
        }

        .page-content {
            flex: 1;
            padding: 28px 32px;
        }

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 28px;
        }

        .stat-card {
            background: #fff;
            border-radius: var(--border-radius);
            padding: 22px 24px;
            box-shadow: var(--shadow-sm);
            border: 1px solid rgba(0,0,0,0.04);
            transition: var(--transition);
            position: relative;
            overflow: hidden;
        }

        .stat-card::before {
            content: '';
            position: absolute;
            top: 0; left: 0; right: 0;
            height: 3px;
            background: linear-gradient(90deg, var(--primary), var(--secondary));
            opacity: 0;
            transition: var(--transition);
        }

        .stat-card:hover::before { opacity: 1; }
        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: var(--shadow-lg);
        }

        .stat-card .stat-icon {
            width: 48px; height: 48px;
            border-radius: 14px;
            display: flex; align-items: center; justify-content: center;
            font-size: 20px; margin-bottom: 14px;
        }

        .stat-card .stat-icon.blue   { background: var(--info-bg); color: var(--info); }
        .stat-card .stat-icon.green  { background: var(--success-bg); color: var(--success); }
        .stat-card .stat-icon.yellow { background: var(--warning-bg); color: var(--warning); }
        .stat-card .stat-icon.red    { background: var(--danger-bg); color: var(--danger); }
        .stat-card .stat-icon.purple { background: rgba(79,70,229,0.1); color: var(--primary); }

        .stat-card .stat-value {
            font-size: 28px; font-weight: 800; color: var(--dark);
            line-height: 1.1; letter-spacing: -0.5px;
        }

        .stat-card .stat-label {
            font-size: 13px; color: var(--gray); font-weight: 500; margin-top: 4px;
        }

        .stat-card .stat-link {
            font-size: 12px; color: var(--primary); text-decoration: none;
            display: inline-flex; align-items: center; margin-top: 12px;
            font-weight: 600; transition: var(--transition);
        }

        .stat-card .stat-link:hover {
            color: var(--primary-dark); gap: 6px;
        }

        .quick-access-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(130px, 1fr));
            gap: 14px;
            margin-bottom: 28px;
        }

        .quick-card {
            background: #fff;
            border-radius: var(--border-radius);
            padding: 20px 14px;
            text-align: center;
            border: 1px solid rgba(0,0,0,0.04);
            box-shadow: var(--shadow-sm);
            transition: var(--transition);
            text-decoration: none;
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 8px;
        }

        .quick-card:hover {
            transform: translateY(-5px);
            box-shadow: var(--shadow-md);
            border-color: var(--primary);
        }

        .quick-card .quick-icon {
            font-size: 26px;
            width: 52px; height: 52px;
            border-radius: 14px;
            display: flex; align-items: center; justify-content: center;
            background: var(--gray-light);
            transition: var(--transition);
        }

        .quick-card:hover .quick-icon { transform: scale(1.08); }

        .quick-card .quick-label {
            font-size: 12px; font-weight: 600; color: var(--dark); line-height: 1.3;
        }

        .charts-grid {
            display: grid;
            grid-template-columns: 2fr 1fr;
            gap: 20px;
            margin-bottom: 28px;
        }

        .chart-card {
            background: #fff;
            border-radius: var(--border-radius);
            padding: 22px 24px;
            border: 1px solid rgba(0,0,0,0.04);
            box-shadow: var(--shadow-sm);
        }

        .chart-card .card-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 18px;
            gap: 12px;
        }

        .chart-card .card-title {
            font-size: 15px; font-weight: 700; color: var(--dark);
        }

        .chart-card .card-subtitle {
            font-size: 12px; color: var(--gray); margin-top: 2px;
        }

        .chart-container {
            position: relative;
            height: 260px;
        }

        .table-section {
            background: #fff;
            border-radius: var(--border-radius);
            padding: 22px 24px;
            border: 1px solid rgba(0,0,0,0.04);
            box-shadow: var(--shadow-sm);
            margin-bottom: 28px;
        }

        .table-section .table-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 18px;
            flex-wrap: wrap;
            gap: 12px;
        }

        .table-section .table-header .title {
            font-size: 15px; font-weight: 700; color: var(--dark);
            display: flex; align-items: center;
        }

        .table-section .table-header .title i { color: var(--primary); }

        .table-section .table-header .actions {
            display: flex; gap: 8px; flex-wrap: wrap;
        }

        .avatar-table {
            width: 36px; height: 36px;
            border-radius: 50%;
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            display: flex; align-items: center; justify-content: center;
            color: #fff; font-weight: 700; font-size: 13px;
            flex-shrink: 0;
        }

        .btn-primary-custom {
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            border: none; color: #fff;
            padding: 8px 18px; border-radius: 10px;
            font-weight: 600; font-size: 13px;
            transition: var(--transition); font-family: 'Inter', sans-serif;
            display: inline-flex; align-items: center; gap: 6px;
            text-decoration: none;
            box-shadow: 0 2px 10px rgba(79,70,229,0.2);
        }

        .btn-primary-custom:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(79,70,229,0.4);
            color: #fff;
        }

        .btn-outline-custom {
            background: var(--gray-light);
            border: 1px solid var(--gray-border);
            color: var(--dark);
            padding: 8px 18px; border-radius: 10px;
            font-weight: 600; font-size: 13px;
            transition: var(--transition); font-family: 'Inter', sans-serif;
            display: inline-flex; align-items: center; gap: 6px;
            text-decoration: none;
        }

        .btn-outline-custom:hover {
            background: var(--gray-border); color: var(--dark);
        }

        .table-custom {
            width: 100%; border-collapse: collapse; font-size: 13px;
        }

        .table-custom thead th {
            background: var(--gray-light);
            padding: 10px 14px; text-align: left;
            font-size: 11px; text-transform: uppercase; letter-spacing: 0.5px;
            font-weight: 700; color: var(--gray);
            border-bottom: 2px solid var(--gray-border);
            white-space: nowrap;
        }

        .table-custom tbody td {
            padding: 10px 14px;
            border-bottom: 1px solid var(--gray-border);
            vertical-align: middle;
        }

        .table-custom tbody tr:hover { background: var(--gray-light); }

        .table-custom .status-badge {
            padding: 3px 12px; border-radius: 20px;
            font-size: 11px; font-weight: 600; display: inline-block;
        }

        .table-custom .status-badge.ativo { background: var(--success-bg); color: var(--success); }
        .table-custom .status-badge.inativo { background: var(--danger-bg); color: var(--danger); }
        .table-custom .status-badge.ferias { background: var(--warning-bg); color: var(--warning); }
        .table-custom .status-badge.licenca { background: var(--info-bg); color: var(--info); }
        .table-custom .status-badge.pendente { background: rgba(245,158,11,0.15); color: #D97706; }
        .table-custom .status-badge.aprovado { background: var(--success-bg); color: var(--success); }

        .alert-custom {
            border-radius: var(--border-radius);
            padding: 16px 20px;
            margin-bottom: 20px;
            border: none;
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .alert-custom.alert-success {
            background: var(--success-bg); color: var(--success);
            border-left: 4px solid var(--success);
        }

        .alert-custom.alert-danger {
            background: var(--danger-bg); color: var(--danger);
            border-left: 4px solid var(--danger);
        }

        .alert-custom.alert-info {
            background: var(--info-bg); color: var(--info);
            border-left: 4px solid var(--info);
        }

        .toast-container-custom {
            position: fixed;
            bottom: 24px; right: 24px;
            z-index: 9999;
            display: flex; flex-direction: column; gap: 8px;
            max-width: 360px; width: 100%;
        }

        .toast-custom {
            background: #fff;
            border-radius: 12px;
            padding: 16px 20px;
            box-shadow: var(--shadow-lg);
            border-left: 4px solid var(--primary);
            animation: slideInRight 0.4s ease forwards;
            display: flex; align-items: center; gap: 12px;
        }

        .toast-custom.success { border-left-color: var(--success); }
        .toast-custom.error { border-left-color: var(--danger); }
        .toast-custom.warning { border-left-color: var(--warning); }
        .toast-custom.info { border-left-color: var(--info); }

        .toast-custom .toast-icon { font-size: 20px; flex-shrink: 0; }
        .toast-custom .toast-icon.success { color: var(--success); }
        .toast-custom .toast-icon.error { color: var(--danger); }
        .toast-custom .toast-icon.warning { color: var(--warning); }
        .toast-custom .toast-icon.info { color: var(--info); }

        .toast-custom .toast-content { flex: 1; }
        .toast-custom .toast-content .title { font-weight: 600; font-size: 14px; color: var(--dark); }
        .toast-custom .toast-content .message { font-size: 13px; color: var(--gray); }

        .toast-custom .toast-close {
            background: none; border: none; color: var(--gray);
            cursor: pointer; font-size: 16px; padding: 4px;
        }

        @keyframes slideInRight {
            from { opacity: 0; transform: translateX(40px); }
            to { opacity: 1; transform: translateX(0); }
        }

        @keyframes slideOutRight {
            from { opacity: 1; transform: translateX(0); }
            to { opacity: 0; transform: translateX(40px); }
        }

        .sidebar-overlay {
            display: none;
            position: fixed; inset: 0;
            background: rgba(0,0,0,0.5);
            z-index: 1045;
            backdrop-filter: blur(4px);
        }
        .sidebar-overlay.show { display: block; }

        @keyframes fadeInUp {
            from { opacity: 0; transform: translateY(18px); }
            to   { opacity: 1; transform: translateY(0); }
        }

        .animate-in {
            animation: fadeInUp 0.45s ease forwards;
        }

        .animate-in-d1 { animation-delay: 0.05s; opacity: 0; }
        .animate-in-d2 { animation-delay: 0.10s; opacity: 0; }
        .animate-in-d3 { animation-delay: 0.15s; opacity: 0; }
        .animate-in-d4 { animation-delay: 0.20s; opacity: 0; }
        .animate-in-d5 { animation-delay: 0.25s; opacity: 0; }

        @media (max-width: 992px) {
            .sidebar { transform: translateX(-100%); }
            .sidebar.open { transform: translateX(0); }
            .main-content { margin-left: 0; }
            .header-left .toggle-sidebar { display: block; }
            .header-right .search-box input { width: 160px; }
            .charts-grid { grid-template-columns: 1fr; }
        }

        @media (max-width: 768px) {
            .header { padding: 0 16px; }
            .page-content { padding: 16px; }
            .header-left .page-title { font-size: 16px; }
            .header-left .page-title small { display: none; }
            .header-right .search-box input { width: 120px; }
            .stats-grid { grid-template-columns: repeat(2, 1fr); gap: 14px; }
            .stat-card { padding: 18px; }
            .stat-card .stat-value { font-size: 22px; }
            .quick-access-grid { grid-template-columns: repeat(4, 1fr); gap: 10px; }
            .quick-card { padding: 14px 8px; }
            .quick-card .quick-icon { width: 42px; height: 42px; font-size: 20px; }
            .quick-card .quick-label { font-size: 11px; }
        }

        @media (max-width: 576px) {
            .header-right .search-box { display: none; }
            .sidebar { width: 100%; max-width: 300px; }
            .header-left .page-title { font-size: 14px; }
            .stats-grid { grid-template-columns: 1fr; }
            .quick-access-grid { grid-template-columns: repeat(2, 1fr); }
        }
    </style>
</head>
<body>
    <!-- Overlay Mobile -->
    <div class="sidebar-overlay" id="sidebarOverlay"></div>
<!-- No header.jsp, dentro da barra de navegação -->

    <!-- SIDEBAR -->
    <nav class="sidebar" id="sidebar" aria-label="Menu principal">
        <div class="sidebar-brand">
            <c:choose>
                <c:when test="${not empty empresaLogo}">
                    <img src="${pageContext.request.contextPath}/uploads/${empresaLogo}"
                         alt="Logo" style="height: 44px; width: 44px; border-radius: 12px; object-fit: cover; flex-shrink: 0;">
                </c:when>
                <c:otherwise>
                    <div class="brand-icon">S</div>
                </c:otherwise>
            </c:choose>
            <div class="brand-text">
                ${empresaNome}
                <small>Sistema Integrado de RH</small>
            </div>
        </div>

        <div class="sidebar-user">
            <div class="avatar" id="userInitials">
                ${sessionScope.usuario.nome.charAt(0)}${sessionScope.usuario.nome.split(' ')[1].charAt(0)}
            </div>
            <div class="user-info">
                <div class="name">${sessionScope.usuario.nome}</div>
                <div class="role">${sessionScope.usuario.perfil}</div>
            </div>
            <span class="role-badge">${sessionScope.usuario.perfil}</span>
        </div>

        <div class="sidebar-menu">
            <div class="menu-label">Menu Principal</div>
            
            <!-- ========== DASHBOARD - TODOS OS PERFIS ========== -->
            <a href="${pageContext.request.contextPath}/dashboard" 
               class="nav-link-top ${param.activeMenu == 'dashboard' ? 'active' : ''}">
                <i class="fas fa-th-large"></i> Dashboard
            </a>

            <!-- ============================================================
                 ADMIN = ADMIN + RH (acesso privilegiado completo)
                 ============================================================ -->
            <c:if test="${sessionScope.usuario.perfil == 'ADMIN'}">
                <!-- Gestão de Pessoas (RH) -->
                <div class="menu-label" style="margin-top: 12px;">Gestão de Pessoas</div>
                
                <div class="accordion-item-custom">
                    <button class="accordion-header-custom" onclick="toggleAccordion('accordionFuncionariosAdmin')">
                        <i class="fas fa-users accordion-icon"></i>
                        Funcionários
                        <span class="badge-menu">${totalFuncionarios != null ? totalFuncionarios : '0'}</span>
                        <i class="fas fa-chevron-down accordion-arrow"></i>
                    </button>
                    <div class="accordion-body-custom" id="accordionFuncionariosAdmin">
                        <div class="nav-item">
                            <a href="${pageContext.request.contextPath}/funcionarios" 
                               class="nav-link ${param.activeMenu == 'funcionarios' ? 'active' : ''}">
                                <i class="fas fa-list"></i> Listar Funcionários
                            </a>
                        </div>
                        <div class="nav-item">
                            <a href="${pageContext.request.contextPath}/funcionarios/novo" class="nav-link">
                                <i class="fas fa-user-plus"></i> Novo Funcionário
                            </a>
                        </div>
                    </div>
                </div>

                <div class="accordion-item-custom">
                    <button class="accordion-header-custom" onclick="toggleAccordion('accordionAgregadosAdmin')">
                        <i class="fas fa-user-friends accordion-icon"></i>
                        Agregados
                        <i class="fas fa-chevron-down accordion-arrow"></i>
                    </button>
                    <div class="accordion-body-custom" id="accordionAgregadosAdmin">
                        <div class="nav-item">
                            <a href="${pageContext.request.contextPath}/agregados" 
                               class="nav-link ${param.activeMenu == 'agregados' ? 'active' : ''}">
                                <i class="fas fa-list"></i> Listar Agregados
                            </a>
                        </div>
                        <div class="nav-item">
                            <a href="${pageContext.request.contextPath}/agregados/novo" class="nav-link">
                                <i class="fas fa-user-plus"></i> Novo Agregado
                            </a>
                        </div>
                    </div>
                </div>

                <div class="accordion-item-custom">
                    <button class="accordion-header-custom" onclick="toggleAccordion('accordionFormacoesAdmin')">
                        <i class="fas fa-graduation-cap accordion-icon"></i>
                        Formações
                        <i class="fas fa-chevron-down accordion-arrow"></i>
                    </button>
                    <div class="accordion-body-custom" id="accordionFormacoesAdmin">
                        <div class="nav-item">
                            <a href="${pageContext.request.contextPath}/formacoes" 
                               class="nav-link ${param.activeMenu == 'formacoes' ? 'active' : ''}">
                                <i class="fas fa-list"></i> Listar Formações
                            </a>
                        </div>
                        <div class="nav-item">
                            <a href="${pageContext.request.contextPath}/formacoes/novo" class="nav-link">
                                <i class="fas fa-plus-circle"></i> Nova Formação
                            </a>
                        </div>
                    </div>
                </div>

                <div class="accordion-item-custom">
                    <button class="accordion-header-custom" onclick="toggleAccordion('accordionNomeacoesAdmin')">
                        <i class="fas fa-briefcase accordion-icon"></i>
                        Nomeações
                        <i class="fas fa-chevron-down accordion-arrow"></i>
                    </button>
                    <div class="accordion-body-custom" id="accordionNomeacoesAdmin">
                        <div class="nav-item">
                            <a href="${pageContext.request.contextPath}/nomeacoes" 
                               class="nav-link ${param.activeMenu == 'nomeacoes' ? 'active' : ''}">
                                <i class="fas fa-list"></i> Listar Nomeações
                            </a>
                        </div>
                        <div class="nav-item">
                            <a href="${pageContext.request.contextPath}/nomeacoes/novo" class="nav-link">
                                <i class="fas fa-plus-circle"></i> Nova Nomeação
                            </a>
                        </div>
                    </div>
                </div>

                <!-- Gestão de Férias (RH) -->
                <div class="menu-label" style="margin-top: 12px;">Gestão de Férias</div>

                <div class="accordion-item-custom">
                    <button class="accordion-header-custom" onclick="toggleAccordion('accordionFeriasAdmin')">
                        <i class="fas fa-umbrella-beach accordion-icon"></i>
                        Férias
                        <span class="badge-menu">${feriasPendentes != null ? feriasPendentes : '0'}</span>
                        <i class="fas fa-chevron-down accordion-arrow"></i>
                    </button>
                    <div class="accordion-body-custom" id="accordionFeriasAdmin">
                        <div class="nav-item">
                            <a href="${pageContext.request.contextPath}/ferias" 
                               class="nav-link ${param.activeMenu == 'ferias' ? 'active' : ''}">
                                <i class="fas fa-list"></i> Gerenciar Férias
                            </a>
                        </div>
                        <div class="nav-item">
                            <a href="${pageContext.request.contextPath}/ferias/pendentes" class="nav-link">
                                <i class="fas fa-clock"></i> Pendentes
                                <span class="badge-menu">${feriasPendentes != null ? feriasPendentes : '0'}</span>
                            </a>
                        </div>
                    </div>
                </div>

                <div class="accordion-item-custom">
                    <button class="accordion-header-custom" onclick="toggleAccordion('accordionPlanoFeriasAdmin')">
                        <i class="fas fa-calendar-alt accordion-icon"></i>
                        Plano de Férias
                        <i class="fas fa-chevron-down accordion-arrow"></i>
                    </button>
                    <div class="accordion-body-custom" id="accordionPlanoFeriasAdmin">
                        <div class="nav-item">
                            <a href="${pageContext.request.contextPath}/plano-ferias" 
                               class="nav-link ${param.activeMenu == 'plano-ferias' ? 'active' : ''}">
                                <i class="fas fa-list"></i> Visualizar Plano
                            </a>
                        </div>
                        <div class="nav-item">
                            <a href="${pageContext.request.contextPath}/plano-ferias/novo" class="nav-link">
                                <i class="fas fa-plus-circle"></i> Adicionar ao Plano
                            </a>
                        </div>
                    </div>
                </div>

                <!-- Administração (exclusivo ADMIN) -->
                <div class="menu-label" style="margin-top: 12px;">Administração</div>

                <div class="accordion-item-custom">
                    <button class="accordion-header-custom" onclick="toggleAccordion('accordionAdmin')">
                        <i class="fas fa-cogs accordion-icon"></i>
                        Configurações
                        <i class="fas fa-chevron-down accordion-arrow"></i>
                    </button>
                    <div class="accordion-body-custom" id="accordionAdmin">
                        <div class="nav-item">
                            <a href="${pageContext.request.contextPath}/usuarios" 
                               class="nav-link ${param.activeMenu == 'usuarios' ? 'active' : ''}">
                                <i class="fas fa-user-cog"></i> Utilizadores
                            </a>
                        </div>
                        <div class="nav-item">
                            <a href="${pageContext.request.contextPath}/setores" 
                               class="nav-link ${param.activeMenu == 'setores' ? 'active' : ''}">
                                <i class="fas fa-building"></i> Setores
                            </a>
                        </div>
                        <div class="nav-item">
                            <a href="${pageContext.request.contextPath}/parametros" 
                               class="nav-link ${param.activeMenu == 'parametros' ? 'active' : ''}">
                                <i class="fas fa-sliders-h"></i> Parâmetros
                            </a>
                        </div>
                        <div class="nav-item">
                            <a href="${pageContext.request.contextPath}/configuracoes" 
                               class="nav-link ${param.activeMenu == 'configuracoes' ? 'active' : ''}">
                                <i class="fas fa-cog"></i> Configurações
                            </a>
                        </div>
                        <div class="nav-item">
                            <a href="${pageContext.request.contextPath}/auditoria" 
                               class="nav-link ${param.activeMenu == 'auditoria' ? 'active' : ''}">
                                <i class="fas fa-clipboard-list"></i> Auditoria
                            </a>
                        </div>
                    </div>
                </div>

                <div class="menu-label" style="margin-top: 12px;">Relatórios</div>
                <a href="${pageContext.request.contextPath}/relatorios" 
                   class="nav-link-top ${param.activeMenu == 'relatorios' ? 'active' : ''}">
                    <i class="fas fa-chart-bar"></i> Central de Relatórios
                </a>
            </c:if>

            <!-- ============================================================
                 RH - SOMENTE Gestão de Pessoas + Férias + Relatórios RH
                 ============================================================ -->
            <c:if test="${sessionScope.usuario.perfil == 'RH'}">
                <div class="menu-label" style="margin-top: 12px;">Gestão de Pessoas</div>
                
                <div class="accordion-item-custom">
                    <button class="accordion-header-custom" onclick="toggleAccordion('accordionFuncionarios')">
                        <i class="fas fa-users accordion-icon"></i>
                        Funcionários
                        <span class="badge-menu">${totalFuncionarios != null ? totalFuncionarios : '0'}</span>
                        <i class="fas fa-chevron-down accordion-arrow"></i>
                    </button>
                    <div class="accordion-body-custom" id="accordionFuncionarios">
                        <div class="nav-item">
                            <a href="${pageContext.request.contextPath}/funcionarios" 
                               class="nav-link ${param.activeMenu == 'funcionarios' ? 'active' : ''}">
                                <i class="fas fa-list"></i> Listar Funcionários
                            </a>
                        </div>
                        <div class="nav-item">
                            <a href="${pageContext.request.contextPath}/funcionarios/novo" class="nav-link">
                                <i class="fas fa-user-plus"></i> Novo Funcionário
                            </a>
                        </div>
                    </div>
                </div>

                <div class="accordion-item-custom">
                    <button class="accordion-header-custom" onclick="toggleAccordion('accordionAgregados')">
                        <i class="fas fa-user-friends accordion-icon"></i>
                        Agregados
                        <i class="fas fa-chevron-down accordion-arrow"></i>
                    </button>
                    <div class="accordion-body-custom" id="accordionAgregados">
                        <div class="nav-item">
                            <a href="${pageContext.request.contextPath}/agregados" 
                               class="nav-link ${param.activeMenu == 'agregados' ? 'active' : ''}">
                                <i class="fas fa-list"></i> Listar Agregados
                            </a>
                        </div>
                        <div class="nav-item">
                            <a href="${pageContext.request.contextPath}/agregados/novo" class="nav-link">
                                <i class="fas fa-user-plus"></i> Novo Agregado
                            </a>
                        </div>
                    </div>
                </div>

                <div class="accordion-item-custom">
                    <button class="accordion-header-custom" onclick="toggleAccordion('accordionFormacoes')">
                        <i class="fas fa-graduation-cap accordion-icon"></i>
                        Formações
                        <i class="fas fa-chevron-down accordion-arrow"></i>
                    </button>
                    <div class="accordion-body-custom" id="accordionFormacoes">
                        <div class="nav-item">
                            <a href="${pageContext.request.contextPath}/formacoes" 
                               class="nav-link ${param.activeMenu == 'formacoes' ? 'active' : ''}">
                                <i class="fas fa-list"></i> Listar Formações
                            </a>
                        </div>
                        <div class="nav-item">
                            <a href="${pageContext.request.contextPath}/formacoes/novo" class="nav-link">
                                <i class="fas fa-plus-circle"></i> Nova Formação
                            </a>
                        </div>
                    </div>
                </div>

                <div class="accordion-item-custom">
                    <button class="accordion-header-custom" onclick="toggleAccordion('accordionNomeacoes')">
                        <i class="fas fa-briefcase accordion-icon"></i>
                        Nomeações
                        <i class="fas fa-chevron-down accordion-arrow"></i>
                    </button>
                    <div class="accordion-body-custom" id="accordionNomeacoes">
                        <div class="nav-item">
                            <a href="${pageContext.request.contextPath}/nomeacoes" 
                               class="nav-link ${param.activeMenu == 'nomeacoes' ? 'active' : ''}">
                                <i class="fas fa-list"></i> Listar Nomeações
                            </a>
                        </div>
                        <div class="nav-item">
                            <a href="${pageContext.request.contextPath}/nomeacoes/novo" class="nav-link">
                                <i class="fas fa-plus-circle"></i> Nova Nomeação
                            </a>
                        </div>
                    </div>
                </div>

                <div class="menu-label" style="margin-top: 12px;">Gestão de Férias</div>

                <div class="accordion-item-custom">
                    <button class="accordion-header-custom" onclick="toggleAccordion('accordionFerias')">
                        <i class="fas fa-umbrella-beach accordion-icon"></i>
                        Férias
                        <span class="badge-menu">${feriasPendentes != null ? feriasPendentes : '0'}</span>
                        <i class="fas fa-chevron-down accordion-arrow"></i>
                    </button>
                    <div class="accordion-body-custom" id="accordionFerias">
                        <div class="nav-item">
                            <a href="${pageContext.request.contextPath}/ferias" 
                               class="nav-link ${param.activeMenu == 'ferias' ? 'active' : ''}">
                                <i class="fas fa-list"></i> Gerenciar Férias
                            </a>
                        </div>
                        <div class="nav-item">
                            <a href="${pageContext.request.contextPath}/ferias/pendentes" class="nav-link">
                                <i class="fas fa-clock"></i> Pendentes
                                <span class="badge-menu">${feriasPendentes != null ? feriasPendentes : '0'}</span>
                            </a>
                        </div>
                    </div>
                </div>

                <div class="accordion-item-custom">
                    <button class="accordion-header-custom" onclick="toggleAccordion('accordionPlanoFerias')">
                        <i class="fas fa-calendar-alt accordion-icon"></i>
                        Plano de Férias
                        <i class="fas fa-chevron-down accordion-arrow"></i>
                    </button>
                    <div class="accordion-body-custom" id="accordionPlanoFerias">
                        <div class="nav-item">
                            <a href="${pageContext.request.contextPath}/plano-ferias" 
                               class="nav-link ${param.activeMenu == 'plano-ferias' ? 'active' : ''}">
                                <i class="fas fa-list"></i> Visualizar Plano
                            </a>
                        </div>
                        <div class="nav-item">
                            <a href="${pageContext.request.contextPath}/plano-ferias/novo" class="nav-link">
                                <i class="fas fa-plus-circle"></i> Adicionar ao Plano
                            </a>
                        </div>
                    </div>
                </div>

                <div class="menu-label" style="margin-top: 12px;">Relatórios</div>
                <a href="${pageContext.request.contextPath}/relatorios" 
                   class="nav-link-top ${param.activeMenu == 'relatorios' ? 'active' : ''}">
                    <i class="fas fa-chart-bar"></i> Central de Relatórios
                </a>
            </c:if>

            <!-- ============================================================
                 GESTOR
                 ============================================================ -->
            <c:if test="${sessionScope.usuario.perfil == 'GESTOR'}">
                <div class="menu-label" style="margin-top: 12px;">Gestão</div>
                
                <a href="${pageContext.request.contextPath}/funcionarios" 
                   class="nav-link-top ${param.activeMenu == 'funcionarios' ? 'active' : ''}">
                    <i class="fas fa-users"></i> Funcionários
                    <span class="badge-menu">${totalFuncionarios != null ? totalFuncionarios : '0'}</span>
                </a>
                
                <div class="accordion-item-custom">
                    <button class="accordion-header-custom" onclick="toggleAccordion('accordionFeriasGestor')">
                        <i class="fas fa-umbrella-beach accordion-icon"></i>
                        Férias
                        <span class="badge-menu">${feriasPendentes != null ? feriasPendentes : '0'}</span>
                        <i class="fas fa-chevron-down accordion-arrow"></i>
                    </button>
                    <div class="accordion-body-custom" id="accordionFeriasGestor">
                        <div class="nav-item">
                            <a href="${pageContext.request.contextPath}/ferias" 
                               class="nav-link ${param.activeMenu == 'ferias' ? 'active' : ''}">
                                <i class="fas fa-list"></i> Gerenciar Férias
                            </a>
                        </div>
                        <div class="nav-item">
                            <a href="${pageContext.request.contextPath}/ferias/pendentes" class="nav-link">
                                <i class="fas fa-clock"></i> Pendentes
                                <span class="badge-menu">${feriasPendentes != null ? feriasPendentes : '0'}</span>
                            </a>
                        </div>
                    </div>
                </div>

                <a href="${pageContext.request.contextPath}/plano-ferias" 
                   class="nav-link-top ${param.activeMenu == 'plano-ferias' ? 'active' : ''}">
                    <i class="fas fa-calendar-alt"></i> Plano de Férias
                </a>

                <div class="menu-label" style="margin-top: 12px;">Relatórios</div>
                <a href="${pageContext.request.contextPath}/relatorios" 
                   class="nav-link-top ${param.activeMenu == 'relatorios' ? 'active' : ''}">
                    <i class="fas fa-chart-bar"></i> Relatórios
                </a>
            </c:if>

            <!-- ============================================================
                 FINANCEIRO
                 ============================================================ -->
            <c:if test="${sessionScope.usuario.perfil == 'FINANCEIRO'}">
                <div class="menu-label" style="margin-top: 12px;">Financeiro</div>
                
                                
                <a href="${pageContext.request.contextPath}/financeiro/folha-pagamento" 
                   class="nav-link-top ${param.activeMenu == 'folha-pagamento' ? 'active' : ''}">
                    <i class="fas fa-file-invoice"></i> Folha de Pagamento
                </a>
                
                <a href="${pageContext.request.contextPath}/financeiro/salarios" 
                   class="nav-link-top ${param.activeMenu == 'salarios' ? 'active' : ''}">
                    <i class="fas fa-coins"></i> Salários
                </a>

                <div class="menu-label" style="margin-top: 12px;">Relatórios</div>
                <a href="${pageContext.request.contextPath}/relatorios" 
                   class="nav-link-top ${param.activeMenu == 'relatorios' ? 'active' : ''}">
                    <i class="fas fa-chart-bar"></i> Relatórios Financeiros
                </a>
            </c:if>

            <!-- ============================================================
                 FUNCIONÁRIO
                 ============================================================ -->
            <c:if test="${sessionScope.usuario.perfil == 'FUNCIONARIO'}">
                <div class="menu-label" style="margin-top: 12px;">Minha Área</div>
                
                <a href="${pageContext.request.contextPath}/funcionario/meus-dados" 
                   class="nav-link-top ${param.activeMenu == 'meus-dados' ? 'active' : ''}">
                    <i class="fas fa-user"></i> Meus Dados
                </a>
                
                <a href="${pageContext.request.contextPath}/funcionario/minhas-ferias" 
                   class="nav-link-top ${param.activeMenu == 'minhas-ferias' ? 'active' : ''}">
                    <i class="fas fa-umbrella-beach"></i> Minhas Férias
                </a>
                
                <a href="${pageContext.request.contextPath}/funcionario/minhas-formacoes" 
                   class="nav-link-top ${param.activeMenu == 'minhas-formacoes' ? 'active' : ''}">
                    <i class="fas fa-graduation-cap"></i> Minhas Formações
                </a>
                
                <a href="${pageContext.request.contextPath}/funcionario/minhas-nomeacoes" 
                   class="nav-link-top ${param.activeMenu == 'minhas-nomeacoes' ? 'active' : ''}">
                    <i class="fas fa-briefcase"></i> Minhas Nomeações
                </a>
                
                <a href="${pageContext.request.contextPath}/funcionario/alterar-senha" 
                   class="nav-link-top ${param.activeMenu == 'alterar-senha' ? 'active' : ''}">
                    <i class="fas fa-key"></i> Alterar Senha
                </a>
            </c:if>

            <!-- ========== COMUNICAÇÃO - TODOS OS PERFIS ========== -->
            <div class="menu-label" style="margin-top: 12px;">Comunicação</div>
            
            <a href="${pageContext.request.contextPath}/notificacoes" 
               class="nav-link-top ${param.activeMenu == 'notificacoes' ? 'active' : ''}">
                <i class="fas fa-bell"></i> Notificações
               
            </a>
        </div>

        <div class="sidebar-footer">
            <form action="${pageContext.request.contextPath}/logout" method="post">
                <button type="submit" class="btn-logout">
                    <i class="fas fa-sign-out-alt"></i> Sair
                </button>
            </form>
        </div>
    </nav>

    <!-- MAIN CONTENT -->
    <div class="main-content">
        <header class="header">
            <div class="header-left">
                <button class="toggle-sidebar" id="toggleSidebar" aria-label="Abrir menu">
                    <i class="fas fa-bars"></i>
                </button>
                <div class="page-title">
                    ${param.pageTitle}
                    <small>${sessionScope.usuario.perfil}</small>
                </div>
            </div>
            <div class="header-right">
                               
              <div class="nav-item dropdown" style="position: relative;">
    <a class="nav-link" href="#" onclick="toggleNotificacoes(event)" style="position: relative; cursor: pointer;">
        <i class="fas fa-bell" style="font-size: 18px;"></i>
        <span id="notificacaoBadge" class="badge bg-danger" style="
            position: absolute;
            top: -5px;
            right: -8px;
            font-size: 10px;
            padding: 2px 6px;
            border-radius: 50%;
            min-width: 18px;
            text-align: center;
            display: none;
        ">0</span>
    </a>
    
    <!-- Dropdown de Notificações -->
    <div id="notificacoesDropdown" class="dropdown-menu dropdown-menu-end" style="
        display: none;
        position: absolute;
        right: 0;
        top: 40px;
        width: 380px;
        max-height: 450px;
        background: #fff;
        border-radius: 12px;
        box-shadow: 0 10px 40px rgba(0,0,0,0.15);
        border: 1px solid var(--gray-border);
        z-index: 1000;
        overflow: hidden;
        padding: 0;
    ">
        <div style="padding: 14px 20px; border-bottom: 1px solid var(--gray-border); display: flex; justify-content: space-between; align-items: center;">
            <span style="font-weight: 700; color: var(--dark);">
                <i class="fas fa-bell" style="color: var(--primary);"></i> Notificações
            </span>
            <a href="${pageContext.request.contextPath}/notificacoes" style="font-size: 12px; color: var(--primary); text-decoration: none;">
                Ver todas
            </a>
        </div>
        
        <div id="listaNotificacoes" style="max-height: 350px; overflow-y: auto;">
            <div style="padding: 30px 20px; text-align: center; color: var(--gray);">
                <i class="fas fa-spinner fa-spin" style="font-size: 24px;"></i>
                <p style="margin-top: 8px;">Carregando...</p>
            </div>
        </div>
        
        <div style="padding: 10px 20px; border-top: 1px solid var(--gray-border); text-align: center;">
            <button onclick="marcarTodasNotificacoes()" style="background: none; border: none; color: var(--primary); font-size: 12px; cursor: pointer;">
                <i class="fas fa-check-double"></i> Marcar todas como lidas
            </button>
        </div>
    </div>
</div>
                
                <div class="user-avatar-header" id="headerInitials" title="${sessionScope.usuario.nome}">
                    ${sessionScope.usuario.nome.charAt(0)}${sessionScope.usuario.nome.split(' ')[1].charAt(0)}
                </div>
            </div>
        </header>

        <div class="page-content">
            <!-- Alertas -->
            <c:if test="${not empty sessionScope.sucesso}">
                <div class="alert-custom alert-success">
                    <i class="fas fa-check-circle"></i> ${sessionScope.sucesso}
                </div>
                <c:remove var="sucesso" scope="session" />
            </c:if>
            <c:if test="${not empty sessionScope.erro}">
                <div class="alert-custom alert-danger">
                    <i class="fas fa-exclamation-circle"></i> ${sessionScope.erro}
                </div>
                <c:remove var="erro" scope="session" />
            </c:if>
            <c:if test="${not empty sessionScope.info}">
                <div class="alert-custom alert-info">
                    <i class="fas fa-info-circle"></i> ${sessionScope.info}
                </div>
                <c:remove var="info" scope="session" />
            </c:if>
            <script>
// ============================================================
// TOGGLE NOTIFICAÇÕES
// ============================================================
function toggleNotificacoes(event) {
    event.preventDefault();
    event.stopPropagation();
    var dropdown = document.getElementById('notificacoesDropdown');
    if (dropdown.style.display === 'block') {
        dropdown.style.display = 'none';
    } else {
        dropdown.style.display = 'block';
        carregarNotificacoes();
    }
}

// ============================================================
// CARREGAR NOTIFICAÇÕES
// ============================================================
function carregarNotificacoes() {
    var lista = document.getElementById('listaNotificacoes');
    
    fetch('${pageContext.request.contextPath}/notificacoes/api')
        .then(function(response) { 
            if (!response.ok) {
                throw new Error('Erro na resposta: ' + response.status);
            }
            return response.json(); 
        })
        .then(function(data) {
            console.log('Notificações recebidas:', data);
            
            if (!data || data.length === 0) {
                lista.innerHTML = '<div style="padding: 30px 20px; text-align: center; color: var(--gray);">' +
                    '<i class="fas fa-bell-slash" style="font-size: 32px; opacity: 0.3;"></i>' +
                    '<p style="margin-top: 8px;">Nenhuma notificação</p>' +
                    '</div>';
                return;
            }
            
            var html = '';
            var naoLidas = 0;
            
            data.forEach(function(n) {
                if (!n.lida) naoLidas++;
                
                var cor = n.tipo === 'SUCESSO' ? 'sucesso' : 
                          n.tipo === 'AVISO' ? 'aviso' : 
                          n.tipo === 'ERRO' ? 'erro' : 'info';
                
                var iconeMap = {
                    'SUCESSO': 'fa-check-circle',
                    'AVISO': 'fa-exclamation-triangle',
                    'ERRO': 'fa-times-circle',
                    'INFO': 'fa-info-circle'
                };
                var icone = iconeMap[n.tipo] || 'fa-bell';
                
                html += '<div class="notificacao-item ' + (n.lida ? '' : 'nao-lida') + '" onclick="marcarLidaNotificacao(' + n.id + ')">' +
                    '<div class="icone ' + cor + '">' +
                    '<i class="fas ' + icone + '"></i>' +
                    '</div>' +
                    '<div class="conteudo">' +
                    '<div class="titulo">' + (n.titulo || 'Sem título') + '</div>' +
                    '<div class="mensagem">' + (n.mensagem || 'Sem mensagem') + '</div>' +
                    '<div class="tempo">' + formatarData(n.dataCriacao) + '</div>' +
                    '</div>' +
                    '</div>';
            });
            
            lista.innerHTML = html;
            
            // Atualizar badge
            atualizarBadge(naoLidas);
        })
        .catch(function(error) {
            console.error('Erro ao carregar notificações:', error);
            lista.innerHTML = '<div style="padding: 30px 20px; text-align: center; color: var(--danger);">' +
                '<i class="fas fa-exclamation-circle" style="font-size: 32px;"></i>' +
                '<p style="margin-top: 8px;">Erro ao carregar notificações</p>' +
                '</div>';
        });
}

// ============================================================
// ATUALIZAR BADGE
// ============================================================
function atualizarBadge(count) {
    var badge = document.getElementById('notificacaoBadge');
    if (count > 0) {
        badge.style.display = 'block';
        badge.textContent = count > 99 ? '99+' : count;
    } else {
        badge.style.display = 'none';
    }
}

// ============================================================
// MARCAR COMO LIDA
// ============================================================
function marcarLidaNotificacao(id) {
    fetch('${pageContext.request.contextPath}/notificacoes/marcar-lida', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: 'id=' + id
    })
    .then(function(response) { return response.json(); })
    .then(function(data) {
        if (data.success) {
            carregarNotificacoes();
            carregarContagemNotificacoes();
        } else {
            console.error('Erro ao marcar como lida:', data.message);
        }
    })
    .catch(function(error) {
        console.error('Erro:', error);
    });
}

// ============================================================
// MARCAR TODAS COMO LIDAS
// ============================================================
function marcarTodasNotificacoes() {
    if (confirm('Marcar todas as notificações como lidas?')) {
        fetch('${pageContext.request.contextPath}/notificacoes/marcar-todas', {
            method: 'POST'
        })
        .then(function(response) { return response.json(); })
        .then(function(data) {
            if (data.success) {
                carregarNotificacoes();
                carregarContagemNotificacoes();
                if (typeof showNotification === 'function') {
                    showNotification('success', 'Atualizado', data.message);
                }
            }
        })
        .catch(function(error) {
            console.error('Erro:', error);
        });
    }
}

// ============================================================
// CARREGAR CONTAGEM
// ============================================================
function carregarContagemNotificacoes() {
    fetch('${pageContext.request.contextPath}/notificacoes/contar')
        .then(function(response) { return response.json(); })
        .then(function(data) {
            console.log('Contagem de notificações:', data);
            if (data.success && data.count > 0) {
                atualizarBadge(data.count);
            } else {
                atualizarBadge(0);
            }
        })
        .catch(function(error) {
            console.error('Erro ao carregar contagem:', error);
            atualizarBadge(0);
        });
}

// ============================================================
// FORMATAR DATA
// ============================================================
function formatarData(dataStr) {
    try {
        if (!dataStr) return 'Data desconhecida';
        var data = new Date(dataStr);
        if (isNaN(data.getTime())) return dataStr;
        
        var agora = new Date();
        var diff = Math.floor((agora - data) / 1000);
        
        if (diff < 60) return 'Agora';
        if (diff < 3600) return Math.floor(diff / 60) + ' min';
        if (diff < 86400) return Math.floor(diff / 3600) + 'h';
        if (diff < 604800) return Math.floor(diff / 86400) + 'd';
        
        return data.toLocaleDateString('pt-MZ', { day: '2-digit', month: '2-digit', year: 'numeric' });
    } catch(e) {
        return dataStr;
    }
}

// ============================================================
// FECHAR DROPDOWN AO CLICAR FORA
// ============================================================
document.addEventListener('click', function(event) {
    var dropdown = document.getElementById('notificacoesDropdown');
    var target = event.target.closest('.nav-item');
    if (!target && dropdown) {
        dropdown.style.display = 'none';
    }
});

// ============================================================
// INICIAR - CARREGAR CONTAGEM
// ============================================================
document.addEventListener('DOMContentLoaded', function() {
    console.log('🔔 Inicializando notificações...');
    carregarContagemNotificacoes();
    
    // Recarregar a cada 60 segundos
    setInterval(function() {
        carregarContagemNotificacoes();
    }, 60000);
});

// Estilos para as notificações (adicionar dinamicamente)
(function adicionarEstilos() {
    var style = document.createElement('style');
    style.textContent = `
        .notificacao-item {
            padding: 12px 16px;
            border-bottom: 1px solid #e5e7eb;
            transition: background 0.2s ease;
            cursor: pointer;
            display: flex;
            align-items: flex-start;
            gap: 12px;
        }
        .notificacao-item:hover {
            background: #f3f4f6;
        }
        .notificacao-item.nao-lida {
            background: rgba(79, 70, 229, 0.03);
            border-left: 3px solid #4f46e5;
        }
        .notificacao-item .icone {
            width: 36px;
            height: 36px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-shrink: 0;
            font-size: 14px;
        }
        .notificacao-item .icone.info { background: rgba(59, 130, 246, 0.1); color: #3b82f6; }
        .notificacao-item .icone.sucesso { background: rgba(16, 185, 129, 0.1); color: #10b981; }
        .notificacao-item .icone.aviso { background: rgba(245, 158, 11, 0.1); color: #f59e0b; }
        .notificacao-item .icone.erro { background: rgba(239, 68, 68, 0.1); color: #ef4444; }
        .notificacao-item .conteudo { flex: 1; min-width: 0; }
        .notificacao-item .titulo { font-weight: 600; font-size: 13px; color: #1f2937; }
        .notificacao-item .mensagem { font-size: 12px; color: #6b7280; margin-top: 2px; }
        .notificacao-item .tempo { font-size: 10px; color: #9ca3af; margin-top: 2px; }
    `;
    document.head.appendChild(style);
})();
</script>
            <!-- CONTEÚDO DA PÁGINA -->
            <!-- O conteúdo de cada página será inserido aqui -->
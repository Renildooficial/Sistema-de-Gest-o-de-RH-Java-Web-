<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core"%>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt"%>

<jsp:include page="/WEB-INF/views/layout/header.jsp">
    <jsp:param name="pageTitle" value="Setores" />
    <jsp:param name="activeMenu" value="setores" />
</jsp:include>

<style>
    /* ============================================================
       BADGES
    ============================================================ */
    .badge-ativo {
        background: rgba(16,185,129,0.1);
        color: #059669;
        padding: 2px 10px;
        border-radius: 12px;
        font-size: 11px;
        font-weight: 600;
        border: 1px solid rgba(16,185,129,0.15);
    }
    .badge-inativo {
        background: rgba(239,68,68,0.1);
        color: #dc2626;
        padding: 2px 10px;
        border-radius: 12px;
        font-size: 11px;
        font-weight: 600;
        border: 1px solid rgba(239,68,68,0.15);
    }
    
    /* ============================================================
       EMPTY STATE
    ============================================================ */
    .empty-state {
        text-align: center;
        padding: 60px 20px;
        color: var(--gray);
    }
    .empty-state i {
        font-size: 48px;
        margin-bottom: 16px;
        color: var(--primary-light);
    }
    .empty-state h5 {
        font-size: 18px;
        font-weight: 600;
        margin-bottom: 8px;
        color: var(--dark);
    }
    .empty-state p {
        font-size: 14px;
    }

    /* ============================================================
       RESPONSIVIDADE - Tabela
    ============================================================ */
    @media (max-width: 768px) {
        .table-custom thead {
            display: none;
        }
        
        .table-custom tbody tr {
            display: block;
            margin-bottom: 16px;
            border: 1px solid var(--gray-border);
            border-radius: var(--border-radius);
            padding: 16px;
            background: #fff;
        }
        
        .table-custom tbody tr td {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 8px 4px;
            border: none;
            border-bottom: 1px solid var(--gray-light);
            font-size: 13px;
        }
        
        .table-custom tbody tr td:last-child {
            border-bottom: none;
        }
        
        .table-custom tbody tr td::before {
            content: attr(data-label);
            font-weight: 600;
            color: var(--dark);
            font-size: 12px;
            margin-right: 12px;
            min-width: 80px;
        }
        
        .table-custom tbody tr td .action-btns {
            display: flex;
            gap: 6px;
        }
        
        .table-custom tbody tr td .action-btns .btn-icon {
            width: 32px;
            height: 32px;
            font-size: 12px;
        }
        
        .empty-state {
            padding: 30px 16px;
        }
        .empty-state i {
            font-size: 32px;
        }
        .empty-state h5 {
            font-size: 16px;
        }
        
        .table-header {
            flex-direction: column;
            gap: 12px;
            align-items: flex-start;
        }
        .table-header .actions {
            width: 100%;
            flex-wrap: wrap;
        }
        .table-header .actions .btn-primary-custom {
            width: 100%;
            justify-content: center;
        }
    }

    @media (max-width: 480px) {
        .table-custom tbody tr {
            padding: 12px;
        }
        .table-custom tbody tr td {
            font-size: 12px;
            padding: 6px 2px;
            flex-wrap: wrap;
        }
        .table-custom tbody tr td::before {
            font-size: 11px;
            min-width: 60px;
        }
        .table-custom tbody tr td .action-btns .btn-icon {
            width: 28px;
            height: 28px;
            font-size: 11px;
        }
    }

    /* ============================================================
       ACTION BUTTONS - MELHORADOS
    ============================================================ */
    .action-btns {
        display: flex;
        gap: 4px;
        flex-wrap: wrap;
    }
    
    .action-btns .btn-icon {
        width: 34px;
        height: 34px;
        border: none;
        border-radius: 8px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        transition: var(--transition);
        text-decoration: none;
        font-size: 13px;
        position: relative;
    }
    
    .action-btns .btn-icon:hover {
        transform: scale(1.1);
    }
    
    .action-btns .btn-icon .tooltip {
        display: none;
        position: absolute;
        bottom: -28px;
        left: 50%;
        transform: translateX(-50%);
        background: var(--dark);
        color: #fff;
        padding: 2px 10px;
        border-radius: 6px;
        font-size: 10px;
        font-weight: 500;
        white-space: nowrap;
        z-index: 10;
    }
    
    .action-btns .btn-icon:hover .tooltip {
        display: block;
    }
    
    .btn-icon.edit {
        background: rgba(79,70,229,0.1);
        color: var(--primary);
    }
    .btn-icon.edit:hover {
        background: var(--primary);
        color: #fff;
    }
    
    .btn-icon.view {
        background: rgba(245,158,11,0.1);
        color: var(--warning);
    }
    .btn-icon.view:hover {
        background: var(--warning);
        color: #fff;
    }
    
    .btn-icon.delete {
        background: rgba(239,68,68,0.1);
        color: var(--danger);
    }
    .btn-icon.delete:hover {
        background: var(--danger);
        color: #fff;
    }
    
    .btn-icon.success {
        background: rgba(16,185,129,0.1);
        color: var(--success);
    }
    .btn-icon.success:hover {
        background: var(--success);
        color: #fff;
    }
    
    .btn-icon.info {
        background: rgba(59,130,246,0.1);
        color: var(--info);
    }
    .btn-icon.info:hover {
        background: var(--info);
        color: #fff;
    }
</style>

<div class="table-section animate-in">
    <div class="table-header">
        <div class="title">
            <i class="fas fa-building me-2"></i>
            Gestão de Setores
            <span style="font-size: 12px; font-weight: 400; color: var(--gray);">${total != null ? total : '0'} registros</span>
            <c:if test="${ativos > 0}">
                <span class="badge" style="background: var(--success); color: #fff; margin-left: 8px; padding: 2px 10px; border-radius: 12px; font-size: 11px;">
                    <i class="fas fa-check-circle"></i> ${ativos} ativos
                </span>
            </c:if>
        </div>
        <div class="actions">
            <a href="${pageContext.request.contextPath}/setores/novo" class="btn-primary-custom">
                <i class="fas fa-plus-circle"></i> Novo Setor
            </a>
        </div>
    </div>

    <div class="table-responsive-custom">
        <table class="table-custom" id="setoresTable">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Nome</th>
                    <th>Descrição</th>
                    <th>Responsável</th>
                    <th>Status</th>
                    <th>Cadastro</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <c:forEach items="${setores}" var="s">
                    <tr>
                        <td data-label="#"><span style="font-weight: 600; color: var(--primary);">${s.id}</span></td>
                        <td data-label="Nome"><strong>${s.nome}</strong></td>
                        <td data-label="Descrição">${s.descricao != null ? s.descricao : '-'}</td>
                        <td data-label="Responsável">${s.responsavel != null ? s.responsavel : '-'}</td>
                        <td data-label="Status">
                            <c:choose>
                                <c:when test="${s.ativo}">
                                    <span class="badge-ativo"><i class="fas fa-check-circle"></i> ATIVO</span>
                                </c:when>
                                <c:otherwise>
                                    <span class="badge-inativo"><i class="fas fa-times-circle"></i> INATIVO</span>
                                </c:otherwise>
                            </c:choose>
                        </td>
                        <td data-label="Cadastro"><fmt:formatDate value="${s.dataCadastro}" pattern="dd/MM/yyyy" /></td>
                        <td data-label="Ações">
                            <div class="action-btns">
                                <!-- Editar -->
                                <a href="${pageContext.request.contextPath}/setores/editar/${s.id}" class="btn-icon edit" title="Editar">
                                    <i class="fas fa-pen"></i>
                                    <span class="tooltip">Editar</span>
                                </a>
                                
                                <!-- Ativar/Desativar -->
                                <c:if test="${s.ativo}">
                                    <button class="btn-icon view" onclick="toggleStatus(${s.id}, ${s.ativo})" title="Desativar">
                                        <i class="fas fa-pause"></i>
                                        <span class="tooltip">Desativar</span>
                                    </button>
                                </c:if>
                                <c:if test="${!s.ativo}">
                                    <button class="btn-icon success" onclick="toggleStatus(${s.id}, ${s.ativo})" title="Ativar">
                                        <i class="fas fa-play"></i>
                                        <span class="tooltip">Ativar</span>
                                    </button>
                                </c:if>
                                
                                <!-- Excluir -->
                                <button class="btn-icon delete" onclick="excluirSetor(${s.id}, '${s.nome}')" title="Excluir">
                                    <i class="fas fa-trash"></i>
                                    <span class="tooltip">Excluir</span>
                                </button>
                            </div>
                        </td>
                    </tr>
                </c:forEach>
                <c:if test="${empty setores}">
                    <tr>
                        <td colspan="7">
                            <div class="empty-state">
                                <i class="fas fa-building"></i>
                                <h5>Nenhum setor cadastrado</h5>
                                <p>Clique em "Novo Setor" para começar</p>
                            </div>
                        </td>
                    </tr>
                </c:if>
            </tbody>
        </table>
    </div>
</div>

<script>
// ============================================================
// EXCLUIR SETOR
// ============================================================
function excluirSetor(id, nome) {
    if (confirm('Tem certeza que deseja excluir o setor "' + nome + '"?')) {
        fetch('${pageContext.request.contextPath}/setores/excluir', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: 'id=' + id
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                showNotification('success', 'Excluído', data.message);
                setTimeout(() => location.reload(), 1000);
            } else {
                showNotification('error', 'Erro', data.message);
            }
        })
        .catch(error => {
            showNotification('error', 'Erro', 'Erro ao excluir setor');
        });
    }
}

// ============================================================
// ALTERNAR STATUS (ATIVAR/DESATIVAR)
// ============================================================
function toggleStatus(id, ativo) {
    const acao = ativo ? 'desativar' : 'ativar';
    const mensagem = ativo ? 'Deseja desativar este setor?' : 'Deseja ativar este setor?';
    
    if (confirm(mensagem)) {
        fetch('${pageContext.request.contextPath}/setores/toggle-status', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: 'id=' + id
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                showNotification('success', 'Status alterado', data.message);
                setTimeout(() => location.reload(), 1000);
            } else {
                showNotification('error', 'Erro', data.message);
            }
        })
        .catch(error => {
            showNotification('error', 'Erro', 'Erro ao alterar status');
        });
    }
}

// ============================================================
// FALLBACK - SHOW NOTIFICATION
// ============================================================
if (typeof showNotification === 'undefined') {
    window.showNotification = function(type, title, message) {
        alert(title + ': ' + message);
    };
}
</script>

<jsp:include page="/WEB-INF/views/layout/footer.jsp" />
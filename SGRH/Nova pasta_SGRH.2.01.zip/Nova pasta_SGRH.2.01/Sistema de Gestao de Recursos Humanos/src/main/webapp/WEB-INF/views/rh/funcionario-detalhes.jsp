<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core"%>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt"%>

<jsp:include page="/WEB-INF/views/layout/header.jsp">
    <jsp:param name="pageTitle" value="Detalhes do Funcionário" />
    <jsp:param name="activeMenu" value="funcionarios" />
</jsp:include>

<style>
    .profile-header {
        background: linear-gradient(135deg, var(--primary), var(--secondary));
        border-radius: var(--border-radius);
        padding: 30px;
        color: #fff;
        margin-bottom: 24px;
        display: flex;
        align-items: center;
        gap: 24px;
        flex-wrap: wrap;
    }
    
    .profile-avatar {
        width: 120px;
        height: 120px;
        border-radius: 50%;
        background: rgba(255,255,255,0.2);
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 48px;
        font-weight: 800;
        color: #fff;
        flex-shrink: 0;
        overflow: hidden;
        border: 4px solid rgba(255,255,255,0.3);
    }
    
    .profile-avatar img {
        width: 100%;
        height: 100%;
        object-fit: cover;
    }
    
    .profile-info h2 {
        font-size: 28px;
        font-weight: 800;
        margin: 0;
    }
    
    .profile-info p {
        opacity: 0.8;
        margin: 4px 0 0;
    }
    
    .status-badge {
        padding: 4px 14px;
        border-radius: 20px;
        font-size: 11px;
        font-weight: 600;
        display: inline-block;
        text-transform: uppercase;
        letter-spacing: 0.3px;
    }
    
    .status-badge.ativo {
        background: rgba(16, 185, 129, 0.2);
        color: var(--success);
        border: 1px solid rgba(16, 185, 129, 0.2);
    }
    .status-badge.inativo {
        background: rgba(239, 68, 68, 0.2);
        color: var(--danger);
        border: 1px solid rgba(239, 68, 68, 0.2);
    }
    .status-badge.ferias {
        background: rgba(245, 158, 11, 0.2);
        color: var(--warning);
        border: 1px solid rgba(245, 158, 11, 0.2);
    }
    .status-badge.licenca {
        background: rgba(59, 130, 246, 0.2);
        color: var(--info);
        border: 1px solid rgba(59, 130, 246, 0.2);
    }
    
    .detail-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
        gap: 16px;
        margin-bottom: 24px;
    }
    
    .detail-card {
        background: #fff;
        border-radius: var(--border-radius);
        padding: 16px 20px;
        border: 1px solid var(--gray-border);
        box-shadow: var(--shadow-sm);
    }
    
    .detail-card .label {
        font-size: 11px;
        text-transform: uppercase;
        color: var(--gray);
        font-weight: 600;
        letter-spacing: 0.5px;
    }
    
    .detail-card .value {
        font-size: 16px;
        font-weight: 600;
        color: var(--dark);
        margin-top: 4px;
    }
    
    .back-btn {
        margin-bottom: 16px;
        display: flex;
        gap: 10px;
        flex-wrap: wrap;
    }
    
    .btn-primary-custom {
        background: linear-gradient(135deg, var(--primary), var(--secondary));
        border: none;
        color: #fff;
        padding: 8px 18px;
        border-radius: 10px;
        font-weight: 600;
        font-size: 13px;
        transition: var(--transition);
        font-family: 'Inter', sans-serif;
        display: inline-flex;
        align-items: center;
        gap: 6px;
        text-decoration: none;
        box-shadow: 0 2px 10px rgba(79,70,229,0.2);
    }
    
    .btn-primary-custom:hover {
        transform: translateY(-2px);
        box-shadow: 0 8px 25px rgba(79,70,229,0.4);
        color: #fff;
    }
    
    .btn-outline-custom {
        background: var(--gray-light);
        border: 1px solid var(--gray-border);
        color: var(--dark);
        padding: 8px 18px;
        border-radius: 10px;
        font-weight: 600;
        font-size: 13px;
        transition: var(--transition);
        font-family: 'Inter', sans-serif;
        display: inline-flex;
        align-items: center;
        gap: 6px;
        text-decoration: none;
    }
    
    .btn-outline-custom:hover {
        background: var(--gray-border);
        color: var(--dark);
    }
</style>

<div class="back-btn">
    <a href="${pageContext.request.contextPath}/funcionarios" class="btn-outline-custom">
        <i class="fas fa-arrow-left me-1"></i> Voltar para lista
    </a>
    <a href="${pageContext.request.contextPath}/funcionarios/editar/${funcionario.id}" class="btn-primary-custom">
        <i class="fas fa-edit me-1"></i> Editar
    </a>
</div>

<div class="profile-header">
    <div class="profile-avatar">
        <c:choose>
            <c:when test="${not empty funcionario.fotoBase64}">
                <img src="data:image/jpeg;base64,${funcionario.fotoBase64}" alt="${funcionario.nome}">
            </c:when>
            <c:otherwise>
                ${funcionario.nome.charAt(0)}${funcionario.nome.split(' ')[1].charAt(0)}
            </c:otherwise>
        </c:choose>
    </div>
    <div class="profile-info">
        <h2>${funcionario.nome}</h2>
        <p>${funcionario.emailEmpresa != null ? funcionario.emailEmpresa : 'Sem e-mail'}</p>
        <span class="status-badge ${funcionario.status == 'ATIVO' ? 'ativo' : 
                                    funcionario.status == 'FERIAS' ? 'ferias' :
                                    funcionario.status == 'LICENCA' ? 'licenca' : 'inativo'}">
            <i class="fas ${funcionario.status == 'ATIVO' ? 'fa-check-circle' : 
                            funcionario.status == 'FERIAS' ? 'fa-umbrella-beach' :
                            funcionario.status == 'LICENCA' ? 'fa-file-medical' : 'fa-times-circle'} me-1"></i>
            ${funcionario.status}
        </span>
    </div>
</div>

<div class="detail-grid">
    <div class="detail-card">
        <div class="label">Data de Nascimento</div>
        <div class="value">
            <c:choose>
                <c:when test="${not empty funcionario.dataNascimento}">
                    <fmt:formatDate value="${funcionario.dataNascimento}" pattern="dd/MM/yyyy" />
                </c:when>
                <c:otherwise>-</c:otherwise>
            </c:choose>
        </div>
    </div>
    <div class="detail-card">
        <div class="label">Data de Admissão</div>
        <div class="value">
            <c:choose>
                <c:when test="${not empty funcionario.dataAdmissao}">
                    <fmt:formatDate value="${funcionario.dataAdmissao}" pattern="dd/MM/yyyy" />
                </c:when>
                <c:otherwise>-</c:otherwise>
            </c:choose>
        </div>
    </div>
    <div class="detail-card">
        <div class="label">Província</div>
        <div class="value">${funcionario.provincia != null ? funcionario.provincia : '-'}</div>
    </div>
    <div class="detail-card">
        <div class="label">Distrito</div>
        <div class="value">${funcionario.distrito != null ? funcionario.distrito : '-'}</div>
    </div>
    <div class="detail-card">
        <div class="label">Setor</div>
        <div class="value">${funcionario.setor != null ? funcionario.setor.nome : '-'}</div>
    </div>
    <div class="detail-card">
        <div class="label">Estado Civil</div>
        <div class="value">${funcionario.estadoCivil != null ? funcionario.estadoCivil : '-'}</div>
    </div>
    <div class="detail-card">
        <div class="label">Telefone</div>
        <div class="value">${funcionario.telefone != null ? funcionario.telefone : '-'}</div>
    </div>
    <div class="detail-card">
        <div class="label">BI (Bilhete de Identidade)</div>
        <div class="value">${funcionario.bi != null ? funcionario.bi : '-'}</div>
    </div>
    <div class="detail-card">
        <div class="label">NUIT</div>
        <div class="value">${funcionario.nuit != null ? funcionario.nuit : '-'}</div>
    </div>
    <div class="detail-card">
        <div class="label">Banco</div>
        <div class="value">${funcionario.banco != null ? funcionario.banco : '-'}</div>
    </div>
    <div class="detail-card">
        <div class="label">Número da Conta</div>
        <div class="value">${funcionario.numeroConta != null ? funcionario.numeroConta : '-'}</div>
    </div>
    <div class="detail-card">
        <div class="label">RG</div>
        <div class="value">${funcionario.rg != null ? funcionario.rg : '-'}</div>
    </div>
    <div class="detail-card">
        <div class="label">Data de Cadastro</div>
        <div class="value">
            <c:choose>
                <c:when test="${not empty funcionario.dataCadastro}">
                    <fmt:formatDate value="${funcionario.dataCadastro}" pattern="dd/MM/yyyy HH:mm" />
                </c:when>
                <c:otherwise>-</c:otherwise>
            </c:choose>
        </div>
    </div>
</div>

<jsp:include page="/WEB-INF/views/layout/footer.jsp" />
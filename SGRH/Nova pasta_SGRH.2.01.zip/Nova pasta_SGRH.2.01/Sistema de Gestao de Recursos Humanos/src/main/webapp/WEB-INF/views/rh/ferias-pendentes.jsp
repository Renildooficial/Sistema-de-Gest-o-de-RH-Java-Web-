<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core"%>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt"%>

<jsp:include page="/WEB-INF/views/layout/header.jsp">
    <jsp:param name="pageTitle" value="Férias Pendentes" />
    <jsp:param name="activeMenu" value="ferias" />
</jsp:include>

<style>
    /* ============================================================
    ESTILOS - FÉRIAS PENDENTES (mesmo estilo das outras páginas)
    ============================================================ */
    .action-btns .btn-icon {
        width: 34px;
        height: 34px;
        border: none;
        border-radius: 8px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        background: transparent;
        color: var(--gray);
        font-size: 14px;
        text-decoration: none;
        margin: 0 2px;
        position: relative;
    }
    
    .action-btns .btn-icon:hover {
        transform: translateY(-3px);
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
    }
    
    .action-btns .btn-icon.edit {
        background: rgba(16, 185, 129, 0.1);
        color: var(--success);
    }
    .action-btns .btn-icon.edit:hover {
        background: rgba(16, 185, 129, 0.2);
        box-shadow: 0 4px 12px rgba(16, 185, 129, 0.3);
    }
    
    .action-btns .btn-icon.delete {
        background: rgba(239, 68, 68, 0.1);
        color: var(--danger);
    }
    .action-btns .btn-icon.delete:hover {
        background: rgba(239, 68, 68, 0.2);
        box-shadow: 0 4px 12px rgba(239, 68, 68, 0.3);
    }
    
    .action-btns .btn-icon.view {
        background: rgba(79, 70, 229, 0.1);
        color: var(--primary);
    }
    .action-btns .btn-icon.view:hover {
        background: rgba(79, 70, 229, 0.2);
        box-shadow: 0 4px 12px rgba(79, 70, 229, 0.3);
    }
    
    .action-btns .btn-icon .tooltip {
        display: none;
        position: absolute;
        bottom: -28px;
        left: 50%;
        transform: translateX(-50%);
        background: var(--dark);
        color: #fff;
        padding: 2px 10px;
        border-radius: 4px;
        font-size: 9px;
        font-weight: 500;
        white-space: nowrap;
        z-index: 100;
    }
    
    .action-btns .btn-icon:hover .tooltip {
        display: block;
    }
    
    .badge-status {
        padding: 4px 14px;
        border-radius: 20px;
        font-size: 11px;
        font-weight: 600;
        display: inline-block;
        text-transform: uppercase;
        letter-spacing: 0.3px;
        white-space: nowrap;
    }
    
    .badge-status.pendente {
        background: rgba(245, 158, 11, 0.12);
        color: #d97706;
        border: 1px solid rgba(245, 158, 11, 0.2);
    }
    
    .avatar-mini {
        width: 36px;
        height: 36px;
        border-radius: 50%;
        background: linear-gradient(135deg, var(--primary), #7c3aed);
        display: flex;
        align-items: center;
        justify-content: center;
        color: #fff;
        font-weight: 700;
        font-size: 14px;
        flex-shrink: 0;
    }
    
    .funcionario-nome {
        font-weight: 500;
        font-size: 13px;
    }
    
    .funcionario-id {
        font-size: 10px;
        color: var(--gray);
    }
    
    .periodo-texto {
        font-weight: 500;
        font-size: 13px;
    }
    
    .dias-texto {
        font-size: 10px;
        color: var(--gray);
    }
    
    .empty-state {
        text-align: center;
        padding: 60px 20px;
        color: var(--gray);
    }
    .empty-state i {
        font-size: 48px;
        margin-bottom: 16px;
        color: var(--success);
        opacity: 0.5;
    }
    .empty-state h5 {
        font-size: 18px;
        font-weight: 600;
        margin-bottom: 8px;
        color: var(--dark);
    }
    .empty-state p {
        font-size: 14px;
    }
    
    /* ============================================================
    TABELA RESPONSIVA
    ============================================================ */
    .table-section {
        background: #fff;
        border-radius: var(--border-radius);
        padding: 20px;
        border: 1px solid var(--gray-border);
        box-shadow: var(--shadow-sm);
        margin-bottom: 24px;
        overflow-x: auto;
        -webkit-overflow-scrolling: touch;
    }
    
    .table-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 16px;
        flex-wrap: wrap;
        gap: 12px;
    }
    
    .table-header .title {
        font-size: 16px;
        font-weight: 700;
        color: var(--dark);
        display: flex;
        align-items: center;
        flex-wrap: wrap;
        gap: 6px;
    }
    
    .table-header .title i {
        color: var(--primary);
    }
    
    .table-header .title .badge-count {
        font-size: 12px;
        font-weight: 400;
        color: var(--gray);
        margin-left: 4px;
    }
    
    .table-header .title .badge-pendentes {
        background: var(--warning);
        color: #fff;
        padding: 2px 10px;
        border-radius: 12px;
        font-size: 11px;
        font-weight: 600;
        margin-left: 6px;
    }
    
    .table-header .actions {
        display: flex;
        gap: 8px;
        flex-wrap: wrap;
        align-items: center;
    }
    
    .btn-outline-custom {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        padding: 8px 16px;
        border: 1.5px solid var(--gray-border);
        border-radius: 8px;
        background: transparent;
        color: var(--gray);
        font-size: 13px;
        font-weight: 600;
        text-decoration: none;
        transition: all 0.2s ease;
        cursor: pointer;
    }
    
    .btn-outline-custom:hover {
        background: var(--gray-light);
        color: var(--dark);
        border-color: #cbd5e1;
    }
    
    .btn-primary-custom {
        background: var(--primary);
        color: #fff;
        padding: 8px 18px;
        border: none;
        border-radius: 8px;
        font-size: 13px;
        font-weight: 600;
        display: inline-flex;
        align-items: center;
        gap: 8px;
        text-decoration: none;
        cursor: pointer;
        transition: all 0.2s ease;
    }
    
    .btn-primary-custom:hover {
        background: var(--primary-hover);
        color: #fff;
        transform: translateY(-2px);
        box-shadow: 0 4px 12px rgba(79, 70, 229, 0.3);
    }
    
    .table-custom {
        width: 100%;
        border-collapse: collapse;
        font-size: 13px;
        min-width: 600px;
    }
    
    .table-custom thead th {
        background: var(--gray-light);
        padding: 10px 14px;
        text-align: left;
        font-size: 11px;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        font-weight: 700;
        color: var(--gray);
        border-bottom: 2px solid var(--gray-border);
        white-space: nowrap;
    }
    
    .table-custom tbody td {
        padding: 10px 14px;
        border-bottom: 1px solid var(--gray-border);
        vertical-align: middle;
    }
    
    .table-custom tbody tr {
        transition: all 0.3s ease;
    }
    
    .table-custom tbody tr:hover {
        background: var(--gray-light);
    }
    
    /* ============================================================
    RESPONSIVO
    ============================================================ */
    @media (max-width: 992px) {
        .table-section {
            padding: 16px;
        }
        .table-header {
            flex-direction: column;
            align-items: stretch;
        }
        .table-header .actions {
            justify-content: center;
        }
        .table-custom {
            font-size: 12px;
            min-width: 500px;
        }
        .table-custom thead th {
            padding: 8px 10px;
            font-size: 10px;
        }
        .table-custom tbody td {
            padding: 8px 10px;
        }
    }
    
    @media (max-width: 768px) {
        .table-section {
            padding: 12px;
        }
        .table-custom {
            font-size: 11px;
            min-width: 400px;
        }
        .table-custom thead th {
            padding: 6px 8px;
            font-size: 9px;
        }
        .table-custom tbody td {
            padding: 6px 8px;
        }
        .action-btns .btn-icon {
            width: 30px;
            height: 30px;
            font-size: 12px;
        }
        .avatar-mini {
            width: 30px;
            height: 30px;
            font-size: 12px;
        }
        .status-badge {
            font-size: 9px;
            padding: 2px 10px;
        }
        .table-header .title {
            font-size: 14px;
        }
        .btn-outline-custom {
            font-size: 11px;
            padding: 6px 12px;
        }
        .funcionario-nome {
            font-size: 12px;
        }
    }
    
    @media (max-width: 576px) {
        .table-section {
            padding: 10px;
        }
        .table-custom {
            font-size: 10px;
            min-width: 350px;
        }
        .table-custom thead th {
            padding: 4px 6px;
            font-size: 8px;
        }
        .table-custom tbody td {
            padding: 4px 6px;
        }
        .action-btns .btn-icon {
            width: 26px;
            height: 26px;
            font-size: 11px;
        }
        .avatar-mini {
            width: 26px;
            height: 26px;
            font-size: 10px;
        }
        .status-badge {
            font-size: 8px;
            padding: 2px 8px;
        }
        .table-header .title {
            font-size: 13px;
        }
        .table-header .title .badge-count {
            font-size: 10px;
        }
        .btn-outline-custom {
            font-size: 10px;
            padding: 4px 10px;
        }
        .funcionario-nome {
            font-size: 11px;
        }
        .empty-state i {
            font-size: 36px;
        }
        .empty-state h5 {
            font-size: 16px;
        }
        .empty-state p {
            font-size: 13px;
        }
    }
    
    @media (max-width: 480px) {
        .table-custom {
            min-width: 300px;
        }
        .table-custom thead th {
            padding: 3px 4px;
            font-size: 7px;
        }
        .table-custom tbody td {
            padding: 3px 4px;
        }
        .action-btns {
            display: flex;
            flex-wrap: wrap;
            gap: 2px;
        }
        .action-btns .btn-icon {
            width: 22px;
            height: 22px;
            font-size: 10px;
            border-radius: 6px;
        }
        .avatar-mini {
            width: 22px;
            height: 22px;
            font-size: 9px;
        }
        .status-badge {
            font-size: 7px;
            padding: 1px 6px;
        }
        .funcionario-nome {
            font-size: 10px;
        }
        .empty-state i {
            font-size: 28px;
        }
        .empty-state h5 {
            font-size: 14px;
        }
        .empty-state p {
            font-size: 12px;
        }
    }

    /* ============================================================
    ANIMAÇÕES
    ============================================================ */
    @keyframes fadeInUp {
        from {
            opacity: 0;
            transform: translateY(20px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }

    .animate-in {
        opacity: 0;
        animation: fadeInUp 0.5s ease forwards;
    }
</style>

<div class="table-section animate-in">
    <div class="table-header">
        <div class="title">
            <i class="fas fa-clock me-2"></i>
            Solicitações de Férias Pendentes
            <span class="badge-count">
                <i class="fas fa-list me-1"></i> ${total != null ? total : '0'} registros
            </span>
            <c:if test="${total > 0}">
                <span class="badge-pendentes">
                    <i class="fas fa-clock me-1"></i> ${total} pendente${total > 1 ? 's' : ''}
                </span>
            </c:if>
        </div>
        <div class="actions">
            <a href="${pageContext.request.contextPath}/ferias" class="btn-outline-custom">
                <i class="fas fa-arrow-left"></i> Voltar
            </a>
            <c:if test="${total > 0}">
                <button class="btn-primary-custom" onclick="aprovarTodas()" title="Aprovar todas as solicitações">
                    <i class="fas fa-check-double"></i> Aprovar Todas
                </button>
            </c:if>
        </div>
    </div>

    <div class="table-responsive-custom">
        <table class="table-custom" id="feriasPendentesTable">
            <thead>
                <tr>
                    <th style="min-width: 130px;">Funcionário</th>
                    <th style="min-width: 160px;">Período</th>
                    <th style="width: 80px;">Dias</th>
                    <th style="width: 80px;">Status</th>
                    <th style="width: 130px;">Solicitação</th>
                    <th style="width: 120px; text-align: center;">Ações</th>
                </tr>
            </thead>
            <tbody>
                <c:forEach items="${ferias}" var="f">
                    <tr>
                        <td>
                            <c:choose>
                                <c:when test="${not empty f.funcionario}">
                                    <div style="display: flex; align-items: center; gap: 10px;">
                                        <div class="avatar-mini">
                                            ${f.funcionario.nome.charAt(0)}${f.funcionario.nome.split(' ')[1].charAt(0)}
                                        </div>
                                        <div>
                                            <div class="funcionario-nome">${f.funcionario.nome}</div>
                                            <div class="funcionario-id">ID: #${f.funcionario.id}</div>
                                        </div>
                                    </div>
                                </c:when>
                                <c:otherwise>
                                    <span style="color: var(--gray);">-</span>
                                </c:otherwise>
                            </c:choose>
                        </td>
                        <td>
                            <div class="periodo-texto">
                                <fmt:formatDate value="${f.dataInicio}" pattern="dd/MM/yyyy" />
                                <i class="fas fa-arrow-right mx-1" style="font-size: 10px; color: var(--gray);"></i>
                                <fmt:formatDate value="${f.dataFim}" pattern="dd/MM/yyyy" />
                            </div>
                            <c:if test="${not empty f.anoReferencia}">
                                <div class="dias-texto">
                                    <i class="fas fa-calendar me-1"></i> Ano: ${f.anoReferencia}
                                </div>
                            </c:if>
                        </td>
                        <td>
                            <div style="font-weight: 600; font-size: 14px; color: var(--warning);">
                                ${f.diasUteis}
                            </div>
                            <div class="dias-texto">
                                <i class="fas fa-clock me-1"></i> ${f.diasCalendario} corridos
                            </div>
                        </td>
                        <td>
                            <span class="badge-status pendente">
                                <i class="fas fa-clock me-1"></i> PENDENTE
                            </span>
                        </td>
                        <td>
                            <div style="font-size: 12px; color: var(--gray);">
                                <fmt:formatDate value="${f.dataSolicitacao}" pattern="dd/MM/yyyy" />
                            </div>
                            <div style="font-size: 10px; color: var(--gray-light);">
                                <fmt:formatDate value="${f.dataSolicitacao}" pattern="HH:mm" />
                            </div>
                        </td>
                        <td style="text-align: center;">
                            <div class="action-btns" style="justify-content: center;">
                                <button class="btn-icon edit" onclick="aprovarFerias(${f.id})" title="Aprovar">
                                    <i class="fas fa-check"></i>
                                    <span class="tooltip">Aprovar</span>
                                </button>
                                <button class="btn-icon delete" onclick="rejeitarFerias(${f.id})" title="Rejeitar">
                                    <i class="fas fa-times"></i>
                                    <span class="tooltip">Rejeitar</span>
                                </button>
                                <button class="btn-icon view" onclick="verDetalhes(${f.id})" title="Ver detalhes">
                                    <i class="fas fa-eye"></i>
                                    <span class="tooltip">Detalhes</span>
                                </button>
                            </div>
                        </td>
                    </tr>
                </c:forEach>
                <c:if test="${empty ferias}">
                    <tr>
                        <td colspan="6">
                            <div class="empty-state">
                                <i class="fas fa-check-circle"></i>
                                <h5>Nenhuma solicitação pendente!</h5>
                                <p>Todas as solicitações de férias foram processadas.</p>
                            </div>
                        </td>
                    </tr>
                </c:if>
            </tbody>
        </table>
    </div>
</div>

<script>
// ============================================================
// APROVAR FÉRIAS
// ============================================================
function aprovarFerias(id) {
    if (confirm('✅ Deseja aprovar esta solicitação de férias?')) {
        fetch('${pageContext.request.contextPath}/ferias/aprovar', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: 'id=' + id
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                showNotification('success', '✅ Aprovado', data.message);
                setTimeout(() => location.reload(), 1200);
            } else {
                showNotification('error', '❌ Erro', data.message);
            }
        })
        .catch(error => {
            showNotification('error', '❌ Erro', 'Falha na comunicação com o servidor');
        });
    }
}

// ============================================================
// REJEITAR FÉRIAS
// ============================================================
function rejeitarFerias(id) {
    const motivo = prompt('Digite o motivo da rejeição:');
    if (motivo !== null && motivo.trim() !== '') {
        fetch('${pageContext.request.contextPath}/ferias/rejeitar', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: 'id=' + id + '&motivo=' + encodeURIComponent(motivo)
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                showNotification('warning', '⚠️ Rejeitado', data.message);
                setTimeout(() => location.reload(), 1200);
            } else {
                showNotification('error', '❌ Erro', data.message);
            }
        })
        .catch(error => {
            showNotification('error', '❌ Erro', 'Falha na comunicação com o servidor');
        });
    } else if (motivo !== null) {
        showNotification('warning', '⚠️ Atenção', 'Motivo da rejeição é obrigatório');
    }
}

// ============================================================
// VER DETALHES
// ============================================================
function verDetalhes(id) {
    window.location.href = '${pageContext.request.contextPath}/ferias/detalhes/' + id;
}

// ============================================================
// APROVAR TODAS
// ============================================================
function aprovarTodas() {
    if (confirm('⚠️ Deseja aprovar TODAS as solicitações pendentes?')) {
        fetch('${pageContext.request.contextPath}/ferias/aprovar-todas', {
            method: 'POST'
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                showNotification('success', '✅ Aprovado', data.message);
                setTimeout(() => location.reload(), 1200);
            } else {
                showNotification('error', '❌ Erro', data.message);
            }
        })
        .catch(error => {
            showNotification('error', '❌ Erro', 'Falha na comunicação com o servidor');
        });
    }
}

// ============================================================
// NOTIFICATIONS
// ============================================================
function showNotification(type, title, message) {
    if (typeof window.showNotification === 'function') {
        window.showNotification(type, title, message);
    } else {
        alert(title + '\n\n' + message);
    }
}

// ============================================================
// FILTRO DE PESQUISA
// ============================================================
document.addEventListener('DOMContentLoaded', function() {
    var searchInput = document.getElementById('globalSearch');
    if (searchInput) {
        searchInput.addEventListener('keyup', function() {
            var filter = this.value.toLowerCase();
            var rows = document.querySelectorAll('#feriasPendentesTable tbody tr');
            
            rows.forEach(function(row) {
                var text = row.textContent.toLowerCase();
                row.style.display = text.includes(filter) ? '' : 'none';
            });
        });
    }
});
</script>

<jsp:include page="/WEB-INF/views/layout/footer.jsp" />
<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core"%>

<jsp:include page="/WEB-INF/views/layout/header.jsp">
    <jsp:param name="pageTitle" value="${acao == 'cadastrar' ? 'Novo Usuário' : 'Editar Usuário'}" />
    <jsp:param name="activeMenu" value="usuarios" />
</jsp:include>

<style>
    .required { color: var(--danger); font-weight: 700; }
    .form-group label { font-weight: 600; font-size: 13px; color: var(--dark); margin-bottom: 4px; }
    .form-control, .form-select { border-radius: 10px; border: 1px solid var(--gray-border); padding: 8px 12px; font-size: 13px; transition: var(--transition); }
    .form-control:focus, .form-select:focus { border-color: var(--primary); box-shadow: 0 0 0 3px rgba(79,70,229,0.1); }
    .form-container { background: #fff; border-radius: var(--border-radius); padding: 28px; box-shadow: var(--shadow-sm); border: 1px solid var(--gray-border); margin-bottom: 24px; }
    .form-title { font-size: 20px; font-weight: 700; color: var(--dark); margin-bottom: 24px; display: flex; align-items: center; gap: 12px; }
    .form-title i { color: var(--primary); }
    .form-actions { margin-top: 24px; padding-top: 20px; border-top: 1px solid var(--gray-border); display: flex; gap: 12px; flex-wrap: wrap; }
    .helper-text { font-size: 11px; color: var(--gray); margin-top: 4px; }
    .helper-text i { color: var(--info); }

    /* Badge de perfil no formulário */
    .badge-perfil-preview {
        display: inline-block;
        padding: 2px 10px;
        border-radius: 12px;
        font-size: 11px;
        font-weight: 600;
        border: 1px solid transparent;
        margin-top: 4px;
    }
    .badge-perfil-preview.admin {
        background: rgba(239,68,68,0.1);
        color: #dc2626;
        border-color: rgba(239,68,68,0.15);
    }
    .badge-perfil-preview.rh {
        background: rgba(79,70,229,0.1);
        color: #4f46e5;
        border-color: rgba(79,70,229,0.15);
    }
    .badge-perfil-preview.financeiro {
        background: rgba(16,185,129,0.1);
        color: #059669;
        border-color: rgba(16,185,129,0.15);
    }
    .badge-perfil-preview.gestor {
        background: rgba(245,158,11,0.1);
        color: #d97706;
        border-color: rgba(245,158,11,0.15);
    }
    .badge-perfil-preview.funcionario {
        background: rgba(59,130,246,0.1);
        color: #2563eb;
        border-color: rgba(59,130,246,0.15);
    }

    .badge-status-preview {
        display: inline-block;
        padding: 2px 10px;
        border-radius: 12px;
        font-size: 11px;
        font-weight: 600;
        border: 1px solid transparent;
        margin-top: 4px;
    }
    .badge-status-preview.ativo {
        background: rgba(16,185,129,0.1);
        color: #059669;
        border-color: rgba(16,185,129,0.15);
    }
    .badge-status-preview.inativo {
        background: rgba(239,68,68,0.1);
        color: #dc2626;
        border-color: rgba(239,68,68,0.15);
    }
    .badge-status-preview.bloqueado {
        background: rgba(245,158,11,0.1);
        color: #d97706;
        border-color: rgba(245,158,11,0.15);
    }

    /* ============================================================
       CAMPO SENHA COM BOTÃO
    ============================================================ */
    .password-wrapper {
        position: relative;
    }
    .password-wrapper .form-control {
        padding-right: 45px;
    }
    .password-wrapper .toggle-password {
        position: absolute;
        right: 12px;
        top: 50%;
        transform: translateY(-50%);
        background: none;
        border: none;
        color: var(--gray);
        cursor: pointer;
        font-size: 16px;
        padding: 4px 8px;
        transition: var(--transition);
        z-index: 5;
    }
    .password-wrapper .toggle-password:hover {
        color: var(--primary);
    }

    /* ============================================================
       AUTO-PREENCHIMENTO
    ============================================================ */
    .auto-fill-badge {
        display: inline-block;
        padding: 2px 10px;
        border-radius: 12px;
        font-size: 11px;
        font-weight: 600;
        background: rgba(16,185,129,0.1);
        color: #059669;
        border: 1px solid rgba(16,185,129,0.15);
        margin-top: 4px;
    }
    .auto-fill-badge i {
        margin-right: 4px;
    }

    @media (max-width: 768px) {
        .form-container { padding: 20px; }
        .form-title { font-size: 18px; }
        .form-actions { flex-direction: column; }
        .form-actions .btn-primary-custom, .form-actions .btn-outline-custom { width: 100%; justify-content: center; }
    }
    @media (max-width: 576px) {
        .form-container { padding: 16px; }
        .form-title { font-size: 16px; }
    }
</style>

<div class="form-container animate-in">
    <div class="form-title">
        <i class="fas ${acao == 'cadastrar' ? 'fa-user-plus' : 'fa-user-edit'}"></i>
        ${acao == 'cadastrar' ? 'Cadastrar Usuário' : 'Editar Usuário'}
    </div>

    <form action="${pageContext.request.contextPath}/usuarios" method="post" id="usuarioForm" novalidate>
        <input type="hidden" name="id" value="${usuario.id}">

        <div class="row g-3">
            <!-- Funcionário Associado -->
            <div class="col-12">
                <div class="form-group">
                    <label for="idFuncionario">Funcionário Associado</label>
                    <select class="form-select" name="idFuncionario" id="idFuncionario">
                        <option value="">Nenhum</option>
                        <c:forEach items="${funcionarios}" var="f">
                            <option value="${f.id}" 
                                    data-nome="${f.nome}" 
                                    data-email="${f.emailEmpresa != null ? f.emailEmpresa : f.email != null ? f.email : ''}"
                                    ${usuario.idFuncionario == f.id ? 'selected' : ''}>
                                ${f.nome}
                            </option>
                        </c:forEach>
                    </select>
                    <div class="helper-text">
                        <i class="fas fa-info-circle"></i> Associar este usuário a um funcionário existente (preenche nome e email automaticamente)
                    </div>
                    <div id="funcionarioInfo" style="margin-top: 8px; display: none;">
                        <span class="auto-fill-badge"><i class="fas fa-user-check"></i> Funcionário selecionado</span>
                    </div>
                </div>
            </div>

            <!-- Nome Completo -->
            <div class="col-md-6">
                <div class="form-group">
                    <label for="nome">Nome Completo <span class="required">*</span></label>
                    <input type="text" class="form-control" name="nome" id="nome"
                           value="${usuario.nome}" required placeholder="Nome completo" 
                           minlength="3" maxlength="100">
                    <div class="helper-text">
                        <i class="fas fa-info-circle"></i> Mínimo 3 caracteres, máximo 100
                    </div>
                </div>
            </div>

            <!-- Usuário -->
            <div class="col-md-6">
                <div class="form-group">
                    <label for="usuario">Usuário <span class="required">*</span></label>
                    <input type="text" class="form-control" name="usuario" id="usuario"
                           value="${usuario.usuario}" required placeholder="Nome de usuário" 
                           minlength="3" maxlength="30">
                    <div class="helper-text">
                        <i class="fas fa-info-circle"></i> Mínimo 3 caracteres, máximo 30
                    </div>
                </div>
            </div>

            <!-- E-mail -->
            <div class="col-md-6">
                <div class="form-group">
                    <label for="email">E-mail <span class="required">*</span></label>
                    <input type="email" class="form-control" name="email" id="email"
                           value="${usuario.email}" required placeholder="E-mail" maxlength="100">
                    <div class="helper-text">
                        <i class="fas fa-info-circle"></i> Digite um e-mail válido
                    </div>
                </div>
            </div>

            <!-- Senha com botão mostrar -->
            <div class="col-md-6">
                <div class="form-group">
                    <label for="senha">${acao == 'cadastrar' ? 'Senha' : 'Nova Senha'} <span class="required">${acao == 'cadastrar' ? '*' : ''}</span></label>
                    <div class="password-wrapper">
                        <input type="password" class="form-control" name="senha" id="senha"
                               placeholder="${acao == 'cadastrar' ? 'Digite a senha' : 'Deixe em branco para manter a atual'}"
                               ${acao == 'cadastrar' ? 'required' : ''}>
                        <button type="button" class="toggle-password" id="toggleSenha" title="Mostrar/Esconder senha">
                            <i class="fas fa-eye"></i>
                        </button>
                    </div>
                    <div class="helper-text">
                        <i class="fas fa-info-circle"></i> Mínimo 8 caracteres, com letras maiúsculas, minúsculas e números
                    </div>
                </div>
            </div>

            <!-- Perfil -->
            <div class="col-md-6">
                <div class="form-group">
                    <label for="perfil">Perfil <span class="required">*</span></label>
                    <select class="form-select" name="perfil" id="perfil" required>
                        <option value="">Selecione um perfil</option>
                        <c:forEach items="${perfis}" var="p">
                            <option value="${p}" ${usuario.perfil == p ? 'selected' : ''}>
                                ${p}
                            </option>
                        </c:forEach>
                    </select>
                    <div class="helper-text">
                        <i class="fas fa-info-circle"></i> Define as permissões do usuário
                    </div>
                    <div id="perfilSelecionado" style="margin-top: 8px;">
                        <!-- Badge do perfil será exibido aqui via JavaScript -->
                    </div>
                </div>
            </div>

            <!-- Status -->
            <div class="col-md-6">
                <div class="form-group">
                    <label for="status">Status <span class="required">*</span></label>
                    <select class="form-select" name="status" id="status" required>
                        <c:forEach items="${statusList}" var="s">
                            <option value="${s}" ${usuario.status == s ? 'selected' : ''}>
                                ${s}
                            </option>
                        </c:forEach>
                    </select>
                    <div class="helper-text">
                        <i class="fas fa-info-circle"></i> ATIVO = pode acessar, INATIVO = bloqueado
                    </div>
                    <div id="statusSelecionado" style="margin-top: 8px;">
                        <!-- Badge do status será exibido aqui via JavaScript -->
                    </div>
                </div>
            </div>
        </div>

        <div class="form-actions">
            <button type="submit" class="btn-primary-custom" id="btnSalvar">
                <i class="fas fa-save"></i> ${acao == 'cadastrar' ? 'Cadastrar' : 'Atualizar'}
            </button>
            <a href="${pageContext.request.contextPath}/usuarios" class="btn-outline-custom">
                <i class="fas fa-times"></i> Cancelar
            </a>
        </div>
    </form>
</div>

<script>
// ============================================================
// AUTO-PREENCHIMENTO - Preencher nome e email ao selecionar funcionário
// ============================================================
document.getElementById('idFuncionario').addEventListener('change', function() {
    const selectedOption = this.options[this.selectedIndex];
    const nome = selectedOption.getAttribute('data-nome');
    const email = selectedOption.getAttribute('data-email');
    const infoDiv = document.getElementById('funcionarioInfo');
    
    if (this.value && nome) {
        // Preencher nome
        const nomeInput = document.getElementById('nome');
        if (!nomeInput.value || nomeInput.value === '') {
            nomeInput.value = nome;
        }
        
        // Preencher email
        const emailInput = document.getElementById('email');
        if (email && (!emailInput.value || emailInput.value === '')) {
            emailInput.value = email;
        }
        
        // Mostrar badge de confirmação
        infoDiv.style.display = 'block';
        infoDiv.innerHTML = '<span class="auto-fill-badge"><i class="fas fa-user-check"></i> Funcionário: ' + nome + (email ? ' | ' + email : '') + '</span>';
    } else {
        infoDiv.style.display = 'none';
    }
});

// ============================================================
// MOSTRAR/ESCONDER SENHA
// ============================================================
document.getElementById('toggleSenha').addEventListener('click', function() {
    const senhaInput = document.getElementById('senha');
    const icon = this.querySelector('i');
    
    if (senhaInput.type === 'password') {
        senhaInput.type = 'text';
        icon.className = 'fas fa-eye-slash';
        this.title = 'Esconder senha';
    } else {
        senhaInput.type = 'password';
        icon.className = 'fas fa-eye';
        this.title = 'Mostrar senha';
    }
});

// ============================================================
// EXIBIR PERFIL SELECIONADO COMO BADGE
// ============================================================
document.getElementById('perfil').addEventListener('change', function() {
    const container = document.getElementById('perfilSelecionado');
    const selected = this.value;
    
    container.innerHTML = '';
    if (selected) {
        const badge = document.createElement('span');
        badge.className = 'badge-perfil-preview ' + selected.toLowerCase();
        const icon = selected === 'ADMIN' ? 'fa-crown' : 
                     selected === 'RH' ? 'fa-users' : 
                     selected === 'FINANCEIRO' ? 'fa-coins' : 
                     selected === 'GESTOR' ? 'fa-user-tie' : 'fa-user';
        badge.innerHTML = '<i class="fas ' + icon + '"></i> ' + selected;
        container.appendChild(badge);
    } else {
        container.innerHTML = '<span style="font-size: 12px; color: var(--gray);">Nenhum perfil selecionado</span>';
    }
});

// ============================================================
// EXIBIR STATUS SELECIONADO COMO BADGE
// ============================================================
document.getElementById('status').addEventListener('change', function() {
    const container = document.getElementById('statusSelecionado');
    const selected = this.value;
    
    container.innerHTML = '';
    if (selected) {
        const badge = document.createElement('span');
        badge.className = 'badge-status-preview ' + selected.toLowerCase();
        const icon = selected === 'ATIVO' ? 'fa-check-circle' : 'fa-times-circle';
        badge.innerHTML = '<i class="fas ' + icon + '"></i> ' + selected;
        container.appendChild(badge);
    } else {
        container.innerHTML = '<span style="font-size: 12px; color: var(--gray);">Nenhum status selecionado</span>';
    }
});

// ============================================================
// CARREGAR VALORES INICIAIS
// ============================================================
document.addEventListener('DOMContentLoaded', function() {
    document.getElementById('perfil').dispatchEvent(new Event('change'));
    document.getElementById('status').dispatchEvent(new Event('change'));
    
    // Disparar change do funcionário para preencher se já tiver selecionado
    document.getElementById('idFuncionario').dispatchEvent(new Event('change'));
});

// ============================================================
// VALIDAÇÃO DO FORMULÁRIO
// ============================================================
document.getElementById('usuarioForm').addEventListener('submit', function(e) {
    let isValid = true;
    let errorMessages = [];

    const nome = document.getElementById('nome');
    if (nome.value.trim().length < 3) {
        errorMessages.push('Nome deve ter no mínimo 3 caracteres');
        isValid = false;
    }
    if (nome.value.trim().length > 100) {
        errorMessages.push('Nome deve ter no máximo 100 caracteres');
        isValid = false;
    }

    const usuario = document.getElementById('usuario');
    if (usuario.value.trim().length < 3) {
        errorMessages.push('Usuário deve ter no mínimo 3 caracteres');
        isValid = false;
    }
    if (usuario.value.trim().length > 30) {
        errorMessages.push('Usuário deve ter no máximo 30 caracteres');
        isValid = false;
    }

    const email = document.getElementById('email');
    if (!email.value.match(/^[A-Za-z0-9+_.-]+@(.+)$/)) {
        errorMessages.push('Digite um e-mail válido');
        isValid = false;
    }

    const senha = document.getElementById('senha');
    if (senha.value) {
        if (senha.value.length < 8) {
            errorMessages.push('Senha deve ter no mínimo 8 caracteres');
            isValid = false;
        }
        if (!senha.value.match(/[A-Z]/)) {
            errorMessages.push('Senha deve conter pelo menos uma letra maiúscula');
            isValid = false;
        }
        if (!senha.value.match(/[a-z]/)) {
            errorMessages.push('Senha deve conter pelo menos uma letra minúscula');
            isValid = false;
        }
        if (!senha.value.match(/[0-9]/)) {
            errorMessages.push('Senha deve conter pelo menos um número');
            isValid = false;
        }
    } else {
        // Se for cadastro, senha é obrigatória
        if (document.getElementById('usuarioForm').querySelector('input[name="id"]').value === '') {
            errorMessages.push('Senha é obrigatória para cadastro');
            isValid = false;
        }
    }

    const perfil = document.getElementById('perfil');
    if (!perfil.value) {
        errorMessages.push('Selecione um perfil');
        isValid = false;
    }

    const status = document.getElementById('status');
    if (!status.value) {
        errorMessages.push('Selecione um status');
        isValid = false;
    }

    if (!isValid) {
        e.preventDefault();
        alert('Erro de Validação:\n' + errorMessages.join('\n'));
        return false;
    }

    return true;
});

// ============================================================
// FALLBACK - SHOW NOTIFICATION
// ============================================================
if (typeof showNotification === 'undefined') {
    window.showNotification = function(type, title, message) {
        alert(title + ': ' + message);
    };
}
</script>

<jsp:include page="/WEB-INF/views/layout/footer.jsp" />
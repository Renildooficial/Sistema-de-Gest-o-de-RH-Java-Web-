<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core"%>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt"%>

<jsp:include page="/WEB-INF/views/layout/header.jsp">
    <jsp:param name="pageTitle" value="Plano de Férias" />
    <jsp:param name="activeMenu" value="plano-ferias" />
</jsp:include>

<style>
    :root {
        --primary: #4f46e5;
        --primary-hover: #4338ca;
        --primary-light: #e0e7ff;
        --success: #22c55e;
        --success-light: #d1fae5;
        --warning: #f59e0b;
        --warning-light: #fef3c7;
        --danger: #ef4444;
        --danger-light: #fee2e2;
        --gray: #64748b;
        --gray-light: #f1f5f9;
        --dark: #0f172a;
        --border: #e2e8f0;
        --shadow: 0 1px 3px rgba(0,0,0,0.06);
        --shadow-hover: 0 8px 25px rgba(0,0,0,0.08);
        --radius: 12px;
    }

    .plano-container {
        max-width: 1200px;
        margin: 0 auto;
        padding: 20px;
    }

    /* ============================================================
       HEADER
    ============================================================ */
    .page-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        flex-wrap: wrap;
        gap: 15px;
        margin-bottom: 28px;
    }

    .page-header h1 {
        font-size: 26px;
        font-weight: 700;
        color: var(--dark);
        display: flex;
        align-items: center;
        gap: 14px;
        margin: 0;
    }

    .page-header h1 i {
        color: var(--primary);
        background: var(--primary-light);
        padding: 12px;
        border-radius: var(--radius);
        font-size: 22px;
    }

    .page-header .subtitle {
        font-size: 14px;
        color: var(--gray);
        font-weight: 400;
        margin-left: 4px;
    }

    .btn-primary-custom {
        background: var(--primary);
        color: #fff;
        padding: 11px 26px;
        border: none;
        border-radius: var(--radius);
        font-size: 14px;
        font-weight: 600;
        display: inline-flex;
        align-items: center;
        gap: 10px;
        text-decoration: none;
        cursor: pointer;
        transition: all 0.2s ease;
        box-shadow: 0 2px 8px rgba(79, 70, 229, 0.25);
    }

    .btn-primary-custom:hover {
        background: var(--primary-hover);
        color: #fff;
        transform: translateY(-2px);
        box-shadow: 0 4px 16px rgba(79, 70, 229, 0.35);
    }

    .btn-outline-custom {
        background: transparent;
        color: var(--gray);
        padding: 10px 20px;
        border: 1.5px solid var(--border);
        border-radius: var(--radius);
        font-size: 14px;
        font-weight: 600;
        display: inline-flex;
        align-items: center;
        gap: 8px;
        text-decoration: none;
        cursor: pointer;
        transition: all 0.2s ease;
    }

    .btn-outline-custom:hover {
        background: var(--gray-light);
        color: var(--dark);
        border-color: #cbd5e1;
    }

    /* ============================================================
       CARDS DE ESTATÍSTICAS
    ============================================================ */
    .stats-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
        gap: 16px;
        margin-bottom: 28px;
    }

    .stat-card {
        background: #fff;
        border-radius: var(--radius);
        padding: 18px 16px;
        text-align: center;
        border: 1px solid var(--border);
        transition: all 0.25s ease;
        position: relative;
        overflow: hidden;
    }

    .stat-card::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        height: 3px;
        border-radius: var(--radius) var(--radius) 0 0;
    }

    .stat-card.total::before { background: var(--primary); }
    .stat-card.pendentes::before { background: var(--warning); }
    .stat-card.aprovados::before { background: var(--success); }
    .stat-card.execucao::before { background: #8b5cf6; }
    .stat-card.concluidos::before { background: #06b6d4; }
    .stat-card.cancelados::before { background: var(--gray); }

    .stat-card:hover {
        transform: translateY(-4px);
        box-shadow: var(--shadow-hover);
        border-color: transparent;
    }

    .stat-card .number {
        font-size: 28px;
        font-weight: 700;
        line-height: 1.2;
    }

    .stat-card.total .number { color: var(--primary); }
    .stat-card.pendentes .number { color: var(--warning); }
    .stat-card.aprovados .number { color: var(--success); }
    .stat-card.execucao .number { color: #8b5cf6; }
    .stat-card.concluidos .number { color: #06b6d4; }
    .stat-card.cancelados .number { color: var(--gray); }

    .stat-card .label {
        font-size: 12px;
        color: var(--gray);
        margin-top: 4px;
        font-weight: 500;
    }

    /* ============================================================
       FILTROS E BUSCA
    ============================================================ */
    .filters-section {
        display: flex;
        flex-wrap: wrap;
        gap: 12px;
        margin-bottom: 20px;
        align-items: center;
    }

    .filters-section .filter-label {
        font-size: 13px;
        font-weight: 600;
        color: var(--gray);
        margin-right: 4px;
    }

    .filter-btn {
        padding: 6px 16px;
        border: 1px solid var(--border);
        border-radius: 20px;
        background: #fff;
        color: var(--gray);
        font-size: 12px;
        font-weight: 500;
        cursor: pointer;
        transition: all 0.2s ease;
    }

    .filter-btn:hover {
        background: var(--gray-light);
        border-color: #cbd5e1;
    }

    .filter-btn.active {
        background: var(--primary);
        color: #fff;
        border-color: var(--primary);
    }

    .search-box {
        display: flex;
        gap: 8px;
        align-items: center;
        margin-left: auto;
    }

    .search-box input {
        padding: 8px 14px;
        border: 1px solid var(--border);
        border-radius: 8px;
        font-size: 13px;
        min-width: 200px;
        transition: border-color 0.2s;
    }

    .search-box input:focus {
        outline: none;
        border-color: var(--primary);
    }

    .search-box button {
        padding: 8px 16px;
        background: var(--primary);
        color: #fff;
        border: none;
        border-radius: 8px;
        cursor: pointer;
        font-size: 13px;
        transition: background 0.2s;
    }

    .search-box button:hover {
        background: var(--primary-hover);
    }

    /* ============================================================
       TABELA
    ============================================================ */
    .table-wrapper {
        background: #fff;
        border-radius: var(--radius);
        border: 1px solid var(--border);
        overflow: hidden;
        box-shadow: var(--shadow);
    }

    .table-header-custom {
        padding: 16px 20px;
        border-bottom: 1px solid var(--border);
        display: flex;
        justify-content: space-between;
        align-items: center;
        flex-wrap: wrap;
        gap: 10px;
        background: #fafbfc;
    }

    .table-header-custom .title {
        font-weight: 600;
        font-size: 15px;
        color: var(--dark);
        display: flex;
        align-items: center;
        gap: 10px;
    }

    .table-header-custom .title .count {
        font-weight: 400;
        color: var(--gray);
        font-size: 13px;
        background: var(--gray-light);
        padding: 2px 10px;
        border-radius: 12px;
    }

    .table-responsive {
        overflow-x: auto;
        -webkit-overflow-scrolling: touch;
    }

    .table-custom {
        width: 100%;
        border-collapse: collapse;
        font-size: 14px;
        min-width: 800px;
    }

    .table-custom thead th {
        background: #f8fafc;
        color: var(--gray);
        font-weight: 600;
        font-size: 11px;
        text-transform: uppercase;
        letter-spacing: 0.6px;
        padding: 14px 16px;
        text-align: left;
        border-bottom: 2px solid var(--border);
        white-space: nowrap;
    }

    .table-custom tbody td {
        padding: 14px 16px;
        border-bottom: 1px solid var(--border);
        vertical-align: middle;
    }

    .table-custom tbody tr:last-child td {
        border-bottom: none;
    }

    .table-custom tbody tr:hover td {
        background: #fafbfc;
    }

    .table-custom .empty-row td {
        text-align: center;
        padding: 60px 20px;
        color: var(--gray);
    }

    .table-custom .empty-row .empty-icon {
        font-size: 48px;
        display: block;
        margin-bottom: 16px;
        color: #cbd5e1;
    }

    .table-custom .empty-row h4 {
        font-size: 18px;
        color: var(--dark);
        margin-bottom: 6px;
    }

    .table-custom .empty-row p {
        font-size: 14px;
        color: var(--gray);
        margin: 0;
    }

    /* ============================================================
       BADGES
    ============================================================ */
    .badge-status {
        padding: 5px 14px;
        border-radius: 20px;
        font-size: 11px;
        font-weight: 600;
        display: inline-flex;
        align-items: center;
        gap: 6px;
        border: 1px solid transparent;
        white-space: nowrap;
    }

    .badge-status .dot {
        width: 6px;
        height: 6px;
        border-radius: 50%;
        display: inline-block;
    }

    .badge-status.pendente {
        background: var(--warning-light);
        color: #d97706;
        border-color: #fde68a;
    }
    .badge-status.pendente .dot { background: #d97706; }

    .badge-status.aprovado {
        background: var(--success-light);
        color: #059669;
        border-color: #a7f3d0;
    }
    .badge-status.aprovado .dot { background: #059669; }

    .badge-status.em_execucao {
        background: #ede9fe;
        color: #7c3aed;
        border-color: #c4b5fd;
    }
    .badge-status.em_execucao .dot { background: #7c3aed; }

    .badge-status.concluido {
        background: #dbeafe;
        color: #2563eb;
        border-color: #93c5fd;
    }
    .badge-status.concluido .dot { background: #2563eb; }

    .badge-status.cancelado {
        background: #f1f5f9;
        color: #64748b;
        border-color: #cbd5e1;
    }
    .badge-status.cancelado .dot { background: #64748b; }

    /* ============================================================
       AÇÕES
    ============================================================ */
    .action-btns {
        display: flex;
        gap: 4px;
        flex-wrap: wrap;
    }

    .btn-icon {
        width: 34px;
        height: 34px;
        border: none;
        border-radius: 8px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        font-size: 13px;
        transition: all 0.2s ease;
        background: transparent;
        color: var(--gray);
        text-decoration: none;
    }

    .btn-icon:hover {
        transform: scale(1.1);
    }

    .btn-icon.view { color: var(--primary); }
    .btn-icon.view:hover { background: var(--primary-light); }

    .btn-icon.edit { color: var(--warning); }
    .btn-icon.edit:hover { background: var(--warning-light); }

    .btn-icon.delete { color: var(--danger); }
    .btn-icon.delete:hover { background: var(--danger-light); }

    .btn-icon.success { color: var(--success); }
    .btn-icon.success:hover { background: var(--success-light); }

    /* ============================================================
       RESPONSIVIDADE
    ============================================================ */
    @media (max-width: 992px) {
        .stats-grid {
            grid-template-columns: repeat(3, 1fr);
        }
    }

    @media (max-width: 768px) {
        .plano-container { padding: 12px; }
        
        .page-header {
            flex-direction: column;
            align-items: stretch;
        }
        
        .page-header h1 { 
            font-size: 20px; 
        }
        
        .page-header h1 i {
            padding: 10px;
            font-size: 18px;
        }
        
        .btn-primary-custom {
            justify-content: center;
            padding: 10px 20px;
        }
        
        .stats-grid {
            grid-template-columns: repeat(2, 1fr);
            gap: 12px;
        }
        
        .stat-card {
            padding: 14px 12px;
        }
        
        .stat-card .number {
            font-size: 22px;
        }
        
        .search-box {
            margin-left: 0;
            width: 100%;
        }
        
        .search-box input {
            flex: 1;
            min-width: 100px;
        }
        
        .table-header-custom {
            padding: 12px 14px;
        }
        
        .table-header-custom .title {
            font-size: 13px;
        }
        
        .table-custom {
            font-size: 12px;
            min-width: 650px;
        }
        
        .table-custom thead th,
        .table-custom tbody td {
            padding: 10px 12px;
        }
        
        .badge-status {
            font-size: 10px;
            padding: 3px 10px;
        }
        
        .btn-icon {
            width: 30px;
            height: 30px;
            font-size: 12px;
        }
        
        .filters-section {
            gap: 6px;
        }
        
        .filter-btn {
            font-size: 11px;
            padding: 4px 12px;
        }
    }

    @media (max-width: 480px) {
        .stats-grid {
            grid-template-columns: 1fr 1fr;
            gap: 10px;
        }
        
        .stat-card {
            padding: 12px 8px;
        }
        
        .stat-card .number {
            font-size: 18px;
        }
        
        .table-custom {
            font-size: 11px;
            min-width: 500px;
        }
        
        .table-custom thead th,
        .table-custom tbody td {
            padding: 8px 8px;
        }
        
        .table-header-custom {
            padding: 10px 12px;
        }
        
        .table-header-custom .title {
            font-size: 12px;
        }
        
        .badge-status {
            font-size: 9px;
            padding: 2px 8px;
        }
        
        .btn-icon {
            width: 26px;
            height: 26px;
            font-size: 10px;
        }
        
        .page-header h1 { 
            font-size: 17px; 
        }
        
        .page-header h1 i {
            padding: 8px;
            font-size: 15px;
        }
    }

    /* ============================================================
       ANIMAÇÃO
    ============================================================ */
    @keyframes fadeInUp {
        from { opacity: 0; transform: translateY(15px); }
        to { opacity: 1; transform: translateY(0); }
    }

    .stat-card { animation: fadeInUp 0.4s ease forwards; }
    .stat-card:nth-child(1) { animation-delay: 0.05s; }
    .stat-card:nth-child(2) { animation-delay: 0.10s; }
    .stat-card:nth-child(3) { animation-delay: 0.15s; }
    .stat-card:nth-child(4) { animation-delay: 0.20s; }
    .stat-card:nth-child(5) { animation-delay: 0.25s; }
    .stat-card:nth-child(6) { animation-delay: 0.30s; }
    
    .table-wrapper { animation: fadeInUp 0.4s ease 0.3s forwards; opacity: 0; }
</style>

<div class="plano-container">
    <!-- ============================================================
    HEADER
    ============================================================ -->
    <div class="page-header">
        <h1>
            <i class="fas fa-calendar-alt"></i>
            Plano de Férias
            <span class="subtitle">— Gerencie as férias dos funcionários</span>
        </h1>
        <div>
            <a href="${pageContext.request.contextPath}/plano-ferias/novo" 
               class="btn-primary-custom">
                <i class="fas fa-plus-circle"></i> Novo Plano
            </a>
        </div>
    </div>

    <!-- ============================================================
    ESTATÍSTICAS
    ============================================================ -->
    <div class="stats-grid">
        <div class="stat-card total">
            <div class="number">${total != null ? total : 0}</div>
            <div class="label"><i class="fas fa-list"></i> Total</div>
        </div>
        <div class="stat-card pendentes">
            <div class="number">${pendentes != null ? pendentes : 0}</div>
            <div class="label"><i class="fas fa-clock"></i> Pendentes</div>
        </div>
        <div class="stat-card aprovados">
            <div class="number">${aprovados != null ? aprovados : 0}</div>
            <div class="label"><i class="fas fa-check-circle"></i> Aprovados</div>
        </div>
        <div class="stat-card execucao">
            <div class="number">${execucao != null ? execucao : 0}</div>
            <div class="label"><i class="fas fa-play-circle"></i> Em Execução</div>
        </div>
        <div class="stat-card concluidos">
            <div class="number">${concluidos != null ? concluidos : 0}</div>
            <div class="label"><i class="fas fa-flag-checkered"></i> Concluídos</div>
        </div>
        <div class="stat-card cancelados">
            <div class="number">${cancelados != null ? cancelados : 0}</div>
            <div class="label"><i class="fas fa-ban"></i> Cancelados</div>
        </div>
    </div>

    <!-- ============================================================
    FILTROS E BUSCA
    ============================================================ -->
    <div class="filters-section">
        <span class="filter-label"><i class="fas fa-filter"></i> Status:</span>
        <button class="filter-btn active" data-filter="all">Todos</button>
        <button class="filter-btn" data-filter="PENDENTE"><i class="fas fa-clock"></i> Pendentes</button>
        <button class="filter-btn" data-filter="APROVADO"><i class="fas fa-check-circle"></i> Aprovados</button>
        <button class="filter-btn" data-filter="EM_EXECUCAO"><i class="fas fa-play-circle"></i> Em Execução</button>
        <button class="filter-btn" data-filter="CONCLUIDO"><i class="fas fa-flag-checkered"></i> Concluídos</button>
        <button class="filter-btn" data-filter="CANCELADO"><i class="fas fa-ban"></i> Cancelados</button>
        
        <div class="search-box">
            <input type="text" id="searchInput" placeholder="Buscar funcionário..." onkeyup="buscarFuncionario()">
            <button onclick="buscarFuncionario()"><i class="fas fa-search"></i></button>
        </div>
    </div>

    <!-- ============================================================
    LISTA DE PLANOS
    ============================================================ -->
    <div class="table-wrapper">
        <div class="table-header-custom">
            <div class="title">
                <i class="fas fa-list-ul"></i>
                Planos de Férias
                <span class="count">${total != null ? total : 0}</span>
            </div>
            <div style="font-size: 13px; color: var(--gray);">
                <i class="fas fa-clock"></i> Atualizado: <fmt:formatDate value="<%= new java.util.Date() %>" pattern="dd/MM/yyyy HH:mm" />
            </div>
        </div>

        <div class="table-responsive">
            <table class="table-custom" id="tabelaPlanos">
                <thead>
                    <tr>
                        <th>Funcionário</th>
                        <th>Mês Planejado</th>
                        <th>Prioridade</th>
                        <th>Status</th>
                        <th>Observação</th>
                        <th style="text-align: center;">Ações</th>
                    </tr>
                </thead>
                <tbody>
                    <c:choose>
                        <c:when test="${empty planos}">
                            <tr class="empty-row">
                                <td colspan="6">
                                    <span class="empty-icon"><i class="fas fa-calendar-plus"></i></span>
                                    <h4>Nenhum plano de férias cadastrado</h4>
                                    <p>Clique em <strong>"Novo Plano"</strong> para criar um plano de férias.</p>
                                </td>
                            </tr>
                        </c:when>
                        <c:otherwise>
                            <c:forEach items="${planos}" var="p">
                                <tr data-status="${p.status}" data-nome="${p.funcionario != null ? p.funcionario.nome : ''}">
                                    <td>
                                        <strong>${p.funcionario != null ? p.funcionario.nome : 'ID: ' . p.idFuncionario}</strong>
                                        <c:if test="${p.funcionario != null && not empty p.funcionario.nuit}">
                                            <br>
                                            <span style="font-size: 11px; color: var(--gray);">
                                                <i class="fas fa-id-card"></i> ${p.funcionario.nuit}
                                            </span>
                                        </c:if>
                                    </td>
                                    <td>
                                        <strong>${p.nomeMes != null ? p.nomeMes : 'Mês ' . p.mesPlanejado}</strong>
                                        <br>
                                        <span style="font-size: 12px; color: var(--gray);">
                                            <i class="fas fa-calendar"></i> ${p.ano}
                                        </span>
                                    </td>
                                    <td>
                                        <c:choose>
                                            <c:when test="${p.prioridade == 1}">
                                                <span style="background: #fee2e2; color: #dc2626; padding: 4px 12px; border-radius: 12px; font-size: 12px; font-weight: 600;">
                                                    <i class="fas fa-arrow-up"></i> Alta
                                                </span>
                                            </c:when>
                                            <c:when test="${p.prioridade == 2}">
                                                <span style="background: #fef3c7; color: #d97706; padding: 4px 12px; border-radius: 12px; font-size: 12px; font-weight: 600;">
                                                    <i class="fas fa-minus"></i> Média
                                                </span>
                                            </c:when>
                                            <c:otherwise>
                                                <span style="background: #dbeafe; color: #2563eb; padding: 4px 12px; border-radius: 12px; font-size: 12px; font-weight: 600;">
                                                    <i class="fas fa-arrow-down"></i> Baixa
                                                </span>
                                            </c:otherwise>
                                        </c:choose>
                                    </td>
                                    <td>
                                        <span class="badge-status 
                                            ${p.status == 'PENDENTE' ? 'pendente' : 
                                              p.status == 'APROVADO' ? 'aprovado' : 
                                              p.status == 'EM_EXECUCAO' ? 'em_execucao' : 
                                              p.status == 'CONCLUIDO' ? 'concluido' : 
                                              p.status == 'CANCELADO' ? 'cancelado' : ''}">
                                            <span class="dot"></span>
                                            <c:choose>
                                                <c:when test="${p.status == 'PENDENTE'}">Pendente</c:when>
                                                <c:when test="${p.status == 'APROVADO'}">Aprovado</c:when>
                                                <c:when test="${p.status == 'EM_EXECUCAO'}">Em Execução</c:when>
                                                <c:when test="${p.status == 'CONCLUIDO'}">Concluído</c:when>
                                                <c:when test="${p.status == 'CANCELADO'}">Cancelado</c:when>
                                                <c:otherwise>${p.status}</c:otherwise>
                                            </c:choose>
                                        </span>
                                    </td>
                                    <td style="font-size: 13px; color: var(--gray); max-width: 150px; word-break: break-word;">
                                        ${p.observacao != null ? p.observacao : '-'}
                                    </td>
                                    <td style="text-align: center;">
                                        <div class="action-btns" style="justify-content: center;">
                                            <!-- Visualizar -->
                                            <a href="#" class="btn-icon view" 
                                               onclick="verDetalhes(${p.id})" 
                                               title="Ver detalhes">
                                                <i class="fas fa-eye"></i>
                                            </a>

                                            <!-- Editar -->
                                            <a href="${pageContext.request.contextPath}/plano-ferias/editar/${p.id}" 
                                               class="btn-icon edit" 
                                               title="Editar plano">
                                                <i class="fas fa-pen"></i>
                                            </a>

                                            <!-- Excluir -->
                                            <button class="btn-icon delete" 
                                                    onclick="excluirPlano(${p.id})" 
                                                    title="Excluir plano">
                                                <i class="fas fa-trash"></i>
                                            </button>

                                            <!-- Aprovar -->
                                            <c:if test="${p.status == 'PENDENTE'}">
                                                <button class="btn-icon success" 
                                                        onclick="aprovarPlano(${p.id})" 
                                                        title="Aprovar plano">
                                                    <i class="fas fa-check"></i>
                                                </button>
                                            </c:if>
                                        </div>
                                    </td>
                                </tr>
                            </c:forEach>
                        </c:otherwise>
                    </c:choose>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- ============================================================
SCRIPTS
============================================================ -->
<script>
// ============================================================
// FILTROS POR STATUS
// ============================================================
document.querySelectorAll('.filter-btn').forEach(btn => {
    btn.addEventListener('click', function() {
        document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
        this.classList.add('active');
        
        const filter = this.dataset.filter;
        const rows = document.querySelectorAll('#tabelaPlanos tbody tr');
        
        rows.forEach(row => {
            if (filter === 'all') {
                row.style.display = '';
            } else {
                const status = row.dataset.status;
                row.style.display = status === filter ? '' : 'none';
            }
        });
    });
});

// ============================================================
// BUSCAR FUNCIONÁRIO
// ============================================================
function buscarFuncionario() {
    const input = document.getElementById('searchInput');
    const filter = input.value.toLowerCase();
    const rows = document.querySelectorAll('#tabelaPlanos tbody tr');
    
    rows.forEach(row => {
        const nome = row.dataset.nome ? row.dataset.nome.toLowerCase() : '';
        if (nome.includes(filter)) {
            row.style.display = '';
        } else {
            row.style.display = 'none';
        }
    });
}

// ============================================================
// EXCLUIR PLANO
// ============================================================
function excluirPlano(id) {
    if (!confirm('Deseja realmente excluir este plano de férias?')) return;
    
    fetch('${pageContext.request.contextPath}/plano-ferias/excluir', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: 'id=' + id
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            showNotification('success', 'Excluído', data.message);
            setTimeout(() => location.reload(), 1200);
        } else {
            showNotification('error', 'Erro', data.message);
        }
    })
    .catch(error => {
        showNotification('error', 'Erro', 'Erro ao excluir plano');
    });
}

// ============================================================
// APROVAR PLANO
// ============================================================
function aprovarPlano(id) {
    if (!confirm('Deseja aprovar este plano de férias?')) return;
    
    fetch('${pageContext.request.contextPath}/plano-ferias/aprovar', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: 'id=' + id
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            showNotification('success', 'Aprovado', data.message);
            setTimeout(() => location.reload(), 1200);
        } else {
            showNotification('error', 'Erro', data.message);
        }
    })
    .catch(error => {
        showNotification('error', 'Erro', 'Erro ao aprovar plano');
    });
}

// ============================================================
// VER DETALHES
// ============================================================
function verDetalhes(id) {
    window.location.href = '${pageContext.request.contextPath}/plano-ferias/detalhes/' + id;
}

// ============================================================
// NOTIFICATIONS
// ============================================================
function showNotification(type, title, message) {
    if (typeof window.showNotification === 'function') {
        window.showNotification(type, title, message);
    } else {
        alert(title + '\n\n' + message);
    }
}
</script>

<jsp:include page="/WEB-INF/views/layout/footer.jsp" />
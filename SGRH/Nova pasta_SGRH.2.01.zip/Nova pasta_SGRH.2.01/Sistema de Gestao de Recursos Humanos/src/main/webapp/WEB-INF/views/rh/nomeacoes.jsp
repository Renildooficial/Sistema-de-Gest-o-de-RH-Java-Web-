<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core"%>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt"%>

<jsp:include page="/WEB-INF/views/layout/header.jsp">
    <jsp:param name="pageTitle" value="Nomeações" />
    <jsp:param name="activeMenu" value="nomeacao" />
</jsp:include>

<style>
    /* ============================================================
    ESTILOS - NOMEAÇÕES (mesmo estilo da página de formações)
    ============================================================ */
    .action-btns .btn-icon {
        width: 34px;
        height: 34px;
        border: none;
        border-radius: 8px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        background: transparent;
        color: var(--gray);
        font-size: 14px;
        text-decoration: none;
        margin: 0 2px;
        position: relative;
    }
    
    .action-btns .btn-icon:hover {
        transform: translateY(-3px);
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
    }
    
    .action-btns .btn-icon.edit {
        background: rgba(16, 185, 129, 0.1);
        color: var(--success);
    }
    .action-btns .btn-icon.edit:hover {
        background: rgba(16, 185, 129, 0.2);
        box-shadow: 0 4px 12px rgba(16, 185, 129, 0.3);
    }
    
    .action-btns .btn-icon.delete {
        background: rgba(239, 68, 68, 0.1);
        color: var(--danger);
    }
    .action-btns .btn-icon.delete:hover {
        background: rgba(239, 68, 68, 0.2);
        box-shadow: 0 4px 12px rgba(239, 68, 68, 0.3);
    }
    
    .action-btns .btn-icon.view {
        background: rgba(79, 70, 229, 0.1);
        color: var(--primary);
    }
    .action-btns .btn-icon.view:hover {
        background: rgba(79, 70, 229, 0.2);
        box-shadow: 0 4px 12px rgba(79, 70, 229, 0.3);
    }
    
    .action-btns .btn-icon.warning {
        background: rgba(245, 158, 11, 0.1);
        color: var(--warning);
    }
    .action-btns .btn-icon.warning:hover {
        background: rgba(245, 158, 11, 0.2);
        box-shadow: 0 4px 12px rgba(245, 158, 11, 0.3);
    }
    
    .action-btns .btn-icon .tooltip {
        display: none;
        position: absolute;
        bottom: -28px;
        left: 50%;
        transform: translateX(-50%);
        background: var(--dark);
        color: #fff;
        padding: 2px 10px;
        border-radius: 4px;
        font-size: 9px;
        font-weight: 500;
        white-space: nowrap;
        z-index: 100;
    }
    
    .action-btns .btn-icon:hover .tooltip {
        display: block;
    }
    
    .status-badge {
        padding: 4px 14px;
        border-radius: 20px;
        font-size: 11px;
        font-weight: 600;
        display: inline-block;
        text-transform: uppercase;
        letter-spacing: 0.3px;
        white-space: nowrap;
    }
    
    .status-badge.ativo {
        background: rgba(16, 185, 129, 0.12);
        color: var(--success);
        border: 1px solid rgba(16, 185, 129, 0.2);
    }
    .status-badge.inativo {
        background: rgba(239, 68, 68, 0.12);
        color: var(--danger);
        border: 1px solid rgba(239, 68, 68, 0.2);
    }
    .status-badge.pendente {
        background: rgba(245, 158, 11, 0.12);
        color: #D97706;
        border: 1px solid rgba(245, 158, 11, 0.2);
    }
    .status-badge.encerrada {
        background: rgba(107, 114, 128, 0.12);
        color: var(--gray);
        border: 1px solid rgba(107, 114, 128, 0.2);
    }
    
    .avatar-mini {
        width: 36px;
        height: 36px;
        border-radius: 50%;
        background: linear-gradient(135deg, var(--primary), #7c3aed);
        display: flex;
        align-items: center;
        justify-content: center;
        color: #fff;
        font-weight: 700;
        font-size: 14px;
        flex-shrink: 0;
    }
    
    .funcionario-nome {
        font-weight: 500;
        font-size: 13px;
    }
    
    .funcionario-id {
        font-size: 10px;
        color: var(--gray);
    }
    
    .badge-funcao {
        display: inline-block;
        padding: 2px 10px;
        border-radius: 12px;
        font-size: 10px;
        font-weight: 600;
        margin: 1px 2px;
        border: 1px solid transparent;
    }
    
    .badge-funcao.diretor { background: rgba(139,92,246,0.1); color: #7c3aed; border-color: rgba(139,92,246,0.15); }
    .badge-funcao.gerente { background: rgba(245,158,11,0.1); color: #d97706; border-color: rgba(245,158,11,0.15); }
    .badge-funcao.coordenador { background: rgba(239,68,68,0.1); color: #dc2626; border-color: rgba(239,68,68,0.15); }
    .badge-funcao.supervisor { background: rgba(139,92,246,0.1); color: #7c3aed; border-color: rgba(139,92,246,0.15); }
    .badge-funcao.analista { background: rgba(79,70,229,0.1); color: #4f46e5; border-color: rgba(79,70,229,0.15); }
    .badge-funcao.desenvolvedor { background: rgba(16,185,129,0.1); color: #059669; border-color: rgba(16,185,129,0.15); }
    .badge-funcao.assistente { background: rgba(236,72,153,0.1); color: #db2777; border-color: rgba(236,72,153,0.15); }
    .badge-funcao.tecnico { background: rgba(59,130,246,0.1); color: #2563eb; border-color: rgba(59,130,246,0.15); }
    .badge-funcao.consultor { background: rgba(20,184,166,0.1); color: #0d9488; border-color: rgba(20,184,166,0.15); }
    .badge-funcao.auditor { background: rgba(168,85,247,0.1); color: #7e22ce; border-color: rgba(168,85,247,0.15); }
    .badge-funcao.pesquisador { background: rgba(251,146,60,0.1); color: #ea580c; border-color: rgba(251,146,60,0.15); }
    .badge-funcao.docente { background: rgba(34,197,94,0.1); color: #16a34a; border-color: rgba(34,197,94,0.15); }
    .badge-funcao.outro { background: rgba(107,114,128,0.1); color: #6b7280; border-color: rgba(107,114,128,0.15); }
    
    .badge-cargo {
        display: inline-block;
        background: rgba(16,185,129,0.1);
        color: #059669;
        padding: 2px 10px;
        border-radius: 12px;
        font-size: 11px;
        font-weight: 600;
        border: 1px solid rgba(16,185,129,0.15);
    }
    
    .despacho-texto {
        font-size: 12px;
        font-weight: 500;
        color: var(--dark);
        max-width: 120px;
        display: inline-block;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
    }
    
    .funcoes-cell {
        display: flex;
        flex-wrap: wrap;
        gap: 2px;
        max-width: 200px;
    }
    
    /* ============================================================
    TABELA RESPONSIVA
    ============================================================ */
    .table-section {
        background: #fff;
        border-radius: var(--border-radius);
        padding: 20px;
        border: 1px solid var(--gray-border);
        box-shadow: var(--shadow-sm);
        margin-bottom: 24px;
        overflow-x: auto;
        -webkit-overflow-scrolling: touch;
    }
    
    .table-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 16px;
        flex-wrap: wrap;
        gap: 12px;
    }
    
    .table-header .title {
        font-size: 16px;
        font-weight: 700;
        color: var(--dark);
        display: flex;
        align-items: center;
        flex-wrap: wrap;
        gap: 6px;
    }
    
    .table-header .title i {
        color: var(--primary);
    }
    
    .table-header .title .badge-count {
        font-size: 12px;
        font-weight: 400;
        color: var(--gray);
        margin-left: 4px;
    }
    
    .table-header .actions {
        display: flex;
        gap: 8px;
        flex-wrap: wrap;
        align-items: center;
    }
    
    .btn-group {
        display: flex;
        gap: 4px;
        background: var(--gray-light);
        padding: 4px;
        border-radius: 8px;
    }
    
    .btn-group .btn-outline-custom {
        padding: 6px 14px;
        border: none;
        border-radius: 6px;
        background: transparent;
        color: var(--gray);
        font-size: 12px;
        font-weight: 600;
        text-decoration: none;
        transition: all 0.2s ease;
        cursor: pointer;
    }
    
    .btn-group .btn-outline-custom:hover {
        background: rgba(255,255,255,0.5);
        color: var(--dark);
    }
    
    .btn-group .btn-outline-custom.active {
        background: #fff;
        color: var(--primary);
        box-shadow: 0 1px 3px rgba(0,0,0,0.08);
    }
    
    .btn-outline-custom {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        padding: 8px 16px;
        border: 1.5px solid var(--gray-border);
        border-radius: 8px;
        background: transparent;
        color: var(--gray);
        font-size: 13px;
        font-weight: 600;
        text-decoration: none;
        transition: all 0.2s ease;
        cursor: pointer;
    }
    
    .btn-outline-custom:hover {
        background: var(--gray-light);
        color: var(--dark);
        border-color: #cbd5e1;
    }
    
    .btn-primary-custom {
        background: var(--primary);
        color: #fff;
        padding: 8px 18px;
        border: none;
        border-radius: 8px;
        font-size: 13px;
        font-weight: 600;
        display: inline-flex;
        align-items: center;
        gap: 8px;
        text-decoration: none;
        cursor: pointer;
        transition: all 0.2s ease;
    }
    
    .btn-primary-custom:hover {
        background: var(--primary-hover);
        color: #fff;
        transform: translateY(-2px);
        box-shadow: 0 4px 12px rgba(79, 70, 229, 0.3);
    }
    
    .table-custom {
        width: 100%;
        border-collapse: collapse;
        font-size: 13px;
        min-width: 700px;
    }
    
    .table-custom thead th {
        background: var(--gray-light);
        padding: 10px 14px;
        text-align: left;
        font-size: 11px;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        font-weight: 700;
        color: var(--gray);
        border-bottom: 2px solid var(--gray-border);
        white-space: nowrap;
    }
    
    .table-custom tbody td {
        padding: 10px 14px;
        border-bottom: 1px solid var(--gray-border);
        vertical-align: middle;
    }
    
    .table-custom tbody tr {
        transition: all 0.3s ease;
    }
    
    .table-custom tbody tr:hover {
        background: var(--gray-light);
    }
    
    /* ============================================================
    RESPONSIVO
    ============================================================ */
    @media (max-width: 992px) {
        .table-section {
            padding: 16px;
        }
        .table-header {
            flex-direction: column;
            align-items: stretch;
        }
        .table-header .actions {
            justify-content: center;
        }
        .table-custom {
            font-size: 12px;
            min-width: 600px;
        }
        .table-custom thead th {
            padding: 8px 10px;
            font-size: 10px;
        }
        .table-custom tbody td {
            padding: 8px 10px;
        }
        .funcoes-cell {
            max-width: 150px;
        }
    }
    
    @media (max-width: 768px) {
        .table-section {
            padding: 12px;
        }
        .table-custom {
            font-size: 11px;
            min-width: 500px;
        }
        .table-custom thead th {
            padding: 6px 8px;
            font-size: 9px;
        }
        .table-custom tbody td {
            padding: 6px 8px;
        }
        .action-btns .btn-icon {
            width: 30px;
            height: 30px;
            font-size: 12px;
        }
        .avatar-mini {
            width: 30px;
            height: 30px;
            font-size: 12px;
        }
        .status-badge {
            font-size: 9px;
            padding: 2px 10px;
        }
        .table-header .title {
            font-size: 14px;
        }
        .btn-primary-custom {
            font-size: 11px;
            padding: 6px 12px;
        }
        .btn-outline-custom {
            font-size: 11px;
            padding: 6px 12px;
        }
        .funcionario-nome {
            font-size: 12px;
        }
        .funcoes-cell {
            max-width: 120px;
        }
        .badge-funcao {
            font-size: 8px;
            padding: 1px 6px;
        }
        .despacho-texto {
            font-size: 10px;
            max-width: 80px;
        }
        .badge-cargo {
            font-size: 9px;
            padding: 1px 8px;
        }
    }
    
    @media (max-width: 576px) {
        .table-section {
            padding: 10px;
        }
        .table-custom {
            font-size: 10px;
            min-width: 400px;
        }
        .table-custom thead th {
            padding: 4px 6px;
            font-size: 8px;
        }
        .table-custom tbody td {
            padding: 4px 6px;
        }
        .action-btns .btn-icon {
            width: 26px;
            height: 26px;
            font-size: 11px;
        }
        .avatar-mini {
            width: 26px;
            height: 26px;
            font-size: 10px;
        }
        .status-badge {
            font-size: 8px;
            padding: 2px 8px;
        }
        .table-header .title {
            font-size: 13px;
        }
        .table-header .title .badge-count {
            font-size: 10px;
        }
        .btn-primary-custom {
            font-size: 10px;
            padding: 4px 10px;
        }
        .btn-outline-custom {
            font-size: 10px;
            padding: 4px 10px;
        }
        .funcionario-nome {
            font-size: 11px;
        }
        .funcoes-cell {
            max-width: 100px;
        }
        .badge-funcao {
            font-size: 7px;
            padding: 1px 5px;
        }
        .despacho-texto {
            font-size: 9px;
            max-width: 60px;
        }
        .badge-cargo {
            font-size: 8px;
            padding: 1px 6px;
        }
        .btn-group .btn-outline-custom {
            font-size: 10px;
            padding: 4px 10px;
        }
    }
    
    @media (max-width: 480px) {
        .table-custom {
            min-width: 350px;
        }
        .table-custom thead th {
            padding: 3px 4px;
            font-size: 7px;
        }
        .table-custom tbody td {
            padding: 3px 4px;
        }
        .action-btns {
            display: flex;
            flex-wrap: wrap;
            gap: 2px;
        }
        .action-btns .btn-icon {
            width: 22px;
            height: 22px;
            font-size: 10px;
            border-radius: 6px;
        }
        .avatar-mini {
            width: 22px;
            height: 22px;
            font-size: 9px;
        }
        .status-badge {
            font-size: 7px;
            padding: 1px 6px;
        }
        .funcionario-nome {
            font-size: 10px;
        }
        .funcoes-cell {
            max-width: 80px;
        }
        .badge-funcao {
            font-size: 6px;
            padding: 1px 4px;
        }
        .despacho-texto {
            font-size: 8px;
            max-width: 50px;
        }
        .badge-cargo {
            font-size: 7px;
            padding: 1px 5px;
        }
        .btn-group .btn-outline-custom {
            font-size: 9px;
            padding: 3px 8px;
        }
    }

    /* ============================================================
    ANIMAÇÕES
    ============================================================ */
    @keyframes fadeInUp {
        from {
            opacity: 0;
            transform: translateY(20px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }

    .animate-in {
        opacity: 0;
        animation: fadeInUp 0.5s ease forwards;
    }
</style>

<div class="table-section animate-in">
    <div class="table-header">
        <div class="title">
            <i class="fas fa-briefcase me-2"></i>
            Nomeações
            <span class="badge-count">
                <i class="fas fa-list me-1"></i> ${total != null ? total : '0'} registros
            </span>
        </div>
        <div class="actions">
            <div class="btn-group">
                <a href="${pageContext.request.contextPath}/nomeacao" class="btn-outline-custom ${empty ativas ? 'active' : ''}">
                    <i class="fas fa-list"></i> Todas
                </a>
                <a href="${pageContext.request.contextPath}/nomeacao/ativas" class="btn-outline-custom ${ativas ? 'active' : ''}">
                    <i class="fas fa-check-circle"></i> Ativas
                </a>
            </div>
            <a href="${pageContext.request.contextPath}/nomeacao/novo" class="btn-primary-custom">
                <i class="fas fa-plus"></i> Nova Nomeação
            </a>
        </div>
    </div>

    <div class="table-responsive-custom">
        <table class="table-custom" id="nomeacoesTable">
            <thead>
                <tr>
                    <th style="min-width: 130px;">Funcionário</th>
                    <th style="min-width: 150px;">Funções</th>
                    <th style="width: 100px;">Cargo</th>
                    <th style="min-width: 100px;">Despacho</th>
                    <th style="width: 90px;">Início</th>
                    <th style="width: 90px;">Status</th>
                    <th style="width: 90px; text-align: center;">Ações</th>
                </tr>
            </thead>
            <tbody>
                <c:forEach items="${nomeacoes}" var="n">
                    <tr>
                        <td>
                            <c:choose>
                                <c:when test="${not empty n.funcionario}">
                                    <div style="display: flex; align-items: center; gap: 10px;">
                                        <div class="avatar-mini">
                                            ${n.funcionario.nome.charAt(0)}${n.funcionario.nome.split(' ')[1].charAt(0)}
                                        </div>
                                        <div>
                                            <div class="funcionario-nome">${n.funcionario.nome}</div>
                                            <div class="funcionario-id">ID: #${n.funcionario.id}</div>
                                        </div>
                                    </div>
                                </c:when>
                                <c:otherwise>
                                    <span style="color: var(--gray);">-</span>
                                </c:otherwise>
                            </c:choose>
                        </td>
                        <td>
                            <div class="funcoes-cell">
                                <c:choose>
                                    <c:when test="${n.funcoes != null && not empty n.funcoes}">
                                        <c:forTokens items="${n.funcoes}" delims="," var="fn">
                                            <span class="badge-funcao ${fn.toLowerCase().trim()}">${fn.trim()}</span>
                                        </c:forTokens>
                                    </c:when>
                                    <c:otherwise>
                                        <span style="color: var(--gray); font-size: 12px;">-</span>
                                    </c:otherwise>
                                </c:choose>
                            </div>
                        </td>
                        <td>
                            <span class="badge-cargo">
                                <i class="fas fa-tag me-1" style="font-size: 9px;"></i>
                                ${n.cargo != null ? n.cargo : '-'}
                            </span>
                        </td>
                        <td>
                            <span class="despacho-texto" title="${n.despacho}">
                                <i class="fas fa-file-alt me-1" style="font-size: 10px; color: var(--gray);"></i>
                                ${n.despacho}
                            </span>
                        </td>
                        <td>
                            <div style="font-weight: 500; font-size: 12px;">
                                <fmt:formatDate value="${n.dataInicio}" pattern="dd/MM/yyyy" />
                            </div>
                        </td>
                        <td>
                            <span class="status-badge 
                                ${n.status == 'ATIVA' ? 'ativo' : 
                                  n.status == 'ENCERRADA' ? 'encerrada' : 
                                  n.status == 'INATIVA' ? 'inativo' : 'pendente'}">
                                <i class="fas 
                                    ${n.status == 'ATIVA' ? 'fa-check-circle' : 
                                      n.status == 'ENCERRADA' ? 'fa-stop-circle' : 
                                      n.status == 'INATIVA' ? 'fa-times-circle' : 'fa-clock'} 
                                    me-1"></i>
                                ${n.status}
                            </span>
                        </td>
                        <td style="text-align: center;">
                            <div class="action-btns" style="justify-content: center;">
                                <a href="${pageContext.request.contextPath}/nomeacao/editar/${n.id}" 
                                   class="btn-icon edit" title="Editar">
                                    <i class="fas fa-edit"></i>
                                    <span class="tooltip">Editar</span>
                                </a>
                                <c:if test="${n.status == 'ATIVA'}">
                                    <button class="btn-icon warning" onclick="encerrarNomeacao(${n.id})" 
                                            title="Encerrar">
                                        <i class="fas fa-stop-circle"></i>
                                        <span class="tooltip">Encerrar</span>
                                    </button>
                                </c:if>
                                <c:if test="${n.status != 'ATIVA'}">
                                    <button class="btn-icon view" onclick="verDetalhes(${n.id})" 
                                            title="Ver detalhes">
                                        <i class="fas fa-eye"></i>
                                        <span class="tooltip">Ver detalhes</span>
                                    </button>
                                </c:if>
                            </div>
                        </td>
                    </tr>
                </c:forEach>
                <c:if test="${empty nomeacoes}">
                    <tr>
                        <td colspan="7" style="text-align: center; padding: 50px 20px; color: var(--gray);">
                            <i class="fas fa-briefcase fa-3x d-block mb-3" style="opacity: 0.3;"></i>
                            <h5 style="font-weight: 600; color: var(--dark);">Nenhuma nomeação cadastrada</h5>
                            <p style="font-size: 14px; color: var(--gray);">Clique em "Nova Nomeação" para começar</p>
                            <a href="${pageContext.request.contextPath}/nomeacao/novo" class="btn-primary-custom" style="margin-top: 10px;">
                                <i class="fas fa-plus"></i> Cadastrar Nomeação
                            </a>
                        </td>
                    </tr>
                </c:if>
            </tbody>
        </table>
    </div>
</div>

<script>
// ============================================================
// ENCERRAR NOMEAÇÃO
// ============================================================
function encerrarNomeacao(id) {
    if (confirm('⚠️ Deseja encerrar esta nomeação?')) {
        fetch('${pageContext.request.contextPath}/nomeacao/encerrar', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: 'id=' + id
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                showNotification('success', '✅ Encerrada', data.message);
                setTimeout(() => location.reload(), 1200);
            } else {
                showNotification('error', '❌ Erro', data.message);
            }
        })
        .catch(error => {
            showNotification('error', '❌ Erro', 'Falha na comunicação com o servidor');
        });
    }
}

// ============================================================
// VER DETALHES
// ============================================================
function verDetalhes(id) {
    window.location.href = '${pageContext.request.contextPath}/nomeacao/detalhes/' + id;
}

// ============================================================
// NOTIFICATIONS
// ============================================================
function showNotification(type, title, message) {
    if (typeof window.showNotification === 'function') {
        window.showNotification(type, title, message);
    } else {
        alert(title + '\n\n' + message);
    }
}

// ============================================================
// FILTRO DE PESQUISA
// ============================================================
document.addEventListener('DOMContentLoaded', function() {
    var searchInput = document.getElementById('globalSearch');
    if (searchInput) {
        searchInput.addEventListener('keyup', function() {
            var filter = this.value.toLowerCase();
            var rows = document.querySelectorAll('#nomeacoesTable tbody tr');
            
            rows.forEach(function(row) {
                var text = row.textContent.toLowerCase();
                row.style.display = text.includes(filter) ? '' : 'none';
            });
        });
    }
});
</script>

<jsp:include page="/WEB-INF/views/layout/footer.jsp" />
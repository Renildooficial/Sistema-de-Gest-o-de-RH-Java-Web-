<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core"%>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt"%>

<jsp:include page="/WEB-INF/views/layout/header.jsp">
    <jsp:param name="pageTitle" value="Detalhes da Folha" />
    <jsp:param name="activeMenu" value="folha-pagamento" />
</jsp:include>

<style>
    .detail-container {
        max-width: 900px;
        margin: 0 auto;
        padding: 20px;
    }
    
    .detail-card {
        background: #fff;
        border-radius: var(--border-radius);
        border: 1px solid var(--gray-border);
        box-shadow: var(--shadow-sm);
        overflow: hidden;
    }
    
    .detail-header {
        padding: 20px 24px;
        background: var(--gray-light);
        border-bottom: 1px solid var(--gray-border);
        display: flex;
        justify-content: space-between;
        align-items: center;
        flex-wrap: wrap;
        gap: 12px;
    }
    
    .detail-header h4 {
        font-size: 18px;
        font-weight: 700;
        color: var(--dark);
        margin: 0;
        display: flex;
        align-items: center;
        gap: 10px;
    }
    
    .detail-header h4 i {
        color: var(--primary);
    }
    
    .badge-status {
        padding: 4px 14px;
        border-radius: 20px;
        font-size: 12px;
        font-weight: 600;
        display: inline-block;
        text-transform: uppercase;
        letter-spacing: 0.3px;
    }
    
    .badge-status.PROCESSADO {
        background: rgba(59, 130, 246, 0.12);
        color: var(--info);
        border: 1px solid rgba(59, 130, 246, 0.2);
    }
    .badge-status.PAGO {
        background: rgba(16, 185, 129, 0.12);
        color: var(--success);
        border: 1px solid rgba(16, 185, 129, 0.2);
    }
    .badge-status.CANCELADO {
        background: rgba(239, 68, 68, 0.12);
        color: var(--danger);
        border: 1px solid rgba(239, 68, 68, 0.2);
    }
    .badge-status.PENDENTE {
        background: rgba(245, 158, 11, 0.12);
        color: #d97706;
        border: 1px solid rgba(245, 158, 11, 0.2);
    }
    
    .detail-body {
        padding: 24px;
    }
    
    .detail-grid {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 20px;
    }
    
    .detail-item {
        display: flex;
        flex-direction: column;
        gap: 4px;
    }
    
    .detail-item.full {
        grid-column: 1 / -1;
    }
    
    .detail-item .label {
        font-size: 11px;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        color: var(--gray);
    }
    
    .detail-item .value {
        font-size: 16px;
        font-weight: 600;
        color: var(--dark);
        padding: 8px 12px;
        background: var(--gray-light);
        border-radius: 8px;
    }
    
    .detail-item .value.primary {
        background: rgba(79, 70, 229, 0.08);
        color: var(--primary);
    }
    
    .detail-item .value.success {
        background: rgba(16, 185, 129, 0.08);
        color: var(--success);
    }
    
    .detail-item .value.warning {
        background: rgba(245, 158, 11, 0.08);
        color: #d97706;
    }
    
    .detail-item .value.danger {
        background: rgba(239, 68, 68, 0.08);
        color: var(--danger);
    }
    
    .detail-item .value .valor {
        font-family: 'Courier New', monospace;
        font-size: 18px;
    }
    
    .funcionario-info {
        display: flex;
        align-items: center;
        gap: 16px;
        padding: 12px 16px;
        background: var(--gray-light);
        border-radius: 12px;
        margin-bottom: 16px;
    }
    
    .funcionario-info .avatar-large {
        width: 56px;
        height: 56px;
        border-radius: 50%;
        background: linear-gradient(135deg, var(--primary), #7c3aed);
        display: flex;
        align-items: center;
        justify-content: center;
        color: #fff;
        font-weight: 700;
        font-size: 22px;
        flex-shrink: 0;
    }
    
    .funcionario-info .nome {
        font-size: 18px;
        font-weight: 700;
        color: var(--dark);
    }
    
    .funcionario-info .id {
        font-size: 13px;
        color: var(--gray);
    }
    
    .section-title {
        font-size: 14px;
        font-weight: 600;
        color: var(--dark);
        margin: 20px 0 12px 0;
        padding-bottom: 8px;
        border-bottom: 2px solid var(--gray-border);
        display: flex;
        align-items: center;
        gap: 8px;
    }
    
    .section-title i {
        color: var(--primary);
    }
    
    .detail-footer {
        padding: 16px 24px;
        border-top: 1px solid var(--gray-border);
        display: flex;
        gap: 12px;
        flex-wrap: wrap;
    }
    
    .btn-primary-custom {
        background: var(--primary);
        color: #fff;
        padding: 10px 24px;
        border: none;
        border-radius: 8px;
        font-size: 14px;
        font-weight: 600;
        display: inline-flex;
        align-items: center;
        gap: 8px;
        text-decoration: none;
        cursor: pointer;
        transition: all 0.2s ease;
    }
    
    .btn-primary-custom:hover {
        background: var(--primary-hover);
        color: #fff;
        transform: translateY(-2px);
        box-shadow: 0 4px 12px rgba(79, 70, 229, 0.3);
    }
    
    .btn-success-custom {
        background: var(--success);
        color: #fff;
        padding: 10px 24px;
        border: none;
        border-radius: 8px;
        font-size: 14px;
        font-weight: 600;
        display: inline-flex;
        align-items: center;
        gap: 8px;
        text-decoration: none;
        cursor: pointer;
        transition: all 0.2s ease;
    }
    
    .btn-success-custom:hover {
        background: #16a34a;
        color: #fff;
        transform: translateY(-2px);
        box-shadow: 0 4px 12px rgba(16, 185, 129, 0.3);
    }
    
    .btn-outline-custom {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        padding: 10px 20px;
        border: 1.5px solid var(--gray-border);
        border-radius: 8px;
        background: transparent;
        color: var(--gray);
        font-size: 14px;
        font-weight: 600;
        text-decoration: none;
        transition: all 0.2s ease;
        cursor: pointer;
    }
    
    .btn-outline-custom:hover {
        background: var(--gray-light);
        color: var(--dark);
        border-color: #cbd5e1;
    }
    
    .btn-danger-custom {
        background: var(--danger);
        color: #fff;
        padding: 10px 24px;
        border: none;
        border-radius: 8px;
        font-size: 14px;
        font-weight: 600;
        display: inline-flex;
        align-items: center;
        gap: 8px;
        text-decoration: none;
        cursor: pointer;
        transition: all 0.2s ease;
    }
    
    .btn-danger-custom:hover {
        background: #dc2626;
        color: #fff;
        transform: translateY(-2px);
        box-shadow: 0 4px 12px rgba(239, 68, 68, 0.3);
    }
    
    .btn-warning-custom {
        background: #d97706;
        color: #fff;
        padding: 10px 24px;
        border: none;
        border-radius: 8px;
        font-size: 14px;
        font-weight: 600;
        display: inline-flex;
        align-items: center;
        gap: 8px;
        text-decoration: none;
        cursor: pointer;
        transition: all 0.2s ease;
    }
    
    .btn-warning-custom:hover {
        background: #b45309;
        color: #fff;
        transform: translateY(-2px);
        box-shadow: 0 4px 12px rgba(217, 119, 6, 0.3);
    }
    
    .grid-3 {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 16px;
        margin-top: 8px;
    }
    
    .info-box {
        padding: 12px 16px;
        border-radius: 8px;
        border: 1px solid var(--gray-border);
        text-align: center;
    }
    
    .info-box .label {
        font-size: 10px;
        text-transform: uppercase;
        color: var(--gray);
        font-weight: 600;
        letter-spacing: 0.5px;
    }
    
    .info-box .value {
        font-size: 18px;
        font-weight: 700;
        margin-top: 4px;
        font-family: 'Courier New', monospace;
    }
    
    .info-box .value.bruto { color: var(--primary); }
    .info-box .value.descontos { color: var(--danger); }
    .info-box .value.liquido { color: var(--success); }
    
    .loading-overlay {
        display: none;
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: rgba(0,0,0,0.5);
        z-index: 9999;
        justify-content: center;
        align-items: center;
    }
    
    .loading-overlay.active {
        display: flex;
    }
    
    .spinner {
        width: 50px;
        height: 50px;
        border: 5px solid #fff;
        border-top-color: var(--primary);
        border-radius: 50%;
        animation: spin 0.8s linear infinite;
    }
    
    @keyframes spin {
        to { transform: rotate(360deg); }
    }
    
    @media (max-width: 768px) {
        .detail-container { padding: 12px; }
        .detail-grid { grid-template-columns: 1fr; gap: 12px; }
        .grid-3 { grid-template-columns: 1fr; }
        .detail-header { flex-direction: column; align-items: stretch; text-align: center; }
        .detail-header h4 { font-size: 16px; justify-content: center; }
        .detail-body { padding: 16px; }
        .detail-footer { flex-direction: column; }
        .detail-footer .btn { width: 100%; justify-content: center; }
        .funcionario-info { flex-direction: column; text-align: center; }
        .funcionario-info .avatar-large { width: 48px; height: 48px; font-size: 18px; }
        .funcionario-info .nome { font-size: 16px; }
        .detail-item .value { font-size: 14px; }
        .info-box .value { font-size: 16px; }
    }
    
    @media (max-width: 480px) {
        .detail-container { padding: 8px; }
        .detail-header h4 { font-size: 14px; }
        .detail-item .value { font-size: 13px; padding: 6px 10px; }
        .info-box .value { font-size: 14px; }
        .btn-primary-custom, .btn-success-custom, .btn-outline-custom, .btn-danger-custom, .btn-warning-custom {
            font-size: 12px; padding: 8px 16px;
        }
    }

    @keyframes fadeInUp {
        from { opacity: 0; transform: translateY(20px); }
        to { opacity: 1; transform: translateY(0); }
    }
    
    .animate-in {
        opacity: 0;
        animation: fadeInUp 0.5s ease forwards;
    }
</style>

<!-- Loading Overlay -->
<div class="loading-overlay" id="loadingOverlay">
    <div class="spinner"></div>
</div>

<div class="detail-container animate-in">
    <div class="detail-card">
        <!-- Header -->
        <div class="detail-header">
            <h4>
                <i class="fas fa-file-invoice-dollar"></i>
                Detalhes da Folha
                <span style="font-size: 14px; font-weight: 400; color: var(--gray);">#${folha.id}</span>
            </h4>
            <div>
                <span class="badge-status ${folha.status}">
                    <i class="fas 
                        ${folha.status == 'PROCESSADO' ? 'fa-sync fa-spin' : 
                          folha.status == 'PAGO' ? 'fa-check-circle' : 
                          folha.status == 'CANCELADO' ? 'fa-times-circle' : 'fa-clock'} 
                        me-1"></i>
                    ${folha.status}
                </span>
            </div>
        </div>

        <!-- Body -->
        <div class="detail-body">
            <!-- Funcionário -->
            <div class="funcionario-info">
                <div class="avatar-large">
                    ${folha.funcionario != null ? folha.funcionario.nome.charAt(0) : '?'}
                </div>
                <div>
                    <div class="nome">${folha.funcionario != null ? folha.funcionario.nome : 'Funcionário não encontrado'}</div>
                    <div class="id">ID: #${folha.idFuncionario}</div>
                </div>
            </div>

            <!-- Resumo em cards -->
            <div class="grid-3">
                <div class="info-box">
                    <div class="label">Total Bruto</div>
                    <div class="value bruto">
                        MZN <fmt:formatNumber value="${folha.totalBruto != null ? folha.totalBruto : 0}" pattern="#,##0.00"/>
                    </div>
                </div>
                <div class="info-box">
                    <div class="label">Total Descontos</div>
                    <div class="value descontos">
                        - MZN <fmt:formatNumber value="${folha.totalDescontos != null ? folha.totalDescontos : 0}" pattern="#,##0.00"/>
                    </div>
                </div>
                <div class="info-box" style="border-color: var(--success); border-width: 2px;">
                    <div class="label">Total Líquido</div>
                    <div class="value liquido">
                        MZN <fmt:formatNumber value="${folha.totalLiquido != null ? folha.totalLiquido : 0}" pattern="#,##0.00"/>
                    </div>
                </div>
            </div>

            <!-- Detalhes -->
            <div class="section-title">
                <i class="fas fa-list"></i> Detalhamento da Folha
            </div>
            
            <div class="detail-grid">
                <div class="detail-item">
                    <span class="label"><i class="fas fa-calendar me-1"></i> Mês/Ano Referência</span>
                    <span class="value primary">
                        <c:choose>
                            <c:when test="${folha.mesReferencia == 1}">Janeiro</c:when>
                            <c:when test="${folha.mesReferencia == 2}">Fevereiro</c:when>
                            <c:when test="${folha.mesReferencia == 3}">Março</c:when>
                            <c:when test="${folha.mesReferencia == 4}">Abril</c:when>
                            <c:when test="${folha.mesReferencia == 5}">Maio</c:when>
                            <c:when test="${folha.mesReferencia == 6}">Junho</c:when>
                            <c:when test="${folha.mesReferencia == 7}">Julho</c:when>
                            <c:when test="${folha.mesReferencia == 8}">Agosto</c:when>
                            <c:when test="${folha.mesReferencia == 9}">Setembro</c:when>
                            <c:when test="${folha.mesReferencia == 10}">Outubro</c:when>
                            <c:when test="${folha.mesReferencia == 11}">Novembro</c:when>
                            <c:when test="${folha.mesReferencia == 12}">Dezembro</c:when>
                        </c:choose>
                        / ${folha.anoReferencia}
                    </span>
                </div>
                
                <div class="detail-item">
                    <span class="label"><i class="fas fa-money-bill-wave me-1"></i> Salário Base</span>
                    <span class="value primary">
                        MZN <fmt:formatNumber value="${folha.salarioBase != null ? folha.salarioBase : 0}" pattern="#,##0.00"/>
                    </span>
                </div>
                
                <div class="detail-item">
                    <span class="label"><i class="fas fa-utensils me-1"></i> Subsídio Alimentação</span>
                    <span class="value">
                        MZN <fmt:formatNumber value="${folha.subsidioAlimentacao != null ? folha.subsidioAlimentacao : 0}" pattern="#,##0.00"/>
                    </span>
                </div>
                
                <div class="detail-item">
                    <span class="label"><i class="fas fa-bus me-1"></i> Subsídio Transporte</span>
                    <span class="value">
                        MZN <fmt:formatNumber value="${folha.subsidioTransporte != null ? folha.subsidioTransporte : 0}" pattern="#,##0.00"/>
                    </span>
                </div>
                
                <div class="detail-item">
                    <span class="label"><i class="fas fa-heartbeat me-1"></i> Subsídio Saúde</span>
                    <span class="value">
                        MZN <fmt:formatNumber value="${folha.subsidioSaude != null ? folha.subsidioSaude : 0}" pattern="#,##0.00"/>
                    </span>
                </div>
                
                <div class="detail-item">
                    <span class="label"><i class="fas fa-percent me-1"></i> IRS</span>
                    <span class="value danger">
                        - MZN <fmt:formatNumber value="${folha.descontoIrs != null ? folha.descontoIrs : 0}" pattern="#,##0.00"/>
                    </span>
                </div>
                
                <div class="detail-item">
                    <span class="label"><i class="fas fa-shield-alt me-1"></i> INSS</span>
                    <span class="value danger">
                        - MZN <fmt:formatNumber value="${folha.descontoInss != null ? folha.descontoInss : 0}" pattern="#,##0.00"/>
                    </span>
                </div>
                
                <c:if test="${not empty folha.observacao}">
                    <div class="detail-item full">
                        <span class="label"><i class="fas fa-comment me-1"></i> Observação</span>
                        <span class="value">${folha.observacao}</span>
                    </div>
                </c:if>
                
                <div class="detail-item">
                    <span class="label"><i class="fas fa-clock me-1"></i> Data Processamento</span>
                    <span class="value">
                        <fmt:formatDate value="${folha.dataProcessamento}" pattern="dd/MM/yyyy HH:mm" />
                    </span>
                </div>
                
                <div class="detail-item">
                    <span class="label"><i class="fas fa-info-circle me-1"></i> Status</span>
                    <span class="value">
                        <span class="badge-status ${folha.status}">
                            ${folha.status}
                        </span>
                    </span>
                </div>
            </div>
        </div>

        <!-- Footer -->
        <div class="detail-footer">
            <a href="${pageContext.request.contextPath}/financeiro/folha-pagamento" class="btn-outline-custom">
                <i class="fas fa-arrow-left"></i> Voltar
            </a>
            
            <c:if test="${folha.status == 'PROCESSADO'}">
                <button class="btn-success-custom" onclick="pagarFolha(${folha.id})">
                    <i class="fas fa-money-bill-wave"></i> Marcar como PAGO
                </button>
            </c:if>
            
            <c:if test="${folha.status == 'PAGO'}">
                <span style="display: inline-flex; align-items: center; gap: 8px; color: var(--success); font-weight: 600; padding: 10px 20px; background: rgba(16, 185, 129, 0.1); border-radius: 8px;">
                    <i class="fas fa-check-circle"></i> Pagamento Confirmado
                </span>
            </c:if>
            
            <c:if test="${folha.status == 'PROCESSADO' || folha.status == 'PAGO'}">
                <button class="btn-danger-custom" onclick="cancelarFolha(${folha.id})">
                    <i class="fas fa-times"></i> Cancelar
                </button>
            </c:if>
            
            <button class="btn-primary-custom" onclick="window.print()">
                <i class="fas fa-print"></i> Imprimir
            </button>
        </div>
    </div>
</div>

<script>
function showLoading() {
    document.getElementById('loadingOverlay').classList.add('active');
}

function hideLoading() {
    document.getElementById('loadingOverlay').classList.remove('active');
}

function showNotification(type, title, message) {
    // Usar a função global se existir
    if (typeof window.showNotification === 'function') {
        window.showNotification(type, title, message);
    } else {
        // Fallback
        var icon = type === 'success' ? '✅' : type === 'error' ? '❌' : type === 'warning' ? '⚠️' : 'ℹ️';
        alert(icon + ' ' + title + '\n\n' + message);
    }
}

function pagarFolha(id) {
    if (confirm('✅ Confirmar pagamento desta folha?\n\n' +
        'ID: #' + id + '\n' +
        'Total Líquido: MZN ' + 
        new Intl.NumberFormat('pt-MZ', {minimumFractionDigits: 2, maximumFractionDigits: 2})
            .format(${folha.totalLiquido != null ? folha.totalLiquido : 0}))) {
        
        showLoading();
        
        fetch('${pageContext.request.contextPath}/financeiro/folha-pagar', {
            method: 'POST',
            headers: { 
                'Content-Type': 'application/x-www-form-urlencoded',
                'Accept': 'application/json'
            },
            body: 'id=' + id
        })
        .then(function(response) {
            return response.json();
        })
        .then(function(data) {
            hideLoading();
            if (data.success) {
                showNotification('success', '✅ Pago', data.message || 'Folha marcada como PAGA com sucesso!');
                setTimeout(function() { 
                    window.location.reload(); 
                }, 1500);
            } else {
                showNotification('error', '❌ Erro', data.message || 'Erro ao processar pagamento');
            }
        })
        .catch(function(error) {
            hideLoading();
            console.error('Erro:', error);
            showNotification('error', '❌ Erro', 'Falha na comunicação com o servidor: ' + error.message);
        });
    }
}

function cancelarFolha(id) {
    if (confirm('⚠️ Deseja realmente CANCELAR esta folha?\n\n' +
        'ID: #' + id + '\n' +
        'Esta ação não pode ser desfeita!')) {
        
        showLoading();
        
        fetch('${pageContext.request.contextPath}/financeiro/folha-cancelar', {
            method: 'POST',
            headers: { 
                'Content-Type': 'application/x-www-form-urlencoded',
                'Accept': 'application/json'
            },
            body: 'id=' + id
        })
        .then(function(response) {
            return response.json();
        })
        .then(function(data) {
            hideLoading();
            if (data.success) {
                showNotification('warning', '⚠️ Cancelado', data.message || 'Folha cancelada com sucesso!');
                setTimeout(function() { 
                    window.location.reload(); 
                }, 1500);
            } else {
                showNotification('error', '❌ Erro', data.message || 'Erro ao cancelar folha');
            }
        })
        .catch(function(error) {
            hideLoading();
            console.error('Erro:', error);
            showNotification('error', '❌ Erro', 'Falha na comunicação com o servidor: ' + error.message);
        });
    }
}
</script>

<jsp:include page="/WEB-INF/views/layout/footer.jsp" />
<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" isELIgnored="false"%>
<%@ page import="com.sigrh.util.ConfiguracaoUtil" %>
<%@ taglib prefix="c" uri="jakarta.tags.core"%>
<%
    String empresaNome = "SIGRH";
    String empresaLogo = null;
    try {
        empresaNome = ConfiguracaoUtil.getEmpresaNome();
        if (empresaNome == null || empresaNome.trim().isEmpty()) {
            empresaNome = "SIGRH";
        }
        empresaLogo = ConfiguracaoUtil.getEmpresaLogo();
        if (empresaLogo != null && empresaLogo.trim().isEmpty()) {
            empresaLogo = null;
        }
    } catch (Exception e) {
        empresaNome = "SIGRH";
        empresaLogo = null;
    }
    request.setAttribute("empresaNome", empresaNome);
    request.setAttribute("empresaLogo", empresaLogo);
%>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${empresaNome} - Sistema Integrado de Gestão de Recursos Humanos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">

    <style>
        :root {
            --primary: #4F46E5;
            --primary-dark: #4338CA;
            --primary-light: #818CF8;
            --secondary: #7C3AED;
            --success: #10B981;
            --warning: #F59E0B;
            --danger: #EF4444;
            --dark: #0F172A;
            --gray: #64748B;
            --gray-light: #F1F5F9;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
            background: var(--dark);
            color: #fff;
            overflow-x: hidden;
            min-height: 100vh;
        }

        /* Animated Background */
        .bg-animated {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            z-index: 0;
            background: linear-gradient(135deg, #0F172A 0%, #1E293B 50%, #0F172A 100%);
            overflow: hidden;
        }

        .bg-animated .orb {
            position: absolute;
            border-radius: 50%;
            filter: blur(80px);
            opacity: 0.3;
            animation: floatOrb 20s ease-in-out infinite;
        }

        .bg-animated .orb:nth-child(1) {
            width: 600px;
            height: 600px;
            background: var(--primary);
            top: -200px;
            right: -200px;
            animation-delay: 0s;
        }

        .bg-animated .orb:nth-child(2) {
            width: 400px;
            height: 400px;
            background: var(--secondary);
            bottom: -100px;
            left: -100px;
            animation-delay: -7s;
        }

        .bg-animated .orb:nth-child(3) {
            width: 300px;
            height: 300px;
            background: #06B6D4;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            animation-delay: -14s;
        }

        @keyframes floatOrb {
            0%, 100% { transform: translate(0, 0) scale(1); }
            33% { transform: translate(30px, -30px) scale(1.1); }
            66% { transform: translate(-20px, 20px) scale(0.9); }
        }

        /* Main Container */
        .main-container {
            position: relative;
            z-index: 1;
            min-height: 100vh;
            display: flex;
            align-items: center;
            padding: 40px 20px;
        }

        /* Content */
        .content-wrapper {
            max-width: 1200px;
            margin: 0 auto;
            width: 100%;
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 60px;
            align-items: center;
        }

        /* Left Side - Branding */
        .brand-section {
            animation: fadeInLeft 0.8s ease;
        }

        @keyframes fadeInLeft {
            from { opacity: 0; transform: translateX(-40px); }
            to { opacity: 1; transform: translateX(0); }
        }

        .brand-section .logo {
            display: flex;
            align-items: center;
            gap: 16px;
            margin-bottom: 32px;
        }

        .brand-section .logo .brand-icon {
            width: 56px;
            height: 56px;
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            border-radius: 16px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 28px;
            font-weight: 800;
            color: #fff;
            box-shadow: 0 8px 32px rgba(79, 70, 229, 0.3);
        }

        .brand-section .logo .brand-logo-img {
            width: 56px;
            height: 56px;
            border-radius: 16px;
            object-fit: cover;
            box-shadow: 0 8px 32px rgba(79, 70, 229, 0.3);
            flex-shrink: 0;
        }

        .brand-section .logo .brand-text h1 {
            font-size: 28px;
            font-weight: 800;
            color: #fff;
            letter-spacing: -0.5px;
            margin: 0;
        }

        .brand-section .logo .brand-text span {
            font-size: 12px;
            font-weight: 500;
            color: var(--gray);
            letter-spacing: 1px;
            text-transform: uppercase;
        }

        .brand-section .hero-title {
            font-size: 42px;
            font-weight: 900;
            line-height: 1.1;
            margin-bottom: 20px;
            background: linear-gradient(135deg, #fff 30%, var(--primary-light) 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        .brand-section .hero-subtitle {
            font-size: 18px;
            color: #94A3B8;
            line-height: 1.6;
            margin-bottom: 32px;
            max-width: 480px;
        }

        /* Features Grid */
        .features-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 16px;
        }

        .feature-card {
            background: rgba(255, 255, 255, 0.04);
            border: 1px solid rgba(255, 255, 255, 0.06);
            border-radius: 16px;
            padding: 20px;
            transition: all 0.3s ease;
            cursor: default;
        }

        .feature-card:hover {
            background: rgba(255, 255, 255, 0.08);
            border-color: rgba(79, 70, 229, 0.3);
            transform: translateY(-4px);
        }

        .feature-card .feature-icon {
            width: 40px;
            height: 40px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 18px;
            margin-bottom: 12px;
        }

        .feature-card .feature-icon.purple { background: rgba(79, 70, 229, 0.15); color: var(--primary-light); }
        .feature-card .feature-icon.green { background: rgba(16, 185, 129, 0.15); color: var(--success); }
        .feature-card .feature-icon.blue { background: rgba(59, 130, 246, 0.15); color: #60A5FA; }
        .feature-card .feature-icon.orange { background: rgba(245, 158, 11, 0.15); color: var(--warning); }

        .feature-card .feature-title {
            font-size: 14px;
            font-weight: 600;
            color: #fff;
            margin-bottom: 4px;
        }

        .feature-card .feature-desc {
            font-size: 12px;
            color: #94A3B8;
        }

        /* Right Side - Login Card */
        .login-section {
            animation: fadeInRight 0.8s ease;
        }

        @keyframes fadeInRight {
            from { opacity: 0; transform: translateX(40px); }
            to { opacity: 1; transform: translateX(0); }
        }

        .login-card {
            background: rgba(255, 255, 255, 0.05);
            backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);
            border: 1px solid rgba(255, 255, 255, 0.08);
            border-radius: 24px;
            padding: 40px;
            max-width: 440px;
            margin: 0 auto;
            box-shadow: 0 24px 80px rgba(0, 0, 0, 0.4);
        }

        .login-card .login-header {
            text-align: center;
            margin-bottom: 32px;
        }

        .login-card .login-header h2 {
            font-size: 24px;
            font-weight: 700;
            color: #fff;
            margin-bottom: 8px;
        }

        .login-card .login-header p {
            font-size: 14px;
            color: #94A3B8;
        }

        .login-card .form-group {
            margin-bottom: 20px;
        }

        .login-card .form-group label {
            font-size: 13px;
            font-weight: 600;
            color: #E2E8F0;
            margin-bottom: 6px;
            display: block;
        }

        .login-card .form-group .input-group {
            position: relative;
        }

        .login-card .form-group .input-group i {
            position: absolute;
            left: 14px;
            top: 50%;
            transform: translateY(-50%);
            color: #64748B;
            font-size: 16px;
            transition: all 0.3s ease;
            z-index: 2;
        }

        .login-card .form-group .input-group .toggle-password {
            position: absolute;
            right: 34px;
            top: 50%;
            transform: translateY(-50%);
            color: #64748B;
            font-size: 16px;
            cursor: pointer;
            transition: all 0.3s ease;
            z-index: 2;
            background: transparent;
            border: none;
            padding: 4px;
        }

        .login-card .form-group .input-group .toggle-password:hover {
            color: #fff;
        }

        .login-card .form-group .form-control {
            width: 100%;
            padding: 12px 44px 12px 44px;
            background: rgba(255, 255, 255, 0.06);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 12px;
            color: #fff;
            font-size: 14px;
            font-family: 'Inter', sans-serif;
            transition: all 0.3s ease;
        }

        .login-card .form-group .form-control::placeholder {
            color: #64748B;
        }

        .login-card .form-group .form-control:focus {
            outline: none;
            border-color: var(--primary);
            background: rgba(255, 255, 255, 0.08);
            box-shadow: 0 0 0 3px rgba(79, 70, 229, 0.15);
        }

        .login-card .form-group .form-control:focus ~ i,
        .login-card .form-group .form-control:focus + i {
            color: var(--primary-light);
        }

        .login-card .form-options {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 24px;
        }

        .login-card .form-options .remember-me {
            display: flex;
            align-items: center;
            gap: 8px;
            color: #94A3B8;
            font-size: 13px;
            cursor: pointer;
        }

        .login-card .form-options .remember-me input[type="checkbox"] {
            width: 16px;
            height: 16px;
            accent-color: var(--primary);
            cursor: pointer;
        }

        .login-card .form-options .forgot-link {
            color: var(--primary-light);
            font-size: 13px;
            text-decoration: none;
            transition: all 0.3s ease;
            cursor: pointer;
            background: transparent;
            border: none;
            font-family: 'Inter', sans-serif;
        }

        .login-card .form-options .forgot-link:hover {
            color: #fff;
        }

        .login-card .btn-login {
            width: 100%;
            padding: 14px;
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            border: none;
            border-radius: 12px;
            color: #fff;
            font-weight: 700;
            font-size: 16px;
            font-family: 'Inter', sans-serif;
            transition: all 0.3s ease;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
        }

        .login-card .btn-login:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 32px rgba(79, 70, 229, 0.4);
        }

        .login-card .btn-login:active {
            transform: scale(0.98);
        }

        .login-card .btn-login:disabled {
            opacity: 0.7;
            cursor: not-allowed;
            transform: none;
        }

        .login-card .btn-login i {
            font-size: 18px;
        }

        .login-card .login-footer {
            text-align: center;
            margin-top: 24px;
            font-size: 13px;
            color: #64748B;
        }

        .login-card .login-footer a {
            color: var(--primary-light);
            text-decoration: none;
            font-weight: 600;
        }

        .login-card .login-footer a:hover {
            color: #fff;
        }

        /* Alerts */
        .alert-custom {
            border-radius: 12px;
            padding: 12px 16px;
            margin-bottom: 16px;
            font-size: 14px;
            display: flex;
            align-items: center;
            gap: 10px;
            animation: slideDown 0.4s ease;
        }

        @keyframes slideDown {
            from { opacity: 0; transform: translateY(-20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .alert-custom.alert-danger {
            background: rgba(239, 68, 68, 0.15);
            color: #FCA5A5;
            border: 1px solid rgba(239, 68, 68, 0.2);
        }

        .alert-custom.alert-success {
            background: rgba(16, 185, 129, 0.15);
            color: #6EE7B7;
            border: 1px solid rgba(16, 185, 129, 0.2);
        }

        .alert-custom.alert-info {
            background: rgba(59, 130, 246, 0.15);
            color: #93C5FD;
            border: 1px solid rgba(59, 130, 246, 0.2);
        }

        .alert-custom i {
            font-size: 18px;
        }

        /* Modal Styles */
        .modal-content {
            background: rgba(30, 41, 59, 0.95);
            backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);
            border: 1px solid rgba(255, 255, 255, 0.08);
            border-radius: 24px;
            color: #fff;
        }

        .modal-header {
            border-bottom: 1px solid rgba(255, 255, 255, 0.06);
            padding: 20px 28px;
        }

        .modal-header .btn-close {
            filter: invert(1);
        }

        .modal-body {
            padding: 28px;
        }

        .modal-footer {
            border-top: 1px solid rgba(255, 255, 255, 0.06);
            padding: 16px 28px;
        }

        .modal-footer .btn-secondary {
            background: rgba(255, 255, 255, 0.06);
            border: 1px solid rgba(255, 255, 255, 0.1);
            color: #fff;
            border-radius: 10px;
            padding: 8px 20px;
            font-weight: 600;
            font-size: 14px;
            transition: all 0.3s ease;
        }

        .modal-footer .btn-secondary:hover {
            background: rgba(255, 255, 255, 0.1);
        }

        .modal-footer .btn-primary-custom {
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            border: none;
            color: #fff;
            padding: 8px 20px;
            border-radius: 10px;
            font-weight: 600;
            font-size: 14px;
            transition: all 0.3s ease;
        }

        .modal-footer .btn-primary-custom:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 24px rgba(79, 70, 229, 0.3);
        }

        .modal-footer .btn-primary-custom:disabled {
            opacity: 0.7;
            cursor: not-allowed;
            transform: none;
        }

        .modal .form-group {
            margin-bottom: 20px;
        }

        .modal .form-group label {
            font-size: 13px;
            font-weight: 600;
            color: #E2E8F0;
            margin-bottom: 6px;
            display: block;
        }

        .modal .form-group .input-group {
            position: relative;
        }

        .modal .form-group .input-group i {
            position: absolute;
            left: 14px;
            top: 50%;
            transform: translateY(-50%);
            color: #64748B;
            font-size: 16px;
        }

        .modal .form-group .form-control {
            width: 100%;
            padding: 12px 16px 12px 44px;
            background: rgba(255, 255, 255, 0.06);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 12px;
            color: #fff;
            font-size: 14px;
            font-family: 'Inter', sans-serif;
            transition: all 0.3s ease;
        }

        .modal .form-group .form-control::placeholder {
            color: #64748B;
        }

        .modal .form-group .form-control:focus {
            outline: none;
            border-color: var(--primary);
            background: rgba(255, 255, 255, 0.08);
            box-shadow: 0 0 0 3px rgba(79, 70, 229, 0.15);
        }

        .modal .form-group .form-control:focus ~ i {
            color: var(--primary-light);
        }

        .modal .modal-title {
            font-weight: 700;
            color: #fff;
        }

        .modal .modal-title i {
            color: var(--primary-light);
            margin-right: 10px;
        }

        /* Responsive */
        @media (max-width: 992px) {
            .content-wrapper {
                grid-template-columns: 1fr;
                gap: 40px;
            }

            .brand-section .hero-title {
                font-size: 32px;
            }

            .login-card {
                max-width: 100%;
            }
        }

        @media (max-width: 576px) {
            .brand-section .hero-title {
                font-size: 26px;
            }

            .features-grid {
                grid-template-columns: 1fr;
            }

            .login-card {
                padding: 24px;
            }

            .login-card .login-header h2 {
                font-size: 20px;
            }

            .brand-section .logo .brand-text h1 {
                font-size: 22px;
            }

            .modal-body {
                padding: 20px;
            }
        }
    </style>
</head>
<body>
    <!-- Animated Background -->
    <div class="bg-animated">
        <div class="orb"></div>
        <div class="orb"></div>
        <div class="orb"></div>
    </div>

    <!-- Main Container -->
    <div class="main-container">
        <div class="content-wrapper">
            <!-- Left Side - Branding -->
            <div class="brand-section">
                <div class="logo">
                    <c:choose>
                        <c:when test="${not empty empresaLogo}">
                            <img src="${pageContext.request.contextPath}/uploads/${empresaLogo}"
                                 alt="Logo" class="brand-logo-img">
                        </c:when>
                        <c:otherwise>
                            <div class="brand-icon">S</div>
                        </c:otherwise>
                    </c:choose>
                    <div class="brand-text">
                        <h1>${empresaNome}</h1>
                        <span>Sistema Integrado de Gestão de RH</span>
                    </div>
                </div>

                <h1 class="hero-title">
                    Gestão de Recursos Humanos<br>
                    <span style="color: #94A3B8; -webkit-text-fill-color: #94A3B8;">Moderna e Integrada</span>
                </h1>

                <p class="hero-subtitle">
                    Gerencie todos os processos de RH em um único lugar.
                    Desde o cadastro de funcionários até a gestão de férias,
                    formações e folha de pagamento.
                </p>

                <div class="features-grid">
                    <div class="feature-card">
                        <div class="feature-icon purple">
                            <i class="fas fa-users"></i>
                        </div>
                        <div class="feature-title">Funcionários</div>
                        <div class="feature-desc">Gestão completa de colaboradores</div>
                    </div>
                    <div class="feature-card">
                        <div class="feature-icon green">
                            <i class="fas fa-umbrella-beach"></i>
                        </div>
                        <div class="feature-title">Férias</div>
                        <div class="feature-desc">Planejamento e aprovação</div>
                    </div>
                    <div class="feature-card">
                        <div class="feature-icon blue">
                            <i class="fas fa-graduation-cap"></i>
                        </div>
                        <div class="feature-title">Formações</div>
                        <div class="feature-desc">Histórico e certificações</div>
                    </div>
                    <div class="feature-card">
                        <div class="feature-icon orange">
                            <i class="fas fa-coins"></i>
                        </div>
                        <div class="feature-title">Financeiro</div>
                        <div class="feature-desc">Folha e salários integrados</div>
                    </div>
                </div>
            </div>

            <!-- Right Side - Login -->
            <div class="login-section">
                <div class="login-card">
                    <div class="login-header">
                        <h2><i class="fas fa-key" style="color: var(--primary-light); margin-right: 10px;"></i>Acessar Sistema</h2>
                        <p>Entre com suas credenciais para continuar</p>
                    </div>

                    <!-- Mensagens -->
                    <c:if test="${not empty sessionScope.erro}">
                        <div class="alert-custom alert-danger">
                            <i class="fas fa-exclamation-circle"></i>
                            ${sessionScope.erro}
                        </div>
                        <c:remove var="erro" scope="session" />
                    </c:if>
                    <c:if test="${not empty sessionScope.sucesso}">
                        <div class="alert-custom alert-success">
                            <i class="fas fa-check-circle"></i>
                            ${sessionScope.sucesso}
                        </div>
                        <c:remove var="sucesso" scope="session" />
                    </c:if>
                    <c:if test="${not empty sessionScope.info}">
                        <div class="alert-custom alert-info">
                            <i class="fas fa-info-circle"></i>
                            ${sessionScope.info}
                        </div>
                        <c:remove var="info" scope="session" />
                    </c:if>

                    <form action="${pageContext.request.contextPath}/login" method="post" id="loginForm">
                        <div class="form-group">
                            <label for="usuario"><i class="fas fa-user" style="margin-right: 8px;"></i>Usuário</label>
                            <div class="input-group">
                                <i class="fas fa-user"></i>
                                <input type="text" class="form-control" id="usuario" name="usuario"
                                       placeholder="Digite seu usuário" required autofocus>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="senha"><i class="fas fa-lock" style="margin-right: 8px;"></i>Senha</label>
                            <div class="input-group">
                                <i class="fas fa-lock"></i>
                                <input type="password" class="form-control" id="senha" name="senha"
                                       placeholder="Digite sua senha" required>
                                <button type="button" class="toggle-password" id="togglePassword"
                                        onclick="togglePasswordVisibility()" title="Mostrar/Esconder senha">
                                    <i class="fas fa-eye" id="passwordIcon"></i>
                                </button>
                            </div>
                        </div>

                        <div class="form-options">
                            <label class="remember-me">
                                <input type="checkbox" checked> Lembrar-me
                            </label>
                            <a href="${pageContext.request.contextPath}/auth/recuperar-senha-codigo" class="forgot-link">
                                <i class="fas fa-key" style="font-size: 12px;"></i> Esqueci minha senha
                            </a>
                        </div>

                        <button type="submit" class="btn-login" id="btnLogin">
                            <i class="fas fa-sign-in-alt"></i>
                            <span>Entrar no Sistema</span>
                        </button>
                    </form>

                    <div class="login-footer">
                       
                        <p style="margin-top: 8px; font-size: 11px; color: #475569;">
                            <i class="fas fa-shield-alt"></i> Ambiente seguro com criptografia SSL
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- ======================================== -->
    <!-- SCRIPTS -->
    <!-- ======================================== -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

    <script>
        // ========================================
        // TOGGLE PASSWORD VISIBILITY
        // ========================================
        function togglePasswordVisibility() {
            const passwordInput = document.getElementById('senha');
            const icon = document.getElementById('passwordIcon');

            if (passwordInput.type === 'password') {
                passwordInput.type = 'text';
                icon.className = 'fas fa-eye-slash';
            } else {
                passwordInput.type = 'password';
                icon.className = 'fas fa-eye';
            }
        }

        // ========================================
        // LOADING EFFECT ON LOGIN SUBMIT
        // ========================================
        document.getElementById('loginForm').addEventListener('submit', function(e) {
            const btn = document.getElementById('btnLogin');
            btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Entrando...';
            btn.disabled = true;
        });

        // ========================================
        // AUTO-FOCUS
        // ========================================
        document.addEventListener('DOMContentLoaded', function() {
            document.getElementById('usuario').focus();
        });

        // ========================================
        // CONSOLE LOG
        // ========================================
        console.log('🚀 ${empresaNome} - Sistema Integrado de Gestão de Recursos Humanos');
        console.log('📋 Versão: 1.0.0');
        console.log('🔐 Ambiente: Desenvolvimento');
        console.log('📧 Recuperação de senha: Via código de verificação');
    </script>
</body>
</html>
<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="java.math.BigDecimal" %>
<%@ taglib prefix="c" uri="jakarta.tags.core"%>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt"%>
<%@ taglib prefix="fn" uri="jakarta.tags.functions" %>
<jsp:include page="/WEB-INF/views/layout/header.jsp">
    <jsp:param name="pageTitle" value="Folha de Pagamento" />
    <jsp:param name="activeMenu" value="folha-pagamento" />
</jsp:include>

<style>
    .action-btns .btn-icon {
        width: 34px;
        height: 34px;
        border: none;
        border-radius: 8px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        background: transparent;
        color: var(--gray);
        font-size: 14px;
        text-decoration: none;
        margin: 0 2px;
        position: relative;
    }
    
    .action-btns .btn-icon:hover {
        transform: translateY(-3px);
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
    }
    
    .action-btns .btn-icon.view {
        background: rgba(79, 70, 229, 0.1);
        color: var(--primary);
    }
    .action-btns .btn-icon.view:hover {
        background: rgba(79, 70, 229, 0.2);
        box-shadow: 0 4px 12px rgba(79, 70, 229, 0.3);
    }
    
    .action-btns .btn-icon .tooltip {
        display: none;
        position: absolute;
        bottom: -28px;
        left: 50%;
        transform: translateX(-50%);
        background: var(--dark);
        color: #fff;
        padding: 2px 10px;
        border-radius: 4px;
        font-size: 9px;
        font-weight: 500;
        white-space: nowrap;
        z-index: 100;
    }
    
    .action-btns .btn-icon:hover .tooltip {
        display: block;
    }
    
    .avatar-mini {
        width: 36px;
        height: 36px;
        border-radius: 50%;
        background: linear-gradient(135deg, var(--primary), #7c3aed);
        display: flex;
        align-items: center;
        justify-content: center;
        color: #fff;
        font-weight: 700;
        font-size: 14px;
        flex-shrink: 0;
    }
    
    .funcionario-nome {
        font-weight: 500;
        font-size: 13px;
    }
    
    .funcionario-id {
        font-size: 10px;
        color: var(--gray);
    }
    
    .valor-monetario {
        font-weight: 600;
        font-family: 'Courier New', monospace;
    }
    
    .valor-monetario.neutro {
        color: var(--primary);
    }
    .valor-monetario.destaque {
        font-size: 16px;
        color: #1a56db;
    }
    
    .stat-card-small {
        background: #fff;
        border-radius: var(--border-radius);
        padding: 16px 20px;
        border: 1px solid var(--gray-border);
        text-align: center;
        flex: 1;
        min-width: 120px;
        transition: all 0.3s ease;
    }
    
    .stat-card-small:hover {
        transform: translateY(-2px);
        box-shadow: var(--shadow-hover);
    }
    
    .stat-card-small .label {
        font-size: 11px;
        color: var(--gray);
        text-transform: uppercase;
        letter-spacing: 0.3px;
    }
    
    .stat-card-small .value {
        font-size: 18px;
        font-weight: 700;
        margin-top: 4px;
    }
    
    .stat-card-small .value.primary { color: var(--primary); }
    .stat-card-small .value.warning { color: var(--warning); }
    .stat-card-small .value.success { color: var(--success); }
    .stat-card-small .value.info { color: var(--info); }
    
    .badge-status {
        padding: 4px 14px;
        border-radius: 20px;
        font-size: 11px;
        font-weight: 600;
        display: inline-block;
        text-transform: uppercase;
        letter-spacing: 0.3px;
        white-space: nowrap;
    }
    
    .badge-status.aprovado {
        background: rgba(16, 185, 129, 0.12);
        color: var(--success);
        border: 1px solid rgba(16, 185, 129, 0.2);
    }
    .badge-status.ativo {
        background: rgba(79, 70, 229, 0.12);
        color: var(--primary);
        border: 1px solid rgba(79, 70, 229, 0.2);
    }
    .badge-status.pendente {
        background: rgba(245, 158, 11, 0.12);
        color: #d97706;
        border: 1px solid rgba(245, 158, 11, 0.2);
    }
    .badge-status.rejeitado {
        background: rgba(239, 68, 68, 0.12);
        color: var(--danger);
        border: 1px solid rgba(239, 68, 68, 0.2);
    }
    
    .alert-warning-custom {
        background: #fef3c7;
        border: 1px solid #fde68a;
        color: #92400e;
        padding: 12px 16px;
        border-radius: 8px;
        display: flex;
        align-items: center;
        gap: 10px;
        margin-top: 10px;
    }
    
    .alert-warning-custom i {
        font-size: 20px;
        color: #d97706;
    }
    
    .subsidios-grid {
        display: grid;
        grid-template-columns: 1fr 1fr 1fr;
        gap: 4px;
        font-size: 11px;
        color: var(--gray);
    }
    
    .subsidios-grid .item {
        padding: 2px 0;
    }
    
    .subsidios-grid .valor {
        font-weight: 600;
        color: var(--dark);
    }
    
    @media (max-width: 768px) {
        .stat-card-small {
            padding: 12px 14px;
            min-width: 80px;
        }
        .stat-card-small .value {
            font-size: 15px;
        }
        .subsidios-grid {
            grid-template-columns: 1fr;
        }
    }
    
    @media (max-width: 576px) {
        .table-custom {
            font-size: 11px;
            min-width: 500px;
        }
        .avatar-mini {
            width: 28px;
            height: 28px;
            font-size: 11px;
        }
        .funcionario-nome {
            font-size: 11px;
        }
        .action-btns .btn-icon {
            width: 28px;
            height: 28px;
            font-size: 12px;
        }
        .valor-monetario.destaque {
            font-size: 13px;
        }
    }
</style>

<!-- Formulário de Processamento -->
<div class="form-container animate-in" style="max-width: 100%;">
    <div class="form-title">
        <i class="fas fa-file-invoice-dollar"></i>
        Processamento da Folha de Pagamento
    </div>

    <form id="formFolha" action="${pageContext.request.contextPath}/financeiro/processar-folha" method="post" onsubmit="return validarFormulario()">
        <div class="row g-3">
            <div class="col-md-3">
                <div class="form-group">
                    <label>Mês <span class="required">*</span></label>
                    <select class="form-select" id="mes" name="mes" required onchange="validarDatas()">
                        <c:forEach var="m" items="${meses}">
                            <option value="${m[0]}" ${m[0] == mes ? 'selected' : ''}>${m[1]}</option>
                        </c:forEach>
                    </select>
                </div>
            </div>
            <div class="col-md-3">
                <div class="form-group">
                    <label>Ano <span class="required">*</span></label>
                    <select class="form-select" id="ano" name="ano" required onchange="validarDatas()">
                        <option value="2024" ${ano == 2024 ? 'selected' : ''}>2024</option>
                        <option value="2025" ${ano == 2025 ? 'selected' : ''}>2025</option>
                        <option value="2026" ${ano == 2026 ? 'selected' : ''}>2026</option>
                        <option value="2027" ${ano == 2027 ? 'selected' : ''}>2027</option>
                    </select>
                </div>
            </div>
            <div class="col-md-3">
                <div class="form-group">
                    <label>Tipo</label>
                    <select class="form-select" name="tipo">
                        <option value="MENSAL">Folha Mensal</option>
                        <option value="DECIMO_TERCEIRO">13º Salário</option>
                        <option value="FERIAS">Férias</option>
                        <option value="RESCISAO">Rescisão</option>
                    </select>
                </div>
            </div>
            <div class="col-md-3">
                <div class="form-group">
                    <label>&nbsp;</label>
                    <button type="submit" id="btnProcessar" class="btn-primary-custom" style="width: 100%;">
                        <i class="fas fa-cogs"></i> Processar Folha
                    </button>
                </div>
            </div>
            <div class="col-12">
                <div id="alertValidacao" class="alert-warning-custom" style="display: none;">
                    <i class="fas fa-exclamation-triangle"></i>
                    <span id="mensagemValidacao">Não é possível processar folha para meses/anos anteriores.</span>
                </div>
            </div>
            <div class="col-12">
                <div class="form-group">
                    <label>Observações</label>
                    <textarea class="form-control" name="observacao" rows="2" 
                              placeholder="Observações sobre o processamento..."></textarea>
                </div>
            </div>
        </div>
    </form>
</div>

<!-- Resumo da Folha -->
<div class="table-section animate-in" style="margin-top: 20px;">
    <div class="table-header">
        <div class="title">
            <i class="fas fa-chart-pie me-2"></i>
            Resumo da Folha
            <span class="badge-count">
                <i class="fas fa-calendar me-1"></i> 
                <c:choose>
                    <c:when test="${mes == 1}">Janeiro</c:when>
                    <c:when test="${mes == 2}">Fevereiro</c:when>
                    <c:when test="${mes == 3}">Março</c:when>
                    <c:when test="${mes == 4}">Abril</c:when>
                    <c:when test="${mes == 5}">Maio</c:when>
                    <c:when test="${mes == 6}">Junho</c:when>
                    <c:when test="${mes == 7}">Julho</c:when>
                    <c:when test="${mes == 8}">Agosto</c:when>
                    <c:when test="${mes == 9}">Setembro</c:when>
                    <c:when test="${mes == 10}">Outubro</c:when>
                    <c:when test="${mes == 11}">Novembro</c:when>
                    <c:when test="${mes == 12}">Dezembro</c:when>
                    <c:otherwise>${mes}</c:otherwise>
                </c:choose>
                / ${ano}
            </span>
            <c:if test="${mes < mesAtual || ano < anoAtual}">
                <span class="badge-status rejeitado" style="margin-left: 8px;">
                    <i class="fas fa-clock me-1"></i> Período Anterior
                </span>
            </c:if>
        </div>
        <div class="actions">
            <button class="btn-outline-custom" onclick="window.location.reload()">
                <i class="fas fa-sync"></i> Atualizar
            </button>
            <c:if test="${mes >= mesAtual && ano >= anoAtual}">
                <span style="font-size: 12px; color: var(--success);">
                    <i class="fas fa-check-circle"></i> Período Atual
                </span>
            </c:if>
        </div>
    </div>
    
    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 12px;">
        <div class="stat-card-small">
            <div class="label"><i class="fas fa-users"></i> Funcionários</div>
            <div class="value info">${resumo != null ? resumo.totalFuncionarios : 0}</div>
        </div>
        <div class="stat-card-small">
            <div class="label"><i class="fas fa-money-bill-wave"></i> Total Bruto</div>
            <div class="value primary">${resumo != null ? resumo.totalBrutoFormatado : 'MZN 0,00'}</div>
        </div>
        <div class="stat-card-small">
            <div class="label"><i class="fas fa-arrow-down"></i> Total Descontos</div>
            <div class="value warning">${resumo != null ? resumo.totalDescontosFormatado : 'MZN 0,00'}</div>
        </div>
        <div class="stat-card-small">
            <div class="label"><i class="fas fa-arrow-up"></i> Total Líquido</div>
            <div class="value success">${resumo != null ? resumo.totalLiquidoFormatado : 'MZN 0,00'}</div>
        </div>
    </div>
</div>

<!-- Lista de Funcionários com Folha -->
<div class="table-section animate-in">
    <div class="table-header">
        <div class="title">
            <i class="fas fa-list me-2"></i>
            Funcionários Processados
            <span class="badge-count">
                <i class="fas fa-users me-1"></i> ${total != null ? total : 0} registros
            </span>
        </div>
    </div>

    <div class="table-responsive-custom">
        <table class="table-custom">
            <thead>
                <tr>
                    <th style="min-width: 160px;">Funcionário</th>
                    <th style="min-width: 110px;">Salário Base</th>
                    <th style="min-width: 130px;">Subsídios</th>
                    <th style="min-width: 120px;">Descontos</th>
                    <th style="min-width: 120px;">Total Líquido</th>
                    <th style="min-width: 100px;">Status</th>
                    <th style="width: 80px; text-align: center;">Ações</th>
                </tr>
            </thead>
            <tbody>
                <c:forEach items="${folhas}" var="f">
                    <tr>
                        <td>
                            <c:choose>
                                <c:when test="${not empty f.funcionario}">
                                    <div style="display: flex; align-items: center; gap: 10px;">
                                        <div class="avatar-mini">
    <c:choose>
        <c:when test="${not empty f.funcionario.nome}">
            ${fn:substring(f.funcionario.nome, 0, 1)}
            <c:set var="resto" value="${fn:substringAfter(f.funcionario.nome, ' ')}" />
            <c:if test="${not empty resto}">
                ${fn:substring(resto, 0, 1)}
            </c:if>
        </c:when>
        <c:otherwise>?</c:otherwise>
    </c:choose>
</div>
                                        <div>
                                            <div class="funcionario-nome">${f.funcionario.nome}</div>
                                            <div class="funcionario-id">ID: #${f.funcionario.id}</div>
                                        </div>
                                    </div>
                                </c:when>
                                <c:otherwise>
                                    <span style="color: var(--gray);">-</span>
                                </c:otherwise>
                            </c:choose>
                        </td>
                        <td>
                            <span class="valor-monetario neutro">
                                MZN <fmt:formatNumber value="${f.salarioBase != null ? f.salarioBase : 0}" pattern="#,##0.00"/>
                            </span>
                        </td>
                        <td>
                            <div class="subsidios-grid">
                                <div class="item">
                                    <i class="fas fa-utensils"></i> Alim: 
                                    <span class="valor">
                                        <fmt:formatNumber value="${f.subsidioAlimentacao != null ? f.subsidioAlimentacao : 0}" pattern="#,##0.00"/>
                                    </span>
                                </div>
                                <div class="item">
                                    <i class="fas fa-bus"></i> Transp: 
                                    <span class="valor">
                                        <fmt:formatNumber value="${f.subsidioTransporte != null ? f.subsidioTransporte : 0}" pattern="#,##0.00"/>
                                    </span>
                                </div>
                                <div class="item">
                                    <i class="fas fa-heartbeat"></i> Saúde: 
                                    <span class="valor">
                                        <fmt:formatNumber value="${f.subsidioSaude != null ? f.subsidioSaude : 0}" pattern="#,##0.00"/>
                                    </span>
                                </div>
                            </div>
                        </td>
                        <td>
                            <div style="font-size: 12px; color: var(--danger);">
                                <div>
                                    <i class="fas fa-percent"></i> IRS: - 
                                    <fmt:formatNumber value="${f.descontoIrs != null ? f.descontoIrs : 0}" pattern="#,##0.00"/>
                                </div>
                                <c:if test="${f.descontoInss != null && f.descontoInss > 0}">
                                    <div>
                                        <i class="fas fa-shield-alt"></i> INSS: - 
                                        <fmt:formatNumber value="${f.descontoInss}" pattern="#,##0.00"/>
                                    </div>
                                </c:if>
                            </div>
                        </td>
                        <td>
                            <span class="valor-monetario destaque">
                                MZN <fmt:formatNumber value="${f.totalLiquido != null ? f.totalLiquido : 0}" pattern="#,##0.00"/>
                            </span>
                        </td>
                        <td>
                            <c:set var="statusStr" value="${f.status}" />
                            <span class="badge-status 
                                ${statusStr == 'PROCESSADO' ? 'aprovado' : 
                                  statusStr == 'PAGO' ? 'ativo' : 
                                  statusStr == 'CANCELADO' ? 'rejeitado' : 'pendente'}">
                                <i class="fas 
                                    ${statusStr == 'PROCESSADO' ? 'fa-check-circle' : 
                                      statusStr == 'PAGO' ? 'fa-money-bill-wave' : 
                                      statusStr == 'CANCELADO' ? 'fa-times-circle' : 'fa-clock'} 
                                    me-1"></i>
                                ${statusStr}
                            </span>
                        </td>
                        <td style="text-align: center;">
                            <div class="action-btns" style="justify-content: center;">
                                <button class="btn-icon view" onclick="verDetalhes(${f.id})" title="Ver detalhes">
                                    <i class="fas fa-eye"></i>
                                    <span class="tooltip">Detalhes</span>
                                </button>
                            </div>
                        </td>
                    </tr>
                </c:forEach>
                
                <c:if test="${empty folhas}">
                    <tr>
                        <td colspan="7" style="text-align: center; padding: 40px; color: var(--gray);">
                            <i class="fas fa-file-invoice-dollar fa-3x d-block mb-3" style="opacity: 0.3;"></i>
                            <h5 style="font-weight: 600; color: var(--dark);">Nenhuma folha processada</h5>
                            <p style="font-size: 14px; color: var(--gray);">
                                Selecione o mês/ano e clique em <strong>"Processar Folha"</strong>
                            </p>
                        </td>
                    </tr>
                </c:if>
            </tbody>
        </table>
    </div>
</div>

<script>
// Variáveis para validação
var mesAtual = ${mesAtual != null ? mesAtual : 1};
var anoAtual = ${anoAtual != null ? anoAtual : 2026};

// Inicializar validação
document.addEventListener('DOMContentLoaded', function() {
    validarDatas();
});

/**
 * Valida se o mês/ano selecionado é válido
 */
function validarDatas() {
    var mes = parseInt(document.getElementById('mes').value);
    var ano = parseInt(document.getElementById('ano').value);
    var dataAtual = new Date();
    var mesAtualReal = dataAtual.getMonth() + 1;
    var anoAtualReal = dataAtual.getFullYear();
    
    var alertDiv = document.getElementById('alertValidacao');
    var mensagem = document.getElementById('mensagemValidacao');
    var btnProcessar = document.getElementById('btnProcessar');
    var selectMes = document.getElementById('mes');
    var selectAno = document.getElementById('ano');
    
    var isAnterior = (ano < anoAtualReal) || (ano == anoAtualReal && mes < mesAtualReal);
    
    selectMes.classList.remove('error');
    selectAno.classList.remove('error');
    
    if (isAnterior) {
        alertDiv.style.display = 'flex';
        mensagem.textContent = '❌ Não é possível processar folha para períodos anteriores. Mês/Ano selecionado: ' + 
            getNomeMes(mes) + '/' + ano + '. Período atual: ' + getNomeMes(mesAtualReal) + '/' + anoAtualReal;
        btnProcessar.disabled = true;
        selectMes.classList.add('error');
        selectAno.classList.add('error');
    } else {
        alertDiv.style.display = 'none';
        btnProcessar.disabled = false;
    }
}

/**
 * Valida o formulário antes de enviar
 */
function validarFormulario() {
    var mes = parseInt(document.getElementById('mes').value);
    var ano = parseInt(document.getElementById('ano').value);
    var dataAtual = new Date();
    var mesAtualReal = dataAtual.getMonth() + 1;
    var anoAtualReal = dataAtual.getFullYear();
    
    if (ano < anoAtualReal || (ano == anoAtualReal && mes < mesAtualReal)) {
        showNotification('error', '❌ Período Inválido', 
            'Não é possível processar folha para meses/anos anteriores. Período selecionado: ' + 
            getNomeMes(mes) + '/' + ano);
        return false;
    }
    
    return confirm('⚠️ Processar folha de pagamento para todos os funcionários ativos?\n\n' +
        'Mês: ' + getNomeMes(mes) + '\n' +
        'Ano: ' + ano + '\n\n' +
        'Os cálculos serão baseados no salário cadastrado de cada funcionário.');
}

/**
 * Retorna o nome do mês
 */
function getNomeMes(mes) {
    var meses = ['Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho', 
                 'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'];
    return meses[mes - 1] || mes;
}

/**
 * Ver detalhes da folha
 */
function verDetalhes(id) {
    window.location.href = '${pageContext.request.contextPath}/financeiro/folha-detalhes/' + id;
}

/**
 * Notificações
 */
function showNotification(type, title, message) {
    if (typeof window.showNotification === 'function') {
        window.showNotification(type, title, message);
    } else {
        alert(title + '\n\n' + message);
    }
}
</script>

<jsp:include page="/WEB-INF/views/layout/footer.jsp" />
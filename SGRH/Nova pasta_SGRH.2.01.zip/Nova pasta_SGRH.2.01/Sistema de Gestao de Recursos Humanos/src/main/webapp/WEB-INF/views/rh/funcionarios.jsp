<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core"%>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt"%>

<jsp:include page="/WEB-INF/views/layout/header.jsp">
    <jsp:param name="pageTitle" value="Funcionários" />
    <jsp:param name="activeMenu" value="funcionarios" />
</jsp:include>

<style>
    /* ============================================================
    ESTILOS GERAIS
    ============================================================ */
    .table-section {
        background: #fff;
        border-radius: var(--border-radius);
        padding: 20px;
        border: 1px solid var(--gray-border);
        box-shadow: var(--shadow-sm);
        margin-bottom: 24px;
        overflow-x: auto;
    }
    
    .table-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 16px;
        flex-wrap: wrap;
        gap: 12px;
    }
    
    .table-header .title {
        font-size: 16px;
        font-weight: 700;
        color: var(--dark);
    }
    
    .table-header .title i { color: var(--primary); }
    
    .table-header .actions {
        display: flex;
        gap: 8px;
        flex-wrap: wrap;
    }
    
    .btn-primary-custom {
        background: linear-gradient(135deg, var(--primary), var(--secondary));
        border: none;
        color: #fff;
        padding: 8px 18px;
        border-radius: 10px;
        font-weight: 600;
        font-size: 13px;
        transition: var(--transition);
        font-family: 'Inter', sans-serif;
        display: inline-flex;
        align-items: center;
        gap: 6px;
        text-decoration: none;
        box-shadow: 0 2px 10px rgba(79,70,229,0.2);
    }
    
    .btn-primary-custom:hover {
        transform: translateY(-2px);
        box-shadow: 0 8px 25px rgba(79,70,229,0.4);
        color: #fff;
    }
    
    .btn-outline-custom {
        background: var(--gray-light);
        border: 1px solid var(--gray-border);
        color: var(--dark);
        padding: 8px 18px;
        border-radius: 10px;
        font-weight: 600;
        font-size: 13px;
        transition: var(--transition);
        font-family: 'Inter', sans-serif;
        display: inline-flex;
        align-items: center;
        gap: 6px;
        text-decoration: none;
    }
    
    .btn-outline-custom:hover {
        background: var(--gray-border);
        color: var(--dark);
    }
    
    /* ============================================================
    TABELA RESPONSIVA
    ============================================================ */
    .table-responsive-custom {
        overflow-x: auto;
        -webkit-overflow-scrolling: touch;
    }
    
    .table-custom {
        width: 100%;
        border-collapse: collapse;
        font-size: 13px;
        min-width: 700px;
    }
    
    .table-custom thead th {
        background: var(--gray-light);
        padding: 10px 14px;
        text-align: left;
        font-size: 11px;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        font-weight: 700;
        color: var(--gray);
        border-bottom: 2px solid var(--gray-border);
        white-space: nowrap;
    }
    
    .table-custom tbody td {
        padding: 10px 14px;
        border-bottom: 1px solid var(--gray-border);
        vertical-align: middle;
    }
    
    .table-custom tbody tr {
        transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    }
    
    .table-custom tbody tr:hover {
        background: var(--gray-light);
    }
    
    /* ============================================================
    STATUS BADGE
    ============================================================ */
    .status-badge {
        padding: 4px 14px;
        border-radius: 20px;
        font-size: 11px;
        font-weight: 600;
        display: inline-block;
        text-transform: uppercase;
        letter-spacing: 0.3px;
    }
    
    .status-badge.ativo {
        background: rgba(16, 185, 129, 0.12);
        color: var(--success);
        border: 1px solid rgba(16, 185, 129, 0.2);
    }
    .status-badge.ferias {
        background: rgba(245, 158, 11, 0.12);
        color: var(--warning);
        border: 1px solid rgba(245, 158, 11, 0.2);
    }
    .status-badge.licenca {
        background: rgba(59, 130, 246, 0.12);
        color: var(--info);
        border: 1px solid rgba(59, 130, 246, 0.2);
    }
    .status-badge.pendente {
        background: rgba(245, 158, 11, 0.12);
        color: #D97706;
        border: 1px solid rgba(245, 158, 11, 0.2);
    }
    .status-badge.inativo {
        background: rgba(239, 68, 68, 0.12);
        color: var(--danger);
        border: 1px solid rgba(239, 68, 68, 0.2);
    }
    
    /* ============================================================
    AVATAR MINI
    ============================================================ */
    .avatar-mini {
        width: 38px;
        height: 38px;
        border-radius: 50%;
        background: linear-gradient(135deg, var(--primary), var(--secondary));
        display: flex;
        align-items: center;
        justify-content: center;
        color: #fff;
        font-weight: 700;
        font-size: 14px;
        flex-shrink: 0;
        overflow: hidden;
    }
    
    .avatar-mini img {
        width: 100%;
        height: 100%;
        border-radius: 50%;
        object-fit: cover;
    }
    
    .funcionario-nome {
        font-weight: 600;
        color: var(--dark);
        font-size: 14px;
    }
    
    .funcionario-email {
        font-size: 12px;
        color: var(--gray);
    }
    
    .setor-tag {
        background: rgba(79, 70, 229, 0.08);
        color: var(--primary);
        padding: 2px 12px;
        border-radius: 12px;
        font-size: 12px;
        border: 1px solid rgba(79, 70, 229, 0.1);
        white-space: nowrap;
    }
    
    .bi-tag {
        font-family: monospace;
        font-weight: 600;
        font-size: 12px;
        background: var(--gray-light);
        padding: 2px 8px;
        border-radius: 4px;
        white-space: nowrap;
    }
    
    /* ============================================================
    BOTÕES DE AÇÃO
    ============================================================ */
    .action-btns {
        display: flex;
        align-items: center;
        gap: 4px;
        flex-wrap: wrap;
    }
    
    .action-btns .btn-icon {
        width: 34px;
        height: 34px;
        border: none;
        border-radius: 8px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        background: transparent;
        color: var(--gray);
        font-size: 14px;
        text-decoration: none;
        position: relative;
    }
    
    .action-btns .btn-icon:hover {
        transform: translateY(-3px);
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
    }
    
    .action-btns .btn-icon.view {
        background: rgba(59, 130, 246, 0.1);
        color: var(--info);
    }
    .action-btns .btn-icon.view:hover {
        background: rgba(59, 130, 246, 0.2);
        box-shadow: 0 4px 12px rgba(59, 130, 246, 0.3);
    }
    
    .action-btns .btn-icon.edit {
        background: rgba(16, 185, 129, 0.1);
        color: var(--success);
    }
    .action-btns .btn-icon.edit:hover {
        background: rgba(16, 185, 129, 0.2);
        box-shadow: 0 4px 12px rgba(16, 185, 129, 0.3);
    }
    
    .action-btns .btn-icon.inactivate {
        background: rgba(245, 158, 11, 0.1);
        color: var(--warning);
    }
    .action-btns .btn-icon.inactivate:hover {
        background: rgba(245, 158, 11, 0.2);
        box-shadow: 0 4px 12px rgba(245, 158, 11, 0.3);
    }
    
    .action-btns .btn-icon .tooltip {
        display: none;
        position: absolute;
        bottom: -28px;
        left: 50%;
        transform: translateX(-50%);
        background: var(--dark);
        color: #fff;
        padding: 2px 10px;
        border-radius: 4px;
        font-size: 9px;
        font-weight: 500;
        white-space: nowrap;
        z-index: 100;
    }
    
    .action-btns .btn-icon:hover .tooltip {
        display: block;
    }
    
    /* ============================================================
    MODAL
    ============================================================ */
    .modal-overlay {
        display: none;
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: rgba(0,0,0,0.6);
        backdrop-filter: blur(8px);
        -webkit-backdrop-filter: blur(8px);
        z-index: 9999;
        justify-content: center;
        align-items: center;
        animation: fadeIn 0.3s ease;
    }
    
    .modal-overlay.active { display: flex; }
    
    @keyframes fadeIn {
        from { opacity: 0; transform: scale(0.95); }
        to { opacity: 1; transform: scale(1); }
    }
    
    .modal-content {
        background: #fff;
        border-radius: 20px;
        max-width: 750px;
        width: 95%;
        max-height: 90vh;
        overflow-y: auto;
        box-shadow: 0 24px 80px rgba(0,0,0,0.3);
        animation: slideUp 0.4s ease;
    }
    
    @keyframes slideUp {
        from { opacity: 0; transform: translateY(30px); }
        to { opacity: 1; transform: translateY(0); }
    }
    
    .modal-header {
        padding: 20px 24px;
        border-bottom: 1px solid var(--gray-border);
        display: flex;
        justify-content: space-between;
        align-items: center;
        background: linear-gradient(135deg, var(--primary), var(--secondary));
        border-radius: 20px 20px 0 0;
        position: sticky;
        top: 0;
        z-index: 10;
    }
    
    .modal-header h3 {
        font-size: 18px;
        font-weight: 700;
        color: #fff;
        margin: 0;
    }
    
    .modal-close {
        background: rgba(255,255,255,0.15);
        border: none;
        color: #fff;
        font-size: 20px;
        width: 36px;
        height: 36px;
        border-radius: 50%;
        cursor: pointer;
        transition: all 0.3s ease;
        display: flex;
        align-items: center;
        justify-content: center;
    }
    
    .modal-close:hover {
        background: rgba(255,255,255,0.25);
        transform: rotate(90deg);
    }
    
    .modal-body { padding: 24px; }
    
    .modal-profile {
        display: flex;
        gap: 24px;
        align-items: flex-start;
        flex-wrap: wrap;
    }
    
    .modal-avatar {
        width: 120px;
        height: 120px;
        border-radius: 50%;
        background: linear-gradient(135deg, var(--primary), var(--secondary));
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 48px;
        font-weight: 800;
        color: #fff;
        flex-shrink: 0;
        overflow: hidden;
        box-shadow: 0 8px 30px rgba(79,70,229,0.3);
    }
    
    .modal-avatar img {
        width: 100%;
        height: 100%;
        object-fit: cover;
    }
    
    .modal-info { flex: 1; min-width: 200px; }
    .modal-info .name { font-size: 22px; font-weight: 800; color: var(--dark); margin-bottom: 4px; }
    .modal-info .email { font-size: 14px; color: var(--gray); margin-bottom: 16px; }
    
    .modal-info .badge-status {
        display: inline-block;
        padding: 4px 16px;
        border-radius: 20px;
        font-size: 12px;
        font-weight: 600;
        margin-bottom: 16px;
    }
    
    .modal-info .badge-status.ativo {
        background: rgba(16, 185, 129, 0.12);
        color: var(--success);
        border: 1px solid rgba(16, 185, 129, 0.2);
    }
    .modal-info .badge-status.inativo {
        background: rgba(239, 68, 68, 0.12);
        color: var(--danger);
        border: 1px solid rgba(239, 68, 68, 0.2);
    }
    
    .modal-details {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 12px;
        margin-top: 16px;
        padding-top: 16px;
        border-top: 1px solid var(--gray-border);
    }
    
    .modal-details .detail-item {
        background: var(--gray-light);
        padding: 10px 14px;
        border-radius: 10px;
    }
    
    .modal-details .detail-item .label {
        font-size: 10px;
        text-transform: uppercase;
        color: var(--gray);
        font-weight: 600;
        letter-spacing: 0.5px;
    }
    
    .modal-details .detail-item .value {
        font-size: 14px;
        font-weight: 600;
        color: var(--dark);
        margin-top: 2px;
    }
    
    .modal-footer {
        padding: 16px 24px;
        border-top: 1px solid var(--gray-border);
        display: flex;
        justify-content: flex-end;
        gap: 12px;
        flex-wrap: wrap;
        position: sticky;
        bottom: 0;
        background: #fff;
        border-radius: 0 0 20px 20px;
    }
    
    .modal-footer .btn-close-modal {
        padding: 8px 24px;
        border: none;
        border-radius: 10px;
        background: var(--gray-light);
        color: var(--dark);
        font-weight: 600;
        font-size: 13px;
        cursor: pointer;
        transition: all 0.3s ease;
    }
    
    .modal-footer .btn-close-modal:hover { background: var(--gray-border); }
    
    .modal-footer .btn-edit-modal {
        padding: 8px 24px;
        border: none;
        border-radius: 10px;
        background: linear-gradient(135deg, var(--primary), var(--secondary));
        color: #fff;
        font-weight: 600;
        font-size: 13px;
        cursor: pointer;
        transition: all 0.3s ease;
        text-decoration: none;
    }
    
    .modal-footer .btn-edit-modal:hover {
        transform: translateY(-2px);
        box-shadow: 0 4px 20px rgba(79,70,229,0.3);
    }
    
    .modal-footer .btn-detalhes-modal {
        padding: 8px 24px;
        border: none;
        border-radius: 10px;
        background: var(--info);
        color: #fff;
        font-weight: 600;
        font-size: 13px;
        cursor: pointer;
        transition: all 0.3s ease;
        text-decoration: none;
    }
    
    .modal-footer .btn-detalhes-modal:hover {
        transform: translateY(-2px);
        box-shadow: 0 4px 20px rgba(59, 130, 246, 0.3);
    }
    
    /* ============================================================
    RESPONSIVO
    ============================================================ */
    @media (max-width: 992px) {
        .modal-profile { flex-direction: column; align-items: center; text-align: center; }
        .modal-details { grid-template-columns: 1fr 1fr; }
        .table-header { flex-direction: column; align-items: stretch; }
        .table-header .actions { justify-content: center; }
    }
    
    @media (max-width: 768px) {
        .table-section { padding: 12px; }
        .table-custom { font-size: 12px; min-width: 550px; }
        .table-custom thead th { padding: 6px 8px; font-size: 10px; }
        .table-custom tbody td { padding: 6px 8px; }
        .action-btns .btn-icon { width: 30px; height: 30px; font-size: 12px; }
        .modal-details { grid-template-columns: 1fr; }
        .modal-content { width: 98%; }
        .modal-header h3 { font-size: 16px; }
        .modal-avatar { width: 80px; height: 80px; font-size: 32px; }
        .modal-info .name { font-size: 18px; }
        .modal-footer { flex-direction: column; }
        .modal-footer a, .modal-footer button { width: 100%; justify-content: center; }
        .funcionario-email { display: none; }
    }
    
    @media (max-width: 576px) {
        .table-custom { min-width: 400px; }
        .table-custom thead th { padding: 4px 6px; font-size: 9px; }
        .table-custom tbody td { padding: 4px 6px; font-size: 11px; }
        .avatar-mini { width: 30px; height: 30px; font-size: 11px; }
        .funcionario-nome { font-size: 12px; }
        .status-badge { font-size: 9px; padding: 2px 8px; }
        .action-btns .btn-icon { width: 26px; height: 26px; font-size: 11px; }
        .setor-tag { font-size: 10px; padding: 1px 8px; }
        .bi-tag { font-size: 10px; }
        .btn-primary-custom, .btn-outline-custom { font-size: 11px; padding: 6px 12px; }
    }
</style>

<div class="table-section animate-in">
    <div class="table-header">
        <div class="title">
            <i class="fas fa-users me-2"></i>
            Gestão de Funcionários
            <span style="font-size: 12px; font-weight: 400; color: var(--gray); margin-left: 8px;">
                <i class="fas fa-user me-1"></i> ${total != null ? total : '0'} registros
            </span>
        </div>
        <div class="actions">
            <a href="${pageContext.request.contextPath}/funcionarios/novo" class="btn-primary-custom">
                <i class="fas fa-plus"></i> Novo Funcionário
            </a>
        </div>
    </div>

    <div class="table-responsive-custom">
        <table class="table-custom" id="tabelaFuncionarios">
            <thead>
                <tr>
                    <th style="width: 50px;">ID</th>
                    <th>Funcionário</th>
                    <th style="min-width: 90px;">Província</th>
                    <th style="min-width: 90px;">Distrito</th>
                    <th style="min-width: 80px;">Setor</th>
                    <th style="width: 90px;">Status</th>
                    <th style="width: 80px;">BI</th>
                    <th style="width: 140px;">Ações</th>
                </tr>
            </thead>
            <tbody>
                <c:forEach items="${funcionarios}" var="f">
                    <tr>
                        <td><span style="font-weight: 600; color: var(--gray);">#${f.id}</span></td>
                        <td>
                            <div style="display: flex; align-items: center; gap: 12px;">
                                <div class="avatar-mini">
                                    <c:choose>
                                        <c:when test="${not empty f.foto}">
                                            <img src="data:image/jpeg;base64,${f.fotoBase64}" alt="${f.nome}">
                                        </c:when>
                                        <c:otherwise>
                                            ${f.nome.charAt(0)}${f.nome.split(' ')[1].charAt(0)}
                                        </c:otherwise>
                                    </c:choose>
                                </div>
                                <div>
                                    <div class="funcionario-nome">${f.nome}</div>
                                    <div class="funcionario-email">
                                        <i class="fas fa-envelope me-1" style="font-size: 10px;"></i>
                                        ${f.emailEmpresa != null ? f.emailEmpresa : 'Sem e-mail'}
                                    </div>
                                </div>
                            </div>
                        </td>
                        <td>${f.provincia != null ? f.provincia : '-'}</td>
                        <td>${f.distrito != null ? f.distrito : '-'}</td>
                        <td>
                            <c:choose>
                                <c:when test="${not empty f.setor}">
                                    <span class="setor-tag">
                                        <i class="fas fa-building me-1"></i> ${f.setor.nome}
                                    </span>
                                </c:when>
                                <c:otherwise>
                                    <span style="color: var(--gray);">-</span>
                                </c:otherwise>
                            </c:choose>
                        </td>
                        <td>
                            <span class="status-badge 
                                ${f.status == 'ATIVO' ? 'ativo' : 
                                  f.status == 'FERIAS' ? 'ferias' :
                                  f.status == 'LICENCA' ? 'licenca' :
                                  f.status == 'AFASTADO' ? 'pendente' : 'inativo'}">
                                <i class="fas 
                                    ${f.status == 'ATIVO' ? 'fa-check-circle' : 
                                      f.status == 'FERIAS' ? 'fa-umbrella-beach' :
                                      f.status == 'LICENCA' ? 'fa-file-medical' :
                                      f.status == 'AFASTADO' ? 'fa-clock' : 'fa-times-circle'} 
                                    me-1"></i>
                                ${f.status}
                            </span>
                        </td>
                        <td>
                            <c:choose>
                                <c:when test="${not empty f.bi}">
                                    <span class="bi-tag">${f.bi}</span>
                                </c:when>
                                <c:otherwise>
                                    <span style="color: var(--gray);">-</span>
                                </c:otherwise>
                            </c:choose>
                        </td>
                        <td>
                            <div class="action-btns">
                                
                                
                                <!-- Ver Detalhes (Página completa) -->
                                <a href="${pageContext.request.contextPath}/funcionarios/visualizar/${f.id}" 
                                   class="btn-icon view" 
                                   title="Ver detalhes completos" 
                                   style="background: rgba(124, 58, 237, 0.1); color: var(--secondary);">
                                    <i class="fas fa-id-card"></i>
                                    <span class="tooltip">Ver detalhes</span>
                                </a>
                                
                                <!-- Editar -->
                                <a href="${pageContext.request.contextPath}/funcionarios/editar/${f.id}" 
                                   class="btn-icon edit" title="Editar">
                                    <i class="fas fa-edit"></i>
                                    <span class="tooltip">Editar</span>
                                </a>
                                
                             
                            </div>
                        </td>
                    </tr>
                </c:forEach>
                <c:if test="${empty funcionarios}">
                    <tr>
                        <td colspan="8" style="text-align: center; padding: 50px 20px; color: var(--gray);">
                            <i class="fas fa-users fa-3x d-block mb-3" style="opacity: 0.3;"></i>
                            <h5 style="font-weight: 600; color: var(--dark);">Nenhum funcionário cadastrado</h5>
                            <p style="font-size: 14px; color: var(--gray);">Clique em "Novo Funcionário" para começar</p>
                            <a href="${pageContext.request.contextPath}/funcionarios/novo" class="btn-primary-custom" style="margin-top: 10px;">
                                <i class="fas fa-plus"></i> Cadastrar Funcionário
                            </a>
                        </td>
                    </tr>
                </c:if>
            </tbody>
        </table>
    </div>
</div>

<!-- ============================================================
MODAL DE PRÉ-VISUALIZAÇÃO
============================================================ -->
<div class="modal-overlay" id="modalVisualizar">
    <div class="modal-content">
        <div class="modal-header">
            <h3><i class="fas fa-id-card me-2"></i> Pré-visualização do Funcionário</h3>
            <button class="modal-close" onclick="fecharModal()">
                <i class="fas fa-times"></i>
            </button>
        </div>
        <div class="modal-body" id="modalBody">
            <div style="text-align: center; padding: 40px;">
                <i class="fas fa-spinner fa-spin fa-2x" style="color: var(--primary);"></i>
                <p style="margin-top: 12px; color: var(--gray);">Carregando dados...</p>
            </div>
        </div>
        <div class="modal-footer">
            <button class="btn-close-modal" onclick="fecharModal()">
                <i class="fas fa-times me-1"></i> Fechar
            </button>
            <a href="#" class="btn-edit-modal" id="btnEditarModal">
                <i class="fas fa-edit me-1"></i> Editar
            </a>
            <a href="#" class="btn-detalhes-modal" id="btnDetalhesModal">
                <i class="fas fa-id-card me-1"></i> Ver Detalhes
            </a>
        </div>
    </div>
</div>

<script>
// ============================================================
// VISUALIZAR FUNCIONÁRIO (PRÉ-VISUALIZAÇÃO EM MODAL)
// ============================================================
function visualizarFuncionario(id) {
    var modal = document.getElementById('modalVisualizar');
    var body = document.getElementById('modalBody');
    var btnEditar = document.getElementById('btnEditarModal');
    var btnDetalhes = document.getElementById('btnDetalhesModal');
    
    modal.classList.add('active');
    document.body.style.overflow = 'hidden';
    
    // Mostrar loading
    body.innerHTML = `
        <div style="text-align: center; padding: 40px;">
            <i class="fas fa-spinner fa-spin fa-2x" style="color: var(--primary);"></i>
            <p style="margin-top: 12px; color: var(--gray);">Carregando dados...</p>
        </div>
    `;
    
    // Buscar dados via AJAX
    fetch('${pageContext.request.contextPath}/funcionarios/visualizar/' + id, {
        headers: { 'Accept': 'application/json' }
    })
    .then(function(response) {
        if (!response.ok) {
            throw new Error('Erro ao carregar dados');
        }
        return response.json();
    })
    .then(function(data) {
        var fotoHtml = data.foto ? 
            '<img src="data:image/jpeg;base64,' + data.foto + '" alt="' + data.nome + '">' : 
            data.nome.charAt(0) + (data.nome.split(' ')[1] ? data.nome.split(' ')[1].charAt(0) : '');
        
        var statusClass = data.status === 'ATIVO' ? 'ativo' : 'inativo';
        var statusIcon = data.status === 'ATIVO' ? 'fa-check-circle' : 'fa-times-circle';
        
        body.innerHTML = `
            <div class="modal-profile">
                <div class="modal-avatar">
                    ${fotoHtml}
                </div>
                <div class="modal-info">
                    <div class="name">${data.nome}</div>
                    <div class="email">${data.email || 'Sem e-mail'}</div>
                    <span class="badge-status ${statusClass}">
                        <i class="fas ${statusIcon} me-1"></i>
                        ${data.status}
                    </span>
                    <div class="modal-details">
                        <div class="detail-item">
                            <div class="label">Província</div>
                            <div class="value">${data.provincia || '-'}</div>
                        </div>
                        <div class="detail-item">
                            <div class="label">Distrito</div>
                            <div class="value">${data.distrito || '-'}</div>
                        </div>
                        <div class="detail-item">
                            <div class="label">Setor</div>
                            <div class="value">${data.setor || '-'}</div>
                        </div>
                        <div class="detail-item">
                            <div class="label">BI</div>
                            <div class="value">${data.bi || '-'}</div>
                        </div>
                        <div class="detail-item">
                            <div class="label">Telefone</div>
                            <div class="value">${data.telefone || '-'}</div>
                        </div>
                        <div class="detail-item">
                            <div class="label">NUIT</div>
                            <div class="value">${data.nuit || '-'}</div>
                        </div>
                        <div class="detail-item">
                            <div class="label">Data Nascimento</div>
                            <div class="value">${data.dataNascimento || '-'}</div>
                        </div>
                        <div class="detail-item">
                            <div class="label">Data Admissão</div>
                            <div class="value">${data.dataAdmissao || '-'}</div>
                        </div>
                        <div class="detail-item">
                            <div class="label">Estado Civil</div>
                            <div class="value">${data.estadoCivil || '-'}</div>
                        </div>
                        <div class="detail-item">
                            <div class="label">Banco</div>
                            <div class="value">${data.banco || '-'}</div>
                        </div>
                    </div>
                </div>
            </div>
        `;
        
        btnEditar.href = '${pageContext.request.contextPath}/funcionarios/editar/' + id;
        btnDetalhes.href = '${pageContext.request.contextPath}/funcionarios/visualizar/' + id;
    })
    .catch(function(error) {
        console.error('Erro:', error);
        body.innerHTML = `
            <div style="text-align: center; padding: 40px;">
                <i class="fas fa-exclamation-circle fa-2x" style="color: var(--danger);"></i>
                <p style="margin-top: 12px; color: var(--gray);">Erro ao carregar dados do funcionário</p>
                <button class="btn-primary-custom" onclick="fecharModal()" style="margin-top: 12px;">
                    <i class="fas fa-times me-1"></i> Fechar
                </button>
            </div>
        `;
    });
}

// ============================================================
// FECHAR MODAL
// ============================================================
function fecharModal() {
    document.getElementById('modalVisualizar').classList.remove('active');
    document.body.style.overflow = '';
}

document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') fecharModal();
});

document.getElementById('modalVisualizar').addEventListener('click', function(e) {
    if (e.target === this) fecharModal();
});

// ============================================================
// ALTERNAR STATUS
// ============================================================
function alternarStatus(id, nome, statusAtual) {
    var acao = statusAtual === 'ATIVO' ? 'INATIVAR' : 'ATIVAR';
    var icone = statusAtual === 'ATIVO' ? '⚠️' : '✅';
    
    if (confirm(icone + ' Tem certeza que deseja ' + acao + ' o funcionário "' + nome + '"?')) {
        fetch('${pageContext.request.contextPath}/funcionarios/alterar-status', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: 'id=' + id
        })
        .then(function(response) {
            return response.json();
        })
        .then(function(data) {
            if (data.success) {
                showNotification('success', '✅ Status Alterado', data.message);
                setTimeout(function() { location.reload(); }, 1500);
            } else {
                showNotification('error', '❌ Erro', data.message);
            }
        })
        .catch(function(err) {
            showNotification('error', '❌ Erro', 'Falha na comunicação com o servidor');
        });
    }
}

// ============================================================
// PESQUISA NA TABELA
// ============================================================
document.addEventListener('DOMContentLoaded', function() {
    var searchInput = document.getElementById('globalSearch');
    if (searchInput) {
        searchInput.addEventListener('keyup', function() {
            var filter = this.value.toLowerCase();
            var rows = document.querySelectorAll('#tabelaFuncionarios tbody tr');
            
            rows.forEach(function(row) {
                var text = row.textContent.toLowerCase();
                row.style.display = text.includes(filter) ? '' : 'none';
            });
        });
    }
});
</script>

<jsp:include page="/WEB-INF/views/layout/footer.jsp" />
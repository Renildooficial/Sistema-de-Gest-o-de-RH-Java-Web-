<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core"%>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt"%>

<jsp:include page="/WEB-INF/views/layout/header.jsp">
    <jsp:param name="pageTitle" value="Férias Pendentes" />
    <jsp:param name="activeMenu" value="ferias" />
</jsp:include>

<div class="table-section animate-in">
    <div class="table-header">
        <div class="title">
            <i class="fas fa-clock me-2"></i>
            Solicitações de Férias Pendentes
            <span style="font-size: 12px; font-weight: 400; color: var(--gray);">${total != null ? total : '0'} registros</span>
        </div>
        <div class="actions">
            <a href="${pageContext.request.contextPath}/dashboard" class="btn-outline-custom">
                <i class="fas fa-arrow-left"></i> Voltar
            </a>
        </div>
    </div>

    <div class="table-responsive-custom">
        <table class="table-custom">
            <thead>
                <tr>
                    <th>Funcionário</th>
                    <th>Período</th>
                    <th>Dias</th>
                    <th>Solicitação</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <c:forEach items="${ferias}" var="f">
                    <tr>
                        <td><strong>${f.funcionario != null ? f.funcionario.nome : '-'}</strong></td>
                        <td>
                            <fmt:formatDate value="${f.dataInicio}" pattern="dd/MM/yyyy" /> - 
                            <fmt:formatDate value="${f.dataFim}" pattern="dd/MM/yyyy" />
                        </td>
                        <td>${f.diasUteis}</td>
                        <td><fmt:formatDate value="${f.dataSolicitacao}" pattern="dd/MM/yyyy HH:mm" /></td>
                        <td>
                            <div class="action-btns">
                                <button class="btn-icon edit" onclick="aprovarFerias(${f.id})" 
                                        style="color: var(--success);" title="Aprovar">
                                    <i class="fas fa-check"></i>
                                </button>
                                <button class="btn-icon delete" onclick="rejeitarFerias(${f.id})" title="Rejeitar">
                                    <i class="fas fa-times"></i>
                                </button>
                            </div>
                        </td>
                    </tr>
                </c:forEach>
                <c:if test="${empty ferias}">
                    <tr>
                        <td colspan="5" style="text-align: center; padding: 30px; color: var(--gray);">
                            <i class="fas fa-check-circle fa-2x d-block mb-2" style="color: var(--success);"></i>
                            Nenhuma solicitação pendente
                        </td>
                    </tr>
                </c:if>
            </tbody>
        </table>
    </div>
</div>

<script>
function aprovarFerias(id) {
    if (confirm('Aprovar esta solicitação de férias?')) {
        fetch('${pageContext.request.contextPath}/ferias/aprovar', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: 'id=' + id
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                showNotification('success', 'Aprovado', data.message);
                location.reload();
            } else {
                showNotification('error', 'Erro', data.message);
            }
        });
    }
}

function rejeitarFerias(id) {
    const motivo = prompt('Digite o motivo da rejeição:');
    if (motivo !== null) {
        fetch('${pageContext.request.contextPath}/ferias/rejeitar', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: 'id=' + id + '&motivo=' + encodeURIComponent(motivo)
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                showNotification('warning', 'Rejeitado', data.message);
                location.reload();
            } else {
                showNotification('error', 'Erro', data.message);
            }
        });
    }
}
</script>

<jsp:include page="/WEB-INF/views/layout/footer.jsp" />
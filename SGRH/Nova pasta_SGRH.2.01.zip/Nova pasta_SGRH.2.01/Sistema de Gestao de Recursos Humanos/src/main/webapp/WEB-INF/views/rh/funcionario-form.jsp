<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core"%>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt"%>

<jsp:include page="/WEB-INF/views/layout/header.jsp">
    <jsp:param name="pageTitle" value="${acao == 'cadastrar' ? 'Novo Funcionário' : 'Editar Funcionário'}" />
    <jsp:param name="activeMenu" value="funcionarios" />
</jsp:include>

<style>
    .required { color: var(--danger); font-weight: 700; }
    .form-group label { font-weight: 600; font-size: 13px; color: var(--dark); margin-bottom: 4px; }
    .form-control, .form-select { border-radius: 10px; border: 1px solid var(--gray-border); padding: 8px 12px; font-size: 13px; transition: var(--transition); }
    .form-control:focus, .form-select:focus { border-color: var(--primary); box-shadow: 0 0 0 3px rgba(79,70,229,0.1); }
    .form-container { background: #fff; border-radius: var(--border-radius); padding: 28px; box-shadow: var(--shadow-sm); border: 1px solid var(--gray-border); margin-bottom: 24px; }
    .form-title { font-size: 20px; font-weight: 700; color: var(--dark); margin-bottom: 24px; display: flex; align-items: center; gap: 12px; }
    .form-title i { color: var(--primary); }
    .form-actions { margin-top: 24px; padding-top: 20px; border-top: 1px solid var(--gray-border); display: flex; gap: 12px; flex-wrap: wrap; }
    .helper-text { font-size: 11px; color: var(--gray); margin-top: 4px; }
    .helper-text i { color: var(--info); }
    .is-invalid { border-color: var(--danger) !important; }
    .is-valid { border-color: var(--success) !important; }
</style>

<div class="form-container animate-in">
    <div class="form-title">
        <i class="fas ${acao == 'cadastrar' ? 'fa-user-plus' : 'fa-user-edit'}"></i>
        ${acao == 'cadastrar' ? 'Cadastrar Funcionário' : 'Editar Funcionário'}
    </div>

    <form action="${pageContext.request.contextPath}/funcionarios" method="post" 
          enctype="multipart/form-data" id="funcionarioForm" novalidate>
        
        <input type="hidden" name="id" value="${funcionario.id}">

        <div class="row g-3">
            <!-- Dados Pessoais -->
            <div class="col-12">
                <h6 style="font-weight: 700; color: var(--primary); border-bottom: 2px solid var(--gray-border); padding-bottom: 8px;">
                    <i class="fas fa-user me-2"></i> Dados Pessoais
                </h6>
            </div>

            <div class="col-md-6">
                <div class="form-group">
                    <label>Nome Completo <span class="required">*</span></label>
                    <input type="text" class="form-control" name="nome" id="nome" 
                           value="${funcionario.nome}" required 
                           placeholder="Nome completo do funcionário"
                           minlength="3" maxlength="100">
                    <div class="helper-text"><i class="fas fa-info-circle"></i> Mínimo 3 caracteres, máximo 100</div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <label>Data de Nascimento <span class="required">*</span></label>
                    <input type="date" class="form-control" name="dataNascimento" id="dataNascimento"
                           value="${funcionario.dataNascimento != null ? funcionario.dataNascimento : ''}" required>
                    <div class="helper-text"><i class="fas fa-info-circle"></i> O funcionário deve ter pelo menos 18 anos</div>
                </div>
            </div>

            <!-- Província e Distrito com Combo -->
            <div class="col-md-6">
                <div class="form-group">
                    <label>Província <span class="required">*</span></label>
                    <select class="form-select" name="provincia" id="provincia" required onchange="carregarDistritos()">
                        <option value="">Selecione a Província</option>
                        <option value="Cabo Delgado" ${funcionario.provincia == 'Cabo Delgado' ? 'selected' : ''}>Cabo Delgado</option>
                        <option value="Gaza" ${funcionario.provincia == 'Gaza' ? 'selected' : ''}>Gaza</option>
                        <option value="Inhambane" ${funcionario.provincia == 'Inhambane' ? 'selected' : ''}>Inhambane</option>
                        <option value="Manica" ${funcionario.provincia == 'Manica' ? 'selected' : ''}>Manica</option>
                        <option value="Maputo" ${funcionario.provincia == 'Maputo' ? 'selected' : ''}>Maputo</option>
                        <option value="Maputo Cidade" ${funcionario.provincia == 'Maputo Cidade' ? 'selected' : ''}>Maputo Cidade</option>
                        <option value="Nampula" ${funcionario.provincia == 'Nampula' ? 'selected' : ''}>Nampula</option>
                        <option value="Niassa" ${funcionario.provincia == 'Niassa' ? 'selected' : ''}>Niassa</option>
                        <option value="Sofala" ${funcionario.provincia == 'Sofala' ? 'selected' : ''}>Sofala</option>
                        <option value="Tete" ${funcionario.provincia == 'Tete' ? 'selected' : ''}>Tete</option>
                        <option value="Zambezia" ${funcionario.provincia == 'Zambezia' ? 'selected' : ''}>Zambezia</option>
                    </select>
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <label>Distrito <span class="required">*</span></label>
                    <select class="form-select" name="distrito" id="distrito" required>
                        <option value="">Selecione primeiro a Província</option>
                        <c:if test="${not empty funcionario.distrito}">
                            <option value="${funcionario.distrito}" selected>${funcionario.distrito}</option>
                        </c:if>
                    </select>
                </div>
            </div>

            <div class="col-md-6">
                <div class="form-group">
                    <label>Estado Civil <span class="required">*</span></label>
                    <select class="form-select" name="estadoCivil" required>
                        <option value="">Selecione</option>
                        <option value="SOLTEIRO" ${funcionario.estadoCivil == 'SOLTEIRO' ? 'selected' : ''}>Solteiro(a)</option>
                        <option value="CASADO" ${funcionario.estadoCivil == 'CASADO' ? 'selected' : ''}>Casado(a)</option>
                        <option value="DIVORCIADO" ${funcionario.estadoCivil == 'DIVORCIADO' ? 'selected' : ''}>Divorciado(a)</option>
                        <option value="VIUVO" ${funcionario.estadoCivil == 'VIUVO' ? 'selected' : ''}>Viúvo(a)</option>
                        <option value="UNIAO_ESTAVEL" ${funcionario.estadoCivil == 'UNIAO_ESTAVEL' ? 'selected' : ''}>União Estável</option>
                    </select>
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <label>Nome do Cônjuge</label>
                    <input type="text" class="form-control" name="nomeConjuge" 
                           value="${funcionario.nomeConjuge}" 
                           placeholder="Nome do cônjuge (se aplicável)"
                           maxlength="100">
                </div>
            </div>

            <div class="col-md-6">
                <div class="form-group">
                    <label>Data de Admissão <span class="required">*</span></label>
                    <input type="date" class="form-control" name="dataAdmissao" id="dataAdmissao"
                           value="${funcionario.dataAdmissao != null ? funcionario.dataAdmissao : ''}" required>
                    <div class="helper-text"><i class="fas fa-info-circle"></i> Não pode ser anterior à data de nascimento</div>
                </div>
            </div>

            <!-- Contato e Documentos -->
            <div class="col-12" style="margin-top: 12px;">
                <h6 style="font-weight: 700; color: var(--primary); border-bottom: 2px solid var(--gray-border); padding-bottom: 8px;">
                    <i class="fas fa-id-card me-2"></i> Contato e Documentos
                </h6>
            </div>

            <div class="col-md-6">
                <div class="form-group">
                    <label>Telefone <span class="required">*</span></label>
                    <input type="tel" class="form-control" name="telefone" id="telefone"
                           value="${funcionario.telefone}" required 
                           placeholder="84 123 4567" maxlength="12">
                    <div class="helper-text"><i class="fas fa-info-circle"></i> Formato: 9 dígitos (ex: 84 123 4567)</div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <label>E-mail Empresa <span class="required">*</span></label>
                    <input type="email" class="form-control" name="emailEmpresa" id="emailEmpresa"
                           value="${funcionario.emailEmpresa}" required 
                           placeholder="email@empresa.com">
                    <div class="helper-text"><i class="fas fa-info-circle"></i> Ex: nome@empresa.co.mz</div>
                </div>
            </div>

            <div class="col-md-4">
                <div class="form-group">
                    <label>NUIT <span class="required">*</span></label>
                    <input type="text" class="form-control" name="nuit" id="nuit"
                           value="${funcionario.nuit}" required 
                           placeholder="123456789" maxlength="9" pattern="[0-9]{9}">
                    <div class="helper-text"><i class="fas fa-info-circle"></i> Exatamente 9 dígitos (ex: 123456789)</div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="form-group">
                    <label>RG</label>
                    <input type="text" class="form-control" name="rg" 
                           value="${funcionario.rg}" 
                           placeholder="Número do RG" maxlength="20">
                </div>
            </div>
            <div class="col-md-4">
                <div class="form-group">
                    <label>BI (Bilhete de Identidade) <span class="required">*</span></label>
                    <input type="text" class="form-control" name="bi" id="bi"
                           value="${funcionario.bi}" required 
                           placeholder="BI-123456789X" maxlength="15">
                    <div class="helper-text"><i class="fas fa-info-circle"></i> 6 a 15 caracteres alfanuméricos</div>
                </div>
            </div>

            <!-- Dados Bancários -->
            <div class="col-12" style="margin-top: 12px;">
                <h6 style="font-weight: 700; color: var(--primary); border-bottom: 2px solid var(--gray-border); padding-bottom: 8px;">
                    <i class="fas fa-university me-2"></i> Dados Bancários
                </h6>
            </div>

            <div class="col-md-6">
                <div class="form-group">
                    <label>Banco <span class="required">*</span></label>
                    <select class="form-select" name="banco" required>
                        <option value="">Selecione o Banco</option>
                        <option value="BCI" ${funcionario.banco == 'BCI' ? 'selected' : ''}>BCI - Banco Comercial de Investimentos</option>
                        <option value="BIM" ${funcionario.banco == 'BIM' ? 'selected' : ''}>BIM - Banco Internacional de Moçambique</option>
                        <option value="BNI" ${funcionario.banco == 'BNI' ? 'selected' : ''}>BNI - Banco Nacional de Investimentos</option>
                        <option value="BCM" ${funcionario.banco == 'BCM' ? 'selected' : ''}>BCM - Banco de Comércio Moçambique</option>
                        <option value="ABS" ${funcionario.banco == 'ABS' ? 'selected' : ''}}>ABS - Access Bank</option>
                        <option value="FNB" ${funcionario.banco == 'FNB' ? 'selected' : ''}>FNB - First National Bank</option>
                        <option value="Standard" ${funcionario.banco == 'Standard' ? 'selected' : ''}>Standard Bank</option>
                        <option value="Millennium" ${funcionario.banco == 'Millennium' ? 'selected' : ''}>Millennium BIM</option>
                        <option value="Moza" ${funcionario.banco == 'Moza' ? 'selected' : ''}>Moza Banco</option>
                        <option value="Outro" ${funcionario.banco == 'Outro' ? 'selected' : ''}>Outro</option>
                    </select>
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <label>Número da Conta <span class="required">*</span></label>
                    <input type="text" class="form-control" name="numeroConta" 
                           value="${funcionario.numeroConta}" required 
                           placeholder="123456789012" maxlength="16" pattern="[0-9]{6,16}">
                    <div class="helper-text"><i class="fas fa-info-circle"></i> 6 a 16 dígitos (apenas números)</div>
                </div>
            </div>

            <!-- Setor e Status -->
            <div class="col-12" style="margin-top: 12px;">
                <h6 style="font-weight: 700; color: var(--primary); border-bottom: 2px solid var(--gray-border); padding-bottom: 8px;">
                    <i class="fas fa-briefcase me-2"></i> Vínculo
                </h6>
            </div>

            <div class="col-md-6">
                <div class="form-group">
                    <label>Setor <span class="required">*</span></label>
                    <select class="form-select" name="idSetor" required>
                        <option value="">Selecione um setor</option>
                        <c:forEach items="${setores}" var="s">
                            <option value="${s.id}" ${funcionario.idSetor == s.id ? 'selected' : ''}>${s.nome}</option>
                        </c:forEach>
                    </select>
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <label>Status <span class="required">*</span></label>
                    <select class="form-select" name="status" required>
                        <option value="ATIVO" ${funcionario.status == 'ATIVO' ? 'selected' : ''}>Ativo</option>
                        <option value="INATIVO" ${funcionario.status == 'INATIVO' ? 'selected' : ''}>Inativo</option>
                        <option value="FERIAS" ${funcionario.status == 'FERIAS' ? 'selected' : ''}>Férias</option>
                        <option value="LICENCA" ${funcionario.status == 'LICENCA' ? 'selected' : ''}>Licença</option>
                        <option value="AFASTADO" ${funcionario.status == 'AFASTADO' ? 'selected' : ''}>Afastado</option>
                    </select>
                </div>
            </div>

            <!-- Foto -->
            <div class="col-12" style="margin-top: 12px;">
                <h6 style="font-weight: 700; color: var(--primary); border-bottom: 2px solid var(--gray-border); padding-bottom: 8px;">
                    <i class="fas fa-camera me-2"></i> Foto
                </h6>
            </div>

            <div class="col-12">
                <div class="form-group">
                    <label>Foto do Funcionário</label>
                    <input type="file" class="form-control" name="foto" accept="image/*">
                    <div class="helper-text">
                        <i class="fas fa-info-circle"></i> Formatos: JPG, PNG, GIF (máx. 2MB)
                    </div>
                </div>
            </div>
        </div>

        <div class="form-actions">
            <button type="submit" class="btn-primary-custom">
                <i class="fas fa-save"></i> ${acao == 'cadastrar' ? 'Cadastrar' : 'Atualizar'}
            </button>
            <a href="${pageContext.request.contextPath}/funcionarios" class="btn-outline-custom">
                <i class="fas fa-times"></i> Cancelar
            </a>
        </div>
    </form>
</div>

<script>
// ============================================================
// DADOS DOS DISTRITOS POR PROVÍNCIA (MOÇAMBIQUE)
// ============================================================
const distritosPorProvincia = {
    'Cabo Delgado': ['Pemba', 'Metuge', 'Chiure', 'Ancuabe', 'Montepuez', 'Macomia', 'Mocimboa da Praia', 'Palma', 'Mueda', 'Meluco', 'Muidumbe', 'Nangade', 'Quissanga', 'Ibo'],
    'Gaza': ['Xai-Xai', 'Chibuto', 'Chokwe', 'Manjacaze', 'Mabalane', 'Massingir', 'Chicualacuala', 'Macia', 'Bilene', 'Limpopo', 'Guija'],
    'Inhambane': ['Inhambane', 'Maxixe', 'Jangamo', 'Morrumbene', 'Zavala', 'Mabote', 'Funhalouro', 'Panda', 'Massinga', 'Govuro', 'Vilanculos'],
    'Manica': ['Chimoio', 'Manica', 'Gondola', 'Sussundenga', 'Macate', 'Tambara', 'Machaze', 'Baraue', 'Guro'],
    'Maputo': ['Matola', 'Boane', 'Moamba', 'Namaacha', 'Manhica', 'Marracuene', 'Magude'],
    'Maputo Cidade': ['Maputo', 'KaMpfumo', 'KaMaxakeni', 'KaMavota', 'KaMubukwana', 'KaTembe', 'KaNyaka'],
    'Nampula': ['Nampula', 'Nacala', 'Memba', 'Mossuril', 'Mogincual', 'Ilha de Mocambique', 'Angoche', 'Moma', 'Larde', 'Meconta', 'Mecuburi', 'Muecate', 'Rapale', 'Erati', 'Malema', 'Lalaua'],
    'Niassa': ['Lichinga', 'Cuamba', 'Mandimba', 'Marrupa', 'Mavago', 'Mecanhelas', 'Metarica', 'Muembe', 'Nipepe', 'Sanga', 'Chimbonila'],
    'Sofala': ['Beira', 'Dondo', 'Nhamatanda', 'Buzi', 'Machanga', 'Chibabava', 'Marromeu', 'Muanza', 'Cheringoma', 'Gorongosa'],
    'Tete': ['Tete', 'Moatize', 'Changara', 'Magoe', 'Maravia', 'Mutarara', 'Magoé', 'Cahora Bassa', 'Zumbo', 'Doo', 'Chiuta'],
    'Zambezia': ['Quelimane', 'Mocuba', 'Maganja da Costa', 'Namacurra', 'Mopeia', 'Chinde', 'Ile', 'Milange', 'Mulevala', 'Morrumbala', 'Derre', 'Nante']
};

// ============================================================
// FUNÇÃO PARA CARREGAR DISTRITOS
// ============================================================
function carregarDistritos() {
    const provinciaSelect = document.getElementById('provincia');
    const distritoSelect = document.getElementById('distrito');
    const provincia = provinciaSelect.value;
    
    distritoSelect.innerHTML = '<option value="">Selecione o Distrito</option>';
    
    if (provincia && distritosPorProvincia[provincia]) {
        const distritos = distritosPorProvincia[provincia];
        distritos.forEach(function(distrito) {
            const option = document.createElement('option');
            option.value = distrito;
            option.textContent = distrito;
            distritoSelect.appendChild(option);
        });
        distritoSelect.disabled = false;
    } else {
        distritoSelect.disabled = true;
    }
}

// ============================================================
// CARREGAR DISTRITOS INICIAL
// ============================================================
document.addEventListener('DOMContentLoaded', function() {
    const provinciaSelect = document.getElementById('provincia');
    const provinciaAtual = provinciaSelect.value;
    
    if (provinciaAtual && distritosPorProvincia[provinciaAtual]) {
        carregarDistritos();
        const distritoAtual = '${funcionario.distrito}';
        if (distritoAtual) {
            const distritoSelect = document.getElementById('distrito');
            for (let i = 0; i < distritoSelect.options.length; i++) {
                if (distritoSelect.options[i].value === distritoAtual) {
                    distritoSelect.selectedIndex = i;
                    break;
                }
            }
        }
    }
});

// ============================================================
// VALIDAÇÕES DE MOÇAMBIQUE
// ============================================================
document.getElementById('funcionarioForm').addEventListener('submit', function(e) {
    let isValid = true;
    let errorMessages = [];
    
    // 1. VALIDAÇÃO DO NOME
    const nome = document.getElementById('nome');
    if (nome.value.trim().length < 3) {
        errorMessages.push('Nome deve ter no mínimo 3 caracteres');
        isValid = false;
    }
    
    // 2. VALIDAÇÃO DO NUIT - EXATAMENTE 9 DÍGITOS
    const nuit = document.getElementById('nuit');
    const nuitRegex = /^[0-9]{9}$/;
    if (!nuitRegex.test(nuit.value.trim())) {
        errorMessages.push('NUIT deve ter exatamente 9 dígitos (apenas números)');
        isValid = false;
    }
    
    // 3. VALIDAÇÃO DO BI - 6 a 15 caracteres alfanuméricos
    const bi = document.getElementById('bi');
    const biRegex = /^[A-Za-z0-9]{6,15}$/;
    if (!biRegex.test(bi.value.trim())) {
        errorMessages.push('BI deve ter entre 6 e 15 caracteres alfanuméricos');
        isValid = false;
    }
    
    // 4. VALIDAÇÃO DO TELEFONE - MOÇAMBIQUE (9 dígitos, começando com 8)
    const telefone = document.getElementById('telefone');
    const telRegex = /^[0-9]{9}$/;
    const telLimpo = telefone.value.replace(/\s/g, '');
    if (!telRegex.test(telLimpo)) {
        errorMessages.push('Telefone deve ter exatamente 9 dígitos (ex: 841234567)');
        isValid = false;
    } else if (!telLimpo.startsWith('8')) {
        errorMessages.push('Telefone deve começar com 8 (ex: 84, 82, 86)');
        isValid = false;
    }
    
    // 5. VALIDAÇÃO DO E-MAIL
    const email = document.getElementById('emailEmpresa');
    const emailRegex = /^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$/;
    if (!emailRegex.test(email.value.trim())) {
        errorMessages.push('E-mail inválido');
        isValid = false;
    }
    
    // 6. VALIDAÇÃO DA DATA DE NASCIMENTO (maior de idade - 18 anos)
    const dataNasc = document.getElementById('dataNascimento');
    if (dataNasc.value) {
        const nascimento = new Date(dataNasc.value);
        const hoje = new Date();
        let idade = hoje.getFullYear() - nascimento.getFullYear();
        const mes = hoje.getMonth() - nascimento.getMonth();
        if (mes < 0 || (mes === 0 && hoje.getDate() < nascimento.getDate())) {
            idade--;
        }
        if (idade < 18) {
            errorMessages.push('Funcionário deve ter pelo menos 18 anos');
            isValid = false;
        }
    }
    
    // 7. VALIDAÇÃO DA DATA DE ADMISSÃO (não pode ser anterior à data de nascimento)
    const dataAdmissao = document.getElementById('dataAdmissao');
    if (dataNasc.value && dataAdmissao.value) {
        if (dataAdmissao.value < dataNasc.value) {
            errorMessages.push('Data de admissão não pode ser anterior à data de nascimento');
            isValid = false;
        }
    }
    
    // 8. VALIDAÇÃO DA CONTA BANCÁRIA (6 a 16 dígitos)
    const conta = document.querySelector('input[name="numeroConta"]');
    const contaRegex = /^[0-9]{6,16}$/;
    if (!contaRegex.test(conta.value.trim())) {
        errorMessages.push('Número da conta deve ter entre 6 e 16 dígitos (apenas números)');
        isValid = false;
    }
    
    // SE HOUVER ERROS, EXIBIR E CANCELAR
    if (!isValid) {
        e.preventDefault();
        const msg = errorMessages.join('\n');
        showNotification('error', 'Erro de Validação', msg);
        return false;
    }
    
    return true;
});

// ============================================================
// MÁSCARA PARA TELEFONE
// ============================================================
document.getElementById('telefone').addEventListener('input', function(e) {
    this.value = this.value.replace(/[^0-9]/g, '');
    if (this.value.length > 9) {
        this.value = this.value.slice(0, 9);
    }
});

// ============================================================
// MÁSCARA PARA NUIT (apenas números)
// ============================================================
document.getElementById('nuit').addEventListener('input', function(e) {
    this.value = this.value.replace(/[^0-9]/g, '');
    if (this.value.length > 9) {
        this.value = this.value.slice(0, 9);
    }
});

// ============================================================
// MÁSCARA PARA BI (alfanumérico, sem espaços)
// ============================================================
document.getElementById('bi').addEventListener('input', function(e) {
    this.value = this.value.replace(/[^A-Za-z0-9]/g, '');
    if (this.value.length > 15) {
        this.value = this.value.slice(0, 15);
    }
});

// ============================================================
// MÁSCARA PARA CONTA (apenas números)
// ============================================================
document.querySelector('input[name="numeroConta"]').addEventListener('input', function(e) {
    this.value = this.value.replace(/[^0-9]/g, '');
    if (this.value.length > 16) {
        this.value = this.value.slice(0, 16);
    }
});
</script>

<jsp:include page="/WEB-INF/views/layout/footer.jsp" />
<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core"%>

<jsp:include page="/WEB-INF/views/layout/header.jsp">
    <jsp:param name="pageTitle" value="${titulo}" />
    <jsp:param name="activeMenu" value="relatorios" />
</jsp:include>

<div class="form-container animate-in" style="max-width: 100%;">
    <div class="form-title">
        <i class="fas fa-users" style="color: var(--primary);"></i>
        ${titulo}
    </div>

    <div class="row g-4">
        <!-- Funcionários por Setor -->
        <div class="col-md-6">
            <div class="chart-card">
                <div class="card-header">
                    <div>
                        <div class="card-title">Funcionários por Setor</div>
                        <div class="card-subtitle">Distribuição atual</div>
                    </div>
                </div>
                <div class="chart-container" style="height: 300px;">
                    <canvas id="setorChart"></canvas>
                </div>
            </div>
        </div>

        <!-- Status dos Funcionários -->
        <div class="col-md-6">
            <div class="chart-card">
                <div class="card-header">
                    <div>
                        <div class="card-title">Status dos Funcionários</div>
                        <div class="card-subtitle">Visão geral</div>
                    </div>
                </div>
                <div class="chart-container" style="height: 300px;">
                    <canvas id="statusChart"></canvas>
                </div>
            </div>
        </div>
    </div>

    <div class="form-actions">
        <button class="btn-primary-custom" onclick="window.print()">
            <i class="fas fa-print"></i> Imprimir
        </button>
        <button class="btn-outline-custom" onclick="window.location.href='${pageContext.request.contextPath}/relatorios'">
            <i class="fas fa-arrow-left"></i> Voltar
        </button>
    </div>
</div>

<script>
// Gráfico de Setores
const ctx1 = document.getElementById('setorChart').getContext('2d');
const setorLabels = [
    <c:forEach items="${funcionariosPorSetor}" var="entry" varStatus="status">
        '${entry.key}'${!status.last ? ',' : ''}
    </c:forEach>
];
const setorData = [
    <c:forEach items="${funcionariosPorSetor}" var="entry" varStatus="status">
        ${entry.value}${!status.last ? ',' : ''}
    </c:forEach>
];

new Chart(ctx1, {
    type: 'bar',
    data: {
        labels: setorLabels.length > 0 ? setorLabels : ['Nenhum dado'],
        datasets: [{
            label: 'Funcionários',
            data: setorData.length > 0 ? setorData : [0],
            backgroundColor: [
                'rgba(79,70,229,0.8)',
                'rgba(59,130,246,0.8)',
                'rgba(16,185,129,0.8)',
                'rgba(245,158,11,0.8)',
                'rgba(124,58,237,0.8)',
                'rgba(239,68,68,0.8)',
                'rgba(14,165,233,0.8)'
            ],
            borderColor: [
                'rgba(79,70,229,1)',
                'rgba(59,130,246,1)',
                'rgba(16,185,129,1)',
                'rgba(245,158,11,1)',
                'rgba(124,58,237,1)',
                'rgba(239,68,68,1)',
                'rgba(14,165,233,1)'
            ],
            borderWidth: 2,
            borderRadius: 8,
            maxBarThickness: 40,
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: { legend: { display: false } },
        scales: {
            y: { beginAtZero: true, grid: { color: 'rgba(0,0,0,0.05)' }, ticks: { stepSize: 1, font: { size: 11 } } },
            x: { grid: { display: false }, ticks: { font: { size: 11 } } }
        }
    }
});

// Gráfico de Status
const ctx2 = document.getElementById('statusChart').getContext('2d');
new Chart(ctx2, {
    type: 'doughnut',
    data: {
        labels: ['Ativos', 'Em Férias', 'Inativos', 'Licença', 'Afastados'],
        datasets: [{
            data: [
                ${statusFuncionarios.get('Ativos') != null ? statusFuncionarios.get('Ativos') : 0},
                ${statusFuncionarios.get('Em Férias') != null ? statusFuncionarios.get('Em Férias') : 0},
                ${statusFuncionarios.get('Inativos') != null ? statusFuncionarios.get('Inativos') : 0},
                ${statusFuncionarios.get('Licença') != null ? statusFuncionarios.get('Licença') : 0},
                ${statusFuncionarios.get('Afastados') != null ? statusFuncionarios.get('Afastados') : 0}
            ],
            backgroundColor: [
                'rgba(16,185,129,0.9)',
                'rgba(245,158,11,0.9)',
                'rgba(239,68,68,0.9)',
                'rgba(59,130,246,0.9)',
                'rgba(124,58,237,0.9)'
            ],
            borderColor: '#fff',
            borderWidth: 3,
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            legend: {
                position: 'bottom',
                labels: { padding: 16, usePointStyle: true, pointStyle: 'circle', font: { size: 12, weight: '500' } }
            }
        },
        cutout: '70%'
    }
});
</script>

<jsp:include page="/WEB-INF/views/layout/footer.jsp" />
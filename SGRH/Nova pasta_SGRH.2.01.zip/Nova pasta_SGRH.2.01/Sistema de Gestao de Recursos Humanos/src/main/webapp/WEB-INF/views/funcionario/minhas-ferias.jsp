<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core"%>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt"%>

<jsp:include page="/WEB-INF/views/layout/header.jsp">
    <jsp:param name="pageTitle" value="Minhas Férias" />
    <jsp:param name="activeMenu" value="minhas-ferias" />
</jsp:include>

<style>
    :root {
        --primary: #4f46e5;
        --primary-hover: #4338ca;
        --primary-light: #e0e7ff;
        --success: #22c55e;
        --success-light: #d1fae5;
        --warning: #f59e0b;
        --warning-light: #fef3c7;
        --danger: #ef4444;
        --danger-light: #fee2e2;
        --gray: #64748b;
        --gray-light: #f1f5f9;
        --dark: #0f172a;
        --border: #e2e8f0;
        --shadow: 0 1px 3px rgba(0,0,0,0.06);
        --shadow-hover: 0 8px 25px rgba(0,0,0,0.08);
        --radius: 12px;
    }

    .ferias-container {
        max-width: 1200px;
        margin: 0 auto;
        padding: 20px;
    }

    .page-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        flex-wrap: wrap;
        gap: 15px;
        margin-bottom: 28px;
    }

    .page-header h1 {
        font-size: 26px;
        font-weight: 700;
        color: var(--dark);
        display: flex;
        align-items: center;
        gap: 14px;
        margin: 0;
    }

    .page-header h1 i {
        color: var(--primary);
        background: var(--primary-light);
        padding: 12px;
        border-radius: var(--radius);
        font-size: 22px;
    }

    .page-header .subtitle {
        font-size: 14px;
        color: var(--gray);
        font-weight: 400;
        margin-left: 4px;
    }

    .btn-primary-custom {
        background: var(--primary);
        color: #fff;
        padding: 11px 26px;
        border: none;
        border-radius: var(--radius);
        font-size: 14px;
        font-weight: 600;
        display: inline-flex;
        align-items: center;
        gap: 10px;
        text-decoration: none;
        cursor: pointer;
        transition: all 0.2s ease;
        box-shadow: 0 2px 8px rgba(79, 70, 229, 0.25);
    }

    .btn-primary-custom:hover {
        background: var(--primary-hover);
        color: #fff;
        transform: translateY(-2px);
        box-shadow: 0 4px 16px rgba(79, 70, 229, 0.35);
    }

    .stats-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(160px, 1fr));
        gap: 16px;
        margin-bottom: 28px;
    }

    .stat-card {
        background: #fff;
        border-radius: var(--radius);
        padding: 20px 16px;
        text-align: center;
        border: 1px solid var(--border);
        transition: all 0.25s ease;
        position: relative;
        overflow: hidden;
    }

    .stat-card::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        height: 3px;
        border-radius: var(--radius) var(--radius) 0 0;
    }

    .stat-card.saldo::before { background: var(--primary); }
    .stat-card.pendentes::before { background: var(--warning); }
    .stat-card.aprovadas::before { background: var(--success); }
    .stat-card.andamento::before { background: #8b5cf6; }
    .stat-card.total::before { background: var(--gray); }

    .stat-card:hover {
        transform: translateY(-4px);
        box-shadow: var(--shadow-hover);
        border-color: transparent;
    }

    .stat-card .number {
        font-size: 30px;
        font-weight: 700;
        line-height: 1.2;
    }

    .stat-card.saldo .number { color: var(--primary); }
    .stat-card.pendentes .number { color: var(--warning); }
    .stat-card.aprovadas .number { color: var(--success); }
    .stat-card.andamento .number { color: #8b5cf6; }
    .stat-card.total .number { color: var(--gray); }

    .stat-card .label {
        font-size: 13px;
        color: var(--gray);
        margin-top: 4px;
        font-weight: 500;
    }

    .filters-section {
        display: flex;
        flex-wrap: wrap;
        gap: 10px;
        margin-bottom: 20px;
        align-items: center;
    }

    .filters-section .filter-label {
        font-size: 13px;
        font-weight: 600;
        color: var(--gray);
        margin-right: 4px;
    }

    .filter-btn {
        padding: 6px 16px;
        border: 1px solid var(--border);
        border-radius: 20px;
        background: #fff;
        color: var(--gray);
        font-size: 12px;
        font-weight: 500;
        cursor: pointer;
        transition: all 0.2s ease;
    }

    .filter-btn:hover {
        background: var(--gray-light);
        border-color: #cbd5e1;
    }

    .filter-btn.active {
        background: var(--primary);
        color: #fff;
        border-color: var(--primary);
    }

    .table-wrapper {
        background: #fff;
        border-radius: var(--radius);
        border: 1px solid var(--border);
        overflow: hidden;
        box-shadow: var(--shadow);
        margin-bottom: 30px;
    }

    .table-header-custom {
        padding: 16px 20px;
        border-bottom: 1px solid var(--border);
        display: flex;
        justify-content: space-between;
        align-items: center;
        flex-wrap: wrap;
        gap: 10px;
        background: #fafbfc;
    }

    .table-header-custom .title {
        font-weight: 600;
        font-size: 15px;
        color: var(--dark);
        display: flex;
        align-items: center;
        gap: 10px;
    }

    .table-header-custom .title .count {
        font-weight: 400;
        color: var(--gray);
        font-size: 13px;
        background: var(--gray-light);
        padding: 2px 10px;
        border-radius: 12px;
    }

    .table-responsive {
        overflow-x: auto;
        -webkit-overflow-scrolling: touch;
    }

    .table-custom {
        width: 100%;
        border-collapse: collapse;
        font-size: 14px;
        min-width: 700px;
    }

    .table-custom thead th {
        background: #f8fafc;
        color: var(--gray);
        font-weight: 600;
        font-size: 11px;
        text-transform: uppercase;
        letter-spacing: 0.6px;
        padding: 14px 16px;
        text-align: left;
        border-bottom: 2px solid var(--border);
        white-space: nowrap;
    }

    .table-custom tbody td {
        padding: 14px 16px;
        border-bottom: 1px solid var(--border);
        vertical-align: middle;
    }

    .table-custom tbody tr:last-child td {
        border-bottom: none;
    }

    .table-custom tbody tr:hover td {
        background: #fafbfc;
    }

    .table-custom .empty-row td {
        text-align: center;
        padding: 60px 20px;
        color: var(--gray);
    }

    .table-custom .empty-row .empty-icon {
        font-size: 48px;
        display: block;
        margin-bottom: 16px;
        color: #cbd5e1;
    }

    .table-custom .empty-row h4 {
        font-size: 18px;
        color: var(--dark);
        margin-bottom: 6px;
    }

    .table-custom .empty-row p {
        font-size: 14px;
        color: var(--gray);
        margin: 0;
    }

    .badge-status {
        padding: 5px 14px;
        border-radius: 20px;
        font-size: 11px;
        font-weight: 600;
        display: inline-flex;
        align-items: center;
        gap: 6px;
        border: 1px solid transparent;
        white-space: nowrap;
    }

    .badge-status .dot {
        width: 6px;
        height: 6px;
        border-radius: 50%;
        display: inline-block;
    }

    .badge-status.solicitada {
        background: var(--warning-light);
        color: #d97706;
        border-color: #fde68a;
    }
    .badge-status.solicitada .dot { background: #d97706; }

    .badge-status.aprovada {
        background: var(--success-light);
        color: #059669;
        border-color: #a7f3d0;
    }
    .badge-status.aprovada .dot { background: #059669; }

    .badge-status.em_andamento {
        background: #ede9fe;
        color: #7c3aed;
        border-color: #c4b5fd;
    }
    .badge-status.em_andamento .dot { background: #7c3aed; }

    .badge-status.concluida {
        background: #dbeafe;
        color: #2563eb;
        border-color: #93c5fd;
    }
    .badge-status.concluida .dot { background: #2563eb; }

    .badge-status.rejeitada {
        background: var(--danger-light);
        color: #dc2626;
        border-color: #fca5a5;
    }
    .badge-status.rejeitada .dot { background: #dc2626; }

    .badge-status.cancelada {
        background: #f1f5f9;
        color: #64748b;
        border-color: #cbd5e1;
    }
    .badge-status.cancelada .dot { background: #64748b; }

    .badge-status.pendente {
        background: var(--warning-light);
        color: #d97706;
        border-color: #fde68a;
    }
    .badge-status.pendente .dot { background: #d97706; }

    .badge-status.aprovado {
        background: var(--success-light);
        color: #059669;
        border-color: #a7f3d0;
    }
    .badge-status.aprovado .dot { background: #059669; }

    .badge-status.em_execucao {
        background: #ede9fe;
        color: #7c3aed;
        border-color: #c4b5fd;
    }
    .badge-status.em_execucao .dot { background: #7c3aed; }

    .badge-status.concluido {
        background: #dbeafe;
        color: #2563eb;
        border-color: #93c5fd;
    }
    .badge-status.concluido .dot { background: #2563eb; }

    .badge-status.cancelado {
        background: #f1f5f9;
        color: #64748b;
        border-color: #cbd5e1;
    }
    .badge-status.cancelado .dot { background: #64748b; }

    .action-btns {
        display: flex;
        gap: 4px;
        flex-wrap: wrap;
        justify-content: center;
    }

    .btn-icon {
        width: 34px;
        height: 34px;
        border: none;
        border-radius: 8px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        font-size: 13px;
        transition: all 0.2s ease;
        background: transparent;
        color: var(--gray);
        text-decoration: none;
    }

    .btn-icon:hover {
        transform: scale(1.1);
    }

    .btn-icon.view { color: var(--primary); }
    .btn-icon.view:hover { background: var(--primary-light); }

    .btn-icon.edit { color: var(--warning); }
    .btn-icon.edit:hover { background: var(--warning-light); }

    .btn-icon.delete { color: var(--danger); }
    .btn-icon.delete:hover { background: var(--danger-light); }

    .btn-icon.success { color: var(--success); }
    .btn-icon.success:hover { background: var(--success-light); }

    .btn-icon.purple { color: #8b5cf6; }
    .btn-icon.purple:hover { background: #ede9fe; }

    @media (max-width: 768px) {
        .ferias-container { padding: 12px; }
        .page-header { flex-direction: column; align-items: stretch; }
        .page-header h1 { font-size: 20px; }
        .page-header h1 i { padding: 10px; font-size: 18px; }
        .btn-primary-custom { justify-content: center; padding: 10px 20px; }
        .stats-grid { grid-template-columns: repeat(2, 1fr); gap: 12px; }
        .stat-card { padding: 14px 12px; }
        .stat-card .number { font-size: 24px; }
        .stat-card .label { font-size: 11px; }
        .table-header-custom { padding: 12px 14px; }
        .table-header-custom .title { font-size: 13px; }
        .table-custom { font-size: 12px; min-width: 600px; }
        .table-custom thead th, .table-custom tbody td { padding: 10px 12px; }
        .badge-status { font-size: 10px; padding: 3px 10px; }
        .btn-icon { width: 30px; height: 30px; font-size: 12px; }
        .filters-section { gap: 6px; }
        .filter-btn { font-size: 11px; padding: 4px 12px; }
    }

    @media (max-width: 480px) {
        .stats-grid { grid-template-columns: 1fr 1fr; gap: 10px; }
        .stat-card { padding: 12px 8px; }
        .stat-card .number { font-size: 20px; }
        .stat-card .label { font-size: 10px; }
        .table-custom { font-size: 11px; min-width: 480px; }
        .table-custom thead th, .table-custom tbody td { padding: 8px 8px; }
        .table-header-custom { padding: 10px 12px; }
        .table-header-custom .title { font-size: 12px; }
        .badge-status { font-size: 9px; padding: 2px 8px; }
        .btn-icon { width: 26px; height: 26px; font-size: 10px; }
        .page-header h1 { font-size: 17px; }
        .page-header h1 i { padding: 8px; font-size: 15px; }
    }

    @keyframes fadeInUp {
        from { opacity: 0; transform: translateY(15px); }
        to { opacity: 1; transform: translateY(0); }
    }

    .stat-card { animation: fadeInUp 0.4s ease forwards; }
    .stat-card:nth-child(1) { animation-delay: 0.05s; }
    .stat-card:nth-child(2) { animation-delay: 0.10s; }
    .stat-card:nth-child(3) { animation-delay: 0.15s; }
    .stat-card:nth-child(4) { animation-delay: 0.20s; }
    .stat-card:nth-child(5) { animation-delay: 0.25s; }
</style>

<div class="ferias-container">
    <!-- HEADER -->
    <div class="page-header">
        <h1>
            <i class="fas fa-umbrella-beach"></i>
            Minhas Férias
            <span class="subtitle">— Gerencie suas solicitações e veja seu plano</span>
        </h1>
        <div>
            <a href="${pageContext.request.contextPath}/ferias/nova" 
               class="btn-primary-custom">
                <i class="fas fa-plus-circle"></i> Nova Solicitação
            </a>
        </div>
    </div>

    <!-- CARDS -->
    <div class="stats-grid">
        <div class="stat-card saldo">
            <div class="number">${saldoFerias != null ? saldoFerias : 0}</div>
            <div class="label">Dias Disponíveis</div>
        </div>
        <div class="stat-card pendentes">
            <div class="number">${pendentes != null ? pendentes : 0}</div>
            <div class="label">Pendentes</div>
        </div>
        <div class="stat-card aprovadas">
            <div class="number">${aprovadas != null ? aprovadas : 0}</div>
            <div class="label">Aprovadas</div>
        </div>
        <div class="stat-card andamento">
            <div class="number">${emAndamento != null ? emAndamento : 0}</div>
            <div class="label">Em Andamento</div>
        </div>
        <div class="stat-card total">
            <div class="number">${total != null ? total : 0}</div>
            <div class="label">Total Solicitações</div>
        </div>
    </div>

    <!-- FILTROS -->
    <div class="filters-section">
        <span class="filter-label"><i class="fas fa-filter"></i> Filtrar:</span>
        <button class="filter-btn active" data-filter="all">Todos</button>
        <button class="filter-btn" data-filter="SOLICITADA">Pendentes</button>
        <button class="filter-btn" data-filter="APROVADA">Aprovadas</button>
        <button class="filter-btn" data-filter="EM_ANDAMENTO">Em Andamento</button>
        <button class="filter-btn" data-filter="CONCLUIDA">Concluídas</button>
        <button class="filter-btn" data-filter="REJEITADA">Rejeitadas</button>
        <button class="filter-btn" data-filter="CANCELADA">Canceladas</button>
    </div>

    <!-- Tabela de Solicitações - CORRIGIDA -->
<div class="table-wrapper">
    <div class="table-header-custom">
        <div class="title">
            <i class="fas fa-list-ul"></i>
            Minhas Solicitações
            <span class="count">${total != null ? total : 0}</span>
        </div>
        <div style="font-size: 13px; color: var(--gray);">
            <i class="fas fa-clock"></i> Atualizado: <fmt:formatDate value="<%= new java.util.Date() %>" pattern="dd/MM/yyyy HH:mm" />
        </div>
    </div>

    <div class="table-responsive">
        <table class="table-custom" id="tabelaFerias">
            <thead>
                <tr>
                    <th>Período</th>
                    <th>Dias</th>
                    <th>Status</th>
                    <th>Solicitação</th>
                    <th style="text-align: center;">Ações</th>
                </tr>
            </thead>
            <tbody>
                <c:choose>
                    <c:when test="${empty listaFerias}">
                        <tr class="empty-row">
                            <td colspan="5">
                                <span class="empty-icon"><i class="fas fa-umbrella-beach"></i></span>
                                <h4>Nenhuma solicitação de férias</h4>
                                <p>Clique em <strong>"Nova Solicitação"</strong> para fazer seu primeiro pedido.</p>
                            </td>
                        </tr>
                    </c:when>
                    <c:otherwise>
                        <c:forEach items="${listaFerias}" var="f">
                            <tr data-status="${f.status}">
                                <td>
                                    <strong>
                                        <fmt:formatDate value="${f.dataInicio}" pattern="dd/MM/yyyy" />
                                    </strong>
                                    <span style="color: var(--gray); margin: 0 4px;">→</span>
                                    <strong>
                                        <fmt:formatDate value="${f.dataFim}" pattern="dd/MM/yyyy" />
                                    </strong>
                                </td>
                                <td>
                                    <strong style="font-size: 16px; color: var(--primary);">
                                        ${f.diasUteis}
                                    </strong>
                                    <span style="font-size: 12px; color: var(--gray); display: block;">
                                        ${f.diasCalendario} dias corridos
                                    </span>
                                </td>
                                <td>
                                    <span class="badge-status 
                                        ${f.status == 'SOLICITADA' ? 'solicitada' : 
                                          f.status == 'APROVADA' ? 'aprovada' : 
                                          f.status == 'EM_ANDAMENTO' ? 'em_andamento' : 
                                          f.status == 'CONCLUIDA' ? 'concluida' : 
                                          f.status == 'REJEITADA' ? 'rejeitada' : 
                                          f.status == 'CANCELADA' ? 'cancelada' : ''}">
                                        <span class="dot"></span>
                                        <c:choose>
                                            <c:when test="${f.status == 'SOLICITADA'}">Pendente</c:when>
                                            <c:when test="${f.status == 'APROVADA'}">Aprovada</c:when>
                                            <c:when test="${f.status == 'EM_ANDAMENTO'}">Em Andamento</c:when>
                                            <c:when test="${f.status == 'CONCLUIDA'}">Concluída</c:when>
                                            <c:when test="${f.status == 'REJEITADA'}">Rejeitada</c:when>
                                            <c:when test="${f.status == 'CANCELADA'}">Cancelada</c:when>
                                            <c:otherwise>${f.status}</c:otherwise>
                                        </c:choose>
                                    </span>
                                    
                                    <c:if test="${f.status == 'REJEITADA' && not empty f.motivoRejeicao}">
                                        <div style="font-size: 11px; color: var(--danger); margin-top: 4px;">
                                            <i class="fas fa-info-circle"></i> ${f.motivoRejeicao}
                                        </div>
                                    </c:if>
                                </td>
                                <td style="font-size: 12px; color: var(--gray);">
                                    <fmt:formatDate value="${f.dataSolicitacao}" pattern="dd/MM/yyyy" />
                                    <br>
                                    <span style="font-size: 10px;">
                                        <fmt:formatDate value="${f.dataSolicitacao}" pattern="HH:mm" />
                                    </span>
                                </td>
                                <td style="text-align: center;">
                                    <div class="action-btns" style="justify-content: center;">
                                       

                                        <!-- Cancelar - APENAS PARA SOLICITAÇÕES PENDENTES -->
                                        <c:if test="${f.status == 'SOLICITADA'}">
                                            <button class="btn-icon delete" 
                                                    onclick="cancelarSolicitacao(${f.id})" 
                                                    title="Cancelar solicitação">
                                                <i class="fas fa-times"></i>
                                            </button>
                                        </c:if>
                                    </div>
                                </td>
                            </tr>
                        </c:forEach>
                    </c:otherwise>
                </c:choose>
            </tbody>
        </table>
    </div>
</div>

    <!-- PLANO DE FÉRIAS -->
    <div class="table-wrapper">
        <div class="table-header-custom">
            <div class="title">
                <i class="fas fa-calendar-alt"></i>
                Meu Plano de Férias
                <span class="count">${totalPlanos != null ? totalPlanos : 0}</span>
            </div>
            <div style="font-size: 13px; color: var(--gray);">
                <i class="fas fa-info-circle"></i> Plano definido pelo RH
            </div>
        </div>

        <div class="table-responsive">
            <table class="table-custom">
                <thead>
                    <tr>
                        <th>Mês Planejado</th>
                        <th>Prioridade</th>
                        <th>Status</th>
                        <th>Observação</th>
                    </tr>
                </thead>
                <tbody>
                    <c:choose>
                        <c:when test="${empty planos}">
                            <tr class="empty-row">
                                <td colspan="4">
                                    <span class="empty-icon"><i class="fas fa-calendar-plus"></i></span>
                                    <h4>Nenhum plano de férias definido</h4>
                                    <p>O RH ainda não gerou um plano para você.</p>
                                </td>
                            </tr>
                        </c:when>
                        <c:otherwise>
                            <c:forEach items="${planos}" var="p">
                                <tr>
                                    <td>
                                        <strong>Mês ${p.mesPlanejado}</strong>
                                        <br>
                                        <span style="font-size: 12px; color: var(--gray);">
                                            <i class="fas fa-calendar"></i> ${p.ano}
                                        </span>
                                    </td>
                                    <td>
                                        <c:choose>
                                            <c:when test="${p.prioridade == 1}">
                                                <span style="background: #fee2e2; color: #dc2626; padding: 4px 12px; border-radius: 12px; font-size: 12px; font-weight: 600;">
                                                    <i class="fas fa-arrow-up"></i> Alta
                                                </span>
                                            </c:when>
                                            <c:when test="${p.prioridade == 2}">
                                                <span style="background: #fef3c7; color: #d97706; padding: 4px 12px; border-radius: 12px; font-size: 12px; font-weight: 600;">
                                                    <i class="fas fa-minus"></i> Média
                                                </span>
                                            </c:when>
                                            <c:otherwise>
                                                <span style="background: #dbeafe; color: #2563eb; padding: 4px 12px; border-radius: 12px; font-size: 12px; font-weight: 600;">
                                                    <i class="fas fa-arrow-down"></i> Baixa
                                                </span>
                                            </c:otherwise>
                                        </c:choose>
                                    </td>
                                    <td>
                                        <span class="badge-status 
                                            ${p.status == 'PENDENTE' ? 'pendente' : 
                                              p.status == 'APROVADO' ? 'aprovado' : 
                                              p.status == 'EM_EXECUCAO' ? 'em_execucao' : 
                                              p.status == 'CONCLUIDO' ? 'concluido' : 
                                              p.status == 'CANCELADO' ? 'cancelado' : ''}">
                                            <span class="dot"></span>
                                            <c:choose>
                                                <c:when test="${p.status == 'PENDENTE'}">Pendente</c:when>
                                                <c:when test="${p.status == 'APROVADO'}">Aprovado</c:when>
                                                <c:when test="${p.status == 'EM_EXECUCAO'}">Em Execução</c:when>
                                                <c:when test="${p.status == 'CONCLUIDO'}">Concluído</c:when>
                                                <c:when test="${p.status == 'CANCELADO'}">Cancelado</c:when>
                                                <c:otherwise>${p.status}</c:otherwise>
                                            </c:choose>
                                        </span>
                                    </td>
                                    <td style="font-size: 13px; color: var(--gray); max-width: 200px; word-break: break-word;">
                                        ${p.observacao != null ? p.observacao : '-'}
                                    </td>
                                </tr>
                            </c:forEach>
                        </c:otherwise>
                    </c:choose>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
// FILTROS
document.querySelectorAll('.filter-btn').forEach(btn => {
    btn.addEventListener('click', function() {
        document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
        this.classList.add('active');
        
        const filter = this.dataset.filter;
        const rows = document.querySelectorAll('#tabelaFerias tbody tr');
        
        rows.forEach(row => {
            if (filter === 'all') {
                row.style.display = '';
            } else {
                const status = row.dataset.status;
                row.style.display = status === filter ? '' : 'none';
            }
        });
    });
});

// CANCELAR
function cancelarSolicitacao(id) {
    if (!confirm('Deseja realmente cancelar esta solicitação de férias?')) return;
    
    fetch('${pageContext.request.contextPath}/ferias/cancelar', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: 'id=' + id
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            showNotification('success', 'Cancelado', data.message);
            setTimeout(() => location.reload(), 1200);
        } else {
            showNotification('error', 'Erro', data.message);
        }
    })
    .catch(error => {
        showNotification('error', 'Erro', 'Erro ao cancelar solicitação');
    });
}

// CHECKOUT
function checkoutFerias(id) {
    if (!confirm('Confirmar início das férias?')) return;
    
    fetch('${pageContext.request.contextPath}/ferias/checkout', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: 'id=' + id
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            showNotification('success', 'Checkout', data.message);
            setTimeout(() => location.reload(), 1200);
        } else {
            showNotification('error', 'Erro', data.message);
        }
    })
    .catch(error => {
        showNotification('error', 'Erro', 'Erro ao iniciar férias');
    });
}

// CHECKIN
function checkinFerias(id) {
    if (!confirm('Confirmar retorno das férias?')) return;
    
    fetch('${pageContext.request.contextPath}/ferias/checkin', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: 'id=' + id
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            showNotification('success', 'Checkin', data.message);
            setTimeout(() => location.reload(), 1200);
        } else {
            showNotification('error', 'Erro', data.message);
        }
    })
    .catch(error => {
        showNotification('error', 'Erro', 'Erro ao finalizar férias');
    });
}

// VER DETALHES
function verDetalhes(id) {
    window.location.href = '${pageContext.request.contextPath}/ferias/detalhes/' + id;
}

// NOTIFICATIONS
function showNotification(type, title, message) {
    if (typeof window.showNotification === 'function') {
        window.showNotification(type, title, message);
    } else {
        alert(title + '\n\n' + message);
    }
}
</script>

<jsp:include page="/WEB-INF/views/layout/footer.jsp" />
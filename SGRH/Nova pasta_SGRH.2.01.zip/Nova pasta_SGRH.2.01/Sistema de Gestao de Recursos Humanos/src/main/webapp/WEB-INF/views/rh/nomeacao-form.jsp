<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core"%>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt"%>

<jsp:include page="/WEB-INF/views/layout/header.jsp">
    <jsp:param name="pageTitle" value="${acao == 'cadastrar' ? 'Nova Nomeação' : 'Editar Nomeação'}" />
    <jsp:param name="activeMenu" value="nomeacao" />
</jsp:include>

<style>
    .required { color: var(--danger); font-weight: 700; }
    .form-group label { font-weight: 600; font-size: 13px; color: var(--dark); margin-bottom: 4px; }
    .form-control, .form-select { border-radius: 10px; border: 1px solid var(--gray-border); padding: 8px 12px; font-size: 13px; transition: var(--transition); }
    .form-control:focus, .form-select:focus { border-color: var(--primary); box-shadow: 0 0 0 3px rgba(79,70,229,0.1); }
    .form-container { background: #fff; border-radius: var(--border-radius); padding: 28px; box-shadow: var(--shadow-sm); border: 1px solid var(--gray-border); margin-bottom: 24px; }
    .form-title { font-size: 20px; font-weight: 700; color: var(--dark); margin-bottom: 24px; display: flex; align-items: center; gap: 12px; }
    .form-title i { color: var(--primary); }
    .form-actions { margin-top: 24px; padding-top: 20px; border-top: 1px solid var(--gray-border); display: flex; gap: 12px; flex-wrap: wrap; }
    .helper-text { font-size: 11px; color: var(--gray); margin-top: 4px; }
    .helper-text i { color: var(--info); }
    .form-check-input:checked { background-color: var(--primary); border-color: var(--primary); }

    select[multiple] {
        min-height: 120px;
        padding: 8px;
        border-radius: 10px;
    }
    select[multiple] option {
        padding: 6px 10px;
        border-radius: 4px;
        margin-bottom: 2px;
    }
    select[multiple] option:checked {
        background: linear-gradient(135deg, var(--primary), var(--secondary));
        color: #fff;
    }
    select[multiple] option:hover {
        background: var(--gray-light);
    }

    .badge-status {
        display: inline-block;
        padding: 2px 10px;
        border-radius: 12px;
        font-size: 11px;
        font-weight: 600;
        margin: 2px 4px 2px 0;
        border: 1px solid transparent;
        animation: fadeInBadge 0.3s ease;
    }
    
    .badge-status.diretor { background: rgba(139,92,246,0.1); color: #7c3aed; border-color: rgba(139,92,246,0.15); }
    .badge-status.gerente { background: rgba(245,158,11,0.1); color: var(--warning); border-color: rgba(245,158,11,0.15); }
    .badge-status.coordenador { background: rgba(239,68,68,0.1); color: var(--danger); border-color: rgba(239,68,68,0.15); }
    .badge-status.supervisor { background: rgba(139,92,246,0.1); color: #7c3aed; border-color: rgba(139,92,246,0.15); }
    .badge-status.analista { background: rgba(79,70,229,0.1); color: var(--primary); border-color: rgba(79,70,229,0.15); }
    .badge-status.desenvolvedor { background: rgba(16,185,129,0.1); color: var(--success); border-color: rgba(16,185,129,0.15); }
    .badge-status.assistente { background: rgba(236,72,153,0.1); color: #db2777; border-color: rgba(236,72,153,0.15); }
    .badge-status.tecnico { background: rgba(59,130,246,0.1); color: #2563eb; border-color: rgba(59,130,246,0.15); }
    .badge-status.consultor { background: rgba(20,184,166,0.1); color: #0d9488; border-color: rgba(20,184,166,0.15); }
    .badge-status.auditor { background: rgba(168,85,247,0.1); color: #7e22ce; border-color: rgba(168,85,247,0.15); }
    .badge-status.pesquisador { background: rgba(251,146,60,0.1); color: #ea580c; border-color: rgba(251,146,60,0.15); }
    .badge-status.docente { background: rgba(34,197,94,0.1); color: #16a34a; border-color: rgba(34,197,94,0.15); }
    .badge-status.outro { background: rgba(107,114,128,0.1); color: var(--gray); border-color: rgba(107,114,128,0.15); }

    .badge-cargo {
        display: inline-block;
        background: rgba(16,185,129,0.1);
        color: var(--success);
        padding: 2px 10px;
        border-radius: 12px;
        font-size: 11px;
        font-weight: 600;
        border: 1px solid rgba(16,185,129,0.15);
        animation: fadeInBadge 0.3s ease;
    }
    
    @keyframes fadeInBadge {
        from { opacity: 0; transform: scale(0.8); }
        to { opacity: 1; transform: scale(1); }
    }

    @media (max-width: 768px) {
        .form-container { padding: 20px; }
        .form-title { font-size: 18px; }
        .form-actions { flex-direction: column; }
        .form-actions .btn-primary-custom, .form-actions .btn-outline-custom { width: 100%; justify-content: center; }
    }

    @media (max-width: 576px) {
        .form-container { padding: 16px; }
        .form-title { font-size: 16px; }
        select[multiple] { min-height: 80px; }
    }
</style>

<div class="form-container animate-in">
    <div class="form-title">
        <i class="fas ${acao == 'cadastrar' ? 'fa-plus-circle' : 'fa-edit'}"></i>
        ${acao == 'cadastrar' ? 'Cadastrar Nomeação' : 'Editar Nomeação'}
    </div>

    <form action="${pageContext.request.contextPath}/nomeacao" method="post" id="nomeacaoForm" novalidate>
        <input type="hidden" name="id" value="${nomeacao.id}">

        <div class="row g-3">
            <!-- Funcionário -->
            <div class="col-md-6">
                <div class="form-group">
                    <label for="idFuncionario">Funcionário <span class="required">*</span></label>
                    <select class="form-select" name="idFuncionario" id="idFuncionario" required>
                        <option value="">Selecione um funcionário</option>
                        <c:forEach items="${funcionarios}" var="f">
                            <option value="${f.id}" ${nomeacao.idFuncionario == f.id ? 'selected' : ''}>
                                ${f.nome}
                            </option>
                        </c:forEach>
                    </select>
                    <div class="helper-text"><i class="fas fa-info-circle"></i> Selecione o funcionário a ser nomeado</div>
                </div>
            </div>

            <!-- Despacho -->
            <div class="col-md-6">
                <div class="form-group">
                    <label for="despacho">Despacho <span class="required">*</span></label>
                    <input type="text" class="form-control" name="despacho" id="despacho"
                           value="${nomeacao.despacho}" required 
                           placeholder="Nº do despacho" maxlength="50">
                    <div class="helper-text"><i class="fas fa-info-circle"></i> Número/Referência do despacho de nomeação</div>
                </div>
            </div>

            <!-- Local -->
            <div class="col-md-6">
                <div class="form-group">
                    <label for="local">Local <span class="required">*</span></label>
                    <input type="text" class="form-control" name="local" id="local"
                           value="${nomeacao.local}" required 
                           placeholder="Cidade/País" maxlength="45">
                    <div class="helper-text"><i class="fas fa-info-circle"></i> Local onde a nomeação é válida</div>
                </div>
            </div>

            <!-- FUNÇÕES (MÚLTIPLA) -->
            <div class="col-md-6">
                <div class="form-group">
                    <label for="funcoes">Funções Desempenhadas <span class="required">*</span></label>
                    <select class="form-select" name="funcoes" id="funcoes" multiple required>
                        <option value="DIRETOR" ${nomeacao.funcoes != null && nomeacao.funcoes.contains('DIRETOR') ? 'selected' : ''}>Diretor</option>
                        <option value="GERENTE" ${nomeacao.funcoes != null && nomeacao.funcoes.contains('GERENTE') ? 'selected' : ''}>Gerente</option>
                        <option value="COORDENADOR" ${nomeacao.funcoes != null && nomeacao.funcoes.contains('COORDENADOR') ? 'selected' : ''}>Coordenador</option>
                        <option value="SUPERVISOR" ${nomeacao.funcoes != null && nomeacao.funcoes.contains('SUPERVISOR') ? 'selected' : ''}>Supervisor</option>
                        <option value="ANALISTA" ${nomeacao.funcoes != null && nomeacao.funcoes.contains('ANALISTA') ? 'selected' : ''}>Analista</option>
                        <option value="DESENVOLVEDOR" ${nomeacao.funcoes != null && nomeacao.funcoes.contains('DESENVOLVEDOR') ? 'selected' : ''}>Desenvolvedor</option>
                        <option value="ASSISTENTE" ${nomeacao.funcoes != null && nomeacao.funcoes.contains('ASSISTENTE') ? 'selected' : ''}>Assistente</option>
                        <option value="TECNICO" ${nomeacao.funcoes != null && nomeacao.funcoes.contains('TECNICO') ? 'selected' : ''}>Técnico</option>
                        <option value="CONSULTOR" ${nomeacao.funcoes != null && nomeacao.funcoes.contains('CONSULTOR') ? 'selected' : ''}>Consultor</option>
                        <option value="AUDITOR" ${nomeacao.funcoes != null && nomeacao.funcoes.contains('AUDITOR') ? 'selected' : ''}>Auditor</option>
                        <option value="PESQUISADOR" ${nomeacao.funcoes != null && nomeacao.funcoes.contains('PESQUISADOR') ? 'selected' : ''}>Pesquisador</option>
                        <option value="DOCENTE" ${nomeacao.funcoes != null && nomeacao.funcoes.contains('DOCENTE') ? 'selected' : ''}>Docente</option>
                        <option value="OUTRO" ${nomeacao.funcoes != null && nomeacao.funcoes.contains('OUTRO') ? 'selected' : ''}>Outro</option>
                    </select>
                    <div class="helper-text">
                        <i class="fas fa-info-circle"></i> 
                        Segure <strong>Ctrl</strong> (Windows) ou <strong>Cmd</strong> (Mac) para selecionar múltiplas funções
                    </div>
                    <div id="funcoesSelecionadas" style="margin-top: 8px;"></div>
                </div>
            </div>

            <!-- CARGO -->
            <div class="col-md-6">
                <div class="form-group">
                    <label for="cargo">Cargo <span class="required">*</span></label>
                    <select class="form-select" name="cargo" id="cargo" required>
                        <option value="">Selecione um cargo</option>
                        <option value="EXECUTIVO" ${nomeacao.cargo == 'EXECUTIVO' ? 'selected' : ''}>Executivo</option>
                        <option value="SENIOR" ${nomeacao.cargo == 'SENIOR' ? 'selected' : ''}>Sênior</option>
                        <option value="PLENO" ${nomeacao.cargo == 'PLENO' ? 'selected' : ''}>Pleno</option>
                        <option value="JUNIOR" ${nomeacao.cargo == 'JUNIOR' ? 'selected' : ''}>Júnior</option>
                        <option value="ESTAGIARIO" ${nomeacao.cargo == 'ESTAGIARIO' ? 'selected' : ''}>Estagiário</option>
                        <option value="TRAINEE" ${nomeacao.cargo == 'TRAINEE' ? 'selected' : ''}>Trainee</option>
                        <option value="CONSULTOR" ${nomeacao.cargo == 'CONSULTOR' ? 'selected' : ''}>Consultor</option>
                        <option value="AUDITOR" ${nomeacao.cargo == 'AUDITOR' ? 'selected' : ''}>Auditor</option>
                        <option value="DOCENTE" ${nomeacao.cargo == 'DOCENTE' ? 'selected' : ''}>Docente</option>
                        <option value="PESQUISADOR" ${nomeacao.cargo == 'PESQUISADOR' ? 'selected' : ''}>Pesquisador</option>
                        <option value="OUTRO" ${nomeacao.cargo == 'OUTRO' ? 'selected' : ''}>Outro</option>
                    </select>
                    <div class="helper-text"><i class="fas fa-info-circle"></i> Nível/grau do cargo ocupado</div>
                    <div id="cargoSelecionado" style="margin-top: 8px;"></div>
                </div>
            </div>

            <!-- Data Nomeação -->
            <div class="col-md-4">
                <div class="form-group">
                    <label for="dataNomeacao">Data da Nomeação <span class="required">*</span></label>
                    <input type="date" class="form-control" name="dataNomeacao" id="dataNomeacao"
                           value="${nomeacao.dataNomeacao != null ? nomeacao.dataNomeacao : ''}" required>
                </div>
            </div>

            <!-- Data Início -->
            <div class="col-md-4">
                <div class="form-group">
                    <label for="dataInicio">Data de Início <span class="required">*</span></label>
                    <input type="date" class="form-control" name="dataInicio" id="dataInicio"
                           value="${nomeacao.dataInicio != null ? nomeacao.dataInicio : ''}" required>
                </div>
            </div>

            <!-- Data Fim -->
            <div class="col-md-4">
                <div class="form-group">
                    <label for="dataFim">Data de Fim</label>
                    <input type="date" class="form-control" name="dataFim" id="dataFim"
                           value="${nomeacao.dataFim != null ? nomeacao.dataFim : ''}">
                    <div class="helper-text"><i class="fas fa-info-circle"></i> Deixe em branco se for indeterminado</div>
                </div>
            </div>

            <!-- Status -->
            <div class="col-md-6">
                <div class="form-group">
                    <label for="status">Status <span class="required">*</span></label>
                    <select class="form-select" name="status" id="status" required>
                        <option value="ATIVA" ${nomeacao.status == 'ATIVA' ? 'selected' : ''}>Ativa</option>
                        <option value="ENCERRADA" ${nomeacao.status == 'ENCERRADA' ? 'selected' : ''}>Encerrada</option>
                        <option value="SUSPENSA" ${nomeacao.status == 'SUSPENSA' ? 'selected' : ''}>Suspensa</option>
                    </select>
                    <div class="helper-text"><i class="fas fa-info-circle"></i> Situação atual da nomeação</div>
                </div>
            </div>

            <!-- Observação -->
            <div class="col-12">
                <div class="form-group">
                    <label for="observacao">Observação</label>
                    <textarea class="form-control" name="observacao" id="observacao" 
                              rows="3" maxlength="500" 
                              placeholder="Observações adicionais sobre a nomeação">${nomeacao.observacao}</textarea>
                    <div class="helper-text"><i class="fas fa-info-circle"></i> Máximo 500 caracteres</div>
                </div>
            </div>
        </div>

        <div class="form-actions">
            <button type="submit" class="btn-primary-custom" id="btnSalvar">
                <i class="fas fa-save"></i> ${acao == 'cadastrar' ? 'Cadastrar' : 'Atualizar'}
            </button>
            <a href="${pageContext.request.contextPath}/nomeacao" class="btn-outline-custom">
                <i class="fas fa-times"></i> Cancelar
            </a>
        </div>
    </form>
</div>

<script>
const statusClassMap = {
    'DIRETOR': 'diretor', 'GERENTE': 'gerente', 'COORDENADOR': 'coordenador',
    'SUPERVISOR': 'supervisor', 'ANALISTA': 'analista', 'DESENVOLVEDOR': 'desenvolvedor',
    'ASSISTENTE': 'assistente', 'TECNICO': 'tecnico', 'CONSULTOR': 'consultor',
    'AUDITOR': 'auditor', 'PESQUISADOR': 'pesquisador', 'DOCENTE': 'docente', 'OUTRO': 'outro'
};

document.getElementById('funcoes').addEventListener('change', function() {
    const container = document.getElementById('funcoesSelecionadas');
    const selected = Array.from(this.selectedOptions).map(opt => opt.value);
    container.innerHTML = '';
    selected.forEach(function(val) {
        const badge = document.createElement('span');
        badge.className = 'badge-status ' + (statusClassMap[val] || 'outro');
        badge.textContent = val.charAt(0) + val.slice(1).toLowerCase();
        container.appendChild(badge);
    });
    if (selected.length === 0) {
        container.innerHTML = '<span style="font-size: 12px; color: var(--gray);">Nenhuma função selecionada</span>';
    }
});

document.getElementById('cargo').addEventListener('change', function() {
    const container = document.getElementById('cargoSelecionado');
    const selected = this.value;
    container.innerHTML = '';
    if (selected) {
        const badge = document.createElement('span');
        badge.className = 'badge-cargo';
        badge.textContent = 'Cargo: ' + selected.charAt(0) + selected.slice(1).toLowerCase();
        container.appendChild(badge);
    } else {
        container.innerHTML = '<span style="font-size: 12px; color: var(--gray);">Nenhum cargo selecionado</span>';
    }
});

document.addEventListener('DOMContentLoaded', function() {
    document.getElementById('funcoes').dispatchEvent(new Event('change'));
    document.getElementById('cargo').dispatchEvent(new Event('change'));
});

document.getElementById('nomeacaoForm').addEventListener('submit', function(e) {
    let isValid = true;
    let errorMessages = [];

    if (!document.getElementById('idFuncionario').value) {
        errorMessages.push('Selecione um funcionário');
        isValid = false;
    }
    if (document.getElementById('despacho').value.trim().length < 2) {
        errorMessages.push('Despacho deve ter no mínimo 2 caracteres');
        isValid = false;
    }
    if (document.getElementById('local').value.trim().length < 2) {
        errorMessages.push('Local deve ter no mínimo 2 caracteres');
        isValid = false;
    }
    if (document.getElementById('funcoes').selectedOptions.length === 0) {
        errorMessages.push('Selecione pelo menos uma função');
        isValid = false;
    }
    if (!document.getElementById('cargo').value) {
        errorMessages.push('Selecione o cargo');
        isValid = false;
    }

    const dataNomeacao = document.getElementById('dataNomeacao');
    const dataInicio = document.getElementById('dataInicio');
    const dataFim = document.getElementById('dataFim');

    if (!dataNomeacao.value) {
        errorMessages.push('Data da nomeação é obrigatória');
        isValid = false;
    }
    if (!dataInicio.value) {
        errorMessages.push('Data de início é obrigatória');
        isValid = false;
    }
    if (dataNomeacao.value && dataInicio.value && dataInicio.value < dataNomeacao.value) {
        errorMessages.push('Data de início não pode ser anterior à data da nomeação');
        isValid = false;
    }
    if (dataFim.value && dataInicio.value && dataFim.value < dataInicio.value) {
        errorMessages.push('Data de fim não pode ser anterior à data de início');
        isValid = false;
    }
    if (document.getElementById('observacao').value.length > 500) {
        errorMessages.push('Observação deve ter no máximo 500 caracteres');
        isValid = false;
    }

    if (!isValid) {
        e.preventDefault();
        alert('Erro de Validação:\n' + errorMessages.join('\n'));
        return false;
    }
    return true;
});

document.getElementById('dataInicio').addEventListener('change', function() {
    const dataNomeacao = document.getElementById('dataNomeacao').value;
    if (dataNomeacao && this.value && this.value < dataNomeacao) {
        alert('Data de início não pode ser anterior à data da nomeação');
    }
});

document.getElementById('dataFim').addEventListener('change', function() {
    const dataInicio = document.getElementById('dataInicio').value;
    if (dataInicio && this.value && this.value < dataInicio) {
        alert('Data de fim não pode ser anterior à data de início');
    }
});
</script>

<jsp:include page="/WEB-INF/views/layout/footer.jsp" />
<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="com.sigrh.util.ConfiguracaoUtil" %>
<%@ taglib prefix="c" uri="jakarta.tags.core"%>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt"%>

<jsp:include page="/WEB-INF/views/layout/header.jsp">
    <jsp:param name="pageTitle" value="Meus Dados" />
    <jsp:param name="activeMenu" value="meus-dados" />
</jsp:include>

<style>
    .profile-card {
        background: #fff;
        border-radius: var(--border-radius);
        padding: 28px;
        box-shadow: var(--shadow-sm);
        border: 1px solid var(--gray-border);
        margin-bottom: 24px;
    }
    .profile-avatar {
        width: 120px;
        height: 120px;
        border-radius: 50%;
        background: linear-gradient(135deg, var(--primary), var(--secondary));
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 48px;
        font-weight: 700;
        color: #fff;
        margin: 0 auto 16px;
        box-shadow: 0 4px 20px rgba(79,70,229,0.3);
    }
    .profile-name {
        text-align: center;
        font-size: 24px;
        font-weight: 700;
        color: var(--dark);
    }
    .profile-role {
        text-align: center;
        font-size: 14px;
        color: var(--gray);
        font-weight: 500;
    }
    .info-row {
        display: flex;
        justify-content: space-between;
        padding: 10px 0;
        border-bottom: 1px solid var(--gray-border);
    }
    .info-row:last-child {
        border-bottom: none;
    }
    .info-label {
        font-weight: 600;
        color: var(--gray);
        font-size: 13px;
    }
    .info-value {
        font-weight: 500;
        color: var(--dark);
        font-size: 13px;
    }
    
    /* ============================================================
       BADGES DE STATUS - CORRIGIDO
    ============================================================ */
    .badge-status {
        display: inline-block;
        padding: 3px 14px;
        border-radius: 20px;
        font-size: 12px;
        font-weight: 600;
        border: 1px solid transparent;
    }
    .badge-status-ATIVO {
        background: rgba(16,185,129,0.1);
        color: #059669;
        border-color: rgba(16,185,129,0.15);
    }
    .badge-status-INATIVO {
        background: rgba(239,68,68,0.1);
        color: #dc2626;
        border-color: rgba(239,68,68,0.15);
    }
    .badge-status-FERIAS {
        background: rgba(245,158,11,0.1);
        color: #d97706;
        border-color: rgba(245,158,11,0.15);
    }
    .badge-status-LICENCA {
        background: rgba(59,130,246,0.1);
        color: #2563eb;
        border-color: rgba(59,130,246,0.15);
    }
    .badge-status-AFASTADO {
        background: rgba(139,92,246,0.1);
        color: #7c3aed;
        border-color: rgba(139,92,246,0.15);
    }
    
    .info-grid {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 16px 32px;
    }
    
    @media (max-width: 768px) {
        .info-grid {
            grid-template-columns: 1fr;
        }
        .profile-avatar {
            width: 80px;
            height: 80px;
            font-size: 32px;
        }
        .profile-name {
            font-size: 20px;
        }
    }
</style>

<div class="profile-card animate-in">
    <div class="row">
        <!-- Coluna do Avatar -->
        <div class="col-md-3 text-center">
            <div class="profile-avatar">
                ${funcionario.nome.charAt(0)}${funcionario.nome.split(' ')[1].charAt(0)}
            </div>
            <div class="profile-name">${funcionario.nome}</div>
            <div class="profile-role">
                <!-- CORRIGIDO: Usando name() para obter o valor do Enum -->
                <span class="badge-status badge-status-${funcionario.status.name()}">
                    ${funcionario.status.name()}
                </span>
            </div>
            <div style="margin-top: 12px; font-size: 13px; color: var(--gray);">
                <i class="fas fa-id-card"></i> #${funcionario.id}
            </div>
        </div>
        
        <!-- Coluna das Informações -->
        <div class="col-md-9">
            <h5 style="font-weight: 700; color: var(--dark); margin-bottom: 16px;">
                <i class="fas fa-user-circle" style="color: var(--primary);"></i> Dados Pessoais
            </h5>
            
            <div class="info-grid">
                <!-- Nome Completo -->
                <div class="info-row">
                    <span class="info-label"><i class="fas fa-user"></i> Nome</span>
                    <span class="info-value">${funcionario.nome}</span>
                </div>
                
                <!-- Data de Nascimento -->
                <div class="info-row">
                    <span class="info-label"><i class="fas fa-calendar-alt"></i> Nascimento</span>
                    <span class="info-value">
                        <fmt:formatDate value="${funcionario.dataNascimento}" pattern="dd/MM/yyyy" />
                    </span>
                </div>
                
                <!-- Estado Civil -->
                <div class="info-row">
                    <span class="info-label"><i class="fas fa-heart"></i> Estado Civil</span>
                    <span class="info-value">${funcionario.estadoCivil}</span>
                </div>
                
                <!-- Nome do Cônjuge -->
                <c:if test="${not empty funcionario.nomeConjuge}">
                    <div class="info-row">
                        <span class="info-label"><i class="fas fa-user-friends"></i> Cônjuge</span>
                        <span class="info-value">${funcionario.nomeConjuge}</span>
                    </div>
                </c:if>
                
                <!-- Província -->
                <div class="info-row">
                    <span class="info-label"><i class="fas fa-map-marker-alt"></i> Província</span>
                    <span class="info-value">${funcionario.provincia}</span>
                </div>
                
                <!-- Distrito -->
                <div class="info-row">
                    <span class="info-label"><i class="fas fa-map-pin"></i> Distrito</span>
                    <span class="info-value">${funcionario.distrito}</span>
                </div>
                
                <!-- Telefone -->
                <div class="info-row">
                    <span class="info-label"><i class="fas fa-phone"></i> Telefone</span>
                    <span class="info-value">${funcionario.telefone}</span>
                </div>
                
                <!-- E-mail -->
                <div class="info-row">
                    <span class="info-label"><i class="fas fa-envelope"></i> E-mail</span>
                    <span class="info-value">${funcionario.emailEmpresa != null ? funcionario.emailEmpresa : '-'}</span>
                </div>
                
                <!-- NUIT -->
                <div class="info-row">
                    <span class="info-label"><i class="fas fa-id-card"></i> NUIT</span>
                    <span class="info-value">${funcionario.nuit}</span>
                </div>
                
                <!-- BI -->
                <div class="info-row">
                    <span class="info-label"><i class="fas fa-id-card-alt"></i> BI</span>
                    <span class="info-value">${funcionario.bi != null ? funcionario.bi : '-'}</span>
                </div>
                
                <!-- Data de Admissão -->
                <div class="info-row">
                    <span class="info-label"><i class="fas fa-calendar-check"></i> Admissão</span>
                    <span class="info-value">
                        <fmt:formatDate value="${funcionario.dataAdmissao}" pattern="dd/MM/yyyy" />
                    </span>
                </div>
                
                <!-- Setor -->
                <div class="info-row">
                    <span class="info-label"><i class="fas fa-building"></i> Setor</span>
                    <span class="info-value">${funcionario.setor != null ? funcionario.setor.nome : '-'}</span>
                </div>
                
                <!-- Banco -->
                <div class="info-row">
                    <span class="info-label"><i class="fas fa-university"></i> Banco</span>
                    <span class="info-value">${funcionario.banco}</span>
                </div>
                
                <!-- Número de Conta -->
                <div class="info-row">
                    <span class="info-label"><i class="fas fa-credit-card"></i> Conta</span>
                    <span class="info-value">${funcionario.numeroConta}</span>
                </div>
                
                <!-- Status -->
                <div class="info-row">
                    <span class="info-label"><i class="fas fa-circle"></i> Status</span>
                    <span class="info-value">
                        <span class="badge-status badge-status-${funcionario.status.name()}">
                            ${funcionario.status.name()}
                        </span>
                    </span>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Actions -->
<div class="form-actions" style="margin-top: 0; padding-top: 0; border-top: none;">
    <a href="${pageContext.request.contextPath}/funcionario/alterar-senha" class="btn-primary-custom">
        <i class="fas fa-key"></i> Alterar Senha
    </a>
    <a href="${pageContext.request.contextPath}/dashboard" class="btn-outline-custom">
        <i class="fas fa-arrow-left"></i> Voltar ao Dashboard
    </a>
</div>

<jsp:include page="/WEB-INF/views/layout/footer.jsp" />
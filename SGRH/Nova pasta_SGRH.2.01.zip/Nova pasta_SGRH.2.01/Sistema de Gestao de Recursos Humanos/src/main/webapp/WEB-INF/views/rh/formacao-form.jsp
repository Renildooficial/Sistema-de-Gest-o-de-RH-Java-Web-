<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core"%>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt"%>

<jsp:include page="/WEB-INF/views/layout/header.jsp">
    <jsp:param name="pageTitle" value="${acao == 'cadastrar' ? 'Nova Formação' : 'Editar Formação'}" />
</jsp:include>

<style>
    .required {
        color: var(--danger);
        font-weight: 700;
    }
    
    .form-group label {
        font-weight: 600;
        font-size: 13px;
        color: var(--dark);
        margin-bottom: 4px;
    }
    
    .form-control, .form-select {
        border-radius: 10px;
        border: 1px solid var(--gray-border);
        padding: 8px 12px;
        font-size: 13px;
        transition: var(--transition);
    }
    
    .form-control:focus, .form-select:focus {
        border-color: var(--primary);
        box-shadow: 0 0 0 3px rgba(79,70,229,0.1);
    }
    
    .form-container {
        background: #fff;
        border-radius: var(--border-radius);
        padding: 28px;
        box-shadow: var(--shadow-sm);
        border: 1px solid var(--gray-border);
        margin-bottom: 24px;
    }
    
    .form-title {
        font-size: 20px;
        font-weight: 700;
        color: var(--dark);
        margin-bottom: 24px;
        display: flex;
        align-items: center;
        gap: 12px;
    }
    
    .form-title i {
        color: var(--primary);
    }
    
    .form-actions {
        margin-top: 24px;
        padding-top: 20px;
        border-top: 1px solid var(--gray-border);
        display: flex;
        gap: 12px;
        flex-wrap: wrap;
    }
    
    .helper-text {
        font-size: 11px;
        color: var(--gray);
        margin-top: 4px;
    }
    
    .helper-text i {
        color: var(--info);
    }
    
    .form-check-input:checked {
        background-color: var(--primary);
        border-color: var(--primary);
    }
    
    .form-check-label {
        font-size: 13px;
        color: var(--dark);
        cursor: pointer;
    }
    
    /* ============================================================
       ESTILO PARA MULTI-SELECT
    ============================================================ */
    select[multiple] {
        min-height: 120px;
        padding: 8px;
        border-radius: 10px;
        border: 1px solid var(--gray-border);
    }
    
    select[multiple] option {
        padding: 6px 10px;
        border-radius: 4px;
        margin-bottom: 2px;
        cursor: pointer;
        transition: background 0.2s;
    }
    
    select[multiple] option:checked {
        background: linear-gradient(135deg, var(--primary), var(--secondary));
        color: #fff;
    }
    
    select[multiple] option:hover {
        background: var(--gray-light);
    }
    
    /* ============================================================
       BADGES - STATUS (FUNÇÕES)
    ============================================================ */
    .badge-status {
        display: inline-block;
        padding: 2px 10px;
        border-radius: 12px;
        font-size: 11px;
        font-weight: 600;
        margin: 2px 4px 2px 0;
        border: 1px solid transparent;
        animation: fadeInBadge 0.3s ease;
    }
    
    .badge-status.analista {
        background: rgba(79,70,229,0.1);
        color: var(--primary);
        border-color: rgba(79,70,229,0.15);
    }
    
    .badge-status.desenvolvedor {
        background: rgba(16,185,129,0.1);
        color: var(--success);
        border-color: rgba(16,185,129,0.15);
    }
    
    .badge-status.gerente {
        background: rgba(245,158,11,0.1);
        color: var(--warning);
        border-color: rgba(245,158,11,0.15);
    }
    
    .badge-status.coordenador {
        background: rgba(239,68,68,0.1);
        color: var(--danger);
        border-color: rgba(239,68,68,0.15);
    }
    
    .badge-status.supervisor {
        background: rgba(139,92,246,0.1);
        color: #7c3aed;
        border-color: rgba(139,92,246,0.15);
    }
    
    .badge-status.tecnico {
        background: rgba(59,130,246,0.1);
        color: #2563eb;
        border-color: rgba(59,130,246,0.15);
    }
    
    .badge-status.assistente {
        background: rgba(236,72,153,0.1);
        color: #db2777;
        border-color: rgba(236,72,153,0.15);
    }
    
    .badge-status.consultor {
        background: rgba(20,184,166,0.1);
        color: #0d9488;
        border-color: rgba(20,184,166,0.15);
    }
    
    .badge-status.auditor {
        background: rgba(168,85,247,0.1);
        color: #7e22ce;
        border-color: rgba(168,85,247,0.15);
    }
    
    .badge-status.pesquisador {
        background: rgba(251,146,60,0.1);
        color: #ea580c;
        border-color: rgba(251,146,60,0.15);
    }
    
    .badge-status.docente {
        background: rgba(34,197,94,0.1);
        color: #16a34a;
        border-color: rgba(34,197,94,0.15);
    }
    
    .badge-status.outro {
        background: rgba(107,114,128,0.1);
        color: var(--gray);
        border-color: rgba(107,114,128,0.15);
    }
    
    @keyframes fadeInBadge {
        from {
            opacity: 0;
            transform: scale(0.8);
        }
        to {
            opacity: 1;
            transform: scale(1);
        }
    }
    
    .badge-cargo {
        display: inline-block;
        background: rgba(16,185,129,0.1);
        color: var(--success);
        padding: 2px 10px;
        border-radius: 12px;
        font-size: 11px;
        font-weight: 600;
        border: 1px solid rgba(16,185,129,0.15);
        animation: fadeInBadge 0.3s ease;
    }
    
    /* ============================================================
       RESPONSIVIDADE
    ============================================================ */
    @media (max-width: 768px) {
        .form-container {
            padding: 20px;
        }
        .form-title {
            font-size: 18px;
        }
        .form-actions {
            flex-direction: column;
        }
        .form-actions .btn-primary-custom,
        .form-actions .btn-outline-custom {
            width: 100%;
            justify-content: center;
        }
    }
    
    @media (max-width: 576px) {
        .form-container {
            padding: 16px;
        }
        .form-title {
            font-size: 16px;
        }
        select[multiple] {
            min-height: 80px;
        }
    }
</style>

<div class="form-container animate-in">
    <div class="form-title">
        <i class="fas ${acao == 'cadastrar' ? 'fa-plus-circle' : 'fa-edit'}"></i>
        ${acao == 'cadastrar' ? 'Cadastrar Formação' : 'Editar Formação'}
    </div>

    <form action="${pageContext.request.contextPath}/formacoes" method="post" id="formacaoForm" novalidate>
        <input type="hidden" name="id" value="${formacao.id}">

        <div class="row g-3">
            <!-- ============================================================
            FUNCIONÁRIO
            ============================================================ -->
            <div class="col-md-6">
                <div class="form-group">
                    <label for="idFuncionario">Funcionário <span class="required">*</span></label>
                    <select class="form-select" name="idFuncionario" id="idFuncionario" required>
                        <option value="">Selecione um funcionário</option>
                        <c:forEach items="${funcionarios}" var="f">
                            <option value="${f.id}" ${formacao.idFuncionario == f.id ? 'selected' : ''}>
                                ${f.nome}
                            </option>
                        </c:forEach>
                    </select>
                    <div class="helper-text">
                        <i class="fas fa-info-circle"></i> Selecione o funcionário vinculado à formação
                    </div>
                </div>
            </div>

            <!-- ============================================================
            CURSO
            ============================================================ -->
            <div class="col-md-6">
                <div class="form-group">
                    <label for="curso">Curso <span class="required">*</span></label>
                    <input type="text" class="form-control" name="curso" id="curso"
                           value="${formacao.curso}" required
                           placeholder="Nome do curso" minlength="3" maxlength="100">
                    <div class="helper-text">
                        <i class="fas fa-info-circle"></i> Mínimo 3 caracteres, máximo 100
                    </div>
                </div>
            </div>

            <!-- ============================================================
            NÍVEL
            ============================================================ -->
            <div class="col-md-4">
                <div class="form-group">
                    <label for="nivel">Nível <span class="required">*</span></label>
                    <select class="form-select" name="nivel" id="nivel" required>
                        <option value="">Selecione</option>
                        <option value="FUNDAMENTAL" ${formacao.nivel == 'FUNDAMENTAL' ? 'selected' : ''}>Fundamental</option>
                        <option value="MEDIO" ${formacao.nivel == 'MEDIO' ? 'selected' : ''}>Médio</option>
                        <option value="TECNICO" ${formacao.nivel == 'TECNICO' ? 'selected' : ''}>Técnico</option>
                        <option value="SUPERIOR" ${formacao.nivel == 'SUPERIOR' ? 'selected' : ''}>Superior</option>
                        <option value="POS_GRADUACAO" ${formacao.nivel == 'POS_GRADUACAO' ? 'selected' : ''}>Pós-Graduação</option>
                        <option value="MASTER" ${formacao.nivel == 'MASTER' ? 'selected' : ''}>Mestrado</option>
                        <option value="DOUTORADO" ${formacao.nivel == 'DOUTORADO' ? 'selected' : ''}>Doutorado</option>
                        <option value="OUTRO" ${formacao.nivel == 'OUTRO' ? 'selected' : ''}>Outro</option>
                    </select>
                    <div class="helper-text">
                        <i class="fas fa-info-circle"></i> Nível de escolaridade da formação
                    </div>
                </div>
            </div>

            <!-- ============================================================
            INSTITUIÇÃO
            ============================================================ -->
            <div class="col-md-4">
                <div class="form-group">
                    <label for="instituicao">Instituição <span class="required">*</span></label>
                    <input type="text" class="form-control" name="instituicao" id="instituicao"
                           value="${formacao.instituicao}" required
                           placeholder="Nome da instituição" maxlength="100">
                    <div class="helper-text">
                        <i class="fas fa-info-circle"></i> Instituição de ensino
                    </div>
                </div>
            </div>

            <!-- ============================================================
            LOCAL
            ============================================================ -->
            <div class="col-md-4">
                <div class="form-group">
                    <label for="local">Local</label>
                    <input type="text" class="form-control" name="local" id="local"
                           value="${formacao.local}"
                           placeholder="Cidade/País" maxlength="50">
                    <div class="helper-text">
                        <i class="fas fa-info-circle"></i> Local onde a formação foi realizada
                    </div>
                </div>
            </div>

            <!-- ============================================================
            DATA INÍCIO
            ============================================================ -->
            <div class="col-md-3">
                <div class="form-group">
                    <label for="dataInicio">Data de Início <span class="required">*</span></label>
                    <input type="date" class="form-control" name="dataInicio" id="dataInicio"
                           value="${formacao.dataInicio != null ? formacao.dataInicio : ''}" required>
                </div>
            </div>

            <!-- ============================================================
            DATA CONCLUSÃO
            ============================================================ -->
            <div class="col-md-3">
                <div class="form-group">
                    <label for="dataConclusao">Data de Conclusão <span class="required">*</span></label>
                    <input type="date" class="form-control" name="dataConclusao" id="dataConclusao"
                           value="${formacao.dataConclusao != null ? formacao.dataConclusao : ''}" required>
                    <div class="helper-text">
                        <i class="fas fa-info-circle"></i> Não pode ser anterior à data de início
                    </div>
                </div>
            </div>

            <!-- ============================================================
            CARGA HORÁRIA
            ============================================================ -->
            <div class="col-md-3">
                <div class="form-group">
                    <label for="cargaHoraria">Carga Horária (horas)</label>
                    <input type="number" class="form-control" name="cargaHoraria" id="cargaHoraria"
                           value="${formacao.cargaHoraria}"
                           placeholder="Ex: 360" min="1" max="9999">
                    <div class="helper-text">
                        <i class="fas fa-info-circle"></i> Carga horária total em horas
                    </div>
                </div>
            </div>

            <!-- ============================================================
            STATUS
            ============================================================ -->
            <div class="col-md-3">
                <div class="form-group">
                    <label for="status">Status <span class="required">*</span></label>
                    <select class="form-select" name="status" id="status" required>
                        <option value="CONCLUIDO" ${formacao.status == 'CONCLUIDO' ? 'selected' : ''}>Concluído</option>
                        <option value="CURSANDO" ${formacao.status == 'CURSANDO' ? 'selected' : ''}>Cursando</option>
                        <option value="INTERROMPIDO" ${formacao.status == 'INTERROMPIDO' ? 'selected' : ''}>Interrompido</option>
                    </select>
                </div>
            </div>

            <!-- ============================================================
            FUNÇÕES DESEMPENHADAS (MÚLTIPLA) - ESTILO STATUS
            ============================================================ -->
            <div class="col-md-6">
                <div class="form-group">
                    <label for="funcoes">Funções Desempenhadas</label>
                    <select class="form-select" name="funcoes" id="funcoes" multiple>
                        <option value="ANALISTA" ${formacao.funcoes != null && formacao.funcoes.contains('ANALISTA') ? 'selected' : ''}>Analista</option>
                        <option value="DESENVOLVEDOR" ${formacao.funcoes != null && formacao.funcoes.contains('DESENVOLVEDOR') ? 'selected' : ''}>Desenvolvedor</option>
                        <option value="GERENTE" ${formacao.funcoes != null && formacao.funcoes.contains('GERENTE') ? 'selected' : ''}>Gerente</option>
                        <option value="COORDENADOR" ${formacao.funcoes != null && formacao.funcoes.contains('COORDENADOR') ? 'selected' : ''}>Coordenador</option>
                        <option value="SUPERVISOR" ${formacao.funcoes != null && formacao.funcoes.contains('SUPERVISOR') ? 'selected' : ''}>Supervisor</option>
                        <option value="TECNICO" ${formacao.funcoes != null && formacao.funcoes.contains('TECNICO') ? 'selected' : ''}>Técnico</option>
                        <option value="ASSISTENTE" ${formacao.funcoes != null && formacao.funcoes.contains('ASSISTENTE') ? 'selected' : ''}>Assistente</option>
                        <option value="CONSULTOR" ${formacao.funcoes != null && formacao.funcoes.contains('CONSULTOR') ? 'selected' : ''}>Consultor</option>
                        <option value="AUDITOR" ${formacao.funcoes != null && formacao.funcoes.contains('AUDITOR') ? 'selected' : ''}>Auditor</option>
                        <option value="PESQUISADOR" ${formacao.funcoes != null && formacao.funcoes.contains('PESQUISADOR') ? 'selected' : ''}>Pesquisador</option>
                        <option value="DOCENTE" ${formacao.funcoes != null && formacao.funcoes.contains('DOCENTE') ? 'selected' : ''}>Docente</option>
                        <option value="OUTRO" ${formacao.funcoes != null && formacao.funcoes.contains('OUTRO') ? 'selected' : ''}>Outro</option>
                    </select>
                    <div class="helper-text">
                        <i class="fas fa-info-circle"></i>
                        Segure <strong>Ctrl</strong> (Windows) ou <strong>Cmd</strong> (Mac) para selecionar múltiplas funções
                    </div>
                    <div id="funcoesSelecionadas" style="margin-top: 8px;">
                        <!-- Badges serão exibidos aqui via JavaScript -->
                    </div>
                </div>
            </div>

            <!-- ============================================================
            CARGO
            ============================================================ -->
            <div class="col-md-6">
                <div class="form-group">
                    <label for="cargo">Cargo <span class="required">*</span></label>
                    <select class="form-select" name="cargo" id="cargo" required>
                        <option value="">Selecione um cargo</option>
                        <option value="DIRETOR" ${formacao.cargo == 'DIRETOR' ? 'selected' : ''}>Diretor</option>
                        <option value="GERENTE" ${formacao.cargo == 'GERENTE' ? 'selected' : ''}>Gerente</option>
                        <option value="COORDENADOR" ${formacao.cargo == 'COORDENADOR' ? 'selected' : ''}>Coordenador</option>
                        <option value="SUPERVISOR" ${formacao.cargo == 'SUPERVISOR' ? 'selected' : ''}>Supervisor</option>
                        <option value="ANALISTA" ${formacao.cargo == 'ANALISTA' ? 'selected' : ''}>Analista</option>
                        <option value="ASSISTENTE" ${formacao.cargo == 'ASSISTENTE' ? 'selected' : ''}>Assistente</option>
                        <option value="TECNICO" ${formacao.cargo == 'TECNICO' ? 'selected' : ''}>Técnico</option>
                        <option value="CONSULTOR" ${formacao.cargo == 'CONSULTOR' ? 'selected' : ''}>Consultor</option>
                        <option value="AUDITOR" ${formacao.cargo == 'AUDITOR' ? 'selected' : ''}>Auditor</option>
                        <option value="PESQUISADOR" ${formacao.cargo == 'PESQUISADOR' ? 'selected' : ''}>Pesquisador</option>
                        <option value="DOCENTE" ${formacao.cargo == 'DOCENTE' ? 'selected' : ''}>Docente</option>
                        <option value="ESTAGIARIO" ${formacao.cargo == 'ESTAGIARIO' ? 'selected' : ''}>Estagiário</option>
                        <option value="OUTRO" ${formacao.cargo == 'OUTRO' ? 'selected' : ''}>Outro</option>
                    </select>
                    <div class="helper-text">
                        <i class="fas fa-info-circle"></i> Cargo ocupado durante a formação
                    </div>
                    <div id="cargoSelecionado" style="margin-top: 8px;">
                        <!-- Badge do cargo selecionado será exibido aqui via JavaScript -->
                    </div>
                </div>
            </div>

            <!-- ============================================================
            CERTIFICADO
            ============================================================ -->
            <div class="col-md-12">
                <div class="form-group">
                    <div class="form-check" style="margin-top: 8px;">
                        <input class="form-check-input" type="checkbox" name="certificado"
                               id="certificado" ${formacao.certificado ? 'checked' : ''}
                               style="width: 18px; height: 18px; cursor: pointer;">
                        <label class="form-check-label" for="certificado" style="font-weight: 500;">
                            <i class="fas fa-certificate me-1" style="color: var(--success);"></i>
                            Possui certificado de conclusão
                        </label>
                    </div>
                    <div class="helper-text">
                        <i class="fas fa-info-circle"></i> Marque se a formação possui certificado emitido
                    </div>
                </div>
            </div>

            <!-- ============================================================
            OBSERVAÇÃO
            ============================================================ -->
            <div class="col-12">
                <div class="form-group">
                    <label for="observacao">Observação</label>
                    <textarea class="form-control" name="observacao" id="observacao"
                              rows="3" maxlength="500"
                              placeholder="Observações adicionais sobre a formação">${formacao.observacao}</textarea>
                    <div class="helper-text">
                        <i class="fas fa-info-circle"></i> Máximo 500 caracteres
                    </div>
                </div>
            </div>
        </div>

        <!-- ============================================================
        BOTÕES
        ============================================================ -->
        <div class="form-actions">
            <button type="submit" class="btn-primary-custom" id="btnSalvar">
                <i class="fas fa-save"></i> ${acao == 'cadastrar' ? 'Cadastrar' : 'Atualizar'}
            </button>
            <a href="${pageContext.request.contextPath}/formacoes" class="btn-outline-custom">
                <i class="fas fa-times"></i> Cancelar
            </a>
        </div>
    </form>
</div>

<script>
    // ============================================================
    // MAPEAMENTO DE CLASSES PARA BADGES DE STATUS
    // ============================================================
    const statusClassMap = {
        'ANALISTA': 'analista',
        'DESENVOLVEDOR': 'desenvolvedor',
        'GERENTE': 'gerente',
        'COORDENADOR': 'coordenador',
        'SUPERVISOR': 'supervisor',
        'TECNICO': 'tecnico',
        'ASSISTENTE': 'assistente',
        'CONSULTOR': 'consultor',
        'AUDITOR': 'auditor',
        'PESQUISADOR': 'pesquisador',
        'DOCENTE': 'docente',
        'OUTRO': 'outro'
    };

    // ============================================================
    // EXIBIR FUNÇÕES SELECIONADAS COMO BADGES DE STATUS
    // ============================================================
    document.getElementById('funcoes').addEventListener('change', function() {
        const container = document.getElementById('funcoesSelecionadas');
        const selected = Array.from(this.selectedOptions).map(opt => opt.value);

        container.innerHTML = '';
        selected.forEach(function(val) {
            const badge = document.createElement('span');
            badge.className = 'badge-status ' + (statusClassMap[val] || 'outro');
            badge.textContent = val.charAt(0) + val.slice(1).toLowerCase();
            container.appendChild(badge);
        });

        if (selected.length === 0) {
            container.innerHTML = '<span style="font-size: 12px; color: var(--gray);">Nenhuma função selecionada</span>';
        }
    });

    // ============================================================
    // EXIBIR CARGO SELECIONADO COMO BADGE
    // ============================================================
    document.getElementById('cargo').addEventListener('change', function() {
        const container = document.getElementById('cargoSelecionado');
        const selected = this.value;

        container.innerHTML = '';
        if (selected) {
            const badge = document.createElement('span');
            badge.className = 'badge-cargo';
            badge.textContent = 'Cargo: ' + selected.charAt(0) + selected.slice(1).toLowerCase();
            container.appendChild(badge);
        } else {
            container.innerHTML = '<span style="font-size: 12px; color: var(--gray);">Nenhum cargo selecionado</span>';
        }
    });

    // ============================================================
    // CARREGAR FUNÇÕES E CARGO INICIAIS (se já houver)
    // ============================================================
    document.addEventListener('DOMContentLoaded', function() {
        // Disparar change para exibir badges iniciais
        const eventFuncoes = new Event('change');
        document.getElementById('funcoes').dispatchEvent(eventFuncoes);

        const eventCargo = new Event('change');
        document.getElementById('cargo').dispatchEvent(eventCargo);
    });

    // ============================================================
    // VALIDAÇÃO DO FORMULÁRIO
    // ============================================================
    document.getElementById('formacaoForm').addEventListener('submit', function(e) {
        let isValid = true;
        let errorMessages = [];

        // 1. VALIDAÇÃO DO CURSO
        const curso = document.getElementById('curso');
        if (curso.value.trim().length < 3) {
            errorMessages.push('Curso deve ter no mínimo 3 caracteres');
            isValid = false;
        }
        if (curso.value.trim().length > 100) {
            errorMessages.push('Curso deve ter no máximo 100 caracteres');
            isValid = false;
        }

        // 2. VALIDAÇÃO DA INSTITUIÇÃO
        const instituicao = document.getElementById('instituicao');
        if (instituicao.value.trim().length < 2) {
            errorMessages.push('Instituição deve ter no mínimo 2 caracteres');
            isValid = false;
        }

        // 3. VALIDAÇÃO DO FUNCIONÁRIO
        const idFuncionario = document.getElementById('idFuncionario');
        if (!idFuncionario.value) {
            errorMessages.push('Selecione um funcionário');
            isValid = false;
        }

        // 4. VALIDAÇÃO DO NÍVEL
        const nivel = document.getElementById('nivel');
        if (!nivel.value) {
            errorMessages.push('Selecione o nível da formação');
            isValid = false;
        }

        // 5. VALIDAÇÃO DO CARGO
        const cargo = document.getElementById('cargo');
        if (!cargo.value) {
            errorMessages.push('Selecione o cargo');
            isValid = false;
        }

        // 6. VALIDAÇÃO DAS DATAS
        const dataInicio = document.getElementById('dataInicio');
        const dataConclusao = document.getElementById('dataConclusao');

        if (!dataInicio.value) {
            errorMessages.push('Data de início é obrigatória');
            isValid = false;
        }
        if (!dataConclusao.value) {
            errorMessages.push('Data de conclusão é obrigatória');
            isValid = false;
        }
        if (dataInicio.value && dataConclusao.value) {
            if (dataConclusao.value < dataInicio.value) {
                errorMessages.push('Data de conclusão não pode ser anterior à data de início');
                isValid = false;
            }
        }

        // 7. VALIDAÇÃO DA CARGA HORÁRIA
        const cargaHoraria = document.getElementById('cargaHoraria');
        if (cargaHoraria.value && parseInt(cargaHoraria.value) <= 0) {
            errorMessages.push('Carga horária deve ser maior que zero');
            isValid = false;
        }
        if (cargaHoraria.value && parseInt(cargaHoraria.value) > 9999) {
            errorMessages.push('Carga horária máxima é 9999 horas');
            isValid = false;
        }

        // 8. VALIDAÇÃO DA OBSERVAÇÃO
        const observacao = document.getElementById('observacao');
        if (observacao.value.length > 500) {
            errorMessages.push('Observação deve ter no máximo 500 caracteres');
            isValid = false;
        }

        // SE HOUVER ERROS, EXIBIR E CANCELAR
        if (!isValid) {
            e.preventDefault();
            const msg = errorMessages.join('\n');
            showNotification('error', 'Erro de Validação', msg);
            return false;
        }

        return true;
    });

    // ============================================================
    // VALIDAÇÃO DA DATA DE CONCLUSÃO EM TEMPO REAL
    // ============================================================
    document.getElementById('dataConclusao').addEventListener('change', function() {
        const dataInicio = document.getElementById('dataInicio').value;
        const dataConclusao = this.value;

        if (dataInicio && dataConclusao && dataConclusao < dataInicio) {
            showNotification('warning', 'Atenção', 'Data de conclusão não pode ser anterior à data de início');
        }
    });

    // ============================================================
    // MÁSCARA PARA CARGA HORÁRIA (apenas números)
    // ============================================================
    document.getElementById('cargaHoraria').addEventListener('input', function() {
        this.value = this.value.replace(/[^0-9]/g, '');
    });

    // ============================================================
    // FUNÇÃO SHOW NOTIFICATION (caso não exista)
    // ============================================================
    if (typeof showNotification === 'undefined') {
        window.showNotification = function(type, title, message) {
            // Fallback simples
            alert(title + ': ' + message);
        };
    }
</script>

<jsp:include page="/WEB-INF/views/layout/footer.jsp" />
<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core"%>

<jsp:include page="/WEB-INF/views/layout/header.jsp">
    <jsp:param name="pageTitle" value="${acao == 'cadastrar' ? 'Novo Setor' : 'Editar Setor'}" />
    <jsp:param name="activeMenu" value="setores" />
</jsp:include>

<style>
    .required { color: var(--danger); font-weight: 700; }
    .form-group label { font-weight: 600; font-size: 13px; color: var(--dark); margin-bottom: 4px; }
    .form-control, .form-select { border-radius: 10px; border: 1px solid var(--gray-border); padding: 8px 12px; font-size: 13px; transition: var(--transition); }
    .form-control:focus, .form-select:focus { border-color: var(--primary); box-shadow: 0 0 0 3px rgba(79,70,229,0.1); }
    .form-container { background: #fff; border-radius: var(--border-radius); padding: 28px; box-shadow: var(--shadow-sm); border: 1px solid var(--gray-border); margin-bottom: 24px; }
    .form-title { font-size: 20px; font-weight: 700; color: var(--dark); margin-bottom: 24px; display: flex; align-items: center; gap: 12px; }
    .form-title i { color: var(--primary); }
    .form-actions { margin-top: 24px; padding-top: 20px; border-top: 1px solid var(--gray-border); display: flex; gap: 12px; flex-wrap: wrap; }
    .helper-text { font-size: 11px; color: var(--gray); margin-top: 4px; }
    .helper-text i { color: var(--info); }
    
    .badge-status {
        display: inline-block;
        padding: 2px 10px;
        border-radius: 12px;
        font-size: 11px;
        font-weight: 600;
        margin: 2px 2px 2px 0;
    }
    .badge-status.ativo {
        background: rgba(16,185,129,0.1);
        color: #059669;
        border: 1px solid rgba(16,185,129,0.15);
    }
    .badge-status.inativo {
        background: rgba(239,68,68,0.1);
        color: #dc2626;
        border: 1px solid rgba(239,68,68,0.15);
    }
    
    .form-check-input:checked {
        background-color: var(--primary);
        border-color: var(--primary);
    }
    .form-check-label {
        font-size: 13px;
        color: var(--dark);
        cursor: pointer;
        font-weight: 500;
    }

    @media (max-width: 768px) {
        .form-container { padding: 20px; }
        .form-title { font-size: 18px; }
        .form-actions { flex-direction: column; }
        .form-actions .btn-primary-custom, .form-actions .btn-outline-custom { width: 100%; justify-content: center; }
    }
    @media (max-width: 576px) {
        .form-container { padding: 16px; }
        .form-title { font-size: 16px; }
    }
</style>

<div class="form-container animate-in">
    <div class="form-title">
        <i class="fas ${acao == 'cadastrar' ? 'fa-plus-circle' : 'fa-edit'}"></i>
        ${acao == 'cadastrar' ? 'Cadastrar Setor' : 'Editar Setor'}
    </div>

    <form action="${pageContext.request.contextPath}/setores" method="post" id="setorForm" novalidate>
        <input type="hidden" name="id" value="${setor.id}">

        <div class="row g-3">
            <!-- Nome do Setor -->
            <div class="col-12">
                <div class="form-group">
                    <label for="nome">Nome do Setor <span class="required">*</span></label>
                    <input type="text" class="form-control" name="nome" id="nome"
                           value="${setor.nome}" required 
                           placeholder="Digite o nome do setor" 
                           minlength="3" maxlength="50">
                    <div class="helper-text">
                        <i class="fas fa-info-circle"></i> Mínimo 3 caracteres, máximo 50
                    </div>
                </div>
            </div>

            <!-- Descrição -->
            <div class="col-12">
                <div class="form-group">
                    <label for="descricao">Descrição</label>
                    <textarea class="form-control" name="descricao" id="descricao" 
                              rows="3" maxlength="500"
                              placeholder="Descreva a função e responsabilidades do setor">${setor.descricao}</textarea>
                    <div class="helper-text">
                        <i class="fas fa-info-circle"></i> Máximo 500 caracteres
                    </div>
                </div>
            </div>

            <!-- Responsável -->
            <div class="col-12">
                <div class="form-group">
                    <label for="responsavel">Responsável</label>
                    <input type="text" class="form-control" name="responsavel" id="responsavel"
                           value="${setor.responsavel}" 
                           placeholder="Nome do responsável pelo setor" maxlength="100">
                    <div class="helper-text">
                        <i class="fas fa-info-circle"></i> Nome do gestor ou responsável pelo setor
                    </div>
                </div>
            </div>

            <!-- Status (Ativo/Inativo) -->
            <div class="col-12">
                <div class="form-group">
                    <div class="form-check" style="margin-top: 8px;">
                        <input class="form-check-input" type="checkbox" name="ativo" 
                               id="ativo" ${setor.ativo != null && setor.ativo ? 'checked' : ''}
                               style="width: 18px; height: 18px; cursor: pointer;">
                        <label class="form-check-label" for="ativo" style="font-weight: 500;">
                            <i class="fas fa-circle me-1" style="color: var(--success);"></i>
                            Setor ativo
                        </label>
                    </div>
                    <div class="helper-text">
                        <i class="fas fa-info-circle"></i> Desmarque para inativar o setor
                    </div>
                    <div id="statusSelecionado" style="margin-top: 8px;">
                        <!-- Badge do status será exibido aqui via JavaScript -->
                    </div>
                </div>
            </div>
        </div>

        <div class="form-actions">
            <button type="submit" class="btn-primary-custom" id="btnSalvar">
                <i class="fas fa-save"></i> ${acao == 'cadastrar' ? 'Cadastrar' : 'Atualizar'}
            </button>
            <a href="${pageContext.request.contextPath}/setores" class="btn-outline-custom">
                <i class="fas fa-times"></i> Cancelar
            </a>
        </div>
    </form>
</div>

<script>
// ============================================================
// EXIBIR STATUS SELECIONADO COMO BADGE
// ============================================================
document.getElementById('ativo').addEventListener('change', function() {
    const container = document.getElementById('statusSelecionado');
    const isChecked = this.checked;
    
    container.innerHTML = '';
    const badge = document.createElement('span');
    badge.className = 'badge-status ' + (isChecked ? 'ativo' : 'inativo');
    badge.innerHTML = isChecked ? '<i class="fas fa-check-circle"></i> ATIVO' : '<i class="fas fa-times-circle"></i> INATIVO';
    container.appendChild(badge);
});

// ============================================================
// CARREGAR STATUS INICIAL
// ============================================================
document.addEventListener('DOMContentLoaded', function() {
    document.getElementById('ativo').dispatchEvent(new Event('change'));
});

// ============================================================
// VALIDAÇÃO DO FORMULÁRIO
// ============================================================
document.getElementById('setorForm').addEventListener('submit', function(e) {
    let isValid = true;
    let errorMessages = [];

    const nome = document.getElementById('nome');
    if (nome.value.trim().length < 3) {
        errorMessages.push('Nome deve ter no mínimo 3 caracteres');
        isValid = false;
    }
    if (nome.value.trim().length > 50) {
        errorMessages.push('Nome deve ter no máximo 50 caracteres');
        isValid = false;
    }

    const descricao = document.getElementById('descricao');
    if (descricao.value.length > 500) {
        errorMessages.push('Descrição deve ter no máximo 500 caracteres');
        isValid = false;
    }

    const responsavel = document.getElementById('responsavel');
    if (responsavel.value.length > 100) {
        errorMessages.push('Responsável deve ter no máximo 100 caracteres');
        isValid = false;
    }

    if (!isValid) {
        e.preventDefault();
        alert('Erro de Validação:\n' + errorMessages.join('\n'));
        return false;
    }

    return true;
});

// ============================================================
// FALLBACK - SHOW NOTIFICATION
// ============================================================
if (typeof showNotification === 'undefined') {
    window.showNotification = function(type, title, message) {
        alert(title + ': ' + message);
    };
}
</script>

<jsp:include page="/WEB-INF/views/layout/footer.jsp" />
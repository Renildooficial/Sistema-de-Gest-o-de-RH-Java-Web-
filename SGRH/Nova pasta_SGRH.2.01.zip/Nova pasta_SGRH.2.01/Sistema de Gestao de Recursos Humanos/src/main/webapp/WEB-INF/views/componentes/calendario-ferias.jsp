<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/fmt" prefix="fmt"%>

<%
    // Parâmetros recebidos:
    // - eventos: List<Map<String, Object>> com os eventos do mês
    // - mes: int (1-12)
    // - ano: int
    // - idFuncionario: Integer (opcional, para filtro)
    // - perfil: String (FUNCIONARIO, GESTOR, RH, ADMIN)
%>

<div class="calendario-container" id="calendarioContainer">
    <!-- Cabeçalho do Calendário -->
    <div class="calendario-header">
        <div class="calendario-nav">
            <button type="button" class="btn-nav" onclick="navegarCalendario(-1)" title="Mês anterior">
                <i class="fas fa-chevron-left"></i>
            </button>
            <span class="calendario-titulo" id="calendarioTitulo">
                <fmt:formatDate value="${dataReferencia}" pattern="MMMM yyyy" />
            </span>
            <button type="button" class="btn-nav" onclick="navegarCalendario(1)" title="Próximo mês">
                <i class="fas fa-chevron-right"></i>
            </button>
        </div>
        <div class="calendario-actions">
            <button type="button" class="btn-hoje" onclick="irParaHoje()">
                <i class="fas fa-calendar-day"></i> Hoje
            </button>
        </div>
    </div>

    <!-- Filtros (apenas para RH/Gestor/ADMIN) -->
    <c:if test="${perfil != 'FUNCIONARIO'}">
        <div class="calendario-filtros">
            <div class="filtro-group">
                <label for="filtroFuncionario">Funcionário</label>
                <select id="filtroFuncionario" class="form-select" onchange="aplicarFiltros()">
                    <option value="">Todos</option>
                    <c:forEach var="func" items="${funcionarios}">
                        <option value="${func.id}">${func.nome}</option>
                    </c:forEach>
                </select>
            </div>
            <div class="filtro-group">
                <label for="filtroDepartamento">Departamento</label>
                <select id="filtroDepartamento" class="form-select" onchange="aplicarFiltros()">
                    <option value="">Todos</option>
                    <c:forEach var="dept" items="${departamentos}">
                        <option value="${dept.id}">${dept.nome}</option>
                    </c:forEach>
                </select>
            </div>
            <div class="filtro-group">
                <label for="filtroStatus">Status</label>
                <select id="filtroStatus" class="form-select" onchange="aplicarFiltros()">
                    <option value="">Todos</option>
                    <option value="SOLICITADA">Pendente</option>
                    <option value="APROVADA">Aprovada</option>
                    <option value="REJEITADA">Rejeitada</option>
                    <option value="EM_ANDAMENTO">Em Andamento</option>
                    <option value="CONCLUIDA">Concluída</option>
                    <option value="INTERROMPIDA">Interrompida</option>
                </select>
            </div>
            <button type="button" class="btn-limpar-filtros" onclick="limparFiltros()">
                <i class="fas fa-undo"></i> Limpar
            </button>
        </div>
    </c:if>

    <!-- Legenda -->
    <div class="calendario-legenda">
        <span class="legenda-item"><span class="legenda-cor" style="background: #28a745;"></span> Aprovada</span>
        <span class="legenda-item"><span class="legenda-cor" style="background: #ffc107;"></span> Pendente</span>
        <span class="legenda-item"><span class="legenda-cor" style="background: #dc3545;"></span> Rejeitada</span>
        <span class="legenda-item"><span class="legenda-cor" style="background: #17a2b8;"></span> Em Andamento</span>
        <span class="legenda-item"><span class="legenda-cor" style="background: #6f42c1;"></span> Concluída</span>
        <span class="legenda-item"><span class="legenda-cor" style="background: #fd7e14;"></span> Interrompida</span>
        <span class="legenda-item"><span class="legenda-cor" style="background: #6c757d;"></span> Ausência</span>
    </div>

    <!-- Grid do Calendário -->
    <div class="calendario-grid">
        <!-- Dias da semana -->
        <div class="calendario-weekdays">
            <div class="weekday">Dom</div>
            <div class="weekday">Seg</div>
            <div class="weekday">Ter</div>
            <div class="weekday">Qua</div>
            <div class="weekday">Qui</div>
            <div class="weekday">Sex</div>
            <div class="weekday">Sáb</div>
        </div>

        <!-- Dias do mês -->
        <div class="calendario-dias" id="calendarioDias">
            <c:forEach var="dia" items="${dias}">
                <div class="calendario-dia ${dia.classe} ${not empty dia.eventos ? 'has-event' : ''}" 
                     data-data="${dia.data}" data-numero="${dia.numero}">
                    <span class="dia-numero">${dia.numero}</span>
                    <div class="dia-eventos">
                        <c:forEach var="evento" items="${dia.eventos}">
                            <div class="evento-mini ${evento.tipo}" 
                                 onclick="abrirDetalhesEvento(${evento.id})"
                                 title="${evento.titulo} - ${evento.periodo}">
                                <span class="evento-cor" style="background: ${evento.cor};"></span>
                                <span class="evento-nome">${evento.nome}</span>
                            </div>
                        </c:forEach>
                    </div>
                </div>
            </c:forEach>
        </div>
    </div>

    <!-- Loading -->
    <div class="calendario-loading" id="calendarioLoading" style="display: none;">
        <div class="spinner-border text-primary" role="status">
            <span class="visually-hidden">Carregando...</span>
        </div>
    </div>
</div>

<style>
.calendario-container {
    background: #fff;
    border-radius: 12px;
    box-shadow: 0 2px 12px rgba(0,0,0,0.08);
    padding: 20px;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
}

.calendario-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 20px;
    flex-wrap: wrap;
    gap: 10px;
}

.calendario-nav {
    display: flex;
    align-items: center;
    gap: 15px;
}

.btn-nav {
    background: none;
    border: none;
    font-size: 18px;
    color: #6c757d;
    cursor: pointer;
    padding: 5px 10px;
    border-radius: 6px;
    transition: all 0.2s;
}

.btn-nav:hover {
    background: #e9ecef;
    color: #212529;
}

.calendario-titulo {
    font-size: 20px;
    font-weight: 600;
    color: #212529;
    min-width: 180px;
    text-align: center;
    text-transform: capitalize;
}

.btn-hoje {
    background: #e9ecef;
    border: none;
    padding: 6px 14px;
    border-radius: 6px;
    font-size: 13px;
    color: #212529;
    cursor: pointer;
    transition: all 0.2s;
}

.btn-hoje:hover {
    background: #dee2e6;
}

.calendario-filtros {
    display: flex;
    flex-wrap: wrap;
    gap: 15px;
    margin-bottom: 20px;
    padding: 15px;
    background: #f8f9fa;
    border-radius: 8px;
}

.filtro-group {
    display: flex;
    flex-direction: column;
    min-width: 150px;
}

.filtro-group label {
    font-size: 12px;
    font-weight: 600;
    color: #6c757d;
    margin-bottom: 3px;
}

.form-select {
    padding: 6px 10px;
    border: 1px solid #ced4da;
    border-radius: 6px;
    font-size: 13px;
    background: white;
}

.btn-limpar-filtros {
    background: none;
    border: none;
    color: #6c757d;
    cursor: pointer;
    padding: 6px 12px;
    border-radius: 6px;
    font-size: 13px;
    align-self: flex-end;
    margin-bottom: 2px;
    transition: all 0.2s;
}

.btn-limpar-filtros:hover {
    background: #e9ecef;
    color: #212529;
}

.calendario-legenda {
    display: flex;
    flex-wrap: wrap;
    gap: 12px;
    margin-bottom: 15px;
    padding: 10px 0;
    border-bottom: 1px solid #e9ecef;
}

.legenda-item {
    display: flex;
    align-items: center;
    gap: 5px;
    font-size: 12px;
    color: #495057;
}

.legenda-cor {
    width: 12px;
    height: 12px;
    border-radius: 3px;
    display: inline-block;
}

.calendario-grid {
    border: 1px solid #e9ecef;
    border-radius: 8px;
    overflow: hidden;
}

.calendario-weekdays {
    display: grid;
    grid-template-columns: repeat(7, 1fr);
    background: #f8f9fa;
}

.weekday {
    padding: 10px;
    text-align: center;
    font-weight: 600;
    font-size: 13px;
    color: #495057;
    border-bottom: 1px solid #e9ecef;
}

.calendario-dias {
    display: grid;
    grid-template-columns: repeat(7, 1fr);
}

.calendario-dia {
    min-height: 90px;
    padding: 5px 8px;
    border-right: 1px solid #e9ecef;
    border-bottom: 1px solid #e9ecef;
    background: white;
    transition: background 0.2s;
    position: relative;
    cursor: default;
}

.calendario-dia:nth-child(7n) {
    border-right: none;
}

.calendario-dia.other-month {
    background: #f8f9fa;
    color: #adb5bd;
}

.calendario-dia.weekend {
    background: #fdf6f6;
}

.calendario-dia.today {
    background: #e8f4fd;
}

.calendario-dia.today .dia-numero {
    background: #007bff;
    color: white;
    border-radius: 50%;
    width: 28px;
    height: 28px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
}

.calendario-dia.has-event {
    cursor: pointer;
}

.calendario-dia:hover {
    background: #f1f3f5;
}

.dia-numero {
    font-size: 14px;
    font-weight: 500;
    color: #212529;
}

.dia-eventos {
    margin-top: 4px;
    display: flex;
    flex-direction: column;
    gap: 2px;
}

.evento-mini {
    display: flex;
    align-items: center;
    gap: 4px;
    font-size: 10px;
    padding: 2px 4px;
    border-radius: 3px;
    cursor: pointer;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    transition: all 0.2s;
}

.evento-mini:hover {
    opacity: 0.8;
    transform: scale(1.02);
}

.evento-cor {
    width: 8px;
    height: 8px;
    border-radius: 2px;
    flex-shrink: 0;
}

.evento-nome {
    font-size: 9px;
    color: #212529;
    overflow: hidden;
    text-overflow: ellipsis;
}

.evento-mini.ferias .evento-cor { background: #28a745; }
.evento-mini.pendente .evento-cor { background: #ffc107; }
.evento-mini.rejeitada .evento-cor { background: #dc3545; }
.evento-mini.andamento .evento-cor { background: #17a2b8; }
.evento-mini.interrompida .evento-cor { background: #fd7e14; }
.evento-mini.ausencia .evento-cor { background: #6c757d; }
.evento-mini.compensacao .evento-cor { background: #6f42c1; }

.calendario-loading {
    display: flex;
    justify-content: center;
    align-items: center;
    padding: 40px;
}

.spinner-border {
    width: 40px;
    height: 40px;
}

/* Responsividade */
@media (max-width: 768px) {
    .calendario-container {
        padding: 10px;
    }
    
    .calendario-header {
        flex-direction: column;
        align-items: stretch;
        gap: 10px;
    }
    
    .calendario-nav {
        justify-content: center;
    }
    
    .calendario-titulo {
        font-size: 16px;
        min-width: auto;
    }
    
    .calendario-filtros {
        flex-direction: column;
        gap: 10px;
    }
    
    .filtro-group {
        min-width: auto;
    }
    
    .calendario-dia {
        min-height: 60px;
        padding: 3px 4px;
    }
    
    .dia-numero {
        font-size: 11px;
    }
    
    .evento-mini {
        font-size: 8px;
        padding: 1px 3px;
    }
    
    .evento-nome {
        font-size: 7px;
    }
    
    .weekday {
        font-size: 10px;
        padding: 6px;
    }
    
    .calendario-legenda {
        gap: 8px;
    }
    
    .legenda-item {
        font-size: 10px;
    }
}

@media (max-width: 480px) {
    .calendario-dia {
        min-height: 45px;
        padding: 2px 3px;
    }
    
    .dia-numero {
        font-size: 9px;
    }
    
    .evento-mini {
        display: none;
    }
    
    .calendario-dia.has-event .dia-numero::after {
        content: "●";
        color: #007bff;
        font-size: 8px;
        margin-left: 2px;
    }
}

/* Scroll horizontal para telas pequenas */
@media (max-width: 576px) {
    .calendario-grid {
        overflow-x: auto;
    }
    .calendario-weekdays,
    .calendario-dias {
        min-width: 560px;
    }
}
</style>

<script>
var mesAtual = ${mes};
var anoAtual = ${ano};
var idFuncionario = ${idFuncionario != null ? idFuncionario : 'null'};

function navegarCalendario(delta) {
    mesAtual += delta;
    if (mesAtual > 12) {
        mesAtual = 1;
        anoAtual++;
    } else if (mesAtual < 1) {
        mesAtual = 12;
        anoAtual--;
    }
    carregarCalendario();
}

function irParaHoje() {
    var hoje = new Date();
    mesAtual = hoje.getMonth() + 1;
    anoAtual = hoje.getFullYear();
    carregarCalendario();
}

function carregarCalendario() {
    var loading = document.getElementById('calendarioLoading');
    var dias = document.getElementById('calendarioDias');
    var titulo = document.getElementById('calendarioTitulo');
    
    loading.style.display = 'flex';
    dias.innerHTML = '';
    
    var params = new URLSearchParams({
        mes: mesAtual,
        ano: anoAtual
    });
    
    if (idFuncionario) {
        params.append('idFuncionario', idFuncionario);
    }
    
    // Aplicar filtros
    var filtroFunc = document.getElementById('filtroFuncionario');
    var filtroDept = document.getElementById('filtroDepartamento');
    var filtroStatus = document.getElementById('filtroStatus');
    
    if (filtroFunc && filtroFunc.value) {
        params.append('idFuncionario', filtroFunc.value);
    }
    if (filtroDept && filtroDept.value) {
        params.append('idDepartamento', filtroDept.value);
    }
    if (filtroStatus && filtroStatus.value) {
        params.append('status', filtroStatus.value);
    }
    
    fetch('/sigrh/api/calendario-eventos?' + params.toString())
        .then(response => response.json())
        .then(data => {
            loading.style.display = 'none';
            
            // Atualizar título
            var meses = ['Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho',
                         'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'];
            titulo.textContent = meses[mesAtual - 1] + ' ' + anoAtual;
            
            // Renderizar dias
            renderizarDias(data.dias);
        })
        .catch(error => {
            loading.style.display = 'none';
            console.error('Erro ao carregar calendário:', error);
            mostrarErro('Erro ao carregar calendário. Tente novamente.');
        });
}

function renderizarDias(dias) {
    var container = document.getElementById('calendarioDias');
    container.innerHTML = '';
    
    dias.forEach(function(dia) {
        var div = document.createElement('div');
        div.className = 'calendario-dia ' + (dia.classe || '');
        if (dia.eventos && dia.eventos.length > 0) {
            div.classList.add('has-event');
        }
        div.dataset.data = dia.data;
        div.dataset.numero = dia.numero;
        
        // Número do dia
        var numero = document.createElement('span');
        numero.className = 'dia-numero';
        numero.textContent = dia.numero;
        div.appendChild(numero);
        
        // Eventos
        if (dia.eventos && dia.eventos.length > 0) {
            var eventosDiv = document.createElement('div');
            eventosDiv.className = 'dia-eventos';
            
            dia.eventos.forEach(function(evento) {
                var ev = document.createElement('div');
                ev.className = 'evento-mini ' + (evento.tipo || '');
                ev.onclick = function() { abrirDetalhesEvento(evento.id); };
                ev.title = evento.titulo + ' - ' + evento.periodo;
                
                var cor = document.createElement('span');
                cor.className = 'evento-cor';
                cor.style.background = getCorEvento(evento.status);
                ev.appendChild(cor);
                
                var nome = document.createElement('span');
                nome.className = 'evento-nome';
                nome.textContent = evento.nome || 'Férias';
                ev.appendChild(nome);
                
                eventosDiv.appendChild(ev);
            });
            
            div.appendChild(eventosDiv);
        }
        
        container.appendChild(div);
    });
}

function getCorEvento(status) {
    var cores = {
        'APROVADA': '#28a745',
        'SOLICITADA': '#ffc107',
        'REJEITADA': '#dc3545',
        'EM_ANDAMENTO': '#17a2b8',
        'CONCLUIDA': '#6f42c1',
        'INTERROMPIDA': '#fd7e14',
        'AUSENCIA': '#6c757d'
    };
    return cores[status] || '#6c757d';
}

function aplicarFiltros() {
    carregarCalendario();
}

function limparFiltros() {
    var filtros = ['filtroFuncionario', 'filtroDepartamento', 'filtroStatus'];
    filtros.forEach(function(id) {
        var el = document.getElementById(id);
        if (el) el.value = '';
    });
    carregarCalendario();
}

function abrirDetalhesEvento(id) {
    // Chamar modal de detalhes
    if (typeof abrirModalDetalhes === 'function') {
        abrirModalDetalhes(id);
    }
}

function mostrarErro(mensagem) {
    // Implementar toast ou alerta
    alert(mensagem);
}

// Carregar calendário ao iniciar
document.addEventListener('DOMContentLoaded', function() {
    carregarCalendario();
});
</script>
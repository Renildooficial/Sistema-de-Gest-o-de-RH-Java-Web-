<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core"%>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt"%>

<jsp:include page="/WEB-INF/views/layout/header.jsp">
    <jsp:param name="pageTitle" value="Auditoria" />
    <jsp:param name="activeMenu" value="auditoria" />
</jsp:include>

<style>
    .badge-action {
        display: inline-block;
        padding: 2px 10px;
        border-radius: 12px;
        font-size: 10px;
        font-weight: 600;
        border: 1px solid transparent;
    }
    .badge-action.CREATE {
        background: rgba(16,185,129,0.1);
        color: #059669;
        border-color: rgba(16,185,129,0.15);
    }
    .badge-action.UPDATE {
        background: rgba(59,130,246,0.1);
        color: #2563eb;
        border-color: rgba(59,130,246,0.15);
    }
    .badge-action.DELETE {
        background: rgba(239,68,68,0.1);
        color: #dc2626;
        border-color: rgba(239,68,68,0.15);
    }
    .badge-action.LOGIN {
        background: rgba(139,92,246,0.1);
        color: #7c3aed;
        border-color: rgba(139,92,246,0.15);
    }
    .badge-action.LOGOUT {
        background: rgba(107,114,128,0.1);
        color: #6b7280;
        border-color: rgba(107,114,128,0.15);
    }
    .badge-action.BACKUP {
        background: rgba(245,158,11,0.1);
        color: #d97706;
        border-color: rgba(245,158,11,0.15);
    }
    .badge-action.ACCESS {
        background: rgba(236,72,153,0.1);
        color: #db2777;
        border-color: rgba(236,72,153,0.15);
    }
    
    .ip-badge {
        font-family: 'Courier New', monospace;
        font-size: 11px;
        background: var(--gray-light);
        padding: 1px 8px;
        border-radius: 4px;
        color: var(--gray);
    }
</style>

<div class="table-section animate-in">
    <div class="table-header">
        <div class="title">
            <i class="fas fa-clipboard-list me-2"></i>
            Log de Auditoria
            <span style="font-size: 12px; font-weight: 400; color: var(--gray);">${total != null ? total : '0'} registros</span>
        </div>
        <div class="actions">
            <button onclick="window.location.reload()" class="btn-outline-custom">
                <i class="fas fa-sync"></i> Atualizar
            </button>
        </div>
    </div>

    <div class="table-responsive-custom">
        <table class="table-custom" id="auditoriaTable">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Usuário</th>
                    <th>Ação</th>
                    <th>Tabela</th>
                    <th>Registro</th>
                    <th>IP</th>
                    <th>Data/Hora</th>
                </tr>
            </thead>
            <tbody>
                <c:forEach items="${logs}" var="log">
                    <tr>
                        <td>${log.id}</td>
                        <td>
                            <strong>${log.usuario != null ? log.usuario.nome : 'Sistema'}</strong>
                            <br>
                            <span style="font-size: 11px; color: var(--gray);">
                                @${log.usuario != null ? log.usuario.usuario : 'sistema'}
                            </span>
                        </td>
                        <td>
                            <span class="badge-action ${log.acao}">${log.acao}</span>
                        </td>
                        <td>${log.tabela}</td>
                        <td>
                            <c:choose>
                                <c:when test="${log.idRegistro != null && log.idRegistro > 0}">
                                    #${log.idRegistro}
                                </c:when>
                                <c:otherwise>
                                    <span style="color: var(--gray); font-size: 12px;">-</span>
                                </c:otherwise>
                            </c:choose>
                        </td>
                        <td><span class="ip-badge">${log.ip != null ? log.ip : '-'}</span></td>
                        <td><fmt:formatDate value="${log.dataHora}" pattern="dd/MM/yyyy HH:mm:ss" /></td>
                    </tr>
                </c:forEach>
                <c:if test="${empty logs}">
                    <tr>
                        <td colspan="7" style="text-align: center; padding: 40px; color: var(--gray);">
                            <i class="fas fa-clipboard-list fa-3x d-block mb-3" style="opacity: 0.3;"></i>
                            <h5>Nenhum registro de auditoria</h5>
                            <p style="font-size: 14px;">As ações dos usuários serão registradas aqui.</p>
                        </td>
                    </tr>
                </c:if>
            </tbody>
        </table>
    </div>
</div>

<jsp:include page="/WEB-INF/views/layout/footer.jsp" />
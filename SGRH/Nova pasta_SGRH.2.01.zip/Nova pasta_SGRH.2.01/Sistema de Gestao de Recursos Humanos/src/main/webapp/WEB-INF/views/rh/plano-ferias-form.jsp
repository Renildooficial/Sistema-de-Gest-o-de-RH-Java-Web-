<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core"%>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt"%>

<jsp:include page="/WEB-INF/views/layout/header.jsp">
    <jsp:param name="pageTitle" value="${acao == 'cadastrar' ? 'Adicionar ao Plano' : 'Editar Plano'}" />
    <jsp:param name="activeMenu" value="plano-ferias" />
</jsp:include>

<style>
    :root {
        --pf-primary: #4f46e5;
        --pf-primary-hover: #4338ca;
        --pf-dark: #0f172a;
        --pf-gray: #64748b;
        --pf-border: #e2e8f0;
        --pf-bg-input: #f8fafc;
        --pf-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.05), 0 8px 10px -6px rgba(0, 0, 0, 0.01);
    }

    .form-container {
        background: #ffffff;
        border-radius: 16px;
        padding: 32px;
        box-shadow: var(--pf-shadow);
        border: 1px solid var(--pf-border);
        margin-bottom: 32px;
        transition: transform 0.2s ease, box-shadow 0.2s ease;
    }

    .form-title {
        font-size: 22px;
        font-weight: 700;
        color: var(--pf-dark);
        margin-bottom: 24px;
        display: flex;
        align-items: center;
        gap: 12px;
        padding-bottom: 16px;
        border-bottom: 1px solid var(--pf-border);
    }

    .form-title i {
        color: var(--pf-primary);
        background: rgba(79, 70, 229, 0.1);
        padding: 10px;
        border-radius: 10px;
        font-size: 18px;
    }

    .form-group {
        margin-bottom: 18px;
    }

    .form-group label {
        font-weight: 600;
        font-size: 13px;
        color: var(--pf-dark);
        margin-bottom: 6px;
        display: block;
    }

    .required {
        color: #ef4444;
        font-weight: 700;
    }

    .form-control, .form-select {
        border-radius: 10px;
        border: 1.5px solid var(--pf-border);
        background-color: var(--pf-bg-input);
        padding: 10px 14px;
        font-size: 14px;
        color: var(--pf-dark);
        transition: all 0.2s ease-in-out;
    }

    .form-control:focus, .form-select:focus {
        background-color: #ffffff;
        border-color: var(--pf-primary);
        box-shadow: 0 0 0 4px rgba(79, 70, 229, 0.15);
        outline: none;
    }

    .helper-text {
        font-size: 12px;
        color: var(--pf-gray);
        margin-top: 6px;
        display: flex;
        align-items: center;
        gap: 4px;
    }

    .helper-text i {
        color: var(--pf-primary);
    }

    /* Modern Badges */
    .badge-prioridade {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        padding: 4px 12px;
        border-radius: 20px;
        font-size: 12px;
        font-weight: 600;
        transition: all 0.2s ease;
    }
    .badge-prioridade::before {
        content: "";
        display: inline-block;
        width: 6px;
        height: 6px;
        border-radius: 50%;
    }
    .badge-prioridade.alta {
        background: #fef2f2;
        color: #dc2626;
        border: 1px solid #fecaca;
    }
    .badge-prioridade.alta::before { background-color: #dc2626; }
    
    .badge-prioridade.media {
        background: #fffbeb;
        color: #d97706;
        border: 1px solid #fde68a;
    }
    .badge-prioridade.media::before { background-color: #d97706; }

    .badge-prioridade.baixa {
        background: #eff6ff;
        color: #2563eb;
        border: 1px solid #bfdbfe;
    }
    .badge-prioridade.baixa::before { background-color: #2563eb; }

    /* Actions */
    .form-actions {
        margin-top: 28px;
        padding-top: 20px;
        border-top: 1px solid var(--pf-border);
        display: flex;
        gap: 12px;
    }

    .btn-primary-custom {
        background: var(--pf-primary);
        color: #ffffff;
        border: none;
        border-radius: 10px;
        padding: 10px 24px;
        font-weight: 600;
        font-size: 14px;
        display: inline-flex;
        align-items: center;
        gap: 8px;
        transition: all 0.2s ease;
        text-decoration: none;
        cursor: pointer;
    }

    .btn-primary-custom:hover {
        background: var(--pf-primary-hover);
        color: #ffffff;
        box-shadow: 0 4px 12px rgba(79, 70, 229, 0.25);
    }

    .btn-outline-custom {
        background: transparent;
        color: var(--pf-gray);
        border: 1.5px solid var(--pf-border);
        border-radius: 10px;
        padding: 10px 20px;
        font-weight: 600;
        font-size: 14px;
        display: inline-flex;
        align-items: center;
        gap: 8px;
        transition: all 0.2s ease;
        text-decoration: none;
    }

    .btn-outline-custom:hover {
        background: #f1f5f9;
        color: var(--pf-dark);
        border-color: #cbd5e1;
    }

    @media (max-width: 768px) {
        .form-container { padding: 20px; }
        .form-actions { flex-direction: column; }
        .btn-primary-custom, .btn-outline-custom { width: 100%; justify-content: center; }
    }
</style>

<div class="form-container animate-in">
    <div class="form-title">
        <i class="fas ${acao == 'cadastrar' ? 'fa-plus' : 'fa-pen'}"></i>
        ${acao == 'cadastrar' ? 'Adicionar ao Plano de Férias' : 'Editar Plano de Férias'}
    </div>

    <form action="${pageContext.request.contextPath}/plano-ferias" method="post" id="planoForm" novalidate>
        <input type="hidden" name="id" value="${plano.id}">

        <div class="row g-3">
            <!-- Funcionário -->
            <div class="col-md-6">
                <div class="form-group">
                    <label for="idFuncionario">Funcionário <span class="required">*</span></label>
                    <select class="form-select" name="idFuncionario" id="idFuncionario" required>
                        <option value="">Selecione um funcionário</option>
                        <c:forEach items="${funcionarios}" var="f">
                            <option value="${f.id}" ${plano.idFuncionario == f.id ? 'selected' : ''}>
                                ${f.nome}
                            </option>
                        </c:forEach>
                    </select>
                    <div class="helper-text"><i class="fas fa-info-circle"></i> Selecione o funcionário para planejar as férias</div>
                </div>
            </div>

            <!-- Mês Planejado -->
            <div class="col-md-6">
                <div class="form-group">
                    <label for="mesPlanejado">Mês Planejado <span class="required">*</span></label>
                    <select class="form-select" name="mesPlanejado" id="mesPlanejado" required>
                        <option value="">Selecione o mês</option>
                        <c:forEach items="${meses}" var="m" varStatus="i">
                            <option value="${i.index + 1}" ${plano.mesPlanejado == i.index + 1 ? 'selected' : ''}>
                                ${m}
                            </option>
                        </c:forEach>
                    </select>
                    <div class="helper-text"><i class="fas fa-info-circle"></i> Mês em que as férias serão tiradas</div>
                </div>
            </div>

            <!-- Ano -->
            <div class="col-md-6">
                <div class="form-group">
                    <label for="ano">Ano <span class="required">*</span></label>
                    <select class="form-select" name="ano" id="ano" required>
                        <c:set var="anoAtual" value="<%= java.time.Year.now().getValue() %>" />
                        <c:set var="anoInicio" value="${anoAtual - 5}" />
                        <c:set var="anoFim" value="${anoAtual + 5}" />
                        
                        <c:forEach var="y" begin="${anoInicio}" end="${anoFim}">
                            <option value="${y}" ${plano.ano == y || (plano.ano == null && y == anoAtual) ? 'selected' : ''}>
                                ${y}
                            </option>
                        </c:forEach>
                    </select>
                    <div class="helper-text"><i class="fas fa-info-circle"></i> Ano de referência do planejamento</div>
                </div>
            </div>

            <!-- Prioridade -->
            <div class="col-md-6">
                <div class="form-group">
                    <label for="prioridade">Prioridade <span class="required">*</span></label>
                    <select class="form-select" name="prioridade" id="prioridade" required>
                        <option value="1" ${plano.prioridade == 1 ? 'selected' : ''}>1 - Alta</option>
                        <option value="2" ${plano.prioridade == 2 ? 'selected' : ''}>2 - Média</option>
                        <option value="3" ${plano.prioridade == 3 ? 'selected' : ''}>3 - Baixa</option>
                    </select>
                    <div class="helper-text"><i class="fas fa-info-circle"></i> Prioridade para aprovação do plano</div>
                    <div id="prioridadeSelecionada" class="mt-2"></div>
                </div>
            </div>

           <!-- Status - campo obrigatório -->
<div class="col-md-6">
    <div class="form-group">
        <label for="status">Status <span class="required">*</span></label>
        <select class="form-select" name="status" id="status" required>
            <option value="PENDENTE" ${plano.status == 'PENDENTE' ? 'selected' : ''}>Pendente</option>
            <option value="APROVADO" ${plano.status == 'APROVADO' ? 'selected' : ''}>Aprovado</option>
            <option value="EM_EXECUCAO" ${plano.status == 'EM_EXECUCAO' ? 'selected' : ''}>Em Execução</option>
            <option value="CONCLUIDO" ${plano.status == 'CONCLUIDO' ? 'selected' : ''}>Concluído</option>
            <option value="CANCELADO" ${plano.status == 'CANCELADO' ? 'selected' : ''}>Cancelado</option>
        </select>
        <div class="helper-text"><i class="fas fa-info-circle"></i> Situação atual do planejamento</div>
    </div>
</div>

            <!-- Observação -->
            <div class="col-12">
                <div class="form-group">
                    <label for="observacao">Observação</label>
                    <textarea class="form-control" name="observacao" id="observacao" 
                              rows="3" maxlength="500" 
                              placeholder="Observações adicionais sobre o planejamento">${plano.observacao}</textarea>
                    <div class="helper-text"><i class="fas fa-info-circle"></i> Máximo 500 caracteres</div>
                </div>
            </div>
        </div>

        <div class="form-actions">
            <button type="submit" class="btn-primary-custom" id="btnSalvar">
                <i class="fas fa-save"></i> ${acao == 'cadastrar' ? 'Cadastrar' : 'Atualizar'}
            </button>
            <a href="${pageContext.request.contextPath}/plano-ferias" class="btn-outline-custom">
                <i class="fas fa-times"></i> Cancelar
            </a>
        </div>
    </form>
</div>

<script>
document.getElementById('prioridade').addEventListener('change', function() {
    const container = document.getElementById('prioridadeSelecionada');
    const selected = parseInt(this.value);
    
    container.innerHTML = '';
    if (selected) {
        const badge = document.createElement('span');
        badge.className = 'badge-prioridade ' + 
            (selected === 1 ? 'alta' : selected === 2 ? 'media' : 'baixa');
        badge.textContent = selected === 1 ? 'Alta' : selected === 2 ? 'Média' : 'Baixa';
        container.appendChild(badge);
    }
});

document.addEventListener('DOMContentLoaded', function() {
    document.getElementById('prioridade').dispatchEvent(new Event('change'));
});

document.getElementById('planoForm').addEventListener('submit', function(e) {
    let isValid = true;
    let errorMessages = [];

    ['idFuncionario', 'mesPlanejado', 'ano', 'prioridade', 'status'].forEach(function(id) {
        const field = document.getElementById(id);
        if (!field.value) {
            isValid = false;
        }
    });

    const observacao = document.getElementById('observacao');
    if (observacao.value.length > 500) {
        errorMessages.push('Observação deve ter no máximo 500 caracteres');
        isValid = false;
    }

    if (!isValid) {
        e.preventDefault();
        alert('Por favor, preencha todos os campos obrigatórios.');
    }
});
</script>

<jsp:include page="/WEB-INF/views/layout/footer.jsp" />
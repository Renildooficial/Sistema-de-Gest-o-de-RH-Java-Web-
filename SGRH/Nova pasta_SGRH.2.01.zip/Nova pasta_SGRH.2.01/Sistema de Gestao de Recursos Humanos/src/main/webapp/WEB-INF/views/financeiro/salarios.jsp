<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="com.sigrh.util.ConfiguracaoUtil" %>
<%@ taglib prefix="c" uri="jakarta.tags.core"%>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt"%>

<jsp:include page="/WEB-INF/views/layout/header.jsp">
    <jsp:param name="pageTitle" value="Gestão de Salários" />
    <jsp:param name="activeMenu" value="salarios" />
</jsp:include>

<style>
    .badge-pago {
        background: rgba(16,185,129,0.1);
        color: #059669;
        padding: 2px 10px;
        border-radius: 12px;
        font-size: 11px;
        font-weight: 600;
        border: 1px solid rgba(16,185,129,0.15);
    }
    .badge-pendente {
        background: rgba(245,158,11,0.1);
        color: #d97706;
        padding: 2px 10px;
        border-radius: 12px;
        font-size: 11px;
        font-weight: 600;
        border: 1px solid rgba(245,158,11,0.15);
    }
    .badge-cancelado {
        background: rgba(239,68,68,0.1);
        color: #dc2626;
        padding: 2px 10px;
        border-radius: 12px;
        font-size: 11px;
        font-weight: 600;
        border: 1px solid rgba(239,68,68,0.15);
    }
    .badge-ativo {
        background: rgba(79,70,229,0.1);
        color: #4f46e5;
        padding: 2px 10px;
        border-radius: 12px;
        font-size: 11px;
        font-weight: 600;
        border: 1px solid rgba(79,70,229,0.15);
    }
    
    .action-btns .btn-icon {
        width: 34px;
        height: 34px;
        border: none;
        border-radius: 8px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        background: transparent;
        color: var(--gray);
        font-size: 14px;
        text-decoration: none;
        margin: 0 2px;
        position: relative;
    }
    
    .action-btns .btn-icon:hover {
        transform: translateY(-3px);
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
    }
    
    .action-btns .btn-icon.edit {
        background: rgba(79, 70, 229, 0.1);
        color: var(--primary);
    }
    .action-btns .btn-icon.edit:hover {
        background: rgba(79, 70, 229, 0.2);
        box-shadow: 0 4px 12px rgba(79, 70, 229, 0.3);
    }
    
    .action-btns .btn-icon .tooltip {
        display: none;
        position: absolute;
        bottom: -28px;
        left: 50%;
        transform: translateX(-50%);
        background: var(--dark);
        color: #fff;
        padding: 2px 10px;
        border-radius: 4px;
        font-size: 9px;
        font-weight: 500;
        white-space: nowrap;
        z-index: 100;
    }
    
    .action-btns .btn-icon:hover .tooltip {
        display: block;
    }
    
    .avatar-mini {
        width: 36px;
        height: 36px;
        border-radius: 50%;
        background: linear-gradient(135deg, var(--primary), #7c3aed);
        display: flex;
        align-items: center;
        justify-content: center;
        color: #fff;
        font-weight: 700;
        font-size: 14px;
        flex-shrink: 0;
    }
    
    .funcionario-nome {
        font-weight: 500;
        font-size: 13px;
    }
    
    .funcionario-id {
        font-size: 10px;
        color: var(--gray);
    }
    
    .valor-monetario {
        font-weight: 600;
        font-family: 'Courier New', monospace;
    }
    
    .config-info {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        font-size: 12px;
        color: var(--gray);
        padding: 4px 12px;
        background: var(--gray-light);
        border-radius: 8px;
    }
    
    .config-info i {
        color: var(--primary);
    }
    .config-info strong {
        color: var(--dark);
    }
    
    .stat-card {
        background: #fff;
        border-radius: var(--border-radius);
        padding: 12px 16px;
        border: 1px solid var(--gray-border);
        text-align: center;
        transition: all 0.3s ease;
    }
    
    .stat-card:hover {
        transform: translateY(-2px);
        box-shadow: var(--shadow-hover);
    }
    
    .stat-card .stat-label {
        font-size: 11px;
        color: var(--gray);
        text-transform: uppercase;
        letter-spacing: 0.3px;
    }
    
    .stat-card .stat-value {
        font-size: 18px;
        font-weight: 700;
        margin-top: 4px;
    }
    
    @media (max-width: 768px) {
        .stat-card .stat-value {
            font-size: 15px;
        }
        .config-info {
            font-size: 10px;
            padding: 2px 8px;
        }
    }
    
    @media (max-width: 576px) {
        .table-custom {
            font-size: 11px;
            min-width: 500px;
        }
        .avatar-mini {
            width: 28px;
            height: 28px;
            font-size: 11px;
        }
        .funcionario-nome {
            font-size: 11px;
        }
        .action-btns .btn-icon {
            width: 28px;
            height: 28px;
            font-size: 12px;
        }
    }
</style>

<div class="table-section animate-in">
    <div class="table-header">
        <div class="title">
            <i class="fas fa-coins me-2"></i>
            Gestão de Salários
            <span class="badge-count">
                <i class="fas fa-users me-1"></i> ${total != null ? total : '0'} registros
            </span>
            <span class="config-info" style="margin-left: 12px;">
                <i class="fas fa-money-bill-wave"></i>
                Moeda: <strong>${ConfiguracaoUtil.getMoedaSimbolo()} (${ConfiguracaoUtil.getMoedaCodigo()})</strong>
            </span>
        </div>
        <div class="actions">
            <a href="${pageContext.request.contextPath}/financeiro/folha-pagamento" class="btn-outline-custom">
                <i class="fas fa-file-invoice"></i> Folha de Pagamento
            </a>
        </div>
    </div>

   

    <div class="table-responsive-custom">
        <table class="table-custom" id="salariosTable">
            <thead>
                <tr>
                    <th style="min-width: 130px;">Funcionário</th>
                    <th style="min-width: 100px;">Salário Base</th>
                    <th style="min-width: 100px;">Subsídios</th>
                    <th style="min-width: 90px;">Status</th>
                    <th style="width: 80px; text-align: center;">Ações</th>
                </tr>
            </thead>
            <tbody>
                <c:forEach items="${funcionarios}" var="f">
                    <tr>
                        <td>
                            <div style="display: flex; align-items: center; gap: 10px;">
                                <div class="avatar-mini">
                                    ${f.nome.charAt(0)}${f.nome.split(' ')[1].charAt(0)}
                                </div>
                                <div>
                                    <div class="funcionario-nome">${f.nome}</div>
                                    <div class="funcionario-id">ID: #${f.id}</div>
                                </div>
                            </div>
                        </td>
                        <td>
                            <span class="valor-monetario" style="color: var(--primary);">
                                <fmt:formatNumber value="${f.salarioBase != null ? f.salarioBase : 0}" pattern="#,##0.00"/>
                            </span>
                        </td>
                        <td>
                            <div style="font-size: 12px; color: var(--gray);">
                                <div>Alim: <fmt:formatNumber value="${f.subsidioAlimentacao != null ? f.subsidioAlimentacao : 0}" pattern="#,##0.00"/></div>
                                <div>Transp: <fmt:formatNumber value="${f.subsidioTransporte != null ? f.subsidioTransporte : 0}" pattern="#,##0.00"/></div>
                                <div>Saúde: <fmt:formatNumber value="${f.subsidioSaude != null ? f.subsidioSaude : 0}" pattern="#,##0.00"/></div>
                            </div>
                        </td>
                        <td>
                            <span class="badge-status ${f.status == 'ATIVO' ? 'ativo' : 'inativo'}">
                                ${f.status}
                            </span>
                        </td>
                        <td style="text-align: center;">
                            <div class="action-btns" style="justify-content: center;">
                                <a href="${pageContext.request.contextPath}/financeiro/editar-salario?id=${f.id}" 
                                   class="btn-icon edit" title="Editar Salário">
                                    <i class="fas fa-edit"></i>
                                    <span class="tooltip">Editar Salário</span>
                                </a>
                            </div>
                        </td>
                    </tr>
                </c:forEach>
                <c:if test="${empty funcionarios}">
                    <tr>
                        <td colspan="5" style="text-align: center; padding: 40px; color: var(--gray);">
                            <i class="fas fa-coins fa-3x d-block mb-3" style="opacity: 0.3;"></i>
                            <h5 style="font-weight: 600; color: var(--dark);">Nenhum funcionário cadastrado</h5>
                            <p style="font-size: 14px; color: var(--gray);">Cadastre funcionários para gerenciar salários.</p>
                        </td>
                    </tr>
                </c:if>
            </tbody>
        </table>
    </div>
</div>

<script>
function showNotification(type, title, message) {
    if (typeof window.showNotification === 'function') {
        window.showNotification(type, title, message);
    } else {
        alert(title + '\n\n' + message);
    }
}
</script>

<jsp:include page="/WEB-INF/views/layout/footer.jsp" />
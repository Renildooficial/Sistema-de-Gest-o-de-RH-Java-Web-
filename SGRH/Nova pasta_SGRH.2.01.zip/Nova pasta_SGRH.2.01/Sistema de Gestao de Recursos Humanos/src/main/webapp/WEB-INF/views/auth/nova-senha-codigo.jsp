<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core"%>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SIGRH - Nova Senha</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Inter', sans-serif;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            background: linear-gradient(135deg, #0F172A 0%, #1E293B 100%);
            padding: 20px;
        }
        .container {
            background: #fff;
            border-radius: 24px;
            padding: 48px 40px;
            max-width: 440px;
            width: 100%;
            box-shadow: 0 24px 80px rgba(0,0,0,0.3);
            animation: fadeInUp 0.6s ease;
        }
        @keyframes fadeInUp {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        .logo { text-align: center; margin-bottom: 32px; }
        .logo .brand-icon {
            width: 64px;
            height: 64px;
            background: linear-gradient(135deg, #4F46E5, #7C3AED);
            border-radius: 16px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            font-size: 32px;
            font-weight: 800;
            color: #fff;
            margin-bottom: 12px;
        }
        .logo h1 { font-size: 24px; font-weight: 800; color: #1E293B; }
        .logo p { color: #64748B; font-size: 14px; margin-top: 4px; }
        .form-group { margin-bottom: 20px; }
        .form-group label { font-weight: 600; font-size: 13px; color: #1E293B; margin-bottom: 6px; display: block; }
        .form-group .input-group { position: relative; }
        .form-group .input-group i {
            position: absolute;
            left: 14px;
            top: 50%;
            transform: translateY(-50%);
            color: #94A3B8;
            font-size: 16px;
        }
        .form-group .form-control {
            border: 1px solid #E2E8F0;
            border-radius: 12px;
            padding: 12px 16px 12px 44px;
            font-size: 14px;
            font-family: 'Inter', sans-serif;
            background: #F8FAFC;
            width: 100%;
        }
        .form-group .form-control:focus {
            border-color: #4F46E5;
            box-shadow: 0 0 0 3px rgba(79,70,229,0.1);
            background: #fff;
            outline: none;
        }
        .form-group .toggle-password {
            position: absolute;
            right: 14px;
            top: 50%;
            transform: translateY(-50%);
            background: none;
            border: none;
            color: #94A3B8;
            cursor: pointer;
            font-size: 16px;
            padding: 4px;
        }
        .form-group .toggle-password:hover { color: #1E293B; }
        .btn-primary-custom {
            width: 100%;
            padding: 12px;
            background: linear-gradient(135deg, #4F46E5, #7C3AED);
            border: none;
            border-radius: 12px;
            color: #fff;
            font-weight: 700;
            font-size: 15px;
            font-family: 'Inter', sans-serif;
            transition: all 0.3s ease;
            cursor: pointer;
        }
        .btn-primary-custom:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 24px rgba(79,70,229,0.3);
        }
        .btn-primary-custom:disabled {
            opacity: 0.7;
            cursor: not-allowed;
            transform: none;
        }
        .alert-custom {
            border-radius: 12px;
            padding: 12px 16px;
            margin-bottom: 16px;
            font-size: 14px;
        }
        .alert-custom.alert-danger {
            background: rgba(239,68,68,0.1);
            color: #EF4444;
            border-left: 4px solid #EF4444;
        }
        .alert-custom.alert-success {
            background: rgba(16,185,129,0.1);
            color: #10B981;
            border-left: 4px solid #10B981;
        }
        .alert-custom.alert-info {
            background: rgba(59,130,246,0.1);
            color: #3B82F6;
            border-left: 4px solid #3B82F6;
        }
        .footer-text { text-align: center; margin-top: 20px; font-size: 12px; color: #94A3B8; }
        .info-text {
            font-size: 13px;
            color: #64748B;
            margin-bottom: 16px;
            text-align: center;
        }
        .password-strength {
            margin-top: 8px;
            height: 4px;
            border-radius: 4px;
            background: #E2E8F0;
            overflow: hidden;
            transition: all 0.3s ease;
        }
        .password-strength .bar {
            height: 100%;
            border-radius: 4px;
            transition: width 0.3s ease;
            width: 0%;
        }
        .password-strength .bar.weak { background: #EF4444; width: 25%; }
        .password-strength .bar.medium { background: #F59E0B; width: 50%; }
        .password-strength .bar.strong { background: #10B981; width: 75%; }
        .password-strength .bar.very-strong { background: #4F46E5; width: 100%; }
    </style>
</head>
<body>
    <div class="container">
        <div class="logo">
            <div class="brand-icon">S</div>
            <h1>SIGRH</h1>
            <p>Nova Senha</p>
        </div>

        <div class="info-text">
            <i class="fas fa-key me-2" style="color: #4F46E5;"></i>
            Digite sua nova senha.
        </div>

        <c:if test="${not empty sessionScope.erro}">
            <div class="alert-custom alert-danger">
                <i class="fas fa-exclamation-circle me-2"></i> ${sessionScope.erro}
            </div>
            <c:remove var="erro" scope="session" />
        </c:if>

        <form action="${pageContext.request.contextPath}/auth/redefinir-senha-codigo" method="post">
            <input type="hidden" name="email" value="${email}">
            <input type="hidden" name="codigo" value="${codigo}">

            <div class="form-group">
                <label for="novaSenha">Nova Senha <span class="required" style="color: #EF4444;">*</span></label>
                <div class="input-group">
                    <i class="fas fa-lock"></i>
                    <input type="password" class="form-control" id="novaSenha" name="novaSenha" 
                           placeholder="Digite a nova senha" required minlength="8">
                    <button type="button" class="toggle-password" onclick="togglePassword('novaSenha')">
                        <i class="fas fa-eye" id="novaSenhaIcon"></i>
                    </button>
                </div>
                <div class="password-strength">
                    <div class="bar" id="passwordStrength"></div>
                </div>
                <div style="font-size: 11px; color: #94A3B8; margin-top: 4px;">
                    Mínimo 8 caracteres, com letras maiúsculas, minúsculas e números
                </div>
            </div>

            <div class="form-group">
                <label for="confirmarSenha">Confirmar Nova Senha <span class="required" style="color: #EF4444;">*</span></label>
                <div class="input-group">
                    <i class="fas fa-lock"></i>
                    <input type="password" class="form-control" id="confirmarSenha" name="confirmarSenha" 
                           placeholder="Confirme a nova senha" required minlength="8">
                    <button type="button" class="toggle-password" onclick="togglePassword('confirmarSenha')">
                        <i class="fas fa-eye" id="confirmarSenhaIcon"></i>
                    </button>
                </div>
            </div>

            <div id="senhaMismatch" style="display: none; color: #EF4444; font-size: 13px; margin-bottom: 12px;">
                <i class="fas fa-times-circle me-1"></i> As senhas não coincidem
            </div>

            <button type="submit" class="btn-primary-custom" id="btnRedefinir">
                <i class="fas fa-save me-2"></i> Redefinir Senha
            </button>
        </form>

        <div class="footer-text">
            <i class="fas fa-shield-alt me-1"></i> Ambiente seguro
        </div>
    </div>

    <script>
        function togglePassword(id) {
            const input = document.getElementById(id);
            const icon = document.getElementById(id + 'Icon');
            if (input.type === 'password') {
                input.type = 'text';
                icon.className = 'fas fa-eye-slash';
            } else {
                input.type = 'password';
                icon.className = 'fas fa-eye';
            }
        }

        // Força da senha
        document.getElementById('novaSenha').addEventListener('input', function() {
            const senha = this.value;
            const bar = document.getElementById('passwordStrength');
            let strength = 0;

            if (senha.length >= 8) strength++;
            if (/[a-z]/.test(senha)) strength++;
            if (/[A-Z]/.test(senha)) strength++;
            if (/[0-9]/.test(senha)) strength++;
            if (/[^a-zA-Z0-9]/.test(senha)) strength++;

            bar.className = 'bar';
            if (strength <= 1) bar.classList.add('weak');
            else if (strength <= 2) bar.classList.add('medium');
            else if (strength <= 3) bar.classList.add('strong');
            else bar.classList.add('very-strong');
        });

        // Verificar se as senhas coincidem
        document.getElementById('confirmarSenha').addEventListener('input', function() {
            const senha = document.getElementById('novaSenha').value;
            const confirmar = this.value;
            const mismatch = document.getElementById('senhaMismatch');
            
            if (confirmar.length > 0 && senha !== confirmar) {
                mismatch.style.display = 'block';
            } else {
                mismatch.style.display = 'none';
            }
        });

        // Validar formulário
        document.getElementById('novaSenhaForm').addEventListener('submit', function(e) {
            const senha = document.getElementById('novaSenha').value;
            const confirmar = document.getElementById('confirmarSenha').value;

            if (senha !== confirmar) {
                e.preventDefault();
                document.getElementById('senhaMismatch').style.display = 'block';
                return;
            }

            const btn = document.getElementById('btnRedefinir');
            btn.disabled = true;
            btn.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i> Redefinindo...';
        });
    </script>
</body>
</html>
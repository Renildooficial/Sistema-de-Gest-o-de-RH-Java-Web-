<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core"%>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt"%>

<jsp:include page="/WEB-INF/views/layout/header.jsp">
    <jsp:param name="pageTitle" value="Editar Salário" />
    <jsp:param name="activeMenu" value="salarios" />
</jsp:include>

<style>
    .form-container {
        max-width: 700px;
        margin: 0 auto;
        background: #fff;
        border-radius: var(--border-radius);
        padding: 30px;
        border: 1px solid var(--gray-border);
        box-shadow: var(--shadow-sm);
    }
    
    .form-title {
        font-size: 20px;
        font-weight: 700;
        color: var(--dark);
        margin-bottom: 24px;
        display: flex;
        align-items: center;
        gap: 12px;
    }
    
    .form-title i {
        color: var(--primary);
        background: var(--primary-light);
        padding: 10px;
        border-radius: 12px;
        font-size: 18px;
    }
    
    .form-group {
        margin-bottom: 16px;
    }
    
    .form-group label {
        display: block;
        font-size: 13px;
        font-weight: 600;
        color: var(--dark);
        margin-bottom: 4px;
    }
    
    .form-group .required {
        color: var(--danger);
    }
    
    .form-control {
        width: 100%;
        padding: 10px 14px;
        border: 1px solid var(--gray-border);
        border-radius: 8px;
        font-size: 14px;
        transition: border-color 0.2s;
    }
    
    .form-control:focus {
        outline: none;
        border-color: var(--primary);
        box-shadow: 0 0 0 3px rgba(79, 70, 229, 0.1);
    }
    
    .form-control.input-money {
        font-family: 'Courier New', monospace;
        font-weight: 600;
    }
    
    .form-actions {
        display: flex;
        gap: 12px;
        margin-top: 24px;
        flex-wrap: wrap;
    }
    
    .btn-primary-custom {
        background: var(--primary);
        color: #fff;
        padding: 10px 28px;
        border: none;
        border-radius: 8px;
        font-size: 14px;
        font-weight: 600;
        display: inline-flex;
        align-items: center;
        gap: 8px;
        text-decoration: none;
        cursor: pointer;
        transition: all 0.2s ease;
    }
    
    .btn-primary-custom:hover {
        background: var(--primary-hover);
        color: #fff;
        transform: translateY(-2px);
        box-shadow: 0 4px 12px rgba(79, 70, 229, 0.3);
    }
    
    .btn-outline-custom {
        display: inline-flex;
        align-items: center;
        gap: 8px;
        padding: 10px 28px;
        border: 1.5px solid var(--gray-border);
        border-radius: 8px;
        background: transparent;
        color: var(--gray);
        font-size: 14px;
        font-weight: 600;
        text-decoration: none;
        cursor: pointer;
        transition: all 0.2s ease;
    }
    
    .btn-outline-custom:hover {
        background: var(--gray-light);
        color: var(--dark);
        border-color: #cbd5e1;
    }
    
    .funcionario-info {
        background: var(--gray-light);
        padding: 16px 20px;
        border-radius: 8px;
        margin-bottom: 20px;
        display: flex;
        align-items: center;
        gap: 16px;
    }
    
    .funcionario-info .avatar {
        width: 48px;
        height: 48px;
        border-radius: 50%;
        background: linear-gradient(135deg, var(--primary), #7c3aed);
        display: flex;
        align-items: center;
        justify-content: center;
        color: #fff;
        font-weight: 700;
        font-size: 20px;
        flex-shrink: 0;
    }
    
    .funcionario-info .nome {
        font-size: 18px;
        font-weight: 700;
        color: var(--dark);
    }
    
    .funcionario-info .id {
        font-size: 13px;
        color: var(--gray);
    }
    
    .help-text {
        font-size: 12px;
        color: var(--gray);
        margin-top: 4px;
    }
    
    .row {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 16px;
    }
    
    .alert-danger-custom {
        background: #fee2e2;
        border: 1px solid #fca5a5;
        color: #991b1b;
        padding: 12px 16px;
        border-radius: 8px;
        display: flex;
        align-items: center;
        gap: 10px;
        margin-bottom: 16px;
    }
    
    @media (max-width: 600px) {
        .row {
            grid-template-columns: 1fr;
        }
        .form-container {
            padding: 20px;
        }
        .funcionario-info {
            flex-direction: column;
            text-align: center;
        }
    }
</style>

<div class="form-container animate-in">
    <div class="form-title">
        <i class="fas fa-coins"></i>
        Editar Salário do Funcionário
    </div>
    
    <!-- Mensagens de erro -->
    <c:if test="${not empty param.erro}">
        <div class="alert-danger-custom">
            <i class="fas fa-exclamation-circle"></i>
            <span>${param.erro}</span>
        </div>
    </c:if>
    
    <div class="funcionario-info">
        <div class="avatar">
            ${funcionario.nome.charAt(0)}
        </div>
        <div>
            <div class="nome">${funcionario.nome}</div>
            <div class="id">ID: #${funcionario.id} | Status: ${funcionario.status}</div>
        </div>
    </div>
    
    <form id="formSalario" action="${pageContext.request.contextPath}/financeiro/salvar-salario" method="post">
        <input type="hidden" name="idFuncionario" value="${funcionario.id}">
        
        <div class="row">
            <div class="form-group">
                <label>Salário Base <span class="required">*</span></label>
                <input type="text" class="form-control input-money" name="salarioBase" 
                       value="<fmt:formatNumber value="${funcionario.salarioBase}" pattern="#,##0.00"/>" 
                       placeholder="Ex: 45000.00" required>
                <div class="help-text">Digite o salário base mensal do funcionário</div>
            </div>
            
            <div class="form-group">
                <label>Subsídio de Alimentação</label>
                <input type="text" class="form-control input-money" name="subsidioAlimentacao" 
                       value="<fmt:formatNumber value="${funcionario.subsidioAlimentacao}" pattern="#,##0.00"/>" 
                       placeholder="Ex: 500.00">
                <div class="help-text">Valor do subsídio de alimentação</div>
            </div>
            
            <div class="form-group">
                <label>Subsídio de Transporte</label>
                <input type="text" class="form-control input-money" name="subsidioTransporte" 
                       value="<fmt:formatNumber value="${funcionario.subsidioTransporte}" pattern="#,##0.00"/>" 
                       placeholder="Ex: 300.00">
                <div class="help-text">Valor do subsídio de transporte</div>
            </div>
            
            <div class="form-group">
                <label>Subsídio de Saúde</label>
                <input type="text" class="form-control input-money" name="subsidioSaude" 
                       value="<fmt:formatNumber value="${funcionario.subsidioSaude}" pattern="#,##0.00"/>" 
                       placeholder="Ex: 200.00">
                <div class="help-text">Valor do subsídio de saúde</div>
            </div>
        </div>
        
        <div style="margin-top: 16px; padding: 16px; background: #f0fdf4; border-radius: 8px; border: 1px solid #bbf7d0;">
            <div style="font-size: 13px; color: #166534; display: flex; align-items: center; gap: 8px;">
                <i class="fas fa-info-circle"></i>
                <span>Os descontos (IRS e INSS) são calculados automaticamente com base nas configurações do sistema.</span>
            </div>
        </div>
        
        <div class="form-actions">
            <button type="submit" class="btn-primary-custom">
                <i class="fas fa-save"></i> Salvar Salário
            </button>
            <a href="${pageContext.request.contextPath}/financeiro/salarios" class="btn-outline-custom">
                <i class="fas fa-times"></i> Cancelar
            </a>
        </div>
    </form>
</div>

<script>
// Formatar campos monetários
document.querySelectorAll('.input-money').forEach(input => {
    input.addEventListener('blur', function() {
        let value = this.value.replace(/[^0-9,.]/g, '');
        if (value) {
            let num = parseFloat(value.replace(',', '.'));
            if (!isNaN(num)) {
                this.value = num.toFixed(2);
            }
        }
    });
});

// Validar formulário antes de enviar
document.getElementById('formSalario').addEventListener('submit', function(e) {
    var salarioBase = document.querySelector('input[name="salarioBase"]');
    if (!salarioBase.value || parseFloat(salarioBase.value.replace(',', '.')) <= 0) {
        alert('⚠️ O salário base deve ser maior que zero!');
        e.preventDefault();
        return false;
    }
    return true;
});
</script>

<jsp:include page="/WEB-INF/views/layout/footer.jsp" />
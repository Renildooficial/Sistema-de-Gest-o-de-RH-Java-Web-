<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" isELIgnored="false"%>
<%@ taglib prefix="c" uri="jakarta.tags.core"%>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt"%>

<jsp:include page="/WEB-INF/views/layout/header.jsp">
    <jsp:param name="pageTitle" value="Minhas Nomeações" />
    <jsp:param name="activeMenu" value="minhas-nomeacoes" />
</jsp:include>

<!-- Estilos adicionais para responsividade -->
<style>
    .nomeacoes-container {
        padding: 1rem 0;
    }
    
    .stats-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
        gap: 1rem;
        margin-bottom: 2rem;
    }
    
    .stat-card {
        background: var(--card-bg, #fff);
        border-radius: 12px;
        padding: 1.25rem 1rem;
        box-shadow: 0 2px 8px rgba(0,0,0,0.08);
        text-align: center;
        transition: transform 0.2s;
    }
    
    .stat-card:hover {
        transform: translateY(-3px);
    }
    
    .stat-icon {
        width: 48px;
        height: 48px;
        border-radius: 50%;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        font-size: 1.25rem;
        margin-bottom: 0.5rem;
    }
    
    .stat-icon.blue { background: rgba(13, 110, 253, 0.12); color: #0d6efd; }
    .stat-icon.green { background: rgba(25, 135, 84, 0.12); color: #198754; }
    .stat-icon.yellow { background: rgba(255, 193, 7, 0.12); color: #ffc107; }
    
    .stat-value {
        font-size: 1.75rem;
        font-weight: 700;
        line-height: 1.2;
    }
    
    .stat-label {
        font-size: 0.875rem;
        color: var(--gray, #6c757d);
        margin-top: 0.25rem;
    }
    
    .table-responsive-custom {
        overflow-x: auto;
        -webkit-overflow-scrolling: touch;
        margin: 0 -0.5rem;
        padding: 0 0.5rem;
    }
    
    .table-custom {
        width: 100%;
        min-width: 600px;
        border-collapse: collapse;
        font-size: 0.9rem;
    }
    
    .table-custom thead th {
        background: var(--table-header-bg, #f8f9fa);
        color: var(--table-header-color, #495057);
        font-weight: 600;
        padding: 0.75rem 1rem;
        text-align: left;
        border-bottom: 2px solid var(--border-color, #dee2e6);
        white-space: nowrap;
    }
    
    .table-custom tbody td {
        padding: 0.75rem 1rem;
        border-bottom: 1px solid var(--border-color, #dee2e6);
        vertical-align: middle;
    }
    
    .table-custom tbody tr:hover {
        background: var(--table-hover-bg, rgba(0,0,0,0.02));
    }
    
    .status-badge {
        display: inline-block;
        padding: 0.25rem 0.75rem;
        border-radius: 20px;
        font-size: 0.75rem;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.3px;
    }
    
    .status-badge.ativo {
        background: rgba(25, 135, 84, 0.12);
        color: #198754;
    }
    
    .status-badge.inativo {
        background: rgba(108, 117, 125, 0.12);
        color: #6c757d;
    }
    
    .status-badge.pendente {
        background: rgba(255, 193, 7, 0.12);
        color: #ffc107;
    }
    
    .empty-state {
        text-align: center;
        padding: 3rem 1rem;
        color: var(--gray, #6c757d);
    }
    
    .empty-state i {
        font-size: 3rem;
        margin-bottom: 1rem;
        opacity: 0.3;
    }
    
    .animate-in {
        opacity: 0;
        animation: fadeInUp 0.4s ease forwards;
    }
    
    .animate-in-d1 { animation-delay: 0.05s; }
    .animate-in-d2 { animation-delay: 0.1s; }
    .animate-in-d3 { animation-delay: 0.15s; }
    .animate-in-d4 { animation-delay: 0.2s; }
    
    @keyframes fadeInUp {
        from { opacity: 0; transform: translateY(15px); }
        to { opacity: 1; transform: translateY(0); }
    }
    
    @media (max-width: 768px) {
        .stats-grid {
            grid-template-columns: repeat(3, 1fr);
            gap: 0.75rem;
        }
        
        .stat-card {
            padding: 0.75rem 0.5rem;
        }
        
        .stat-value {
            font-size: 1.25rem;
        }
        
        .stat-label {
            font-size: 0.7rem;
        }
        
        .stat-icon {
            width: 36px;
            height: 36px;
            font-size: 0.9rem;
        }
        
        .table-custom {
            font-size: 0.8rem;
        }
        
        .table-custom thead th,
        .table-custom tbody td {
            padding: 0.5rem 0.75rem;
        }
    }
    
    @media (max-width: 480px) {
        .stats-grid {
            grid-template-columns: 1fr 1fr;
            gap: 0.5rem;
        }
        
        .stat-card {
            padding: 0.5rem;
        }
        
        .stat-value {
            font-size: 1rem;
        }
        
        .stat-icon {
            width: 28px;
            height: 28px;
            font-size: 0.75rem;
        }
        
        .table-custom {
            font-size: 0.7rem;
            min-width: 480px;
        }
        
        .table-custom thead th,
        .table-custom tbody td {
            padding: 0.35rem 0.5rem;
        }
    }
</style>

<div class="nomeacoes-container">
    <!-- Cards de estatísticas -->
    <div class="stats-grid">
        <div class="stat-card animate-in animate-in-d1">
            <div class="stat-icon blue">
                <i class="fas fa-briefcase"></i>
            </div>
            <div class="stat-value">${total != null ? total : '0'}</div>
            <div class="stat-label">Total de Nomeações</div>
        </div>
        <div class="stat-card animate-in animate-in-d2">
            <div class="stat-icon green">
                <i class="fas fa-check-circle"></i>
            </div>
            <div class="stat-value">${ativas != null ? ativas : '0'}</div>
            <div class="stat-label">Ativas</div>
        </div>
    </div>

    <!-- Tabela de nomeações -->
    <div class="table-section animate-in animate-in-d4">
        <div class="table-header" style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 0.5rem; margin-bottom: 1rem;">
            <div class="title" style="font-weight: 600; font-size: 1.1rem;">
                <i class="fas fa-list me-2"></i>
                Histórico de Nomeações
            </div>
            <span style="font-size: 0.8rem; color: var(--gray, #6c757d);">
                <i class="fas fa-chevron-left me-1"></i>
                Deslize para ver mais
                <i class="fas fa-chevron-right ms-1"></i>
            </span>
        </div>
        
        <div class="table-responsive-custom">
            <table class="table-custom">
                <thead>
                    <tr>
                        <th>Função</th>
                        <th>Cargo</th>
                        <th>Despacho</th>
                        <th>Início</th>
                        <th>Fim</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <c:forEach items="${nomeacoes}" var="n">
                        <tr>
                            <td><strong>${n.funcao}</strong></td>
                            <td>${n.cargo}</td>
                            <td>${n.despacho}</td>
                            <td><fmt:formatDate value="${n.dataInicio}" pattern="dd/MM/yyyy" /></td>
                            <td>
                                <c:if test="${n.dataFim != null}">
                                    <fmt:formatDate value="${n.dataFim}" pattern="dd/MM/yyyy" />
                                </c:if>
                                <c:if test="${n.dataFim == null}">
                                    <span style="color: var(--gray, #6c757d);">Em vigor</span>
                                </c:if>
                            </td>
                            <td>
                                <span class="status-badge ${n.status == 'ATIVA' ? 'ativo' : n.status == 'PENDENTE' ? 'pendente' : 'inativo'}">
                                    ${n.status}
                                </span>
                            </td>
                        </tr>
                    </c:forEach>
                    <c:if test="${empty nomeacoes}">
                        <tr>
                            <td colspan="6">
                                <div class="empty-state">
                                    <i class="fas fa-inbox"></i>
                                    <p>Nenhuma nomeação cadastrada</p>
                                </div>
                            </td>
                        </tr>
                    </c:if>
                </tbody>
            </table>
        </div>
    </div>
</div>

<jsp:include page="/WEB-INF/views/layout/footer.jsp" />
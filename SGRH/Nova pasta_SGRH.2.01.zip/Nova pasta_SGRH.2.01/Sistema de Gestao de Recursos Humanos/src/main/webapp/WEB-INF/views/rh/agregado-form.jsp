<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core"%>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt"%>

<jsp:include page="/WEB-INF/views/layout/header.jsp">
    <jsp:param name="pageTitle" value="${acao == 'cadastrar' ? 'Novo Agregado' : 'Editar Agregado'}" />
    <jsp:param name="activeMenu" value="agregados" />
</jsp:include>

<style>
    .required { color: var(--danger); font-weight: 700; }
    .form-group label { font-weight: 600; font-size: 13px; color: var(--dark); margin-bottom: 4px; }
    .form-control, .form-select { border-radius: 10px; border: 1px solid var(--gray-border); padding: 8px 12px; font-size: 13px; transition: var(--transition); }
    .form-control:focus, .form-select:focus { border-color: var(--primary); box-shadow: 0 0 0 3px rgba(79,70,229,0.1); }
    .form-container { background: #fff; border-radius: var(--border-radius); padding: 28px; box-shadow: var(--shadow-sm); border: 1px solid var(--gray-border); margin-bottom: 24px; }
    .form-title { font-size: 20px; font-weight: 700; color: var(--dark); margin-bottom: 24px; display: flex; align-items: center; gap: 12px; }
    .form-title i { color: var(--primary); }
    .form-actions { margin-top: 24px; padding-top: 20px; border-top: 1px solid var(--gray-border); display: flex; gap: 12px; flex-wrap: wrap; }
    .helper-text { font-size: 11px; color: var(--gray); margin-top: 4px; }
    .helper-text i { color: var(--info); }
    .helper-text .required-doc { color: var(--danger); font-weight: 600; }
    .documento-group { display: flex; gap: 10px; flex-wrap: wrap; }
    .documento-group .form-select { width: 40%; min-width: 140px; }
    .documento-group .form-control { width: 55%; min-width: 160px; }
    
    @media (max-width: 576px) {
        .documento-group .form-select { width: 100%; }
        .documento-group .form-control { width: 100%; }
    }
</style>

<div class="form-container animate-in">
    <div class="form-title">
        <i class="fas ${acao == 'cadastrar' ? 'fa-user-plus' : 'fa-user-edit'}"></i>
        ${acao == 'cadastrar' ? 'Cadastrar Agregado' : 'Editar Agregado'}
    </div>

    <form action="${pageContext.request.contextPath}/agregados" method="post" id="agregadoForm">
        <input type="hidden" name="id" value="${agregado.id}">

        <div class="row g-3">
            <!-- Funcionário -->
            <div class="col-md-6">
                <div class="form-group">
                    <label>Funcionário <span class="required">*</span></label>
                    <select class="form-select" name="idFuncionario" id="idFuncionario" required>
                        <option value="">Selecione um funcionário</option>
                        <c:forEach items="${funcionarios}" var="f">
                            <option value="${f.id}" ${agregado.idFuncionario == f.id ? 'selected' : ''}>
                                ${f.nome}
                            </option>
                        </c:forEach>
                    </select>
                </div>
            </div>

            <!-- Nome do Agregado -->
            <div class="col-md-6">
                <div class="form-group">
                    <label>Nome do Agregado <span class="required">*</span></label>
                    <input type="text" class="form-control" name="nome" id="nome"
                           value="${agregado.nome}" required 
                           placeholder="Digite o nome completo" 
                           minlength="3" maxlength="100">
                    <div class="helper-text"><i class="fas fa-info-circle"></i> Mínimo 3 caracteres, máximo 100</div>
                </div>
            </div>

            <!-- Grau de Parentesco -->
            <div class="col-md-6">
                <div class="form-group">
                    <label>Grau de Parentesco <span class="required">*</span></label>
                    <select class="form-select" name="grauParentesco" id="grauParentesco" required>
                        <option value="">Selecione</option>
                        <option value="CONJUGE" ${agregado.grauParentesco == 'CONJUGE' ? 'selected' : ''}>Cônjuge</option>
                        <option value="FILHO" ${agregado.grauParentesco == 'FILHO' ? 'selected' : ''}>Filho</option>
                        <option value="FILHA" ${agregado.grauParentesco == 'FILHA' ? 'selected' : ''}>Filha</option>
                        <option value="PAI" ${agregado.grauParentesco == 'PAI' ? 'selected' : ''}>Pai</option>
                        <option value="MAE" ${agregado.grauParentesco == 'MAE' ? 'selected' : ''}>Mãe</option>
                        <option value="IRMAO" ${agregado.grauParentesco == 'IRMAO' ? 'selected' : ''}>Irmão</option>
                        <option value="IRMA" ${agregado.grauParentesco == 'IRMA' ? 'selected' : ''}>Irmã</option>
                        <option value="AVO" ${agregado.grauParentesco == 'AVO' ? 'selected' : ''}>Avô/Avó</option>
                        <option value="TIO" ${agregado.grauParentesco == 'TIO' ? 'selected' : ''}>Tio/Tia</option>
                        <option value="PRIMO" ${agregado.grauParentesco == 'PRIMO' ? 'selected' : ''}>Primo/Prima</option>
                        <option value="SOBRINHO" ${agregado.grauParentesco == 'SOBRINHO' ? 'selected' : ''}>Sobrinho/Sobrinha</option>
                        <option value="OUTRO" ${agregado.grauParentesco == 'OUTRO' ? 'selected' : ''}>Outro</option>
                    </select>
                </div>
            </div>

            <!-- Data de Nascimento -->
            <div class="col-md-6">
                <div class="form-group">
                    <label>Data de Nascimento <span class="required">*</span></label>
                    <input type="date" class="form-control" name="dataNascimento" id="dataNascimento"
                           value="${agregado.dataNascimento != null ? agregado.dataNascimento : ''}" required>
                    <div class="helper-text"><i class="fas fa-info-circle"></i> O agregado deve ter pelo menos 1 ano</div>
                </div>
            </div>

            <!-- Tipo e Número do Documento com validação por tipo -->
            <div class="col-md-12">
                <div class="form-group">
                    <label>Documento de Identificação</label>
                    <div class="documento-group">
                        <select class="form-select" name="tipoDocumento" id="tipoDocumento" onchange="atualizarValidacaoDocumento()">
                            <option value="">Tipo</option>
                            <option value="BI" ${agregado.tipoDocumento == 'BI' ? 'selected' : ''}>BI (Bilhete de Identidade)</option>
                            <option value="PASSAPORTE" ${agregado.tipoDocumento == 'PASSAPORTE' ? 'selected' : ''}>Passaporte</option>
                            <option value="RG" ${agregado.tipoDocumento == 'RG' ? 'selected' : ''}>RG</option>
                            <option value="CERTIDAO" ${agregado.tipoDocumento == 'CERTIDAO' ? 'selected' : ''}>Certidão de Nascimento</option>
                            <option value="OUTRO" ${agregado.tipoDocumento == 'OUTRO' ? 'selected' : ''}>Outro</option>
                        </select>
                        <input type="text" class="form-control" name="documento" id="documento"
                               value="${agregado.documento}" 
                               placeholder="Nº do documento" maxlength="30">
                    </div>
                    <div class="helper-text" id="docHelperText">
                        <i class="fas fa-info-circle"></i> 
                        <span id="docMensagem">Selecione o tipo de documento para ver o formato</span>
                    </div>
                </div>
            </div>

            <!-- Status -->
            <div class="col-md-6">
                <div class="form-group">
                    <label>Status <span class="required">*</span></label>
                    <select class="form-select" name="ativo" required>
                        <option value="true" ${agregado.ativo ? 'selected' : ''}>Ativo</option>
                        <option value="false" ${!agregado.ativo ? 'selected' : ''}>Inativo</option>
                    </select>
                </div>
            </div>

            <!-- Observação -->
            <div class="col-md-12">
                <div class="form-group">
                    <label>Observação</label>
                    <textarea class="form-control" name="observacao" id="observacao" 
                              rows="2" maxlength="255" 
                              placeholder="Observações adicionais sobre o agregado">${agregado.observacao}</textarea>
                    <div class="helper-text"><i class="fas fa-info-circle"></i> Máximo 255 caracteres</div>
                </div>
            </div>

            <!-- Exibir idade (apenas visualização) -->
            <c:if test="${not empty agregado.id}">
                <div class="col-md-12">
                    <div class="form-group" style="background: var(--gray-light); padding: 12px 16px; border-radius: 10px;">
                        <span style="font-weight: 600; color: var(--dark);">
                            <i class="fas fa-info-circle me-2" style="color: var(--info);"></i>
                            Idade do agregado: <strong>${agregado.idade} anos</strong>
                        </span>
                    </div>
                </div>
            </c:if>
        </div>

        <div class="form-actions">
            <button type="submit" class="btn-primary-custom" id="btnSalvar">
                <i class="fas fa-save"></i> ${acao == 'cadastrar' ? 'Cadastrar' : 'Atualizar'}
            </button>
            <a href="${pageContext.request.contextPath}/agregados" class="btn-outline-custom">
                <i class="fas fa-times"></i> Cancelar
            </a>
        </div>
    </form>
</div>

<script>
// ============================================================
// VALIDAÇÃO POR TIPO DE DOCUMENTO (MOÇAMBIQUE) COM LIMITE
// ============================================================
const validacoesDocumento = {
    'BI': {
        regex: /^[A-Za-z0-9]{10,16}$/,
        min: 10,
        max: 16,
        mensagem: 'BI deve ter 10 a 16 caracteres alfanuméricos (ex: 1234567890123)'
    },
    'PASSAPORTE': {
        regex: /^[A-Za-z0-9]{6,12}$/,
        min: 6,
        max: 12,
        mensagem: 'Passaporte deve ter 6 a 12 caracteres alfanuméricos (ex: AB123456)'
    },
    'RG': {
        regex: /^[0-9]{7,12}$/,
        min: 7,
        max: 12,
        mensagem: 'RG deve ter 7 a 12 dígitos numéricos (ex: 123456789)'
    },
    'CERTIDAO': {
        regex: /^[A-Za-z0-9\-]{8,20}$/,
        min: 8,
        max: 20,
        mensagem: 'Certidão deve ter 8 a 20 caracteres alfanuméricos (pode conter hífen)'
    },
    'OUTRO': {
        regex: /^[A-Za-z0-9\-]{3,30}$/,
        min: 3,
        max: 30,
        mensagem: 'Documento deve ter 3 a 30 caracteres alfanuméricos (pode conter hífen)'
    }
};

// ============================================================
// ATUALIZAR VALIDAÇÃO DO DOCUMENTO (COM LIMITE)
// ============================================================
function atualizarValidacaoDocumento() {
    const tipo = document.getElementById('tipoDocumento').value;
    const docInput = document.getElementById('documento');
    const helperText = document.getElementById('docMensagem');
    
    if (tipo && validacoesDocumento[tipo]) {
        const validacao = validacoesDocumento[tipo];
        
        // Atualizar mensagem
        helperText.innerHTML = '<span class="required-doc">*</span> ' + validacao.mensagem;
        
        // Atualizar placeholder
        docInput.placeholder = 'Digite o número do ' + tipo + ' (' + validacao.min + '-' + validacao.max + ' caracteres)';
        
        // ATUALIZAR O LIMITE MÁXIMO
        docInput.maxLength = validacao.max;
        
        // Definir pattern para validação HTML5
        docInput.setAttribute('pattern', validacao.regex.source);
        docInput.title = validacao.mensagem;
        
        // Se o valor atual for maior que o novo limite, cortar
        if (docInput.value.length > validacao.max) {
            docInput.value = docInput.value.slice(0, validacao.max);
        }
    } else {
        helperText.textContent = 'Selecione o tipo de documento para ver o formato';
        docInput.placeholder = 'Nº do documento';
        docInput.maxLength = 30;
        docInput.removeAttribute('pattern');
        docInput.title = '';
    }
}

// ============================================================
// VALIDAÇÃO DO FORMULÁRIO
// ============================================================
document.getElementById('agregadoForm').addEventListener('submit', function(e) {
    let isValid = true;
    let errorMessages = [];
    
    // 1. VALIDAÇÃO DO NOME
    const nome = document.getElementById('nome');
    if (nome.value.trim().length < 3) {
        errorMessages.push('Nome deve ter no mínimo 3 caracteres');
        isValid = false;
    }
    if (nome.value.trim().length > 100) {
        errorMessages.push('Nome deve ter no máximo 100 caracteres');
        isValid = false;
    }
    
    // 2. VALIDAÇÃO DO FUNCIONÁRIO
    const idFuncionario = document.getElementById('idFuncionario');
    if (!idFuncionario.value) {
        errorMessages.push('Selecione um funcionário');
        isValid = false;
    }
    
    // 3. VALIDAÇÃO DO GRAU DE PARENTESCO
    const grauParentesco = document.getElementById('grauParentesco');
    if (!grauParentesco.value) {
        errorMessages.push('Selecione o grau de parentesco');
        isValid = false;
    }
    
    // 4. VALIDAÇÃO DA DATA DE NASCIMENTO
    const dataNasc = document.getElementById('dataNascimento');
    if (dataNasc.value) {
        const nascimento = new Date(dataNasc.value);
        const hoje = new Date();
        let idade = hoje.getFullYear() - nascimento.getFullYear();
        const mes = hoje.getMonth() - nascimento.getMonth();
        if (mes < 0 || (mes === 0 && hoje.getDate() < nascimento.getDate())) {
            idade--;
        }
        if (idade < 1) {
            errorMessages.push('O agregado deve ter pelo menos 1 ano de idade');
            isValid = false;
        }
        if (idade > 120) {
            errorMessages.push('Idade inválida (máximo 120 anos)');
            isValid = false;
        }
    } else {
        errorMessages.push('Data de nascimento é obrigatória');
        isValid = false;
    }
    
    // 5. VALIDAÇÃO DO DOCUMENTO
    const tipoDocumento = document.getElementById('tipoDocumento');
    const documento = document.getElementById('documento');
    
    if (tipoDocumento.value && !documento.value.trim()) {
        errorMessages.push('Informe o número do documento');
        isValid = false;
    }
    
    if (documento.value.trim() && !tipoDocumento.value) {
        errorMessages.push('Selecione o tipo do documento');
        isValid = false;
    }
    
    // Validação específica por tipo (incluindo tamanho mínimo e máximo)
    if (documento.value.trim() && tipoDocumento.value) {
        const validacao = validacoesDocumento[tipoDocumento.value];
        if (validacao) {
            // Validar tamanho mínimo
            if (documento.value.trim().length < validacao.min) {
                errorMessages.push('Documento deve ter no mínimo ' + validacao.min + ' caracteres');
                isValid = false;
            }
            // Validar tamanho máximo
            if (documento.value.trim().length > validacao.max) {
                errorMessages.push('Documento deve ter no máximo ' + validacao.max + ' caracteres');
                isValid = false;
            }
            // Validar padrão
            if (!validacao.regex.test(documento.value.trim())) {
                errorMessages.push(validacao.mensagem);
                isValid = false;
            }
        }
    }
    
    // 6. VALIDAÇÃO DA OBSERVAÇÃO
    const observacao = document.getElementById('observacao');
    if (observacao.value.length > 255) {
        errorMessages.push('Observação deve ter no máximo 255 caracteres');
        isValid = false;
    }
    
    // SE HOUVER ERROS, EXIBIR E CANCELAR
    if (!isValid) {
        e.preventDefault();
        const msg = errorMessages.join('\n');
        showNotification('error', 'Erro de Validação', msg);
        return false;
    }
    
    return true;
});

// ============================================================
// MÁSCARA PARA DOCUMENTO (apenas caracteres permitidos)
// ============================================================
document.getElementById('documento').addEventListener('input', function(e) {
    const tipo = document.getElementById('tipoDocumento').value;
    const validacao = validacoesDocumento[tipo];
    
    if (tipo === 'RG') {
        // RG: apenas números
        this.value = this.value.replace(/[^0-9]/g, '');
    } else {
        // Outros: alfanumérico e hífen
        this.value = this.value.replace(/[^A-Za-z0-9\-]/g, '');
    }
    
    // Aplicar limite máximo dinâmico
    if (validacao && this.value.length > validacao.max) {
        this.value = this.value.slice(0, validacao.max);
    }
    
    // Limite global de segurança
    if (this.value.length > 30) {
        this.value = this.value.slice(0, 30);
    }
});

// ============================================================
// LIMPAR DOCUMENTO QUANDO MUDAR O TIPO
// ============================================================
document.getElementById('tipoDocumento').addEventListener('change', function() {
    const docInput = document.getElementById('documento');
    // Opcional: limpar o campo ao mudar o tipo
    // docInput.value = '';
    atualizarValidacaoDocumento();
});

// ============================================================
// CARREGAR VALIDAÇÃO INICIAL
// ============================================================
document.addEventListener('DOMContentLoaded', function() {
    atualizarValidacaoDocumento();
});

// ============================================================
// CALCULAR IDADE EM TEMPO REAL (visual)
// ============================================================
document.getElementById('dataNascimento').addEventListener('change', function() {
    // Apenas para visualização
});
</script>

<jsp:include page="/WEB-INF/views/layout/footer.jsp" />
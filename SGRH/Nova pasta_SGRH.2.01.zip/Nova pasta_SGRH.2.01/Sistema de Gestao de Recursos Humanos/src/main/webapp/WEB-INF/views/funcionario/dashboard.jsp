<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" isELIgnored="false"%>
<%@ taglib prefix="c" uri="jakarta.tags.core"%>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt"%>

<jsp:include page="/WEB-INF/views/layout/header.jsp">
    <jsp:param name="pageTitle" value="Dashboard - Funcionário" />
    <jsp:param name="activeMenu" value="dashboard" />
</jsp:include>

<style>
    .dashboard-container {
        padding: 0.5rem 0;
    }
    
    /* Cards de estatísticas */
    .stats-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
        gap: 1rem;
        margin-bottom: 1.5rem;
    }
    
    .stat-card {
        background: var(--card-bg, #fff);
        border-radius: 12px;
        padding: 1.25rem 1rem;
        box-shadow: 0 2px 8px rgba(0,0,0,0.08);
        text-align: center;
        transition: transform 0.2s, box-shadow 0.2s;
        position: relative;
        overflow: hidden;
    }
    
    .stat-card:hover {
        transform: translateY(-3px);
        box-shadow: 0 4px 16px rgba(0,0,0,0.12);
    }
    
    .stat-card .stat-icon {
        width: 48px;
        height: 48px;
        border-radius: 50%;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        font-size: 1.25rem;
        margin-bottom: 0.5rem;
    }
    
    .stat-icon.blue { background: rgba(13, 110, 253, 0.12); color: #0d6efd; }
    .stat-icon.green { background: rgba(25, 135, 84, 0.12); color: #198754; }
    .stat-icon.yellow { background: rgba(255, 193, 7, 0.12); color: #ffc107; }
    .stat-icon.purple { background: rgba(111, 66, 193, 0.12); color: #6f42c1; }
    .stat-icon.red { background: rgba(220, 53, 69, 0.12); color: #dc3545; }
    .stat-icon.info { background: rgba(13, 202, 240, 0.12); color: #0dcaf0; }
    
    .stat-value {
        font-size: 1.75rem;
        font-weight: 700;
        line-height: 1.2;
    }
    
    .stat-label {
        font-size: 0.875rem;
        color: var(--gray, #6c757d);
        margin-top: 0.25rem;
    }
    
    .stat-link {
        display: inline-block;
        margin-top: 0.5rem;
        font-size: 0.8rem;
        color: var(--primary, #0d6efd);
        text-decoration: none;
        font-weight: 500;
    }
    
    .stat-link:hover {
        text-decoration: underline;
    }
    
    /* Avatar */
    .avatar {
        width: 80px;
        height: 80px;
        border-radius: 50%;
        background: linear-gradient(135deg, var(--primary, #0d6efd), var(--secondary, #6c757d));
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 32px;
        font-weight: 700;
        color: #fff;
        margin: 0 auto 12px;
    }
    
    /* Tabelas */
    .table-section {
        background: var(--card-bg, #fff);
        border-radius: 12px;
        padding: 1rem;
        box-shadow: 0 2px 8px rgba(0,0,0,0.08);
        margin-bottom: 1.5rem;
    }
    
    .table-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        flex-wrap: wrap;
        gap: 0.5rem;
        margin-bottom: 1rem;
        padding-bottom: 0.5rem;
        border-bottom: 1px solid var(--border-color, #dee2e6);
    }
    
    .table-header .title {
        font-weight: 600;
        font-size: 1rem;
        color: var(--dark, #212529);
    }
    
    .table-header .actions {
        display: flex;
        gap: 0.5rem;
        flex-wrap: wrap;
    }
    
    .btn-primary-custom {
        display: inline-flex;
        align-items: center;
        gap: 0.25rem;
        padding: 0.35rem 0.75rem;
        background: var(--primary, #0d6efd);
        color: #fff;
        border: none;
        border-radius: 6px;
        font-size: 0.8rem;
        text-decoration: none;
        transition: background 0.2s;
        cursor: pointer;
    }
    
    .btn-primary-custom:hover {
        background: var(--primary-dark, #0b5ed7);
        color: #fff;
    }
    
    .btn-outline-custom {
        display: inline-flex;
        align-items: center;
        gap: 0.25rem;
        padding: 0.35rem 0.75rem;
        background: transparent;
        color: var(--primary, #0d6efd);
        border: 1px solid var(--primary, #0d6efd);
        border-radius: 6px;
        font-size: 0.8rem;
        text-decoration: none;
        transition: all 0.2s;
    }
    
    .btn-outline-custom:hover {
        background: var(--primary, #0d6efd);
        color: #fff;
    }
    
    .btn-icon {
        width: 28px;
        height: 28px;
        border: none;
        border-radius: 6px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        transition: all 0.2s;
        font-size: 0.75rem;
    }
    
    .btn-icon.delete {
        background: rgba(220, 53, 69, 0.1);
        color: #dc3545;
    }
    
    .btn-icon.delete:hover {
        background: #dc3545;
        color: #fff;
    }
    
    .table-responsive-custom {
        overflow-x: auto;
        -webkit-overflow-scrolling: touch;
    }
    
    .table-custom {
        width: 100%;
        min-width: 500px;
        border-collapse: collapse;
        font-size: 0.85rem;
    }
    
    .table-custom thead th {
        background: var(--table-header-bg, #f8f9fa);
        color: var(--table-header-color, #495057);
        font-weight: 600;
        padding: 0.5rem 0.75rem;
        text-align: left;
        border-bottom: 2px solid var(--border-color, #dee2e6);
        white-space: nowrap;
    }
    
    .table-custom tbody td {
        padding: 0.5rem 0.75rem;
        border-bottom: 1px solid var(--border-color, #dee2e6);
        vertical-align: middle;
    }
    
    .table-custom tbody tr:hover {
        background: var(--table-hover-bg, rgba(0,0,0,0.02));
    }
    
    .status-badge {
        display: inline-block;
        padding: 0.2rem 0.6rem;
        border-radius: 20px;
        font-size: 0.7rem;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.3px;
    }
    
    .status-badge.ativo,
    .status-badge.concluido,
    .status-badge.aprovado {
        background: rgba(25, 135, 84, 0.12);
        color: #198754;
    }
    
    .status-badge.pendente,
    .status-badge.solicitada {
        background: rgba(255, 193, 7, 0.12);
        color: #ffc107;
    }
    
    .status-badge.inativo,
    .status-badge.rejeitada,
    .status-badge.cancelada {
        background: rgba(108, 117, 125, 0.12);
        color: #6c757d;
    }
    
    .status-badge.ferias,
    .status-badge.cursando {
        background: rgba(13, 202, 240, 0.12);
        color: #0dcaf0;
    }
    
    .empty-state {
        text-align: center;
        padding: 2rem 1rem;
        color: var(--gray, #6c757d);
    }
    
    .empty-state i {
        font-size: 2rem;
        margin-bottom: 0.5rem;
        opacity: 0.3;
    }
    
    .animate-in {
        opacity: 0;
        animation: fadeInUp 0.4s ease forwards;
    }
    
    .animate-in-d1 { animation-delay: 0.05s; }
    .animate-in-d2 { animation-delay: 0.1s; }
    .animate-in-d3 { animation-delay: 0.15s; }
    .animate-in-d4 { animation-delay: 0.2s; }
    .animate-in-d5 { animation-delay: 0.25s; }
    
    @keyframes fadeInUp {
        from { opacity: 0; transform: translateY(15px); }
        to { opacity: 1; transform: translateY(0); }
    }
    
    /* Responsividade */
    @media (max-width: 768px) {
        .stats-grid {
            grid-template-columns: repeat(2, 1fr);
            gap: 0.75rem;
        }
        
        .stat-card {
            padding: 0.75rem 0.5rem;
        }
        
        .stat-value {
            font-size: 1.25rem;
        }
        
        .stat-label {
            font-size: 0.7rem;
        }
        
        .stat-icon {
            width: 36px;
            height: 36px;
            font-size: 0.9rem;
        }
        
        .avatar {
            width: 60px;
            height: 60px;
            font-size: 24px;
        }
        
        .table-custom {
            font-size: 0.75rem;
            min-width: 400px;
        }
        
        .table-custom thead th,
        .table-custom tbody td {
            padding: 0.35rem 0.5rem;
        }
        
        .table-header .title {
            font-size: 0.9rem;
        }
        
        .btn-primary-custom,
        .btn-outline-custom {
            font-size: 0.7rem;
            padding: 0.25rem 0.5rem;
        }
    }
    
    @media (max-width: 480px) {
        .stats-grid {
            grid-template-columns: 1fr 1fr;
            gap: 0.5rem;
        }
        
        .stat-card {
            padding: 0.5rem;
        }
        
        .stat-value {
            font-size: 1rem;
        }
        
        .stat-icon {
            width: 28px;
            height: 28px;
            font-size: 0.75rem;
        }
        
        .avatar {
            width: 48px;
            height: 48px;
            font-size: 18px;
        }
        
        .table-section {
            padding: 0.5rem;
        }
        
        .table-custom {
            font-size: 0.65rem;
            min-width: 340px;
        }
        
        .table-custom thead th,
        .table-custom tbody td {
            padding: 0.25rem 0.35rem;
        }
        
        .status-badge {
            font-size: 0.6rem;
            padding: 0.1rem 0.4rem;
        }
    }
</style>

<div class="dashboard-container">
    <!-- Cards de estatísticas -->
    <div class="stats-grid">
        <!-- Perfil -->
        <div class="stat-card animate-in animate-in-d1" style="text-align: center;">
            <div class="avatar">
                ${sessionScope.usuario.nome.charAt(0)}
            </div>
            <h5 style="font-weight: 700; color: var(--dark, #212529); font-size: 1rem;">${sessionScope.usuario.nome}</h5>
            <p style="color: var(--gray, #6c757d); font-size: 0.8rem; margin: 0;">${sessionScope.usuario.perfil}</p>
            <a href="${pageContext.request.contextPath}/funcionario/meus-dados" class="btn-outline-custom" style="margin-top: 0.5rem; font-size: 0.7rem; padding: 0.2rem 0.75rem;">
                <i class="fas fa-user-edit"></i> Editar
            </a>
        </div>

        <!-- Férias -->
        <div class="stat-card animate-in animate-in-d2">
            <div class="stat-icon yellow">
                <i class="fas fa-umbrella-beach"></i>
            </div>
            <div class="stat-value">${saldoFerias != null ? saldoFerias : '0'}</div>
            <div class="stat-label">Saldo de Férias (dias)</div>
            <a href="${pageContext.request.contextPath}/ferias/nova" class="stat-link">
                Solicitar <i class="fas fa-arrow-right ms-1"></i>
            </a>
        </div>

        <!-- Formações -->
        <div class="stat-card animate-in animate-in-d3">
            <div class="stat-icon purple">
                <i class="fas fa-graduation-cap"></i>
            </div>
            <div class="stat-value">${totalFormacoes != null ? totalFormacoes : '0'}</div>
            <div class="stat-label">Formações Realizadas</div>
            <a href="${pageContext.request.contextPath}/funcionario/minhas-formacoes" class="stat-link">
                Ver todas <i class="fas fa-arrow-right ms-1"></i>
            </a>
        </div>

        <!-- Nomeações -->
        <div class="stat-card animate-in animate-in-d4">
            <div class="stat-icon blue">
                <i class="fas fa-briefcase"></i>
            </div>
            <div class="stat-value">${totalNomeacoes != null ? totalNomeacoes : '0'}</div>
            <div class="stat-label">Nomeações</div>
            <a href="${pageContext.request.contextPath}/funcionario/minhas-nomeacoes" class="stat-link">
                Ver todas <i class="fas fa-arrow-right ms-1"></i>
            </a>
        </div>
    </div>

    <!-- PRÓXIMAS FÉRIAS -->
    <div class="table-section animate-in animate-in-d4">
        <div class="table-header">
            <div class="title">
                <i class="fas fa-calendar-alt me-2"></i>
                Próximas Férias
            </div>
            <div class="actions">
                <a href="${pageContext.request.contextPath}/ferias/nova" class="btn-primary-custom">
                    <i class="fas fa-plus"></i> Solicitar
                </a>
            </div>
        </div>
        <div class="table-responsive-custom">
            <table class="table-custom">
                <thead>
                    <tr>
                        <th>Período</th>
                        <th>Dias</th>
                        <th>Status</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody>
                    <c:forEach items="${minhasFerias}" var="f" begin="0" end="4">
                        <tr>
                            <td>
                                <fmt:formatDate value="${f.dataInicio}" pattern="dd/MM/yyyy" /> - 
                                <fmt:formatDate value="${f.dataFim}" pattern="dd/MM/yyyy" />
                            </td>
                            <td>${f.diasUteis}</td>
                            <td>
                                <span class="status-badge 
                                    ${f.status == 'APROVADA' ? 'aprovado' : 
                                      f.status == 'CONCLUIDA' ? 'concluido' : 
                                      f.status == 'SOLICITADA' ? 'solicitada' : 
                                      f.status == 'EM_ANDAMENTO' ? 'ferias' :
                                      f.status == 'REJEITADA' ? 'rejeitada' : 
                                      f.status == 'CANCELADA' ? 'cancelada' : 'inativo'}">
                                    ${f.status}
                                </span>
                            </td>
                            <td>
                                <c:if test="${f.status == 'SOLICITADA'}">
                                    <button class="btn-icon delete" onclick="cancelarFerias(${f.id})" title="Cancelar">
                                        <i class="fas fa-times"></i>
                                    </button>
                                </c:if>
                            </td>
                        </tr>
                    </c:forEach>
                    <c:if test="${empty minhasFerias}">
                        <tr>
                            <td colspan="4">
                                <div class="empty-state">
                                    <i class="fas fa-inbox"></i>
                                    <p>Nenhuma solicitação de férias</p>
                                </div>
                            </td>
                        </tr>
                    </c:if>
                </tbody>
            </table>
        </div>
    </div>

    <!-- FORMAÇÕES -->
    <div class="table-section animate-in animate-in-d5">
        <div class="table-header">
            <div class="title">
                <i class="fas fa-graduation-cap me-2"></i>
                Últimas Formações
            </div>
            <div class="actions">
                <a href="${pageContext.request.contextPath}/funcionario/minhas-formacoes" class="btn-outline-custom">
                    Ver todas <i class="fas fa-arrow-right ms-1"></i>
                </a>
            </div>
        </div>
        <div class="table-responsive-custom">
            <table class="table-custom">
                <thead>
                    <tr>
                        <th>Curso</th>
                        <th>Nível</th>
                        <th>Instituição</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <c:forEach items="${formacoes}" var="f" begin="0" end="4">
                        <tr>
                            <td><strong>${f.curso}</strong></td>
                            <td>${f.nivel}</td>
                            <td>${f.instituicao}</td>
                            <td>
                                <span class="status-badge 
                                    ${f.status == 'CONCLUIDO' ? 'concluido' : 
                                      f.status == 'CURSANDO' ? 'cursando' : 'inativo'}">
                                    ${f.status}
                                </span>
                            </td>
                        </tr>
                    </c:forEach>
                    <c:if test="${empty formacoes}">
                        <tr>
                            <td colspan="4">
                                <div class="empty-state">
                                    <i class="fas fa-inbox"></i>
                                    <p>Nenhuma formação cadastrada</p>
                                </div>
                            </td>
                        </tr>
                    </c:if>
                </tbody>
            </table>
        </div>
    </div>

    <!-- NOMEAÇÕES -->
    <div class="table-section animate-in animate-in-d5">
        <div class="table-header">
            <div class="title">
                <i class="fas fa-briefcase me-2"></i>
                Últimas Nomeações
            </div>
            <div class="actions">
                <a href="${pageContext.request.contextPath}/funcionario/minhas-nomeacoes" class="btn-outline-custom">
                    Ver todas <i class="fas fa-arrow-right ms-1"></i>
                </a>
            </div>
        </div>
        <div class="table-responsive-custom">
            <table class="table-custom">
                <thead>
                    <tr>
                        <th>Função</th>
                        <th>Cargo</th>
                        <th>Início</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <c:forEach items="${nomeacoes}" var="n" begin="0" end="4">
                        <tr>
                            <td><strong>${n.funcao}</strong></td>
                            <td>${n.cargo}</td>
                            <td><fmt:formatDate value="${n.dataInicio}" pattern="dd/MM/yyyy" /></td>
                            <td>
                                <span class="status-badge ${n.status == 'ATIVA' ? 'ativo' : 'inativo'}">
                                    ${n.status}
                                </span>
                            </td>
                        </tr>
                    </c:forEach>
                    <c:if test="${empty nomeacoes}">
                        <tr>
                            <td colspan="4">
                                <div class="empty-state">
                                    <i class="fas fa-inbox"></i>
                                    <p>Nenhuma nomeação cadastrada</p>
                                </div>
                            </td>
                        </tr>
                    </c:if>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Script para cancelar férias -->
<script>
function cancelarFerias(id) {
    if (confirm('Tem certeza que deseja cancelar esta solicitação de férias?')) {
        fetch('${pageContext.request.contextPath}/ferias/cancelar', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: 'id=' + id
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                showNotification('warning', 'Cancelado', data.message);
                location.reload();
            } else {
                showNotification('error', 'Erro', data.message);
            }
        })
        .catch(error => {
            showNotification('error', 'Erro', 'Erro ao cancelar solicitação');
        });
    }
}
</script>

<jsp:include page="/WEB-INF/views/layout/footer.jsp" />
<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" isELIgnored="false"%>
<%@ taglib prefix="c" uri="jakarta.tags.core"%>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt"%>

<jsp:include page="/WEB-INF/views/layout/header.jsp">
    <jsp:param name="pageTitle" value="Dashboard - RH" />
    <jsp:param name="activeMenu" value="dashboard" />
</jsp:include>

<style>
    /* ============================================================
    ESTILOS GERAIS
    ============================================================ */
    :root {
        --primary: #4f46e5;
        --success: #22c55e;
        --warning: #f59e0b;
        --danger: #ef4444;
        --gray: #64748b;
        --gray-light: #f1f5f9;
        --gray-border: #e2e8f0;
        --dark: #0f172a;
        --border-radius: 12px;
        --shadow-sm: 0 1px 3px rgba(0,0,0,0.06);
    }

    .stats-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
        gap: 16px;
        margin-bottom: 24px;
    }

    .stat-card {
        background: #fff;
        border-radius: var(--border-radius);
        padding: 20px;
        border: 1px solid var(--gray-border);
        box-shadow: var(--shadow-sm);
        text-align: center;
        transition: all 0.3s ease;
    }

    .stat-card:hover {
        transform: translateY(-4px);
        box-shadow: 0 8px 25px rgba(0,0,0,0.08);
    }

    .stat-card .stat-icon {
        width: 48px;
        height: 48px;
        border-radius: 12px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        font-size: 20px;
        margin-bottom: 12px;
    }

    .stat-icon.blue { background: rgba(79, 70, 229, 0.1); color: var(--primary); }
    .stat-icon.green { background: rgba(34, 197, 94, 0.1); color: var(--success); }
    .stat-icon.yellow { background: rgba(245, 158, 11, 0.1); color: var(--warning); }
    .stat-icon.purple { background: rgba(124, 58, 237, 0.1); color: #7c3aed; }

    .stat-value {
        font-size: 28px;
        font-weight: 700;
        color: var(--dark);
        line-height: 1.2;
    }

    .stat-label {
        font-size: 13px;
        color: var(--gray);
        margin-top: 4px;
    }

    .stat-link {
        display: inline-block;
        margin-top: 8px;
        font-size: 12px;
        font-weight: 600;
        color: var(--primary);
        text-decoration: none;
    }

    .stat-link:hover {
        text-decoration: underline;
    }

    .charts-grid {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 20px;
        margin-bottom: 24px;
    }

    .chart-card {
        background: #fff;
        border-radius: var(--border-radius);
        padding: 20px;
        border: 1px solid var(--gray-border);
        box-shadow: var(--shadow-sm);
    }

    .card-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 16px;
        flex-wrap: wrap;
        gap: 8px;
    }

    .card-title {
        font-size: 15px;
        font-weight: 600;
        color: var(--dark);
    }

    .card-subtitle {
        font-size: 12px;
        color: var(--gray);
    }

    .chart-container {
        position: relative;
        height: 250px;
        width: 100%;
    }

    /* ============================================================
    TABELA RESPONSIVA
    ============================================================ */
    .table-section {
        background: #fff;
        border-radius: var(--border-radius);
        padding: 20px;
        border: 1px solid var(--gray-border);
        box-shadow: var(--shadow-sm);
        margin-bottom: 24px;
        overflow-x: auto;
        -webkit-overflow-scrolling: touch;
    }
    
    .table-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 16px;
        flex-wrap: wrap;
        gap: 12px;
    }
    
    .table-header .title {
        font-size: 16px;
        font-weight: 700;
        color: var(--dark);
        display: flex;
        align-items: center;
        flex-wrap: wrap;
        gap: 6px;
    }
    
    .table-header .title i {
        color: var(--primary);
    }
    
    .table-header .title .badge-count {
        font-size: 12px;
        font-weight: 400;
        color: var(--gray);
        margin-left: 4px;
    }
    
    .table-header .actions {
        display: flex;
        gap: 8px;
        flex-wrap: wrap;
    }
    
    .btn-outline-custom {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        padding: 8px 16px;
        border: 1.5px solid var(--gray-border);
        border-radius: 8px;
        background: transparent;
        color: var(--gray);
        font-size: 13px;
        font-weight: 600;
        text-decoration: none;
        transition: all 0.2s ease;
        cursor: pointer;
    }
    
    .btn-outline-custom:hover {
        background: var(--gray-light);
        color: var(--dark);
        border-color: #cbd5e1;
    }
    
    .table-custom {
        width: 100%;
        border-collapse: collapse;
        font-size: 13px;
        min-width: 600px;
    }
    
    .table-custom thead th {
        background: var(--gray-light);
        padding: 10px 14px;
        text-align: left;
        font-size: 11px;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        font-weight: 700;
        color: var(--gray);
        border-bottom: 2px solid var(--gray-border);
        white-space: nowrap;
    }
    
    .table-custom tbody td {
        padding: 10px 14px;
        border-bottom: 1px solid var(--gray-border);
        vertical-align: middle;
    }
    
    .table-custom tbody tr {
        transition: all 0.3s ease;
    }
    
    .table-custom tbody tr:hover {
        background: var(--gray-light);
    }
    
    .action-btns .btn-icon {
        width: 34px;
        height: 34px;
        border: none;
        border-radius: 8px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        background: transparent;
        color: var(--gray);
        font-size: 14px;
        text-decoration: none;
        margin: 0 2px;
        position: relative;
    }
    
    .action-btns .btn-icon:hover {
        transform: translateY(-3px);
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
    }
    
    .action-btns .btn-icon.edit {
        background: rgba(16, 185, 129, 0.1);
        color: var(--success);
    }
    .action-btns .btn-icon.edit:hover {
        background: rgba(16, 185, 129, 0.2);
        box-shadow: 0 4px 12px rgba(16, 185, 129, 0.3);
    }
    
    .action-btns .btn-icon.delete {
        background: rgba(239, 68, 68, 0.1);
        color: var(--danger);
    }
    .action-btns .btn-icon.delete:hover {
        background: rgba(239, 68, 68, 0.2);
        box-shadow: 0 4px 12px rgba(239, 68, 68, 0.3);
    }
    
    .action-btns .btn-icon .tooltip {
        display: none;
        position: absolute;
        bottom: -28px;
        left: 50%;
        transform: translateX(-50%);
        background: var(--dark);
        color: #fff;
        padding: 2px 10px;
        border-radius: 4px;
        font-size: 9px;
        font-weight: 500;
        white-space: nowrap;
        z-index: 100;
    }
    
    .action-btns .btn-icon:hover .tooltip {
        display: block;
    }
    
    .status-badge {
        padding: 4px 14px;
        border-radius: 20px;
        font-size: 11px;
        font-weight: 600;
        display: inline-block;
        text-transform: uppercase;
        letter-spacing: 0.3px;
        white-space: nowrap;
    }
    
    .status-badge.ativo,
    .status-badge.aprovado {
        background: rgba(16, 185, 129, 0.12);
        color: var(--success);
        border: 1px solid rgba(16, 185, 129, 0.2);
    }
    .status-badge.pendente {
        background: rgba(245, 158, 11, 0.12);
        color: #D97706;
        border: 1px solid rgba(245, 158, 11, 0.2);
    }
    .status-badge.rejeitado,
    .status-badge.inativo {
        background: rgba(239, 68, 68, 0.12);
        color: var(--danger);
        border: 1px solid rgba(239, 68, 68, 0.2);
    }
    .status-badge.cancelado {
        background: rgba(107, 114, 128, 0.12);
        color: var(--gray);
        border: 1px solid rgba(107, 114, 128, 0.2);
    }
    .status-badge.ferias {
        background: rgba(245, 158, 11, 0.12);
        color: var(--warning);
        border: 1px solid rgba(245, 158, 11, 0.2);
    }
    
    .avatar-mini {
        width: 36px;
        height: 36px;
        border-radius: 50%;
        background: linear-gradient(135deg, var(--primary), #7c3aed);
        display: flex;
        align-items: center;
        justify-content: center;
        color: #fff;
        font-weight: 700;
        font-size: 14px;
        flex-shrink: 0;
    }
    
    .funcionario-nome {
        font-weight: 500;
        font-size: 13px;
    }
    
    .funcionario-id {
        font-size: 10px;
        color: var(--gray);
    }

    /* ============================================================
    RESPONSIVO
    ============================================================ */
    @media (max-width: 992px) {
        .charts-grid {
            grid-template-columns: 1fr 1fr;
            gap: 16px;
        }
        .chart-container {
            height: 200px;
        }
        .table-section {
            padding: 16px;
        }
        .table-header {
            flex-direction: column;
            align-items: stretch;
        }
        .table-header .actions {
            justify-content: center;
        }
        .table-custom {
            font-size: 12px;
            min-width: 500px;
        }
        .table-custom thead th {
            padding: 8px 10px;
            font-size: 10px;
        }
        .table-custom tbody td {
            padding: 8px 10px;
        }
        .stats-grid {
            grid-template-columns: repeat(2, 1fr);
        }
    }
    
    @media (max-width: 768px) {
        .charts-grid {
            grid-template-columns: 1fr;
            gap: 16px;
        }
        .chart-container {
            height: 220px;
        }
        .stats-grid {
            grid-template-columns: repeat(2, 1fr);
            gap: 12px;
        }
        .stat-card {
            padding: 16px;
        }
        .stat-value {
            font-size: 24px;
        }
        .table-section {
            padding: 12px;
        }
        .table-custom {
            font-size: 11px;
            min-width: 400px;
        }
        .table-custom thead th {
            padding: 6px 8px;
            font-size: 9px;
        }
        .table-custom tbody td {
            padding: 6px 8px;
        }
        .action-btns .btn-icon {
            width: 30px;
            height: 30px;
            font-size: 12px;
        }
        .avatar-mini {
            width: 30px;
            height: 30px;
            font-size: 12px;
        }
        .status-badge {
            font-size: 9px;
            padding: 2px 10px;
        }
        .table-header .title {
            font-size: 14px;
        }
        .funcionario-nome {
            font-size: 12px;
        }
    }
    
    @media (max-width: 576px) {
        .stats-grid {
            grid-template-columns: 1fr 1fr;
            gap: 10px;
        }
        .stat-card {
            padding: 12px;
        }
        .stat-value {
            font-size: 20px;
        }
        .stat-label {
            font-size: 11px;
        }
        .stat-icon {
            width: 36px;
            height: 36px;
            font-size: 16px;
        }
        .chart-container {
            height: 180px;
        }
        .table-section {
            padding: 10px;
        }
        .table-custom {
            font-size: 10px;
            min-width: 350px;
        }
        .table-custom thead th {
            padding: 4px 6px;
            font-size: 8px;
        }
        .table-custom tbody td {
            padding: 4px 6px;
        }
        .action-btns .btn-icon {
            width: 26px;
            height: 26px;
            font-size: 11px;
        }
        .avatar-mini {
            width: 26px;
            height: 26px;
            font-size: 10px;
        }
        .status-badge {
            font-size: 8px;
            padding: 2px 8px;
        }
        .table-header .title {
            font-size: 13px;
        }
        .funcionario-nome {
            font-size: 11px;
        }
        .btn-outline-custom {
            font-size: 10px;
            padding: 4px 10px;
        }
    }
    
    @media (max-width: 480px) {
        .stats-grid {
            grid-template-columns: 1fr 1fr;
            gap: 8px;
        }
        .stat-card {
            padding: 10px;
        }
        .stat-value {
            font-size: 18px;
        }
        .stat-icon {
            width: 32px;
            height: 32px;
            font-size: 14px;
        }
        .chart-container {
            height: 160px;
        }
        .table-custom {
            min-width: 300px;
        }
        .table-custom thead th {
            padding: 3px 4px;
            font-size: 7px;
        }
        .table-custom tbody td {
            padding: 3px 4px;
        }
        .action-btns {
            display: flex;
            flex-wrap: wrap;
            gap: 2px;
        }
        .action-btns .btn-icon {
            width: 22px;
            height: 22px;
            font-size: 10px;
            border-radius: 6px;
        }
        .avatar-mini {
            width: 22px;
            height: 22px;
            font-size: 9px;
        }
        .status-badge {
            font-size: 7px;
            padding: 1px 6px;
        }
        .funcionario-nome {
            font-size: 10px;
        }
        .table-header .title {
            font-size: 12px;
        }
    }

    /* ============================================================
    ANIMAÇÕES
    ============================================================ */
    @keyframes fadeInUp {
        from {
            opacity: 0;
            transform: translateY(20px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }

    .animate-in {
        opacity: 0;
        animation: fadeInUp 0.5s ease forwards;
    }

    .animate-in-d1 { animation-delay: 0.05s; }
    .animate-in-d2 { animation-delay: 0.10s; }
    .animate-in-d3 { animation-delay: 0.15s; }
    .animate-in-d4 { animation-delay: 0.20s; }
</style>

<!-- Stats Cards -->
<div class="stats-grid">
    <div class="stat-card animate-in animate-in-d1">
        <div class="stat-icon blue">
            <i class="fas fa-users"></i>
        </div>
        <div class="stat-value">${totalFuncionarios != null ? totalFuncionarios : '0'}</div>
        <div class="stat-label">Total de Funcionários</div>
        <a href="${pageContext.request.contextPath}/funcionarios" class="stat-link">
            Ver todos <i class="fas fa-arrow-right ms-1"></i>
        </a>
    </div>
    <div class="stat-card animate-in animate-in-d2">
        <div class="stat-icon green">
            <i class="fas fa-user-check"></i>
        </div>
        <div class="stat-value">${ativos != null ? ativos : '0'}</div>
        <div class="stat-label">Funcionários Ativos</div>
    </div>
    <div class="stat-card animate-in animate-in-d3">
        <div class="stat-icon yellow">
            <i class="fas fa-clock"></i>
        </div>
        <div class="stat-value">${feriasPendentes != null ? feriasPendentes : '0'}</div>
        <div class="stat-label">Férias Pendentes</div>
        <a href="${pageContext.request.contextPath}/ferias/pendentes" class="stat-link">
            Aprovar <i class="fas fa-arrow-right ms-1"></i>
        </a>
    </div>
    <div class="stat-card animate-in animate-in-d4">
        <div class="stat-icon purple">
            <i class="fas fa-graduation-cap"></i>
        </div>
        <div class="stat-value">${totalFormacoes != null ? totalFormacoes : '0'}</div>
        <div class="stat-label">Formações Realizadas</div>
    </div>
</div>

<!-- Charts -->
<div class="charts-grid">
    <div class="chart-card animate-in animate-in-d2">
        <div class="card-header">
            <div>
                <div class="card-title">Funcionários por Setor</div>
                <div class="card-subtitle">Distribuição atual</div>
            </div>
            <a href="${pageContext.request.contextPath}/relatorios" style="font-size: 12px; color: var(--primary); text-decoration: none; font-weight: 600;">
                Ver detalhes <i class="fas fa-arrow-right"></i>
            </a>
        </div>
        <div class="chart-container">
            <canvas id="setorChart"></canvas>
        </div>
    </div>
    <div class="chart-card animate-in animate-in-d3">
        <div class="card-header">
            <div>
                <div class="card-title">Status dos Funcionários</div>
                <div class="card-subtitle">Visão geral</div>
            </div>
        </div>
        <div class="chart-container">
            <canvas id="statusChart"></canvas>
        </div>
    </div>
</div>

<!-- Últimas Solicitações -->
<div class="table-section animate-in animate-in-d4">
    <div class="table-header">
        <div class="title">
            <i class="fas fa-clock me-2"></i>
            Últimas Solicitações de Férias
            <span class="badge-count">
                <i class="fas fa-list me-1"></i> ${ultimasSolicitacoes != null ? ultimasSolicitacoes.size() : '0'} registros
            </span>
        </div>
        <div class="actions">
            <a href="${pageContext.request.contextPath}/ferias" class="btn-outline-custom">
                Ver todas <i class="fas fa-arrow-right ms-1"></i>
            </a>
        </div>
    </div>

    <div class="table-responsive-custom">
        <table class="table-custom">
            <thead>
                <tr>
                    <th>Funcionário</th>
                    <th>Período</th>
                    <th>Status</th>
                    <th style="text-align: center;">Ações</th>
                </tr>
            </thead>
            <tbody>
                <c:forEach items="${ultimasSolicitacoes}" var="s">
                    <tr>
                        <td>
                            <c:choose>
                                <c:when test="${not empty s.funcionario}">
                                    <div style="display: flex; align-items: center; gap: 10px;">
                                        <div class="avatar-mini">
                                            ${s.funcionario.nome.charAt(0)}${s.funcionario.nome.split(' ')[1].charAt(0)}
                                        </div>
                                        <div>
                                            <div class="funcionario-nome">${s.funcionario.nome}</div>
                                            <div class="funcionario-id">ID: #${s.funcionario.id}</div>
                                        </div>
                                    </div>
                                </c:when>
                                <c:otherwise>
                                    <span style="color: var(--gray);">Funcionário não encontrado</span>
                                </c:otherwise>
                            </c:choose>
                        </td>
                        <td>
                            <div style="font-weight: 500; font-size: 13px;">
                                <fmt:formatDate value="${s.dataInicio}" pattern="dd/MM/yyyy" />
                                <i class="fas fa-arrow-right mx-1" style="font-size: 10px; color: var(--gray);"></i>
                                <fmt:formatDate value="${s.dataFim}" pattern="dd/MM/yyyy" />
                            </div>
                            <c:if test="${not empty s.diasUteis}">
                                <div style="font-size: 10px; color: var(--gray);">
                                    <i class="fas fa-calendar-day me-1"></i> ${s.diasUteis} dias
                                </div>
                            </c:if>
                        </td>
                        <td>
                            <span class="status-badge 
                                ${s.status == 'APROVADA' ? 'aprovado' : 
                                  s.status == 'SOLICITADA' ? 'pendente' : 
                                  s.status == 'REJEITADA' ? 'rejeitado' : 
                                  s.status == 'CANCELADA' ? 'cancelado' : 
                                  s.status == 'EM_ANDAMENTO' ? 'ferias' : 'inativo'}">
                                <i class="fas 
                                    ${s.status == 'APROVADA' ? 'fa-check-circle' : 
                                      s.status == 'SOLICITADA' ? 'fa-clock' : 
                                      s.status == 'REJEITADA' ? 'fa-times-circle' : 
                                      s.status == 'CANCELADA' ? 'fa-ban' : 
                                      s.status == 'EM_ANDAMENTO' ? 'fa-play-circle' : 'fa-circle'} 
                                    me-1"></i>
                                ${s.status}
                            </span>
                        </td>
                        <td style="text-align: center;">
                            <div class="action-btns" style="justify-content: center;">
                                <c:if test="${s.status == 'SOLICITADA'}">
                                    <button class="btn-icon edit" onclick="aprovarFerias(${s.id})" title="Aprovar">
                                        <i class="fas fa-check"></i>
                                        <span class="tooltip">Aprovar</span>
                                    </button>
                                    <button class="btn-icon delete" onclick="rejeitarFerias(${s.id})" title="Rejeitar">
                                        <i class="fas fa-times"></i>
                                        <span class="tooltip">Rejeitar</span>
                                    </button>
                                </c:if>
                                <c:if test="${s.status != 'SOLICITADA'}">
                                    <button class="btn-icon" onclick="verDetalhes(${s.id})" title="Ver detalhes" style="background: rgba(79, 70, 229, 0.1); color: var(--primary);">
                                        <i class="fas fa-eye"></i>
                                        <span class="tooltip">Ver detalhes</span>
                                    </button>
                                </c:if>
                            </div>
                        </td>
                    </tr>
                </c:forEach>
                <c:if test="${empty ultimasSolicitacoes}">
                    <tr>
                        <td colspan="4" style="text-align: center; padding: 50px 20px; color: var(--gray);">
                            <i class="fas fa-inbox fa-3x d-block mb-3" style="opacity: 0.3;"></i>
                            <h5 style="font-weight: 600; color: var(--dark);">Nenhuma solicitação pendente</h5>
                            <p style="font-size: 14px; color: var(--gray);">Todas as solicitações foram processadas</p>
                        </td>
                    </tr>
                </c:if>
            </tbody>
        </table>
    </div>
</div>

<script>
// ========================================
// GRÁFICO DE SETORES - RESPONSIVO
// ========================================
const ctx1 = document.getElementById('setorChart').getContext('2d');
const setorLabels = [
    <c:forEach items="${funcionariosPorSetor}" var="entry" varStatus="status">
        '${entry.key}'${!status.last ? ',' : ''}
    </c:forEach>
];
const setorData = [
    <c:forEach items="${funcionariosPorSetor}" var="entry" varStatus="status">
        ${entry.value}${!status.last ? ',' : ''}
    </c:forEach>
];

new Chart(ctx1, {
    type: 'bar',
    data: {
        labels: setorLabels.length > 0 ? setorLabels : ['Nenhum dado'],
        datasets: [{
            label: 'Funcionários',
            data: setorData.length > 0 ? setorData : [0],
            backgroundColor: [
                'rgba(79,70,229,0.8)',
                'rgba(59,130,246,0.8)',
                'rgba(16,185,129,0.8)',
                'rgba(245,158,11,0.8)',
                'rgba(124,58,237,0.8)',
                'rgba(239,68,68,0.8)',
                'rgba(14,165,233,0.8)'
            ],
            borderColor: [
                'rgba(79,70,229,1)',
                'rgba(59,130,246,1)',
                'rgba(16,185,129,1)',
                'rgba(245,158,11,1)',
                'rgba(124,58,237,1)',
                'rgba(239,68,68,1)',
                'rgba(14,165,233,1)'
            ],
            borderWidth: 2,
            borderRadius: 8,
            maxBarThickness: 40,
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: { 
            legend: { display: false } 
        },
        scales: {
            y: { 
                beginAtZero: true, 
                grid: { color: 'rgba(0,0,0,0.05)' }, 
                ticks: { stepSize: 1, font: { size: 11 } } 
            },
            x: { 
                grid: { display: false }, 
                ticks: { font: { size: 11 } } 
            }
        }
    }
});

// ========================================
// GRÁFICO DE STATUS - RESPONSIVO
// ========================================
const ctx2 = document.getElementById('statusChart').getContext('2d');
new Chart(ctx2, {
    type: 'doughnut',
    data: {
        labels: ['Ativos', 'Em Férias', 'Inativos', 'Licença', 'Afastados'],
        datasets: [{
            data: [
                ${ativos != null ? ativos : 0},
                ${ferias != null ? ferias : 0},
                ${inativos != null ? inativos : 0},
                ${licenca != null ? licenca : 0},
                ${afastados != null ? afastados : 0}
            ],
            backgroundColor: [
                'rgba(16,185,129,0.9)',
                'rgba(245,158,11,0.9)',
                'rgba(239,68,68,0.9)',
                'rgba(59,130,246,0.9)',
                'rgba(124,58,237,0.9)'
            ],
            borderColor: '#fff',
            borderWidth: 3,
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            legend: {
                position: 'bottom',
                labels: { 
                    padding: 16, 
                    usePointStyle: true, 
                    pointStyle: 'circle', 
                    font: { size: 12, weight: '500' } 
                }
            }
        },
        cutout: '70%'
    }
});

// ========================================
// FUNÇÕES DE AÇÃO
// ========================================
function aprovarFerias(id) {
    if (confirm('✅ Aprovar esta solicitação de férias?')) {
        fetch('${pageContext.request.contextPath}/ferias/aprovar', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: 'id=' + id
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                showNotification('success', '✅ Aprovado', data.message);
                setTimeout(() => location.reload(), 1200);
            } else {
                showNotification('error', '❌ Erro', data.message);
            }
        })
        .catch(error => {
            showNotification('error', '❌ Erro', 'Falha na comunicação com o servidor');
        });
    }
}

function rejeitarFerias(id) {
    const motivo = prompt('Digite o motivo da rejeição:');
    if (motivo !== null && motivo.trim() !== '') {
        fetch('${pageContext.request.contextPath}/ferias/rejeitar', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: 'id=' + id + '&motivo=' + encodeURIComponent(motivo)
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                showNotification('warning', '⚠️ Rejeitado', data.message);
                setTimeout(() => location.reload(), 1200);
            } else {
                showNotification('error', '❌ Erro', data.message);
            }
        })
        .catch(error => {
            showNotification('error', '❌ Erro', 'Falha na comunicação com o servidor');
        });
    } else if (motivo !== null) {
        showNotification('warning', '⚠️ Atenção', 'Motivo da rejeição é obrigatório');
    }
}

function verDetalhes(id) {
    window.location.href = '${pageContext.request.contextPath}/ferias/detalhes/' + id;
}

// ========================================
// NOTIFICATIONS
// ========================================
function showNotification(type, title, message) {
    if (typeof window.showNotification === 'function') {
        window.showNotification(type, title, message);
    } else {
        alert(title + '\n\n' + message);
    }
}
</script>

<jsp:include page="/WEB-INF/views/layout/footer.jsp" />
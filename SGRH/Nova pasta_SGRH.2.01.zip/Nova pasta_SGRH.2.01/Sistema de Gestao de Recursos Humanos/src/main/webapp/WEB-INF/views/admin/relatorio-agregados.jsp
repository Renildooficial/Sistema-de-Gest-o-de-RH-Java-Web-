<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core"%>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt"%>

<jsp:include page="/WEB-INF/views/layout/header.jsp">
    <jsp:param name="pageTitle" value="${titulo}" />
    <jsp:param name="activeMenu" value="relatorios" />
</jsp:include>

<div class="form-container animate-in" style="max-width: 100%;">
    <div class="form-title">
        <i class="fas fa-user-friends" style="color: var(--primary);"></i>
        ${titulo}
    </div>

    <!-- Resumo -->
    <div class="stats-grid" style="margin-bottom: 24px;">
        <div class="stat-card">
            <div class="stat-icon blue">
                <i class="fas fa-users"></i>
            </div>
            <div class="stat-value">
                <c:set var="totalFuncionarios" value="0" />
                <c:forEach items="${agregadosPorFuncionario}" var="item">
                    <c:set var="totalFuncionarios" value="${totalFuncionarios + 1}" />
                </c:forEach>
                ${totalFuncionarios}
            </div>
            <div class="stat-label">Funcionários com Agregados</div>
        </div>
        <div class="stat-card">
            <div class="stat-icon green">
                <i class="fas fa-user-friends"></i>
            </div>
            <div class="stat-value">
                <c:set var="totalAgregados" value="0" />
                <c:forEach items="${agregadosPorFuncionario}" var="item">
                    <c:set var="totalAgregados" value="${totalAgregados + item.totalAgregados}" />
                </c:forEach>
                ${totalAgregados}
            </div>
            <div class="stat-label">Total de Agregados</div>
        </div>
        <div class="stat-card">
            <div class="stat-icon yellow">
                <i class="fas fa-chart-pie"></i>
            </div>
            <div class="stat-value">
                <c:set var="media" value="${totalFuncionarios > 0 ? totalAgregados / totalFuncionarios : 0}" />
                <fmt:formatNumber value="${media}" pattern="#,##0.0" />
            </div>
            <div class="stat-label">Média por Funcionário</div>
        </div>
    </div>

    <div class="row g-4">
        <!-- Gráfico de Parentesco -->
        <div class="col-md-6">
            <div class="chart-card">
                <div class="card-header">
                    <div>
                        <div class="card-title">Agregados por Parentesco</div>
                        <div class="card-subtitle">Distribuição dos graus</div>
                    </div>
                </div>
                <div class="chart-container" style="height: 300px;">
                    <canvas id="parentescoChart"></canvas>
                </div>
            </div>
        </div>

        <!-- Lista de Funcionários -->
        <div class="col-md-6">
            <div class="stat-card" style="max-height: 380px; overflow-y: auto;">
                <h6 style="font-weight: 700; color: var(--dark); margin-bottom: 16px;">
                    <i class="fas fa-list me-2"></i> Funcionários com Agregados
                </h6>
                <table class="table-custom">
                    <thead>
                        <tr>
                            <th>Funcionário</th>
                            <th>Agregados</th>
                        </tr>
                    </thead>
                    <tbody>
                        <c:forEach items="${agregadosPorFuncionario}" var="item">
                            <tr>
                                <td><strong>${item.funcionarioNome}</strong></td>
                                <td>${item.totalAgregados}</td>
                            </tr>
                        </c:forEach>
                        <c:if test="${empty agregadosPorFuncionario}">
                            <tr>
                                <td colspan="2" style="text-align: center; padding: 20px; color: var(--gray);">
                                    Nenhum dado disponível
                                </td>
                            </tr>
                        </c:if>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Tabela Detalhada -->
    <div class="table-section" style="margin-top: 24px;">
        <div class="table-header">
            <div class="title">
                <i class="fas fa-list me-2"></i>
                Detalhamento por Funcionário
            </div>
        </div>
        <div class="table-responsive-custom">
            <table class="table-custom">
                <thead>
                    <tr>
                        <th>Funcionário</th>
                        <th>Nome</th>
                        <th>Parentesco</th>
                        <th>Nascimento</th>
                        <th>Idade</th>
                    </tr>
                </thead>
                <tbody>
                    <c:forEach items="${agregadosPorFuncionario}" var="item">
                        <c:forEach items="${item.agregados}" var="a">
                            <tr>
                                <td><strong>${item.funcionarioNome}</strong></td>
                                <td>${a.nome}</td>
                                <td>${a.grauParentesco}</td>
                                <td><fmt:formatDate value="${a.dataNascimento}" pattern="dd/MM/yyyy" /></td>
                                <td>${a.idade} anos</td>
                            </tr>
                        </c:forEach>
                    </c:forEach>
                    <c:if test="${empty agregadosPorFuncionario}">
                        <tr>
                            <td colspan="5" style="text-align: center; padding: 20px; color: var(--gray);">
                                Nenhum dado disponível
                            </td>
                        </tr>
                    </c:if>
                </tbody>
            </table>
        </div>
    </div>

    <div class="form-actions">
        <button class="btn-primary-custom" onclick="window.print()">
            <i class="fas fa-print"></i> Imprimir
        </button>
        <button class="btn-outline-custom" onclick="window.location.href='${pageContext.request.contextPath}/relatorios'">
            <i class="fas fa-arrow-left"></i> Voltar
        </button>
    </div>
</div>

<script>
// Gráfico de Parentesco
const ctx = document.getElementById('parentescoChart').getContext('2d');
const labels = [
    <c:forEach items="${agregadosPorParentesco}" var="entry" varStatus="status">
        '${entry.key}'${!status.last ? ',' : ''}
    </c:forEach>
];
const data = [
    <c:forEach items="${agregadosPorParentesco}" var="entry" varStatus="status">
        ${entry.value}${!status.last ? ',' : ''}
    </c:forEach>
];

new Chart(ctx, {
    type: 'doughnut',
    data: {
        labels: labels.length > 0 ? labels : ['Nenhum dado'],
        datasets: [{
            data: data.length > 0 ? data : [0],
            backgroundColor: [
                'rgba(79,70,229,0.9)',
                'rgba(59,130,246,0.9)',
                'rgba(16,185,129,0.9)',
                'rgba(245,158,11,0.9)',
                'rgba(124,58,237,0.9)',
                'rgba(239,68,68,0.9)',
                'rgba(14,165,233,0.9)'
            ],
            borderColor: '#fff',
            borderWidth: 3,
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            legend: {
                position: 'bottom',
                labels: { padding: 16, usePointStyle: true, pointStyle: 'circle', font: { size: 12, weight: '500' } }
            }
        },
        cutout: '70%'
    }
});
</script>

<jsp:include page="/WEB-INF/views/layout/footer.jsp" />
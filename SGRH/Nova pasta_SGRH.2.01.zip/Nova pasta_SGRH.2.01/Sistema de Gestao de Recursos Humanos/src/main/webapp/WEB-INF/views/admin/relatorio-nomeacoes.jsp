<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core"%>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt"%>

<jsp:include page="/WEB-INF/views/layout/header.jsp">
    <jsp:param name="pageTitle" value="${titulo}" />
    <jsp:param name="activeMenu" value="relatorios" />
</jsp:include>

<div class="form-container animate-in" style="max-width: 100%;">
    <div class="form-title">
        <i class="fas fa-briefcase" style="color: var(--secondary);"></i>
        ${titulo}
    </div>

    <!-- Resumo -->
    <div class="stats-grid" style="margin-bottom: 24px;">
        <div class="stat-card">
            <div class="stat-icon blue">
                <i class="fas fa-users"></i>
            </div>
            <div class="stat-value">
                <c:set var="totalFuncionarios" value="0" />
                <c:forEach items="${nomeacoesPorFuncionario}" var="item">
                    <c:set var="totalFuncionarios" value="${totalFuncionarios + 1}" />
                </c:forEach>
                ${totalFuncionarios}
            </div>
            <div class="stat-label">Funcionários com Nomeações</div>
        </div>
        <div class="stat-card">
            <div class="stat-icon green">
                <i class="fas fa-briefcase"></i>
            </div>
            <div class="stat-value">
                <c:set var="totalNomeacoes" value="0" />
                <c:forEach items="${nomeacoesPorFuncionario}" var="item">
                    <c:set var="totalNomeacoes" value="${totalNomeacoes + item.totalNomeacoes}" />
                </c:forEach>
                ${totalNomeacoes}
            </div>
            <div class="stat-label">Total de Nomeações</div>
        </div>
        <div class="stat-card">
            <div class="stat-icon yellow">
                <i class="fas fa-check-circle"></i>
            </div>
            <div class="stat-value">
                <c:set var="totalAtivas" value="0" />
                <c:forEach items="${nomeacoesPorFuncionario}" var="item">
                    <c:set var="totalAtivas" value="${totalAtivas + item.nomeacoesAtivas}" />
                </c:forEach>
                ${totalAtivas}
            </div>
            <div class="stat-label">Nomeações Ativas</div>
        </div>
    </div>

    <div class="row g-4">
        <!-- Nomeações Ativas -->
        <div class="col-md-6">
            <div class="stat-card" style="max-height: 380px; overflow-y: auto;">
                <h6 style="font-weight: 700; color: var(--dark); margin-bottom: 16px;">
                    <i class="fas fa-check-circle me-2" style="color: var(--success);"></i> Nomeações Ativas
                </h6>
                <table class="table-custom">
                    <thead>
                        <tr>
                            <th>Funcionário</th>
                            <th>Função</th>
                            <th>Despacho</th>
                        </tr>
                    </thead>
                    <tbody>
                        <c:forEach items="${nomeacoesAtivas}" var="n">
                            <tr>
                                <td><strong>${n.funcionario != null ? n.funcionario.nome : '-'}</strong></td>
                                <td>${n.funcao}</td>
                                <td>${n.despacho}</td>
                            </tr>
                        </c:forEach>
                        <c:if test="${empty nomeacoesAtivas}">
                            <tr>
                                <td colspan="3" style="text-align: center; padding: 20px; color: var(--gray);">
                                    Nenhuma nomeação ativa
                                </td>
                            </tr>
                        </c:if>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Resumo por Funcionário -->
        <div class="col-md-6">
            <div class="stat-card" style="max-height: 380px; overflow-y: auto;">
                <h6 style="font-weight: 700; color: var(--dark); margin-bottom: 16px;">
                    <i class="fas fa-list me-2"></i> Resumo por Funcionário
                </h6>
                <table class="table-custom">
                    <thead>
                        <tr>
                            <th>Funcionário</th>
                            <th>Total</th>
                            <th>Ativas</th>
                        </tr>
                    </thead>
                    <tbody>
                        <c:forEach items="${nomeacoesPorFuncionario}" var="item">
                            <tr>
                                <td><strong>${item.funcionarioNome}</strong></td>
                                <td>${item.totalNomeacoes}</td>
                                <td>${item.nomeacoesAtivas}</td>
                            </tr>
                        </c:forEach>
                        <c:if test="${empty nomeacoesPorFuncionario}">
                            <tr>
                                <td colspan="3" style="text-align: center; padding: 20px; color: var(--gray);">
                                    Nenhum dado disponível
                                </td>
                            </tr>
                        </c:if>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Tabela Detalhada -->
    <div class="table-section" style="margin-top: 24px;">
        <div class="table-header">
            <div class="title">
                <i class="fas fa-list me-2"></i>
                Histórico de Nomeações
            </div>
        </div>
        <div class="table-responsive-custom">
            <table class="table-custom">
                <thead>
                    <tr>
                        <th>Funcionário</th>
                        <th>Função</th>
                        <th>Cargo</th>
                        <th>Despacho</th>
                        <th>Início</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <c:forEach items="${nomeacoesPorFuncionario}" var="item">
                        <c:forEach items="${item.nomeacoes}" var="n">
                            <tr>
                                <td><strong>${item.funcionarioNome}</strong></td>
                                <td>${n.funcao}</td>
                                <td>${n.cargo}</td>
                                <td>${n.despacho}</td>
                                <td><fmt:formatDate value="${n.dataInicio}" pattern="dd/MM/yyyy" /></td>
                                <td>
                                    <span class="status-badge ${n.status == 'ATIVA' ? 'ativo' : 'inativo'}">
                                        ${n.status}
                                    </span>
                                </td>
                            </tr>
                        </c:forEach>
                    </c:forEach>
                    <c:if test="${empty nomeacoesPorFuncionario}">
                        <tr>
                            <td colspan="6" style="text-align: center; padding: 20px; color: var(--gray);">
                                Nenhum dado disponível
                            </td>
                        </tr>
                    </c:if>
                </tbody>
            </table>
        </div>
    </div>

    <div class="form-actions">
        <button class="btn-primary-custom" onclick="window.print()">
            <i class="fas fa-print"></i> Imprimir
        </button>
        <button class="btn-outline-custom" onclick="window.location.href='${pageContext.request.contextPath}/relatorios'">
            <i class="fas fa-arrow-left"></i> Voltar
        </button>
    </div>
</div>

<jsp:include page="/WEB-INF/views/layout/footer.jsp" />
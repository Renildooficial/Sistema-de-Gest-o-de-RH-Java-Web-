<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core"%>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt"%>

<jsp:include page="/WEB-INF/views/layout/header.jsp">
    <jsp:param name="pageTitle" value="${titulo}" />
    <jsp:param name="activeMenu" value="relatorios" />
</jsp:include>

<div class="form-container animate-in" style="max-width: 100%;">
    <div class="form-title">
        <i class="fas fa-users" style="color: var(--primary);"></i>
        ${titulo}
    </div>

    <!-- Resumo -->
    <div class="stats-grid" style="margin-bottom: 24px;">
        <div class="stat-card">
            <div class="stat-icon blue">
                <i class="fas fa-users"></i>
            </div>
            <div class="stat-value">
                <c:set var="total" value="0" />
                <c:forEach items="${funcionariosPorSetor}" var="entry">
                    <c:set var="total" value="${total + entry.value}" />
                </c:forEach>
                ${total}
            </div>
            <div class="stat-label">Total de Funcionários</div>
        </div>
        <div class="stat-card">
            <div class="stat-icon green">
                <i class="fas fa-user-check"></i>
            </div>
            <div class="stat-value">${statusFuncionarios.get('Ativos') != null ? statusFuncionarios.get('Ativos') : 0}</div>
            <div class="stat-label">Funcionários Ativos</div>
        </div>
        <div class="stat-card">
            <div class="stat-icon yellow">
                <i class="fas fa-umbrella-beach"></i>
            </div>
            <div class="stat-value">${statusFuncionarios.get('Em Férias') != null ? statusFuncionarios.get('Em Férias') : 0}</div>
            <div class="stat-label">Em Férias</div>
        </div>
        <div class="stat-card">
            <div class="stat-icon red">
                <i class="fas fa-user-slash"></i>
            </div>
            <div class="stat-value">${statusFuncionarios.get('Inativos') != null ? statusFuncionarios.get('Inativos') : 0}</div>
            <div class="stat-label">Funcionários Inativos</div>
        </div>
    </div>

    <div class="row g-4">
        <!-- Funcionários por Setor -->
        <div class="col-md-6">
            <div class="chart-card">
                <div class="card-header">
                    <div>
                        <div class="card-title">Funcionários por Setor</div>
                        <div class="card-subtitle">Distribuição atual</div>
                    </div>
                </div>
                <div class="chart-container" style="height: 300px;">
                    <canvas id="setorChart"></canvas>
                </div>
            </div>
        </div>

        <!-- Status dos Funcionários -->
        <div class="col-md-6">
            <div class="chart-card">
                <div class="card-header">
                    <div>
                        <div class="card-title">Status dos Funcionários</div>
                        <div class="card-subtitle">Visão geral</div>
                    </div>
                </div>
                <div class="chart-container" style="height: 300px;">
                    <canvas id="statusChart"></canvas>
                </div>
            </div>
        </div>
    </div>

    <!-- Tabela Detalhada -->
    <div class="table-section" style="margin-top: 24px;">
        <div class="table-header">
            <div class="title">
                <i class="fas fa-list me-2"></i>
                Detalhamento por Setor
            </div>
        </div>
        <div class="table-responsive-custom">
            <table class="table-custom">
                <thead>
                    <tr>
                        <th>Setor</th>
                        <th>Quantidade</th>
                        <th>Percentual</th>
                    </tr>
                </thead>
                <tbody>
                    <c:set var="totalGeral" value="0" />
                    <c:forEach items="${funcionariosPorSetor}" var="entry">
                        <c:set var="totalGeral" value="${totalGeral + entry.value}" />
                    </c:forEach>
                    <c:forEach items="${funcionariosPorSetor}" var="entry">
                        <tr>
                            <td><strong>${entry.key}</strong></td>
                            <td>${entry.value}</td>
                            <td>
                                <fmt:formatNumber value="${totalGeral > 0 ? (entry.value / totalGeral) * 100 : 0}" 
                                                  pattern="#,##0.0" />%
                            </td>
                        </tr>
                    </c:forEach>
                    <c:if test="${empty funcionariosPorSetor}">
                        <tr>
                            <td colspan="3" style="text-align: center; padding: 20px; color: var(--gray);">
                                Nenhum dado disponível
                            </td>
                        </tr>
                    </c:if>
                </tbody>
            </table>
        </div>
    </div>

    <div class="form-actions">
        <button class="btn-primary-custom" onclick="window.print()">
            <i class="fas fa-print"></i> Imprimir
        </button>
        <button class="btn-outline-custom" onclick="window.location.href='${pageContext.request.contextPath}/relatorios'">
            <i class="fas fa-arrow-left"></i> Voltar
        </button>
    </div>
</div>

<script>
// Gráfico de Setores
const ctx1 = document.getElementById('setorChart').getContext('2d');
const setorLabels = [
    <c:forEach items="${funcionariosPorSetor}" var="entry" varStatus="status">
        '${entry.key}'${!status.last ? ',' : ''}
    </c:forEach>
];
const setorData = [
    <c:forEach items="${funcionariosPorSetor}" var="entry" varStatus="status">
        ${entry.value}${!status.last ? ',' : ''}
    </c:forEach>
];

new Chart(ctx1, {
    type: 'bar',
    data: {
        labels: setorLabels.length > 0 ? setorLabels : ['Nenhum dado'],
        datasets: [{
            label: 'Funcionários',
            data: setorData.length > 0 ? setorData : [0],
            backgroundColor: [
                'rgba(79,70,229,0.8)',
                'rgba(59,130,246,0.8)',
                'rgba(16,185,129,0.8)',
                'rgba(245,158,11,0.8)',
                'rgba(124,58,237,0.8)',
                'rgba(239,68,68,0.8)',
                'rgba(14,165,233,0.8)'
            ],
            borderColor: [
                'rgba(79,70,229,1)',
                'rgba(59,130,246,1)',
                'rgba(16,185,129,1)',
                'rgba(245,158,11,1)',
                'rgba(124,58,237,1)',
                'rgba(239,68,68,1)',
                'rgba(14,165,233,1)'
            ],
            borderWidth: 2,
            borderRadius: 8,
            maxBarThickness: 40,
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: { legend: { display: false } },
        scales: {
            y: { beginAtZero: true, grid: { color: 'rgba(0,0,0,0.05)' }, ticks: { stepSize: 1, font: { size: 11 } } },
            x: { grid: { display: false }, ticks: { font: { size: 11 } } }
        }
    }
});

// Gráfico de Status
const ctx2 = document.getElementById('statusChart').getContext('2d');
new Chart(ctx2, {
    type: 'doughnut',
    data: {
        labels: ['Ativos', 'Em Férias', 'Inativos', 'Licença', 'Afastados'],
        datasets: [{
            data: [
                ${statusFuncionarios.get('Ativos') != null ? statusFuncionarios.get('Ativos') : 0},
                ${statusFuncionarios.get('Em Férias') != null ? statusFuncionarios.get('Em Férias') : 0},
                ${statusFuncionarios.get('Inativos') != null ? statusFuncionarios.get('Inativos') : 0},
                ${statusFuncionarios.get('Licença') != null ? statusFuncionarios.get('Licença') : 0},
                ${statusFuncionarios.get('Afastados') != null ? statusFuncionarios.get('Afastados') : 0}
            ],
            backgroundColor: [
                'rgba(16,185,129,0.9)',
                'rgba(245,158,11,0.9)',
                'rgba(239,68,68,0.9)',
                'rgba(59,130,246,0.9)',
                'rgba(124,58,237,0.9)'
            ],
            borderColor: '#fff',
            borderWidth: 3,
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            legend: {
                position: 'bottom',
                labels: { padding: 16, usePointStyle: true, pointStyle: 'circle', font: { size: 12, weight: '500' } }
            }
        },
        cutout: '70%'
    }
});
</script>

<jsp:include page="/WEB-INF/views/layout/footer.jsp" />
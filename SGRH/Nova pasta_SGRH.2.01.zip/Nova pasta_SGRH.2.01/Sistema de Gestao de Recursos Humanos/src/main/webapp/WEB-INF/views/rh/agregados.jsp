<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core"%>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt"%>

<jsp:include page="/WEB-INF/views/layout/header.jsp">
    <jsp:param name="pageTitle" value="Agregados Familiares" />
</jsp:include>

<style>
    /* ============================================================
    ESTILOS GERAIS - AGREDADOS
    ============================================================ */
    .action-btns .btn-icon {
        width: 34px;
        height: 34px;
        border: none;
        border-radius: 8px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        background: transparent;
        color: var(--gray);
        font-size: 14px;
        text-decoration: none;
        margin: 0 2px;
        position: relative;
    }
    
    .action-btns .btn-icon:hover {
        transform: translateY(-3px);
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
    }
    
    .action-btns .btn-icon.edit {
        background: rgba(16, 185, 129, 0.1);
        color: var(--success);
    }
    .action-btns .btn-icon.edit:hover {
        background: rgba(16, 185, 129, 0.2);
        box-shadow: 0 4px 12px rgba(16, 185, 129, 0.3);
    }
    
    .action-btns .btn-icon.delete {
        background: rgba(239, 68, 68, 0.1);
        color: var(--danger);
    }
    .action-btns .btn-icon.delete:hover {
        background: rgba(239, 68, 68, 0.2);
        box-shadow: 0 4px 12px rgba(239, 68, 68, 0.3);
    }
    
    .action-btns .btn-icon .tooltip {
        display: none;
        position: absolute;
        bottom: -28px;
        left: 50%;
        transform: translateX(-50%);
        background: var(--dark);
        color: #fff;
        padding: 2px 10px;
        border-radius: 4px;
        font-size: 9px;
        font-weight: 500;
        white-space: nowrap;
        z-index: 100;
    }
    
    .action-btns .btn-icon:hover .tooltip {
        display: block;
    }
    
    .status-badge {
        padding: 4px 14px;
        border-radius: 20px;
        font-size: 11px;
        font-weight: 600;
        display: inline-block;
        text-transform: uppercase;
        letter-spacing: 0.3px;
        white-space: nowrap;
    }
    
    .status-badge.ativo {
        background: rgba(16, 185, 129, 0.12);
        color: var(--success);
        border: 1px solid rgba(16, 185, 129, 0.2);
    }
    .status-badge.inativo {
        background: rgba(239, 68, 68, 0.12);
        color: var(--danger);
        border: 1px solid rgba(239, 68, 68, 0.2);
    }
    .status-badge.licenca {
        background: rgba(59, 130, 246, 0.12);
        color: var(--info);
        border: 1px solid rgba(59, 130, 246, 0.2);
    }
    .status-badge.ferias {
        background: rgba(245, 158, 11, 0.12);
        color: var(--warning);
        border: 1px solid rgba(245, 158, 11, 0.2);
    }
    .status-badge.pendente {
        background: rgba(245, 158, 11, 0.12);
        color: #D97706;
        border: 1px solid rgba(245, 158, 11, 0.2);
    }
    
    .doc-tag {
        font-family: monospace;
        font-weight: 600;
        font-size: 11px;
        background: var(--gray-light);
        padding: 2px 8px;
        border-radius: 4px;
        white-space: nowrap;
    }
    
    .doc-badge {
        background: rgba(79, 70, 229, 0.08);
        color: var(--primary);
        padding: 1px 8px;
        border-radius: 10px;
        font-size: 10px;
        font-weight: 600;
        border: 1px solid rgba(79, 70, 229, 0.1);
        white-space: nowrap;
    }
    
    .avatar-mini {
        width: 36px;
        height: 36px;
        border-radius: 50%;
        background: linear-gradient(135deg, var(--primary), var(--secondary));
        display: flex;
        align-items: center;
        justify-content: center;
        color: #fff;
        font-weight: 700;
        font-size: 14px;
        flex-shrink: 0;
    }
    
    .nome-agregado {
        font-weight: 600;
        font-size: 13px;
        color: var(--dark);
    }
    
    .observacao-agregado {
        font-size: 10px;
        color: var(--gray);
        max-width: 120px;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
    }
    
    .funcionario-nome {
        font-weight: 500;
        font-size: 13px;
    }
    
    .funcionario-id {
        font-size: 10px;
        color: var(--gray);
    }
    
    .idade-valor {
        font-weight: 700;
        color: var(--dark);
        font-size: 14px;
    }
    
    .idade-label {
        font-size: 10px;
        color: var(--gray);
    }

    /* ============================================================
    RESPONSIVO - TABELA
    ============================================================ */
    .table-section {
        background: #fff;
        border-radius: var(--border-radius);
        padding: 20px;
        border: 1px solid var(--gray-border);
        box-shadow: var(--shadow-sm);
        margin-bottom: 24px;
        overflow-x: auto;
        -webkit-overflow-scrolling: touch;
    }
    
    .table-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 16px;
        flex-wrap: wrap;
        gap: 12px;
    }
    
    .table-header .title {
        font-size: 16px;
        font-weight: 700;
        color: var(--dark);
        display: flex;
        align-items: center;
        flex-wrap: wrap;
        gap: 6px;
    }
    
    .table-header .title i {
        color: var(--primary);
    }
    
    .table-header .title .badge-count {
        font-size: 12px;
        font-weight: 400;
        color: var(--gray);
        margin-left: 4px;
    }
    
    .table-header .actions {
        display: flex;
        gap: 8px;
        flex-wrap: wrap;
    }
    
    .table-custom {
        width: 100%;
        border-collapse: collapse;
        font-size: 13px;
        min-width: 700px;
    }
    
    .table-custom thead th {
        background: var(--gray-light);
        padding: 10px 14px;
        text-align: left;
        font-size: 11px;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        font-weight: 700;
        color: var(--gray);
        border-bottom: 2px solid var(--gray-border);
        white-space: nowrap;
    }
    
    .table-custom tbody td {
        padding: 10px 14px;
        border-bottom: 1px solid var(--gray-border);
        vertical-align: middle;
    }
    
    .table-custom tbody tr {
        transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    }
    
    .table-custom tbody tr:hover {
        background: var(--gray-light);
    }
    
    /* ============================================================
    RESPONSIVO - BREAKPOINTS
    ============================================================ */
    @media (max-width: 992px) {
        .table-section {
            padding: 16px;
        }
        .table-header {
            flex-direction: column;
            align-items: stretch;
        }
        .table-header .actions {
            justify-content: center;
        }
        .table-custom {
            font-size: 12px;
            min-width: 600px;
        }
        .table-custom thead th {
            padding: 8px 10px;
            font-size: 10px;
        }
        .table-custom tbody td {
            padding: 8px 10px;
        }
    }
    
    @media (max-width: 768px) {
        .table-section {
            padding: 12px;
        }
        .table-custom {
            font-size: 11px;
            min-width: 500px;
        }
        .table-custom thead th {
            padding: 6px 8px;
            font-size: 9px;
        }
        .table-custom tbody td {
            padding: 6px 8px;
        }
        .action-btns .btn-icon {
            width: 30px;
            height: 30px;
            font-size: 12px;
        }
        .avatar-mini {
            width: 30px;
            height: 30px;
            font-size: 12px;
        }
        .nome-agregado {
            font-size: 12px;
        }
        .doc-tag {
            font-size: 10px;
            padding: 1px 6px;
        }
        .doc-badge {
            font-size: 9px;
            padding: 1px 6px;
        }
        .status-badge {
            font-size: 9px;
            padding: 2px 10px;
        }
        .idade-valor {
            font-size: 12px;
        }
        .observacao-agregado {
            max-width: 80px;
        }
        .table-header .title {
            font-size: 14px;
        }
        .btn-primary-custom {
            font-size: 11px;
            padding: 6px 12px;
        }
    }
    
    @media (max-width: 576px) {
        .table-section {
            padding: 10px;
        }
        .table-custom {
            font-size: 10px;
            min-width: 400px;
        }
        .table-custom thead th {
            padding: 4px 6px;
            font-size: 8px;
        }
        .table-custom tbody td {
            padding: 4px 6px;
        }
        .action-btns .btn-icon {
            width: 26px;
            height: 26px;
            font-size: 11px;
        }
        .avatar-mini {
            width: 26px;
            height: 26px;
            font-size: 10px;
        }
        .nome-agregado {
            font-size: 11px;
        }
        .doc-tag {
            font-size: 9px;
            padding: 1px 4px;
        }
        .doc-badge {
            font-size: 8px;
            padding: 1px 4px;
        }
        .status-badge {
            font-size: 8px;
            padding: 2px 8px;
        }
        .idade-valor {
            font-size: 11px;
        }
        .observacao-agregado {
            max-width: 60px;
        }
        .funcionario-nome {
            font-size: 11px;
        }
        .table-header .title {
            font-size: 13px;
        }
        .table-header .title .badge-count {
            font-size: 10px;
        }
        .btn-primary-custom {
            font-size: 10px;
            padding: 4px 10px;
        }
        .btn-primary-custom i {
            font-size: 10px;
        }
    }
    
    /* ============================================================
    CARD MOBILE - PARA TELAS MUITO PEQUENAS (opcional)
    ============================================================ */
    @media (max-width: 480px) {
        .table-custom {
            min-width: 350px;
        }
        .table-custom thead th {
            padding: 3px 4px;
            font-size: 7px;
        }
        .table-custom tbody td {
            padding: 3px 4px;
        }
        .action-btns {
            flex-direction: column;
            gap: 2px;
        }
        .action-btns .btn-icon {
            width: 22px;
            height: 22px;
            font-size: 10px;
            border-radius: 6px;
        }
        .avatar-mini {
            width: 22px;
            height: 22px;
            font-size: 9px;
        }
        .status-badge {
            font-size: 7px;
            padding: 1px 6px;
        }
        .doc-tag {
            font-size: 8px;
            padding: 1px 4px;
        }
        .doc-badge {
            font-size: 7px;
            padding: 1px 4px;
        }
        .nome-agregado {
            font-size: 10px;
        }
        .observacao-agregado {
            max-width: 40px;
            font-size: 8px;
        }
        .funcionario-nome {
            font-size: 10px;
        }
        .idade-valor {
            font-size: 10px;
        }
    }
</style>

<div class="table-section animate-in">
    <div class="table-header">
        <div class="title">
            <i class="fas fa-user-friends me-2"></i>
            Agregados Familiares
            <span class="badge-count">
                <i class="fas fa-user me-1"></i> ${total != null ? total : '0'} registros
            </span>
        </div>
        <div class="actions">
            <a href="${pageContext.request.contextPath}/agregados/novo" class="btn-primary-custom">
                <i class="fas fa-plus"></i> Novo Agregado
            </a>
        </div>
    </div>

    <div class="table-responsive-custom">
        <table class="table-custom" id="agregadosTable">
            <thead>
                <tr>
                    <th style="min-width: 120px;">Nome</th>
                    <th style="min-width: 130px;">Funcionário</th>
                    <th style="width: 100px;">Parentesco</th>
                    <th style="width: 100px;">Nascimento</th>
                    <th style="width: 60px;">Idade</th>
                    <th style="width: 100px;">Documento</th>
                    <th style="width: 80px;">Status</th>
                    <th style="width: 90px;">Ações</th>
                </tr>
            </thead>
            <tbody>
                <c:forEach items="${agregados}" var="a">
                    <tr>
                        <td>
                            <div style="display: flex; align-items: center; gap: 10px;">
                                <div class="avatar-mini">
                                    ${a.nome.charAt(0)}
                                </div>
                                <div>
                                    <div class="nome-agregado">${a.nome}</div>
                                    <c:if test="${not empty a.observacao}">
                                        <div class="observacao-agregado" title="${a.observacao}">
                                            <i class="fas fa-comment me-1"></i> ${a.observacao}
                                        </div>
                                    </c:if>
                                </div>
                            </div>
                        </td>
                        <td>
                            <c:choose>
                                <c:when test="${not empty a.funcionario}">
                                    <div class="funcionario-nome">${a.funcionario.nome}</div>
                                    <div class="funcionario-id">ID: #${a.funcionario.id}</div>
                                </c:when>
                                <c:otherwise>
                                    <span style="color: var(--gray);">-</span>
                                </c:otherwise>
                            </c:choose>
                        </td>
                        <td>
                            <span class="status-badge 
                                ${a.grauParentesco == 'CONJUGE' ? 'ativo' : 
                                  a.grauParentesco == 'FILHO' ? 'licenca' : 
                                  a.grauParentesco == 'FILHA' ? 'ferias' : 
                                  a.grauParentesco == 'PAI' ? 'pendente' : 
                                  a.grauParentesco == 'MAE' ? 'pendente' : 'ativo'}">
                                <i class="fas 
                                    ${a.grauParentesco == 'CONJUGE' ? 'fa-heart' : 
                                      a.grauParentesco == 'FILHO' ? 'fa-baby' : 
                                      a.grauParentesco == 'FILHA' ? 'fa-female' : 
                                      a.grauParentesco == 'PAI' ? 'fa-male' : 
                                      a.grauParentesco == 'MAE' ? 'fa-female' : 'fa-user'} 
                                    me-1"></i>
                                ${a.grauParentesco}
                            </span>
                        </td>
                        <td style="font-size: 12px;">
                            <fmt:formatDate value="${a.dataNascimento}" pattern="dd/MM/yyyy" />
                        </td>
                        <td>
                            <span class="idade-valor">${a.idade}</span>
                            <span class="idade-label">anos</span>
                        </td>
                        <td>
                            <c:choose>
                                <c:when test="${not empty a.documento}">
                                    <span class="doc-badge">${a.tipoDocumento != null ? a.tipoDocumento : 'DOC'}</span>
                                    <span class="doc-tag">${a.documento}</span>
                                </c:when>
                                <c:otherwise>
                                    <span style="color: var(--gray);">-</span>
                                </c:otherwise>
                            </c:choose>
                        </td>
                        <td>
                            <span class="status-badge ${a.ativo ? 'ativo' : 'inativo'}">
                                <i class="fas ${a.ativo ? 'fa-check-circle' : 'fa-times-circle'} me-1"></i>
                                ${a.ativo ? 'Ativo' : 'Inativo'}
                            </span>
                        </td>
                        <td>
                            <div class="action-btns">
                                <a href="${pageContext.request.contextPath}/agregados/editar/${a.id}" 
                                   class="btn-icon edit" title="Editar">
                                    <i class="fas fa-edit"></i>
                                    <span class="tooltip">Editar</span>
                                </a>

                            </div>
                        </td>
                    </tr>
                </c:forEach>
                <c:if test="${empty agregados}">
                    <tr>
                        <td colspan="8" style="text-align: center; padding: 50px 20px; color: var(--gray);">
                            <i class="fas fa-user-friends fa-3x d-block mb-3" style="opacity: 0.3;"></i>
                            <h5 style="font-weight: 600; color: var(--dark);">Nenhum agregado cadastrado</h5>
                            <p style="font-size: 14px; color: var(--gray);">Clique em "Novo Agregado" para começar</p>
                            <a href="${pageContext.request.contextPath}/agregados/novo" class="btn-primary-custom" style="margin-top: 10px;">
                                <i class="fas fa-plus"></i> Cadastrar Agregado
                            </a>
                        </td>
                    </tr>
                </c:if>
            </tbody>
        </table>
    </div>
</div>

<script>
// ============================================================
// EXCLUIR AGREGADO
// ============================================================
function excluirAgregado(id, nome) {
    if (confirm('⚠️ Tem certeza que deseja excluir o agregado "' + nome + '"?')) {
        fetch('${pageContext.request.contextPath}/agregados/excluir', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: 'id=' + id
        })
        .then(function(response) {
            return response.json();
        })
        .then(function(data) {
            if (data.success) {
                showNotification('success', '✅ Excluído', data.message);
                setTimeout(function() { location.reload(); }, 1500);
            } else {
                showNotification('error', '❌ Erro', data.message);
            }
        })
        .catch(function(error) {
            showNotification('error', '❌ Erro', 'Falha na comunicação com o servidor');
        });
    }
}

// ============================================================
// FILTRO DE PESQUISA
// ============================================================
document.addEventListener('DOMContentLoaded', function() {
    var searchInput = document.getElementById('globalSearch');
    if (searchInput) {
        searchInput.addEventListener('keyup', function() {
            var filter = this.value.toLowerCase();
            var rows = document.querySelectorAll('#agregadosTable tbody tr');
            
            rows.forEach(function(row) {
                var text = row.textContent.toLowerCase();
                row.style.display = text.includes(filter) ? '' : 'none';
            });
        });
    }
});
</script>

<jsp:include page="/WEB-INF/views/layout/footer.jsp" />
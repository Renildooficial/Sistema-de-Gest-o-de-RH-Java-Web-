<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/fmt" prefix="fmt"%>

<div class="modal fade" id="modalDetalhesFerias" tabindex="-1" aria-labelledby="modalDetalhesFeriasLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 shadow-lg" style="border-radius: 16px; overflow: hidden;">
            <div class="modal-header text-white" style="background: linear-gradient(135deg, #4f46e5, #4338ca);">
                <h5 class="modal-title font-weight-bold" id="modalDetalhesFeriasLabel">
                    <i class="fas fa-info-circle me-2"></i>Detalhes da Solicitação
                </h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            
            <div class="modal-body p-4">
                <div id="loadingDetalhes" class="text-center py-4">
                    <div class="spinner-border text-primary" role="status">
                        <span class="visually-hidden">Carregando...</span>
                    </div>
                    <p class="text-muted mt-2 mb-0">Buscando informações...</p>
                </div>

                <div id="conteudoDetalhes" style="display: none;">
                    <div class="row g-3">
                        <div class="col-6">
                            <label class="text-uppercase text-muted fw-bold small">Data Início</label>
                            <p id="detalheDataInicio" class="fw-semibold text-dark fs-6 mb-0">-</p>
                        </div>
                        <div class="col-6">
                            <label class="text-uppercase text-muted fw-bold small">Data Fim</label>
                            <p id="detalheDataFim" class="fw-semibold text-dark fs-6 mb-0">-</p>
                        </div>
                        <div class="col-6">
                            <label class="text-uppercase text-muted fw-bold small">Dias Úteis</label>
                            <p id="detalheDiasUteis" class="fw-semibold text-dark fs-6 mb-0">-</p>
                        </div>
                        <div class="col-6">
                            <label class="text-uppercase text-muted fw-bold small">Status</label>
                            <p id="detalheStatus" class="mb-0">-</p>
                        </div>
                        <div class="col-12">
                            <label class="text-uppercase text-muted fw-bold small">Data da Solicitação</label>
                            <p id="detalheDataSolicitacao" class="text-secondary mb-0">-</p>
                        </div>
                        
                        <!-- Bloco de Observação renderizado com segurança via JSTL se usado pelo servidor -->
                        <c:if test="${not empty ferias.observacao}">
                            <div class="col-12 mt-3 pt-3 border-top">
                                <label class="text-uppercase text-muted fw-bold small">Observação</label>
                                <p class="text-dark mb-0 bg-light p-3 rounded-3">${ferias.observacao}</p>
                            </div>
                        </c:if>

                        <!-- Container para preenchimento dinâmico via JS caso seja via AJAX -->
                        <!-- Container de observação controlado exclusivamente via JS -->
<div id="containerObservacaoJS" class="col-12 mt-3 pt-3 border-top" style="display: none;">
    <label class="text-uppercase text-muted fw-bold small">Observação</label>
    <p id="detalheObservacao" class="text-dark mb-0 bg-light p-3 rounded-3"></p>
</div>
                    </div>
                </div>
            </div>
            
            <div class="modal-footer bg-light border-0">
                <button type="button" class="btn btn-secondary rounded-pill px-4" data-bs-dismiss="modal">Fechar</button>
            </div>
        </div>
    </div>
</div>
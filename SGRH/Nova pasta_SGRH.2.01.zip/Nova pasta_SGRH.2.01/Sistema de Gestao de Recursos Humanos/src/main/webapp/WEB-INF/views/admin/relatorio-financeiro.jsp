<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core"%>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt"%>

<jsp:include page="/WEB-INF/views/layout/header.jsp">
    <jsp:param name="pageTitle" value="${titulo}" />
    <jsp:param name="activeMenu" value="relatorios" />
</jsp:include>

<div class="form-container animate-in" style="max-width: 100%;">
    <div class="form-title">
        <i class="fas fa-coins" style="color: var(--success);"></i>
        ${titulo} - ${ano}
    </div>

    <div class="row g-4">
        <div class="col-md-8">
            <div class="chart-card">
                <div class="card-header">
                    <div>
                        <div class="card-title">Folha de Pagamento por Mês</div>
                        <div class="card-subtitle">Total líquido mensal</div>
                    </div>
                </div>
                <div class="chart-container" style="height: 300px;">
                    <canvas id="financeiroChart"></canvas>
                </div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="stat-card">
                <h6 style="font-weight: 700; color: var(--dark); margin-bottom: 16px;">
                    <i class="fas fa-calculator me-2"></i> Resumo Anual
                </h6>
                <c:set var="totalAnual" value="0" />
                <c:forEach items="${folhaPorMes}" var="entry">
                    <c:set var="totalAnual" value="${totalAnual + entry.value}" />
                </c:forEach>
                <div style="text-align: center; padding: 16px;">
                    <div style="font-size: 12px; color: var(--gray);">Total Anual</div>
                    <div style="font-size: 28px; font-weight: 800; color: var(--primary);">
                        <fmt:formatNumber value="${totalAnual}" type="currency" currencySymbol="MZN " />
                    </div>
                </div>
                <div style="border-top: 1px solid var(--gray-border); padding-top: 12px; margin-top: 8px;">
                    <div style="display: flex; justify-content: space-between; font-size: 13px;">
                        <span style="color: var(--gray);">Média Mensal</span>
                        <strong>
                            <fmt:formatNumber value="${totalAnual / 12}" type="currency" currencySymbol="MZN " />
                        </strong>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="form-actions">
        <button class="btn-primary-custom" onclick="window.print()">
            <i class="fas fa-print"></i> Imprimir
        </button>
        <button class="btn-outline-custom" onclick="window.location.href='${pageContext.request.contextPath}/relatorios'">
            <i class="fas fa-arrow-left"></i> Voltar
        </button>
    </div>
</div>

<script>
// Gráfico Financeiro
const ctx = document.getElementById('financeiroChart').getContext('2d');
const labels = [
    <c:forEach items="${folhaPorMes}" var="entry" varStatus="status">
        '${entry.key}'${!status.last ? ',' : ''}
    </c:forEach>
];
const data = [
    <c:forEach items="${folhaPorMes}" var="entry" varStatus="status">
        ${entry.value}${!status.last ? ',' : ''}
    </c:forEach>
];

new Chart(ctx, {
    type: 'bar',
    data: {
        labels: labels.length > 0 ? labels : ['Nenhum dado'],
        datasets: [{
            label: 'Total Líquido',
            data: data.length > 0 ? data : [0],
            backgroundColor: 'rgba(79,70,229,0.8)',
            borderColor: 'rgba(79,70,229,1)',
            borderWidth: 2,
            borderRadius: 8,
            maxBarThickness: 40,
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            legend: { display: false },
            tooltip: {
                callbacks: {
                    label: function(context) {
                        return 'MZN ' + context.parsed.y.toFixed(2);
                    }
                }
            }
        },
        scales: {
            y: { 
                beginAtZero: true, 
                grid: { color: 'rgba(0,0,0,0.05)' }, 
                ticks: { 
                    font: { size: 11 },
                    callback: function(value) {
                        return 'MZN ' + value.toFixed(0);
                    }
                } 
            },
            x: { grid: { display: false }, ticks: { font: { size: 11 } } }
        }
    }
});
</script>

<jsp:include page="/WEB-INF/views/layout/footer.jsp" />
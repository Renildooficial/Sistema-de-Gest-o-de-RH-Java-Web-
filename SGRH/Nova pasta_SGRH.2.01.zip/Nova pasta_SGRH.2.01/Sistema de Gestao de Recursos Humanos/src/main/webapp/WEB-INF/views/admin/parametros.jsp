<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core"%>

<jsp:include page="/WEB-INF/views/layout/header.jsp">
    <jsp:param name="pageTitle" value="Parâmetros do Sistema" />
    <jsp:param name="activeMenu" value="parametros" />
</jsp:include>

<div class="row g-4 animate-in">
    <div class="col-12">
        <h5 style="font-weight: 700; color: var(--dark);">
            <i class="fas fa-sliders-h me-2" style="color: var(--primary);"></i>
            Parâmetros do Sistema
        </h5>
        <p style="color: var(--gray); font-size: 14px;">Gerencie as configurações globais do sistema.</p>
    </div>

    <!-- Formulário para adicionar parâmetro -->
    <div class="col-md-4">
        <div class="stat-card">
            <h6 style="font-weight: 700; color: var(--dark); margin-bottom: 16px;">
                <i class="fas fa-plus-circle me-2" style="color: var(--primary);"></i>
                Novo Parâmetro
            </h6>
            <form action="${pageContext.request.contextPath}/parametros" method="post">
                <div class="form-group" style="margin-bottom: 12px;">
                    <label style="font-size: 13px; font-weight: 600; color: var(--dark);">Chave <span class="required" style="color: var(--danger);">*</span></label>
                    <input type="text" class="form-control" name="chave" placeholder="Ex: empresa_nome" required style="border-radius: 10px; border: 1px solid var(--gray-border); padding: 8px 12px; font-size: 13px; width: 100%;">
                </div>
                <div class="form-group" style="margin-bottom: 12px;">
                    <label style="font-size: 13px; font-weight: 600; color: var(--dark);">Valor <span class="required" style="color: var(--danger);">*</span></label>
                    <input type="text" class="form-control" name="valor" placeholder="Valor do parâmetro" required style="border-radius: 10px; border: 1px solid var(--gray-border); padding: 8px 12px; font-size: 13px; width: 100%;">
                </div>
                <div class="form-group" style="margin-bottom: 12px;">
                    <label style="font-size: 13px; font-weight: 600; color: var(--dark);">Descrição</label>
                    <input type="text" class="form-control" name="descricao" placeholder="Descrição do parâmetro" style="border-radius: 10px; border: 1px solid var(--gray-border); padding: 8px 12px; font-size: 13px; width: 100%;">
                </div>
                <div class="form-group" style="margin-bottom: 12px;">
                    <label style="font-size: 13px; font-weight: 600; color: var(--dark);">Categoria</label>
                    <select class="form-select" name="categoria" style="border-radius: 10px; border: 1px solid var(--gray-border); padding: 8px 12px; font-size: 13px; width: 100%;">
                        <option value="Geral">Geral</option>
                        <option value="EMAIL">E-mail</option>
                        <option value="FINANCEIRO">Financeiro</option>
                        <option value="RH">Recursos Humanos</option>
                        <option value="SEGURANCA">Segurança</option>
                    </select>
                </div>
                <button type="submit" class="btn-primary-custom" style="width: 100%; justify-content: center;">
                    <i class="fas fa-save"></i> Salvar
                </button>
            </form>
        </div>
    </div>

    <!-- Lista de parâmetros -->
    <div class="col-md-8">
        <div class="table-section">
            <div class="table-header">
                <div class="title">
                    <i class="fas fa-list me-2"></i>
                    Parâmetros Cadastrados
                    <span style="font-size: 12px; font-weight: 400; color: var(--gray);">${total != null ? total : '0'} registros</span>
                </div>
            </div>
            <div class="table-responsive-custom">
                <table class="table-custom">
                    <thead>
                        <tr>
                            <th>Chave</th>
                            <th>Valor</th>
                            <th>Descrição</th>
                            <th>Categoria</th>
                            <th>Ações</th>
                        </tr>
                    </thead>
                    <tbody>
                        <c:forEach items="${parametros}" var="p">
                            <tr>
                                <td><strong>${p.chave}</strong></td>
                                <td>${p.valor}</td>
                                <td>${p.descricao != null ? p.descricao : '-'}</td>
                                <td>
                                    <span class="badge" style="background: var(--primary-light); color: #fff; padding: 4px 10px; border-radius: 12px; font-size: 11px;">
                                        ${p.categoria != null ? p.categoria : 'Geral'}
                                    </span>
                                </td>
                                <td>
                                    <div class="action-btns">
                                        <button class="btn-icon edit" onclick="editarParametro('${p.chave}')" title="Editar">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        <button class="btn-icon delete" onclick="excluirParametro('${p.chave}')" title="Excluir">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        </c:forEach>
                        <c:if test="${empty parametros}">
                            <tr>
                                <td colspan="5" style="text-align: center; padding: 30px; color: var(--gray);">
                                    <i class="fas fa-inbox fa-2x d-block mb-2"></i>
                                    Nenhum parâmetro cadastrado
                                </td>
                            </tr>
                        </c:if>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script>
function excluirParametro(chave) {
    if (confirm(`Tem certeza que deseja excluir o parâmetro "${chave}"?`)) {
        fetch('${pageContext.request.contextPath}/parametros/excluir', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: 'chave=' + encodeURIComponent(chave)
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                showNotification('success', 'Excluído', data.message);
                location.reload();
            } else {
                showNotification('error', 'Erro', data.message);
            }
        });
    }
}

function editarParametro(chave) {
    // Buscar parâmetro e preencher o formulário
    fetch('${pageContext.request.contextPath}/parametros/buscar/' + encodeURIComponent(chave))
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            document.querySelector('input[name="chave"]').value = data.chave;
            document.querySelector('input[name="chave"]').readOnly = true;
            document.querySelector('input[name="valor"]').value = data.valor;
            document.querySelector('input[name="descricao"]').value = data.descricao || '';
            document.querySelector('select[name="categoria"]').value = data.categoria || 'Geral';
            document.querySelector('.stat-card h6').innerHTML = '<i class="fas fa-edit me-2" style="color: var(--warning);"></i> Editar Parâmetro';
            window.scrollTo({ top: 0, behavior: 'smooth' });
        } else {
            showNotification('error', 'Erro', data.message);
        }
    });
}

// Resetar formulário quando mudar de página
document.addEventListener('DOMContentLoaded', function() {
    const form = document.querySelector('form');
    const chaveInput = document.querySelector('input[name="chave"]');
    
    // Remover readonly quando o formulário for resetado
    form.addEventListener('reset', function() {
        chaveInput.readOnly = false;
        document.querySelector('.stat-card h6').innerHTML = '<i class="fas fa-plus-circle me-2" style="color: var(--primary);"></i> Novo Parâmetro';
    });
});
</script>

<jsp:include page="/WEB-INF/views/layout/footer.jsp" />
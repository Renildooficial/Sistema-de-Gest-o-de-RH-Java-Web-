<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core"%>

<jsp:include page="/WEB-INF/views/layout/header.jsp">
    <jsp:param name="pageTitle" value="Relatórios" />
    <jsp:param name="activeMenu" value="relatorios" />
</jsp:include>

<div class="row g-4 animate-in">
    <div class="col-12">
        <div class="d-flex justify-content-between align-items-center flex-wrap gap-3">
            <div>
                <h5 style="font-weight: 700; color: var(--dark); margin-bottom: 4px;">
                    <i class="fas fa-chart-bar me-2" style="color: var(--primary);"></i>
                    Central de Relatórios
                </h5>
                <p style="color: var(--gray); font-size: 14px; margin: 0;">
                    Visualize e exporte dados do sistema em diferentes formatos
                </p>
            </div>
            
        </div>
        <hr style="border-color: var(--gray-border); margin: 16px 0 24px;">
    </div>

    <!-- ======================================== -->
    <!-- SEÇÃO: RELATÓRIOS DE VISUALIZAÇÃO -->
    <!-- ======================================== -->
    <div class="col-12">
        <h6 style="font-weight: 600; color: var(--dark); margin-bottom: 12px;">
            <i class="fas fa-eye me-2" style="color: var(--info);"></i>
            Visualizar Relatórios
        </h6>
    </div>

    <div class="col-md-4">
        <div class="stat-card" style="cursor: pointer; transition: all 0.3s ease; border-left: 4px solid var(--info);" 
             onclick="window.location.href='${pageContext.request.contextPath}/relatorios/funcionarios'">
            <div class="d-flex align-items-center gap-3">
                <div class="stat-icon blue" style="width: 48px; height: 48px; margin-bottom: 0;">
                    <i class="fas fa-users fa-lg"></i>
                </div>
                <div>
                    <div style="font-weight: 700; font-size: 16px; color: var(--dark);">Funcionários</div>
                    <div style="font-size: 13px; color: var(--gray);">Análise completa do quadro</div>
                </div>
            </div>
            <div style="margin-top: 12px; display: flex; justify-content: space-between; align-items: center;">
                <span class="badge" style="background: var(--info-bg); color: var(--info); padding: 4px 12px;">
                    <i class="fas fa-chart-pie me-1"></i> Gráficos
                </span>
                <span style="color: var(--primary); font-size: 13px; font-weight: 600;">
                    Visualizar <i class="fas fa-arrow-right ms-1"></i>
                </span>
            </div>
        </div>
    </div>

    <div class="col-md-4">
        <div class="stat-card" style="cursor: pointer; transition: all 0.3s ease; border-left: 4px solid var(--warning);"
             onclick="window.location.href='${pageContext.request.contextPath}/relatorios/ferias'">
            <div class="d-flex align-items-center gap-3">
                <div class="stat-icon yellow" style="width: 48px; height: 48px; margin-bottom: 0;">
                    <i class="fas fa-umbrella-beach fa-lg"></i>
                </div>
                <div>
                    <div style="font-weight: 700; font-size: 16px; color: var(--dark);">Férias</div>
                    <div style="font-size: 13px; color: var(--gray);">Status e planejamento</div>
                </div>
            </div>
            <div style="margin-top: 12px; display: flex; justify-content: space-between; align-items: center;">
                <span class="badge" style="background: var(--warning-bg); color: var(--warning); padding: 4px 12px;">
                    <i class="fas fa-chart-pie me-1"></i> Gráficos
                </span>
                <span style="color: var(--primary); font-size: 13px; font-weight: 600;">
                    Visualizar <i class="fas fa-arrow-right ms-1"></i>
                </span>
            </div>
        </div>
    </div>

    <div class="col-md-4">
        <div class="stat-card" style="cursor: pointer; transition: all 0.3s ease; border-left: 4px solid var(--success);"
             onclick="window.location.href='${pageContext.request.contextPath}/relatorios/financeiro'">
            <div class="d-flex align-items-center gap-3">
                <div class="stat-icon green" style="width: 48px; height: 48px; margin-bottom: 0;">
                    <i class="fas fa-coins fa-lg"></i>
                </div>
                <div>
                    <div style="font-weight: 700; font-size: 16px; color: var(--dark);">Financeiro</div>
                    <div style="font-size: 13px; color: var(--gray);">Folha e custos</div>
                </div>
            </div>
            <div style="margin-top: 12px; display: flex; justify-content: space-between; align-items: center;">
                <span class="badge" style="background: var(--success-bg); color: var(--success); padding: 4px 12px;">
                    <i class="fas fa-chart-line me-1"></i> Gráficos
                </span>
                <span style="color: var(--primary); font-size: 13px; font-weight: 600;">
                    Visualizar <i class="fas fa-arrow-right ms-1"></i>
                </span>
            </div>
        </div>
    </div>

    <div class="col-md-4">
        <div class="stat-card" style="cursor: pointer; transition: all 0.3s ease; border-left: 4px solid var(--secondary);"
             onclick="window.location.href='${pageContext.request.contextPath}/relatorios/agregados'">
            <div class="d-flex align-items-center gap-3">
                <div class="stat-icon purple" style="width: 48px; height: 48px; margin-bottom: 0;">
                    <i class="fas fa-user-friends fa-lg"></i>
                </div>
                <div>
                    <div style="font-weight: 700; font-size: 16px; color: var(--dark);">Agregados</div>
                    <div style="font-size: 13px; color: var(--gray);">Dependentes por funcionário</div>
                </div>
            </div>
            <div style="margin-top: 12px; display: flex; justify-content: space-between; align-items: center;">
                <span class="badge" style="background: rgba(124,58,237,0.1); color: var(--secondary); padding: 4px 12px;">
                    <i class="fas fa-users me-1"></i> Detalhado
                </span>
                <span style="color: var(--primary); font-size: 13px; font-weight: 600;">
                    Visualizar <i class="fas fa-arrow-right ms-1"></i>
                </span>
            </div>
        </div>
    </div>

    <div class="col-md-4">
        <div class="stat-card" style="cursor: pointer; transition: all 0.3s ease; border-left: 4px solid #F59E0B;"
             onclick="window.location.href='${pageContext.request.contextPath}/relatorios/formacoes'">
            <div class="d-flex align-items-center gap-3">
                <div class="stat-icon orange" style="width: 48px; height: 48px; margin-bottom: 0;">
                    <i class="fas fa-graduation-cap fa-lg"></i>
                </div>
                <div>
                    <div style="font-weight: 700; font-size: 16px; color: var(--dark);">Formações</div>
                    <div style="font-size: 13px; color: var(--gray);">Histórico educacional</div>
                </div>
            </div>
            <div style="margin-top: 12px; display: flex; justify-content: space-between; align-items: center;">
                <span class="badge" style="background: rgba(245,158,11,0.1); color: #D97706; padding: 4px 12px;">
                    <i class="fas fa-graduation-cap me-1"></i> Educacional
                </span>
                <span style="color: var(--primary); font-size: 13px; font-weight: 600;">
                    Visualizar <i class="fas fa-arrow-right ms-1"></i>
                </span>
            </div>
        </div>
    </div>

    <div class="col-md-4">
        <div class="stat-card" style="cursor: pointer; transition: all 0.3s ease; border-left: 4px solid #EF4444;"
             onclick="window.location.href='${pageContext.request.contextPath}/relatorios/nomeacoes'">
            <div class="d-flex align-items-center gap-3">
                <div class="stat-icon red" style="width: 48px; height: 48px; margin-bottom: 0;">
                    <i class="fas fa-briefcase fa-lg"></i>
                </div>
                <div>
                    <div style="font-weight: 700; font-size: 16px; color: var(--dark);">Nomeações</div>
                    <div style="font-size: 13px; color: var(--gray);">Cargos e funções</div>
                </div>
            </div>
            <div style="margin-top: 12px; display: flex; justify-content: space-between; align-items: center;">
                <span class="badge" style="background: rgba(239,68,68,0.1); color: var(--danger); padding: 4px 12px;">
                    <i class="fas fa-briefcase me-1"></i> Cargos
                </span>
                <span style="color: var(--primary); font-size: 13px; font-weight: 600;">
                    Visualizar <i class="fas fa-arrow-right ms-1"></i>
                </span>
            </div>
        </div>
    </div>

    <!-- ======================================== -->
    <!-- DIVISOR -->
    <!-- ======================================== -->
    <div class="col-12" style="margin-top: 8px;">
        <hr style="border-color: var(--gray-border); margin: 16px 0 24px;">
    </div>

    <!-- ======================================== -->
    <!-- SEÇÃO: EXPORTAÇÃO DE RELATÓRIOS -->
    <!-- ======================================== -->
    <div class="col-12">
        <h6 style="font-weight: 600; color: var(--dark); margin-bottom: 12px;">
            <i class="fas fa-download me-2" style="color: var(--success);"></i>
            Exportar Relatórios
        </h6>
        <p style="color: var(--gray); font-size: 13px; margin-bottom: 16px;">
            Baixe os relatórios nos formatos Excel ou PDF
        </p>
    </div>

    <div class="col-md-3">
        <div class="stat-card" style="cursor: pointer; transition: all 0.3s ease; background: linear-gradient(135deg, #f8fafc, #e8f5e9); border: 1px solid #c8e6c9;" 
             onclick="window.location.href='${pageContext.request.contextPath}/relatorios/exportar/funcionarios/excel'">
            <div class="d-flex align-items-center gap-3">
                <div style="width: 44px; height: 44px; border-radius: 10px; background: #217346; display: flex; align-items: center; justify-content: center; color: #fff; font-size: 20px;">
                    <i class="fas fa-file-excel"></i>
                </div>
                <div>
                    <div style="font-weight: 700; font-size: 14px; color: var(--dark);">Funcionários</div>
                    <div style="font-size: 11px; color: var(--gray);">.xlsx</div>
                </div>
            </div>
            <div style="margin-top: 10px; text-align: right;">
                <span style="color: #217346; font-weight: 600; font-size: 12px;">
                    <i class="fas fa-download me-1"></i> Baixar
                </span>
            </div>
        </div>
    </div>

    <div class="col-md-3">
        <div class="stat-card" style="cursor: pointer; transition: all 0.3s ease; background: linear-gradient(135deg, #f8fafc, #fff3e0); border: 1px solid #ffe0b2;" 
             onclick="window.location.href='${pageContext.request.contextPath}/relatorios/exportar/ferias/excel'">
            <div class="d-flex align-items-center gap-3">
                <div style="width: 44px; height: 44px; border-radius: 10px; background: #217346; display: flex; align-items: center; justify-content: center; color: #fff; font-size: 20px;">
                    <i class="fas fa-file-excel"></i>
                </div>
                <div>
                    <div style="font-weight: 700; font-size: 14px; color: var(--dark);">Férias</div>
                    <div style="font-size: 11px; color: var(--gray);">.xlsx</div>
                </div>
            </div>
            <div style="margin-top: 10px; text-align: right;">
                <span style="color: #217346; font-weight: 600; font-size: 12px;">
                    <i class="fas fa-download me-1"></i> Baixar
                </span>
            </div>
        </div>
    </div>

    <div class="col-md-3">
        <div class="stat-card" style="cursor: pointer; transition: all 0.3s ease; background: linear-gradient(135deg, #f8fafc, #e8f5e9); border: 1px solid #c8e6c9;" 
             onclick="window.location.href='${pageContext.request.contextPath}/relatorios/exportar/financeiro/excel'">
            <div class="d-flex align-items-center gap-3">
                <div style="width: 44px; height: 44px; border-radius: 10px; background: #217346; display: flex; align-items: center; justify-content: center; color: #fff; font-size: 20px;">
                    <i class="fas fa-file-excel"></i>
                </div>
                <div>
                    <div style="font-weight: 700; font-size: 14px; color: var(--dark);">Financeiro</div>
                    <div style="font-size: 11px; color: var(--gray);">.xlsx</div>
                </div>
            </div>
            <div style="margin-top: 10px; text-align: right;">
                <span style="color: #217346; font-weight: 600; font-size: 12px;">
                    <i class="fas fa-download me-1"></i> Baixar
                </span>
            </div>
        </div>
    </div>

    <div class="col-md-3">
        <div class="stat-card" style="cursor: pointer; transition: all 0.3s ease; background: linear-gradient(135deg, #f8fafc, #fce4ec); border: 1px solid #f8bbd0;" 
             onclick="window.location.href='${pageContext.request.contextPath}/relatorios/exportar/agregados/pdf'">
            <div class="d-flex align-items-center gap-3">
                <div style="width: 44px; height: 44px; border-radius: 10px; background: #E74C3C; display: flex; align-items: center; justify-content: center; color: #fff; font-size: 20px;">
                    <i class="fas fa-file-pdf"></i>
                </div>
                <div>
                    <div style="font-weight: 700; font-size: 14px; color: var(--dark);">Agregados</div>
                    <div style="font-size: 11px; color: var(--gray);">.pdf</div>
                </div>
            </div>
            <div style="margin-top: 10px; text-align: right;">
                <span style="color: #E74C3C; font-weight: 600; font-size: 12px;">
                    <i class="fas fa-download me-1"></i> Baixar
                </span>
            </div>
        </div>
    </div>

   


<jsp:include page="/WEB-INF/views/layout/footer.jsp" />
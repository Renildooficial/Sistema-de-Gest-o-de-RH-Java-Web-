<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core"%>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt"%>

<jsp:include page="/WEB-INF/views/layout/header.jsp">
    <jsp:param name="pageTitle" value="${titulo}" />
    <jsp:param name="activeMenu" value="relatorios" />
</jsp:include>

<div class="form-container animate-in" style="max-width: 100%;">
    <div class="form-title">
        <i class="fas fa-graduation-cap" style="color: var(--warning);"></i>
        ${titulo}
    </div>

    <!-- Resumo -->
    <div class="stats-grid" style="margin-bottom: 24px;">
        <div class="stat-card">
            <div class="stat-icon blue">
                <i class="fas fa-users"></i>
            </div>
            <div class="stat-value">
                <c:set var="totalFuncionarios" value="0" />
                <c:forEach items="${formacoesPorFuncionario}" var="item">
                    <c:set var="totalFuncionarios" value="${totalFuncionarios + 1}" />
                </c:forEach>
                ${totalFuncionarios}
            </div>
            <div class="stat-label">Funcionários com Formações</div>
        </div>
        <div class="stat-card">
            <div class="stat-icon green">
                <i class="fas fa-graduation-cap"></i>
            </div>
            <div class="stat-value">
                <c:set var="totalFormacoes" value="0" />
                <c:forEach items="${formacoesPorFuncionario}" var="item">
                    <c:set var="totalFormacoes" value="${totalFormacoes + item.totalFormacoes}" />
                </c:forEach>
                ${totalFormacoes}
            </div>
            <div class="stat-label">Total de Formações</div>
        </div>
        <div class="stat-card">
            <div class="stat-icon yellow">
                <i class="fas fa-chart-pie"></i>
            </div>
            <div class="stat-value">
                <c:set var="media" value="${totalFuncionarios > 0 ? totalFormacoes / totalFuncionarios : 0}" />
                <fmt:formatNumber value="${media}" pattern="#,##0.0" />
            </div>
            <div class="stat-label">Média por Funcionário</div>
        </div>
    </div>

    <div class="row g-4">
        <!-- Gráfico de Níveis -->
        <div class="col-md-6">
            <div class="chart-card">
                <div class="card-header">
                    <div>
                        <div class="card-title">Formações por Nível</div>
                        <div class="card-subtitle">Distribuição dos níveis</div>
                    </div>
                </div>
                <div class="chart-container" style="height: 300px;">
                    <canvas id="nivelChart"></canvas>
                </div>
            </div>
        </div>

        <!-- Resumo -->
        <div class="col-md-6">
            <div class="stat-card" style="max-height: 380px; overflow-y: auto;">
                <h6 style="font-weight: 700; color: var(--dark); margin-bottom: 16px;">
                    <i class="fas fa-list me-2"></i> Resumo por Funcionário
                </h6>
                <table class="table-custom">
                    <thead>
                        <tr>
                            <th>Funcionário</th>
                            <th>Formações</th>
                        </tr>
                    </thead>
                    <tbody>
                        <c:forEach items="${formacoesPorFuncionario}" var="item">
                            <tr>
                                <td><strong>${item.funcionarioNome}</strong></td>
                                <td>${item.totalFormacoes}</td>
                            </tr>
                        </c:forEach>
                        <c:if test="${empty formacoesPorFuncionario}">
                            <tr>
                                <td colspan="2" style="text-align: center; padding: 20px; color: var(--gray);">
                                    Nenhum dado disponível
                                </td>
                            </tr>
                        </c:if>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Tabela Detalhada -->
    <div class="table-section" style="margin-top: 24px;">
        <div class="table-header">
            <div class="title">
                <i class="fas fa-list me-2"></i>
                Detalhamento das Formações
            </div>
        </div>
        <div class="table-responsive-custom">
            <table class="table-custom">
                <thead>
                    <tr>
                        <th>Funcionário</th>
                        <th>Curso</th>
                        <th>Nível</th>
                        <th>Instituição</th>
                        <th>Período</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <c:forEach items="${formacoesPorFuncionario}" var="item">
                        <c:forEach items="${item.formacoes}" var="f">
                            <tr>
                                <td><strong>${item.funcionarioNome}</strong></td>
                                <td>${f.curso}</td>
                                <td>${f.nivel}</td>
                                <td>${f.instituicao}</td>
                                <td>
                                    <fmt:formatDate value="${f.dataInicio}" pattern="yyyy" /> - 
                                    <fmt:formatDate value="${f.dataConclusao}" pattern="yyyy" />
                                </td>
                                <td>
                                    <span class="status-badge ${f.status == 'CONCLUIDO' ? 'ativo' : f.status == 'CURSANDO' ? 'ferias' : 'inativo'}">
                                        ${f.status}
                                    </span>
                                </td>
                            </tr>
                        </c:forEach>
                    </c:forEach>
                    <c:if test="${empty formacoesPorFuncionario}">
                        <tr>
                            <td colspan="6" style="text-align: center; padding: 20px; color: var(--gray);">
                                Nenhum dado disponível
                            </td>
                        </tr>
                    </c:if>
                </tbody>
            </table>
        </div>
    </div>

    <div class="form-actions">
        <button class="btn-primary-custom" onclick="window.print()">
            <i class="fas fa-print"></i> Imprimir
        </button>
        <button class="btn-outline-custom" onclick="window.location.href='${pageContext.request.contextPath}/relatorios'">
            <i class="fas fa-arrow-left"></i> Voltar
        </button>
    </div>
</div>

<script>
// Gráfico de Níveis
const ctx = document.getElementById('nivelChart').getContext('2d');
const labels = [
    <c:forEach items="${formacoesPorNivel}" var="entry" varStatus="status">
        '${entry.key}'${!status.last ? ',' : ''}
    </c:forEach>
];
const data = [
    <c:forEach items="${formacoesPorNivel}" var="entry" varStatus="status">
        ${entry.value}${!status.last ? ',' : ''}
    </c:forEach>
];

new Chart(ctx, {
    type: 'bar',
    data: {
        labels: labels.length > 0 ? labels : ['Nenhum dado'],
        datasets: [{
            label: 'Formações',
            data: data.length > 0 ? data : [0],
            backgroundColor: [
                'rgba(79,70,229,0.8)',
                'rgba(59,130,246,0.8)',
                'rgba(16,185,129,0.8)',
                'rgba(245,158,11,0.8)',
                'rgba(124,58,237,0.8)',
                'rgba(239,68,68,0.8)'
            ],
            borderColor: [
                'rgba(79,70,229,1)',
                'rgba(59,130,246,1)',
                'rgba(16,185,129,1)',
                'rgba(245,158,11,1)',
                'rgba(124,58,237,1)',
                'rgba(239,68,68,1)'
            ],
            borderWidth: 2,
            borderRadius: 8,
            maxBarThickness: 40,
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: { legend: { display: false } },
        scales: {
            y: { beginAtZero: true, grid: { color: 'rgba(0,0,0,0.05)' }, ticks: { stepSize: 1, font: { size: 11 } } },
            x: { grid: { display: false }, ticks: { font: { size: 11 } } }
        }
    }
});
</script>

<jsp:include page="/WEB-INF/views/layout/footer.jsp" />
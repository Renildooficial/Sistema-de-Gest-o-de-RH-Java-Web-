<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core"%>

<jsp:include page="/WEB-INF/views/layout/header.jsp">
    <jsp:param name="pageTitle" value="Alterar Senha" />
    <jsp:param name="activeMenu" value="alterar-senha" />
</jsp:include>

<style>
    /* ============================================================
       ESTILOS PRINCIPAIS
       ============================================================ */
    .required { color: var(--danger); font-weight: 700; }
    
    .form-group label { 
        font-weight: 600; 
        font-size: 14px; 
        color: var(--dark); 
        margin-bottom: 6px; 
        display: flex;
        align-items: center;
        gap: 6px;
    }
    
    .form-control { 
        border-radius: 10px; 
        border: 1px solid var(--gray-border); 
        padding: 10px 14px; 
        font-size: 14px; 
        transition: var(--transition); 
        height: 46px;
    }
    
    .form-control:focus { 
        border-color: var(--primary); 
        box-shadow: 0 0 0 3px rgba(79,70,229,0.1); 
    }
    
    .form-control.is-invalid { 
        border-color: var(--danger) !important; 
    }
    
    .form-control.is-valid { 
        border-color: var(--success) !important; 
    }
    
    /* ============================================================
       CONTAINER PRINCIPAL
       ============================================================ */
    .form-container { 
        background: #fff; 
        border-radius: var(--border-radius); 
        padding: 32px 36px; 
        box-shadow: var(--shadow-sm); 
        border: 1px solid var(--gray-border); 
        margin-bottom: 24px; 
        max-width: 580px;
        margin-left: auto;
        margin-right: auto;
    }
    
    .form-title { 
        font-size: 22px; 
        font-weight: 700; 
        color: var(--dark); 
        margin-bottom: 28px; 
        display: flex; 
        align-items: center; 
        gap: 14px; 
        padding-bottom: 16px;
        border-bottom: 2px solid var(--gray-border);
    }
    
    .form-title i { 
        color: var(--primary); 
        font-size: 24px;
        background: var(--primary-light);
        padding: 10px;
        border-radius: 12px;
    }
    
    .form-title span {
        background: var(--primary);
        color: #fff;
        font-size: 12px;
        font-weight: 600;
        padding: 2px 12px;
        border-radius: 20px;
        margin-left: auto;
    }
    
    /* ============================================================
       CAMPOS COM ÍCONE (Input Group)
       ============================================================ */
    .input-group-custom {
        position: relative;
        display: flex;
        align-items: stretch;
        width: 100%;
    }
    
    .input-group-custom .form-control {
        flex: 1 1 auto;
        width: 1%;
        padding-right: 46px;
    }
    
    .input-group-custom .input-icon {
        position: absolute;
        left: 14px;
        top: 50%;
        transform: translateY(-50%);
        color: var(--gray);
        font-size: 16px;
        z-index: 4;
        pointer-events: none;
    }
    
    .input-group-custom .form-control {
        padding-left: 42px;
    }
    
    .input-group-custom .btn-toggle-password {
        position: absolute;
        right: 4px;
        top: 50%;
        transform: translateY(-50%);
        background: none;
        border: none;
        color: var(--gray);
        font-size: 16px;
        padding: 8px 12px;
        cursor: pointer;
        z-index: 4;
        transition: var(--transition);
        border-radius: 8px;
    }
    
    .input-group-custom .btn-toggle-password:hover {
        color: var(--primary);
        background: var(--gray-light);
    }
    
    .input-group-custom .btn-toggle-password:active {
        transform: translateY(-50%) scale(0.95);
    }
    
    /* ============================================================
       FORÇA DA SENHA
       ============================================================ */
    .password-strength-container {
        margin-top: 8px;
    }
    
    .password-strength {
        height: 6px;
        border-radius: 6px;
        background: var(--gray-border);
        overflow: hidden;
        margin-top: 4px;
    }
    
    .password-strength-bar {
        height: 100%;
        width: 0%;
        border-radius: 6px;
        transition: width 0.4s ease, background 0.4s ease;
    }
    
    .password-strength-text {
        font-size: 12px;
        color: var(--gray);
        margin-top: 4px;
        display: flex;
        align-items: center;
        gap: 6px;
        font-weight: 500;
    }
    
    .password-requirements {
        display: flex;
        flex-wrap: wrap;
        gap: 12px 20px;
        margin-top: 6px;
        padding: 8px 12px;
        background: var(--gray-light);
        border-radius: 8px;
    }
    
    .password-requirements .req-item {
        font-size: 12px;
        color: var(--gray);
        display: flex;
        align-items: center;
        gap: 4px;
        transition: var(--transition);
    }
    
    .password-requirements .req-item.met {
        color: var(--success);
    }
    
    .password-requirements .req-item i {
        font-size: 12px;
    }
    
    /* ============================================================
       HELPER TEXT
       ============================================================ */
    .helper-text { 
        font-size: 12px; 
        color: var(--gray); 
        margin-top: 6px; 
        display: flex;
        align-items: center;
        gap: 6px;
    }
    
    .helper-text i { 
        color: var(--info); 
        font-size: 13px;
    }
    
    .helper-text.success { color: var(--success); }
    .helper-text.success i { color: var(--success); }
    .helper-text.error { color: var(--danger); }
    .helper-text.error i { color: var(--danger); }
    
    /* ============================================================
       ALERTAS
       ============================================================ */
    .alert-custom {
        border-radius: 10px;
        padding: 14px 18px;
        font-size: 14px;
        display: flex;
        align-items: flex-start;
        gap: 12px;
        margin-bottom: 20px;
        border: 1px solid transparent;
    }
    
    .alert-custom i { 
        font-size: 18px; 
        margin-top: 1px;
        flex-shrink: 0;
    }
    
    .alert-custom .alert-content {
        flex: 1;
    }
    
    .alert-custom .alert-title {
        font-weight: 700;
        margin-bottom: 2px;
    }
    
    .alert-success-custom {
        background: #ecfdf5;
        color: #065f46;
        border-color: #a7f3d0;
    }
    
    .alert-danger-custom {
        background: #fef2f2;
        color: #991b1b;
        border-color: #fca5a5;
    }
    
    .alert-custom .btn-close-custom {
        background: none;
        border: none;
        font-size: 20px;
        cursor: pointer;
        color: inherit;
        opacity: 0.6;
        padding: 0 4px;
        line-height: 1;
        transition: var(--transition);
        flex-shrink: 0;
        margin-top: -2px;
    }
    
    .alert-custom .btn-close-custom:hover {
        opacity: 1;
    }
    
    /* ============================================================
       BOTÕES
       ============================================================ */
    .form-actions { 
        margin-top: 28px; 
        padding-top: 24px; 
        border-top: 2px solid var(--gray-border); 
        display: flex; 
        gap: 14px; 
        flex-wrap: wrap; 
    }
    
    .btn-primary-custom {
        background: var(--primary);
        color: #fff;
        border: none;
        padding: 12px 32px;
        border-radius: 10px;
        font-weight: 600;
        font-size: 15px;
        transition: var(--transition);
        display: inline-flex;
        align-items: center;
        gap: 10px;
        cursor: pointer;
        text-decoration: none;
        flex: 1;
        justify-content: center;
        min-width: 160px;
    }
    
    .btn-primary-custom:hover {
        background: var(--primary-dark);
        color: #fff;
        transform: translateY(-2px);
        box-shadow: var(--shadow-md);
    }
    
    .btn-primary-custom:active {
        transform: translateY(0);
    }
    
    .btn-primary-custom i {
        font-size: 16px;
    }
    
    .btn-outline-custom {
        background: transparent;
        color: var(--gray);
        border: 1.5px solid var(--gray-border);
        padding: 12px 32px;
        border-radius: 10px;
        font-weight: 600;
        font-size: 15px;
        transition: var(--transition);
        display: inline-flex;
        align-items: center;
        gap: 10px;
        cursor: pointer;
        text-decoration: none;
        flex: 1;
        justify-content: center;
        min-width: 140px;
    }
    
    .btn-outline-custom:hover {
        background: var(--gray-light);
        color: var(--dark);
        border-color: var(--gray);
        transform: translateY(-2px);
    }
    
    /* ============================================================
       ANIMAÇÃO
       ============================================================ */
    .animate-in {
        animation: fadeInUp 0.4s ease-out;
    }
    
    @keyframes fadeInUp {
        from { 
            opacity: 0; 
            transform: translateY(30px); 
        }
        to { 
            opacity: 1; 
            transform: translateY(0); 
        }
    }
    
    /* ============================================================
       RESPONSIVIDADE
       ============================================================ */
    @media (max-width: 768px) {
        .form-container {
            padding: 20px;
            margin: 0 12px;
        }
        
        .form-title {
            font-size: 18px;
            flex-wrap: wrap;
        }
        
        .form-title span {
            margin-left: 0;
            width: 100%;
            text-align: center;
        }
        
        .form-title i {
            font-size: 18px;
            padding: 8px;
        }
        
        .form-actions {
            flex-direction: column;
        }
        
        .btn-primary-custom,
        .btn-outline-custom {
            flex: none;
            width: 100%;
            padding: 12px 20px;
        }
        
        .password-requirements {
            flex-direction: column;
            gap: 4px;
        }
        
        .form-control {
            height: 44px;
            font-size: 15px; /* Evita zoom no iOS */
            padding: 8px 12px;
        }
        
        .input-group-custom .form-control {
            padding-left: 38px;
            padding-right: 42px;
        }
        
        .input-group-custom .input-icon {
            left: 12px;
            font-size: 14px;
        }
    }
    
    @media (max-width: 480px) {
        .form-container {
            padding: 16px;
            margin: 0 8px;
        }
        
        .form-title {
            font-size: 16px;
        }
        
        .form-title i {
            font-size: 16px;
            padding: 6px;
        }
        
        .alert-custom {
            font-size: 13px;
            padding: 12px 14px;
        }
    }
</style>

<!-- ============================================================
    CONTAINER PRINCIPAL
    ============================================================ -->
<div class="form-container animate-in">
    <div class="form-title">
        <i class="fas fa-key"></i>
        Alterar Senha
        <span>Segurança</span>
    </div>

    <!-- ============================================================
        MENSAGENS DE FEEDBACK
        ============================================================ -->
    <c:if test="${not empty param.success}">
        <div class="alert-custom alert-success-custom" role="alert">
            <i class="fas fa-check-circle"></i>
            <div class="alert-content">
                <div class="alert-title">Sucesso!</div>
                <div>Sua senha foi alterada com sucesso.</div>
            </div>
            <button type="button" class="btn-close-custom" data-dismiss="alert" aria-label="Fechar">&times;</button>
        </div>
    </c:if>
    
    <c:if test="${not empty param.error}">
        <div class="alert-custom alert-danger-custom" role="alert">
            <i class="fas fa-exclamation-triangle"></i>
            <div class="alert-content">
                <div class="alert-title">Atenção!</div>
                <div>
                    <c:choose>
                        <c:when test="${param.error == 'invalid'}">
                            Senha atual incorreta. Por favor, tente novamente.
                        </c:when>
                        <c:when test="${param.error == 'confirm'}">
                            A confirmação da nova senha não coincide. Por favor, verifique.
                        </c:when>
                        <c:when test="${param.error == 'empty'}">
                            Todos os campos são obrigatórios. Por favor, preencha todos.
                        </c:when>
                        <c:when test="${param.error == 'weak'}">
                            A nova senha não atende aos requisitos mínimos de segurança.
                        </c:when>
                        <c:otherwise>
                            Erro ao alterar senha. Por favor, tente novamente mais tarde.
                        </c:otherwise>
                    </c:choose>
                </div>
            </div>
            <button type="button" class="btn-close-custom" data-dismiss="alert" aria-label="Fechar">&times;</button>
        </div>
    </c:if>

    <!-- ============================================================
        FORMULÁRIO
        ============================================================ -->
    <form id="alterarSenhaForm" action="${pageContext.request.contextPath}/funcionario/alterar-senha" method="post" novalidate>
        
        <!-- ============================================================
            SENHA ATUAL
            ============================================================ -->
        <div class="form-group">
            <label for="senhaAtual">
                <i class="fas fa-lock" style="color: var(--primary);"></i>
                Senha Atual
                <span class="required">*</span>
            </label>
            <div class="input-group-custom">
                <span class="input-icon"><i class="fas fa-key"></i></span>
                <input type="password" class="form-control" id="senhaAtual" name="senhaAtual"
                       placeholder="Digite sua senha atual" required
                       autocomplete="current-password">
                <button type="button" class="btn-toggle-password" 
                        onclick="togglePassword('senhaAtual', this)" 
                        aria-label="Mostrar senha">
                    <i class="fas fa-eye"></i>
                </button>
            </div>
            <div class="helper-text">
                <i class="fas fa-info-circle"></i> 
                Digite sua senha atual para confirmar sua identidade
            </div>
        </div>

        <!-- ============================================================
            NOVA SENHA
            ============================================================ -->
        <div class="form-group" style="margin-top: 20px;">
            <label for="novaSenha">
                <i class="fas fa-shield-alt" style="color: var(--primary);"></i>
                Nova Senha
                <span class="required">*</span>
            </label>
            <div class="input-group-custom">
                <span class="input-icon"><i class="fas fa-key"></i></span>
                <input type="password" class="form-control" id="novaSenha" name="novaSenha"
                       placeholder="Digite a nova senha" required
                       minlength="8"
                       autocomplete="new-password"
                       oninput="validarForcaSenha()">
                <button type="button" class="btn-toggle-password" 
                        onclick="togglePassword('novaSenha', this)" 
                        aria-label="Mostrar senha">
                    <i class="fas fa-eye"></i>
                </button>
            </div>
            
            <!-- Indicador de força da senha -->
            <div class="password-strength-container">
                <div class="password-strength">
                    <div class="password-strength-bar" id="senhaStrengthBar"></div>
                </div>
                <div class="password-strength-text" id="senhaStrengthText">
                    <i class="fas fa-circle" style="font-size: 6px; color: var(--gray);"></i>
                    Digite uma senha forte
                </div>
            </div>
            
            <!-- Requisitos da senha -->
            <div class="password-requirements" id="passwordRequirements">
                <span class="req-item" id="reqLength">
                    <i class="fas fa-times-circle" style="color: var(--danger);"></i>
                    8+ caracteres
                </span>
                <span class="req-item" id="reqLowercase">
                    <i class="fas fa-times-circle" style="color: var(--danger);"></i>
                    Letra minúscula
                </span>
                <span class="req-item" id="reqUppercase">
                    <i class="fas fa-times-circle" style="color: var(--danger);"></i>
                    Letra maiúscula
                </span>
                <span class="req-item" id="reqNumber">
                    <i class="fas fa-times-circle" style="color: var(--danger);"></i>
                    Número
                </span>
            </div>
        </div>

        <!-- ============================================================
            CONFIRMAR NOVA SENHA
            ============================================================ -->
        <div class="form-group" style="margin-top: 20px;">
            <label for="confirmarSenha">
                <i class="fas fa-check-circle" style="color: var(--primary);"></i>
                Confirmar Nova Senha
                <span class="required">*</span>
            </label>
            <div class="input-group-custom">
                <span class="input-icon"><i class="fas fa-check"></i></span>
                <input type="password" class="form-control" id="confirmarSenha" name="confirmarSenha"
                       placeholder="Confirme a nova senha" required
                       autocomplete="new-password">
                <button type="button" class="btn-toggle-password" 
                        onclick="togglePassword('confirmarSenha', this)" 
                        aria-label="Mostrar senha">
                    <i class="fas fa-eye"></i>
                </button>
            </div>
            <div class="helper-text" id="confirmarHelper">
                <i class="fas fa-info-circle"></i> 
                Digite novamente a nova senha para confirmar
            </div>
        </div>

        <!-- ============================================================
            BOTÕES DE AÇÃO
            ============================================================ -->
        <div class="form-actions">
            <button type="submit" class="btn-primary-custom">
                <i class="fas fa-save"></i> 
                Alterar Senha
            </button>
            <a href="${pageContext.request.contextPath}/dashboard" class="btn-outline-custom">
                <i class="fas fa-times"></i> 
                Cancelar
            </a>
        </div>
    </form>
</div>

<!-- ============================================================
    SCRIPTS
    ============================================================ -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('alterarSenhaForm');
    const senhaAtual = document.getElementById('senhaAtual');
    const novaSenha = document.getElementById('novaSenha');
    const confirmarSenha = document.getElementById('confirmarSenha');
    const confirmarHelper = document.getElementById('confirmarHelper');

    // ============================================================
    // TOGGLE MOSTRAR/ESCONDER SENHA
    // ============================================================
    window.togglePassword = function(inputId, button) {
        const input = document.getElementById(inputId);
        const icon = button.querySelector('i');
        
        if (input.type === 'password') {
            input.type = 'text';
            icon.className = 'fas fa-eye-slash';
            button.setAttribute('aria-label', 'Esconder senha');
        } else {
            input.type = 'password';
            icon.className = 'fas fa-eye';
            button.setAttribute('aria-label', 'Mostrar senha');
        }
    };

    // ============================================================
    // VALIDAÇÃO DA FORÇA DA SENHA
    // ============================================================
    window.validarForcaSenha = function() {
        const senha = novaSenha.value;
        const bar = document.getElementById('senhaStrengthBar');
        const text = document.getElementById('senhaStrengthText');
        
        // Atualizar requisitos
        const reqs = {
            length: document.getElementById('reqLength'),
            lowercase: document.getElementById('reqLowercase'),
            uppercase: document.getElementById('reqUppercase'),
            number: document.getElementById('reqNumber')
        };
        
        const checks = {
            length: senha.length >= 8,
            lowercase: /[a-z]/.test(senha),
            uppercase: /[A-Z]/.test(senha),
            number: /[0-9]/.test(senha)
        };
        
        Object.keys(reqs).forEach(key => {
            const el = reqs[key];
            const icon = el.querySelector('i');
            if (checks[key]) {
                el.classList.add('met');
                icon.className = 'fas fa-check-circle';
                icon.style.color = 'var(--success)';
            } else {
                el.classList.remove('met');
                icon.className = 'fas fa-times-circle';
                icon.style.color = 'var(--danger)';
            }
        });
        
        if (senha.length === 0) {
            bar.style.width = '0%';
            bar.style.background = 'var(--gray-border)';
            text.innerHTML = '<i class="fas fa-circle" style="font-size: 6px; color: var(--gray);"></i> Digite uma senha forte';
            return;
        }

        // Calcular força
        let forca = 0;
        Object.values(checks).forEach(v => { if (v) forca++; });
        
        const percentual = (forca / 4) * 100;
        bar.style.width = percentual + '%';

        let cor, descricao, icone;
        if (forca <= 1) {
            cor = '#ef4444';
            descricao = 'Muito fraca';
            icone = 'fa-times-circle';
        } else if (forca === 2) {
            cor = '#f59e0b';
            descricao = 'Fraca';
            icone = 'fa-exclamation-circle';
        } else if (forca === 3) {
            cor = '#3b82f6';
            descricao = 'Boa';
            icone = 'fa-check-circle';
        } else {
            cor = '#22c55e';
            descricao = 'Forte';
            icone = 'fa-check-circle';
        }

        bar.style.background = cor;
        text.innerHTML = `<i class="fas ${icone}" style="color: ${cor};"></i> ${descricao} (${forca}/4 critérios)`;
    };

    // ============================================================
    // VALIDAÇÃO DA CONFIRMAÇÃO EM TEMPO REAL
    // ============================================================
    confirmarSenha.addEventListener('input', function() {
        const senha = novaSenha.value;
        const confirm = this.value;
        
        if (confirm.length === 0) {
            this.classList.remove('is-invalid', 'is-valid');
            confirmarHelper.className = 'helper-text';
            confirmarHelper.innerHTML = '<i class="fas fa-info-circle"></i> Digite novamente a nova senha para confirmar';
            return;
        }

        if (confirm === senha) {
            this.classList.remove('is-invalid');
            this.classList.add('is-valid');
            confirmarHelper.className = 'helper-text success';
            confirmarHelper.innerHTML = '<i class="fas fa-check-circle"></i> As senhas coincidem';
        } else {
            this.classList.remove('is-valid');
            this.classList.add('is-invalid');
            confirmarHelper.className = 'helper-text error';
            confirmarHelper.innerHTML = '<i class="fas fa-times-circle"></i> As senhas não coincidem';
        }
    });

    // ============================================================
    // VALIDAÇÃO NO ENVIO
    // ============================================================
    form.addEventListener('submit', function(event) {
        let isValid = true;
        let errorMessages = [];

        // 1. Senha atual
        if (!senhaAtual.value.trim()) {
            senhaAtual.classList.add('is-invalid');
            errorMessages.push('Digite sua senha atual');
            isValid = false;
        } else {
            senhaAtual.classList.remove('is-invalid');
        }

        // 2. Nova senha (força)
        const senha = novaSenha.value;
        const checks = {
            length: senha.length >= 8,
            lowercase: /[a-z]/.test(senha),
            uppercase: /[A-Z]/.test(senha),
            number: /[0-9]/.test(senha)
        };
        const forca = Object.values(checks).filter(v => v).length;
        
        if (senha.length < 8 || forca < 3) {
            novaSenha.classList.add('is-invalid');
            errorMessages.push('A nova senha deve ter no mínimo 8 caracteres, com letras maiúsculas, minúsculas e números');
            isValid = false;
        } else {
            novaSenha.classList.remove('is-invalid');
        }

        // 3. Confirmação
        if (confirmarSenha.value !== senha) {
            confirmarSenha.classList.add('is-invalid');
            errorMessages.push('As senhas não coincidem');
            isValid = false;
        } else {
            confirmarSenha.classList.remove('is-invalid');
        }

        if (!isValid) {
            event.preventDefault();
            const msg = errorMessages.join('\n');
            
            if (typeof showNotification === 'function') {
                showNotification('error', 'Erro de Validação', msg);
            } else {
                alert(msg);
            }
            return false;
        }

        return true;
    });

    // ============================================================
    // REMOVER ERRO AO DIGITAR
    // ============================================================
    [senhaAtual, novaSenha, confirmarSenha].forEach(input => {
        input.addEventListener('input', function() {
            this.classList.remove('is-invalid');
        });
    });

    // ============================================================
    // FECHAR ALERTAS
    // ============================================================
    document.querySelectorAll('[data-dismiss="alert"]').forEach(btn => {
        btn.addEventListener('click', function() {
            this.closest('.alert-custom').remove();
        });
    });
});

// ============================================================
// FUNÇÃO DE NOTIFICAÇÃO (fallback)
// ============================================================
if (typeof showNotification !== 'function') {
    window.showNotification = function(type, title, message) {
        const isError = type === 'error';
        const icon = isError ? 'fa-exclamation-triangle' : 'fa-check-circle';
        const alertClass = isError ? 'alert-danger-custom' : 'alert-success-custom';
        
        const html = `
            <div class="alert-custom ${alertClass}" role="alert" style="position: fixed; top: 20px; right: 20px; z-index: 9999; max-width: 420px; box-shadow: 0 8px 24px rgba(0,0,0,0.15);">
                <i class="fas ${icon}"></i>
                <div class="alert-content">
                    <div class="alert-title">${title}</div>
                    <div>${message}</div>
                </div>
                <button type="button" class="btn-close-custom" onclick="this.closest('.alert-custom').remove()" aria-label="Fechar">&times;</button>
            </div>
        `;
        document.body.insertAdjacentHTML('beforeend', html);
        setTimeout(() => {
            const alert = document.querySelector('.alert-custom:last-child');
            if (alert) alert.remove();
        }, 5000);
    };
}
</script>

<jsp:include page="/WEB-INF/views/layout/footer.jsp" />